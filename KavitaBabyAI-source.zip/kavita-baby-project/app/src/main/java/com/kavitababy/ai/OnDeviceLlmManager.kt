// OnDeviceLlmManager.kt
package com.kavitababy.ai

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import com.google.mediapipe.tasks.genai.llminference.LlmInference.LlmInferenceOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit

/**
 * Runs a small language model (Gemma-3 1B, int4 quantized, ~529MB)
 * completely on-device. Used as the offline fallback in [AIRepository]
 * when there's no internet to reach Gemini.
 *
 * This is genuinely a much smaller/weaker model than cloud Gemini —
 * answers will be shorter, sometimes less accurate, and slower to
 * generate (a few tokens/sec on a mid-range phone). It's meant to give
 * a real conversational answer offline, not to match cloud quality.
 *
 * The model file is NOT bundled in the APK (that would make the app
 * 500MB+ to install and likely breaks CI/CD size limits). Instead it's
 * downloaded once — the first time the user has internet — and cached
 * in app-private storage, so every session after that works fully
 * offline with no further downloads.
 */
class OnDeviceLlmManager(private val context: Context) {

    companion object {
        // litert-community's pre-converted, MediaPipe-ready build of
        // Gemma-3 1B-IT, int4 quantized. Gated on Hugging Face — the
        // request must carry an HF access token that has accepted the
        // Gemma license, or the download 403s.
        private const val MODEL_URL =
            "https://huggingface.co/litert-community/Gemma3-1B-IT/resolve/main/gemma3-1b-it-int4.task"
        private const val MODEL_FILENAME = "gemma3-1b-it-int4.task"
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(5, TimeUnit.MINUTES) // model file is large; a short read timeout would abort mid-download
        .build()

    private var llmInference: LlmInference? = null

    private val modelFile: File
        get() = File(context.getExternalFilesDir(null) ?: context.filesDir, MODEL_FILENAME)

    fun isModelDownloaded(): Boolean = modelFile.exists() && modelFile.length() > 0

    /**
     * Downloads the model file if not already present. [onProgress] gets
     * called with 0–100 periodically so the UI can show a progress bar —
     * this is a ~529MB download and must not look frozen.
     * [hfToken] is a Hugging Face access token with the Gemma license
     * accepted on the account — required because this model is gated.
     */
    suspend fun downloadModelIfNeeded(
        hfToken: String,
        onProgress: (Int) -> Unit
    ): Boolean = withContext(Dispatchers.IO) {
        if (isModelDownloaded()) {
            onProgress(100)
            return@withContext true
        }

        val tempFile = File(modelFile.parentFile, "$MODEL_FILENAME.tmp")

        try {
            val request = Request.Builder()
                .url(MODEL_URL)
                .addHeader("Authorization", "Bearer $hfToken")
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    return@withContext false
                }

                val body = response.body ?: return@withContext false
                val totalBytes = body.contentLength()
                var downloadedBytes = 0L
                var lastReportedPercent = -1

                body.byteStream().use { input ->
                    FileOutputStream(tempFile).use { output ->
                        val buffer = ByteArray(8 * 1024)
                        var bytesRead: Int
                        while (input.read(buffer).also { bytesRead = it } != -1) {
                            output.write(buffer, 0, bytesRead)
                            downloadedBytes += bytesRead
                            if (totalBytes > 0) {
                                val percent = ((downloadedBytes * 100) / totalBytes).toInt()
                                if (percent != lastReportedPercent) {
                                    lastReportedPercent = percent
                                    onProgress(percent)
                                }
                            }
                        }
                    }
                }
            }

            // Only rename into the real filename once the download is
            // fully complete — avoids ever treating a partial file as
            // a valid, ready-to-load model.
            tempFile.renameTo(modelFile)
            onProgress(100)
            true
        } catch (e: Exception) {
            tempFile.delete()
            false
        }
    }

    /** Loads the model into memory. Must succeed before [generate] can be called. */
    suspend fun loadModel(): Boolean = withContext(Dispatchers.IO) {
        if (llmInference != null) return@withContext true
        if (!isModelDownloaded()) return@withContext false

        try {
            val options = LlmInferenceOptions.builder()
                .setModelPath(modelFile.absolutePath)
                .setMaxTokens(1024)
                .build()
            llmInference = LlmInference.createFromOptions(context, options)
            true
        } catch (e: Exception) {
            llmInference = null
            false
        }
    }

    /**
     * Generates a reply to [prompt] fully offline. Returns null if the
     * model isn't downloaded/loaded yet or generation failed — caller
     * should fall back to the PDF-notes-only offline path in that case.
     */
    suspend fun generate(prompt: String): String? = withContext(Dispatchers.IO) {
        val inference = llmInference ?: run {
            if (!loadModel()) return@withContext null
            llmInference
        } ?: return@withContext null

        try {
            inference.generateResponse(prompt)
        } catch (e: Exception) {
            null
        }
    }

    fun unload() {
        llmInference?.close()
        llmInference = null
    }
}
