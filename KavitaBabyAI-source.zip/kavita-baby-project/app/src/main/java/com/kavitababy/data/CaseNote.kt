// data/CaseNote.kt
package com.kavitababy.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * A single Doctor Mode case entry, saved locally on-device only.
 *
 * Deliberately has NO name/patient-identifier field. [caseLabel] is meant
 * for the doctor's own reference (e.g. "OPD-14", initials, a bed number —
 * whatever they use that isn't a real name), not for us to enforce. Nothing
 * here is ever sent anywhere except to the Gemini API as part of a single
 * request when the doctor asks a question about this case.
 */
@Entity(tableName = "case_notes")
data class CaseNote(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val caseLabel: String,
    val ageGender: String,
    val symptoms: String,
    val history: String,
    val aiSuggestion: String,
    val createdAt: Long = System.currentTimeMillis()
)
