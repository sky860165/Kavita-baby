// NetworkUtil.kt
package com.kavitababy.util

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities

object NetworkUtil {
    /**
     * True if the device currently has a network that's validated as
     * actually reaching the internet (not just "connected to WiFi" —
     * a WiFi with no internet, e.g. a router with no uplink, reports
     * TRANSPORT_WIFI but not NET_CAPABILITY_VALIDATED). This is what
     * decides whether we try the cloud (Gemini) or go straight to the
     * on-device model, so it needs to be an honest check.
     */
    fun isOnline(context: Context): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return false
        val network = cm.activeNetwork ?: return false
        val capabilities = cm.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }
}
