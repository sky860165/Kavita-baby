// data/CaseNoteDao.kt
package com.kavitababy.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query

@Dao
interface CaseNoteDao {

    @Insert
    suspend fun insert(note: CaseNote): Long

    @Query("SELECT * FROM case_notes ORDER BY createdAt DESC")
    suspend fun getAll(): List<CaseNote>

    @Delete
    suspend fun delete(note: CaseNote)
}
