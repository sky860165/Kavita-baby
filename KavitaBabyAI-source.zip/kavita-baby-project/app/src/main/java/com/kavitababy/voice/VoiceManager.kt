// VoiceManager.kt
package com.kavitababy.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.util.Locale

class VoiceManager(private val context: Context) {

    private var textToSpeech: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null

    private var ttsReady = false

    init {
        textToSpeech = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                textToSpeech?.language = Locale("hi", "IN")
                textToSpeech?.setSpeechRate(0.95f)
                ttsReady = true
            }
        }
    }

    /** Speaks [text]. Calls [onDone] when speech finishes or fails, so callers can reset UI state. */
    fun speak(text: String, onDone: (() -> Unit)? = null) {
        if (!ttsReady) {
            onDone?.invoke()
            return
        }

        if (onDone != null) {
            textToSpeech?.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {
                    onDone()
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    onDone()
                }
            })
        }

        textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "kavita_speak")
    }

    fun stopSpeaking() {
        textToSpeech?.stop()
    }

    /**
     * Starts listening for speech. [onResult] is called with the recognized text,
     * or an empty string if nothing was understood — check for blank rather than
     * assuming a result is always present.
     * [onError] is called if recognition fails outright (no permission, no network, etc),
     * with the SpeechRecognizer error code so callers can decide whether to retry
     * (e.g. ERROR_NO_MATCH / ERROR_SPEECH_TIMEOUT are fine to just listen again).
     */
    fun startListening(onResult: (String) -> Unit, onError: ((Int) -> Unit)? = null) {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onError?.invoke(SpeechRecognizer.ERROR_CLIENT)
            return
        }

        // SpeechRecognizer must be created and driven from the main thread —
        // when this is called from a background Service, that isn't always
        // guaranteed, so we force it onto the main looper explicitly. Skipping
        // this is a common cause of recognition silently failing every time
        // when triggered from a floating-widget service instead of an Activity.
        android.os.Handler(context.mainLooper).post {
            startListeningOnMainThread(onResult, onError)
        }
    }

    private fun startListeningOnMainThread(onResult: (String) -> Unit, onError: ((Int) -> Unit)?) {
        // Avoid leaking a previous recognizer instance if startListening
        // is called again before the last one was cleaned up.
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context)

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            // Standard, reliable timing — matches what Android's own apps use.
            // Too-short values here (sub-1s) made the recognizer give up and
            // error out almost immediately, which is what was causing the
            // rapid on/off/on/off flicker.
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2000)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2000)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 3000)
        }

        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}

            override fun onError(error: Int) {
                // Covers cases like ERROR_NO_MATCH, ERROR_SPEECH_TIMEOUT, ERROR_NETWORK, etc.
                // Without this, the caller's UI would stay stuck in a "listening" state forever.
                onError?.invoke(error)
            }

            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                onResult(matches?.firstOrNull() ?: "")
            }

            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        speechRecognizer?.startListening(intent)
    }

    fun stopListening() {
        android.os.Handler(context.mainLooper).post {
            speechRecognizer?.stopListening()
        }
    }

    private var resultReceiver: android.content.BroadcastReceiver? = null

    /**
     * Same contract as [startListening], but routes the actual recognition
     * through [VoiceRecognitionActivity] instead of driving SpeechRecognizer
     * directly from this (Service) context. Use this from FloatingWidgetService:
     * several OEM recognizers (MIUI/Xiaomi-Redmi in particular) silently reject
     * recognition requests that don't originate from a foreground Activity,
     * surfacing as ERROR_CLIENT (error code 7), even though the same device's
     * Google app — which always listens from an Activity — works fine.
     *
     * When [continuous] is true, the Activity itself loops internally on
     * blank results / transient errors instead of finishing and needing to
     * be relaunched — relaunching a fresh Activity every retry cycle was
     * stealing window focus from whatever else was on screen (including the
     * keyboard) every few seconds, which is far more disruptive than one
     * Activity quietly retrying in the background. In this mode, onResult
     * is only called once with genuine (non-blank) recognized text, and
     * onError only for a permanent failure — not for retryable ones.
     */
    fun startListeningViaActivity(onResult: (String) -> Unit, onError: ((Int) -> Unit)? = null, continuous: Boolean = false) {
        unregisterResultReceiver()

        val receiver = object : android.content.BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                unregisterResultReceiver()
                if (intent == null) return
                if (intent.hasExtra(VoiceRecognitionActivity.EXTRA_ERROR)) {
                    val code = intent.getIntExtra(VoiceRecognitionActivity.EXTRA_ERROR, SpeechRecognizer.ERROR_CLIENT)
                    onError?.invoke(code)
                } else {
                    val text = intent.getStringExtra(VoiceRecognitionActivity.EXTRA_TEXT) ?: ""
                    onResult(text)
                }
            }
        }
        resultReceiver = receiver

        val filter = android.content.IntentFilter(VoiceRecognitionActivity.ACTION_RESULT)
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            context.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            context.registerReceiver(receiver, filter)
        }

        val activityIntent = Intent(context, VoiceRecognitionActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            putExtra(VoiceRecognitionActivity.CONTINUOUS_MODE_EXTRA, continuous)
        }
        context.startActivity(activityIntent)
    }

    /** Tells a running continuous-mode [VoiceRecognitionActivity] to stop and finish. */
    fun stopListeningViaActivity() {
        unregisterResultReceiver()
        val stopIntent = Intent(VoiceRecognitionActivity.ACTION_STOP).apply {
            setPackage(context.packageName)
        }
        context.sendBroadcast(stopIntent)
    }

    private fun unregisterResultReceiver() {
        resultReceiver?.let {
            try {
                context.unregisterReceiver(it)
            } catch (_: IllegalArgumentException) {
                // Already unregistered — fine to ignore.
            }
        }
        resultReceiver = null
    }

    fun destroy() {
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        unregisterResultReceiver()
        android.os.Handler(context.mainLooper).post {
            speechRecognizer?.destroy()
            speechRecognizer = null
        }
    }
}
