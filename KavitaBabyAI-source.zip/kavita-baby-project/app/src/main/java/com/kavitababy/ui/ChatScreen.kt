// ChatScreen.kt
package com.kavitababy.ui

import android.content.Context
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kavitababy.R
import com.kavitababy.ai.AIRepository
import com.kavitababy.data.CaseNote
import com.kavitababy.data.KavitaDatabase
import com.kavitababy.data.RagSearchEngine
import com.kavitababy.voice.VoiceManager
import kotlinx.coroutines.launch

private enum class AppMode { STUDY, DOCTOR }

@Composable
fun ChatScreen(voiceManager: VoiceManager) {
    val context = LocalContext.current
    var mode by remember { mutableStateOf(AppMode.STUDY) }
    var messages by remember { mutableStateOf(listOf<Message>()) }
    var inputText by remember { mutableStateOf("") }
    var isListening by remember { mutableStateOf(false) }
    var isThinking by remember { mutableStateOf(false) }
    var voiceErrorMessage by remember { mutableStateOf<String?>(null) }
    val aiRepository = remember { AIRepository() }
    val ragEngine = remember { RagSearchEngine(context.applicationContext) }
    val scope = rememberCoroutineScope()

    fun send(text: String) {
        if (text.isBlank()) return
        messages = messages + Message(text, isUser = true)
        isThinking = true

        scope.launch {
            val relevantChunks = try {
                ragEngine.findRelevantChunks(text)
            } catch (e: Exception) {
                emptyList()
            }

            val response = try {
                if (mode == AppMode.DOCTOR) {
                    aiRepository.getDoctorResponse(text, relevantChunks)
                } else {
                    aiRepository.getResponse(text, relevantChunks)
                }
            } catch (e: Exception) {
                "Sorry jaani, thoda dikkat aa gayi. Dobara try karo."
            }

            messages = messages + Message(response, isUser = false)
            isThinking = false

            if (mode == AppMode.DOCTOR) {
                saveCaseNote(context, scope, text, response)
            }

            // Doctor Mode answers are long/clinical — reading them aloud
            // isn't useful the way it is for the casual Study Mode chat.
            if (mode == AppMode.STUDY) {
                voiceManager.speak(response)
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF1A1A2E))
    ) {
        // Header with Kavita's face
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF16213E))
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Image(
                    painter = painterResource(id = R.drawable.kavita_face),
                    contentDescription = "Kavita Baby",
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                )
                Text(
                    text = if (mode == AppMode.DOCTOR) "Kavita Baby — Doctor Mode 🩺" else "Kavita Baby 💕",
                    color = Color.White,
                    fontSize = 20.sp
                )
                Text(
                    text = when {
                        isListening -> "Sunn rahi hoon... 👂"
                        voiceErrorMessage != null -> voiceErrorMessage!!
                        isThinking -> "Soch rahi hoon... 🤔"
                        mode == AppMode.DOCTOR -> "Case describe karo (naam mat likho)... 📋"
                        else -> "Bolo jaani... 💬"
                    },
                    color = if (voiceErrorMessage != null) Color.Red else Color(0xFFFF6B9D),
                    fontSize = 14.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Mode toggle
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color(0xFF0F1729))
                        .padding(4.dp)
                ) {
                    ModeChip(
                        label = "Study",
                        selected = mode == AppMode.STUDY,
                        onClick = { mode = AppMode.STUDY }
                    )
                    ModeChip(
                        label = "Doctor",
                        selected = mode == AppMode.DOCTOR,
                        onClick = { mode = AppMode.DOCTOR }
                    )
                }
            }
        }

        if (mode == AppMode.DOCTOR) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF2A1A1A))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "⚠️ Reference only — patient ka naam/identity kabhi mat likho. " +
                        "Final decision aapka clinical judgement hai.",
                    color = Color(0xFFFFB4A2),
                    fontSize = 11.sp
                )
            }
        }

        // Chat Messages
        LazyColumn(
            modifier = Modifier.weight(1f),
            reverseLayout = true
        ) {
            items(messages.reversed()) { message ->
                MessageBubble(message)
            }
        }

        // Input Area
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Voice Button
            IconButton(
                onClick = {
                    isListening = true
                    voiceErrorMessage = null
                    // Driven directly from this Activity's own context —
                    // no separate window is opened, so the rest of the
                    // screen (buttons, text field) stays touchable while
                    // listening. VoiceManager internally retries once via
                    // Google's recognizer explicitly if the device default
                    // rejects the request (common on some MIUI builds).
                    voiceManager.startListening(
                        onResult = { text ->
                            isListening = false
                            if (text.isNotBlank()) {
                                send(text)
                            } else {
                                // Recognizer returned success but with no
                                // usable text — surface this instead of
                                // silently doing nothing, since otherwise
                                // it looks identical to the mic not working.
                                voiceErrorMessage = "Kuch samajh nahi aaya, dobara bolo 🎙️"
                                scope.launch {
                                    kotlinx.coroutines.delay(2500)
                                    if (voiceErrorMessage != null) voiceErrorMessage = null
                                }
                            }
                        },
                        onError = { errorCode ->
                            isListening = false
                            voiceErrorMessage = when (errorCode) {
                                android.speech.SpeechRecognizer.ERROR_NO_MATCH,
                                android.speech.SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                                    "Kuch samajh nahi aaya, dobara bolo 🎙️"
                                android.speech.SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                                    "Mic permission chahiye ⚠️"
                                android.speech.SpeechRecognizer.ERROR_NETWORK,
                                android.speech.SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                                    "Network problem, dobara try karo 📡"
                                else -> "Mic mein error aaya, dobara try karo ⚠️"
                            }
                            scope.launch {
                                kotlinx.coroutines.delay(3000)
                                if (voiceErrorMessage != null) voiceErrorMessage = null
                            }
                        }
                    )
                }
            ) {
                Icon(
                    painter = painterResource(id = R.drawable.ic_mic),
                    contentDescription = "Voice",
                    tint = if (isListening) Color.Red else Color(0xFFFF6B9D)
                )
            }

            // Text Input
            OutlinedTextField(
                value = inputText,
                onValueChange = { inputText = it },
                modifier = Modifier.weight(1f),
                placeholder = {
                    Text(if (mode == AppMode.DOCTOR) "Age/gender, symptoms, history..." else "Kuch bolo... 💬")
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                )
            )

            // Send Button
            IconButton(
                onClick = {
                    val text = inputText
                    inputText = ""
                    send(text)
                }
            ) {
                Icon(
                    painter = painterResource(id = R.drawable.ic_send),
                    contentDescription = "Send",
                    tint = Color(0xFFFF6B9D)
                )
            }
        }
    }
}

@Composable
private fun ModeChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (selected) Color(0xFFFF6B9D) else Color.Transparent)
            .clickable(
                indication = null,
                interactionSource = remember { MutableInteractionSource() },
                onClick = onClick
            )
            .padding(horizontal = 14.dp, vertical = 6.dp)
    ) {
        Text(
            text = label,
            color = if (selected) Color.White else Color(0xFFAAAAAA),
            fontSize = 13.sp
        )
    }
}

/**
 * Persists a Doctor Mode exchange locally (Room, on-device only). No name or
 * patient identifier is collected — [caseDescription] is whatever free text
 * the doctor typed, which by app convention should already exclude names.
 */
private fun saveCaseNote(
    context: Context,
    scope: kotlinx.coroutines.CoroutineScope,
    caseDescription: String,
    aiSuggestion: String
) {
    val dao = KavitaDatabase.getInstance(context.applicationContext).caseNoteDao()
    scope.launch(kotlinx.coroutines.Dispatchers.IO) {
        try {
            dao.insert(
                CaseNote(
                    caseLabel = "Case ${System.currentTimeMillis()}",
                    ageGender = "",
                    symptoms = caseDescription,
                    history = "",
                    aiSuggestion = aiSuggestion
                )
            )
        } catch (e: Exception) {
            // Local save failing shouldn't disrupt the chat — the answer is
            // already shown on screen either way.
        }
    }
}

@Composable
fun MessageBubble(message: Message) {
    val isUser = message.isUser
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 4.dp),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        if (!isUser) {
            Image(
                painter = painterResource(id = R.drawable.kavita_face),
                contentDescription = "Kavita",
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
            )
            Spacer(modifier = Modifier.width(8.dp))
        }

        Box(
            modifier = Modifier
                .background(
                    if (isUser) Color(0xFF4A90E2) else Color(0xFFFF6B9D),
                    RoundedCornerShape(16.dp)
                )
                .padding(12.dp)
        ) {
            Text(
                text = message.text,
                color = Color.White,
                fontSize = 16.sp
            )
        }
    }
}

data class Message(val text: String, val isUser: Boolean)
