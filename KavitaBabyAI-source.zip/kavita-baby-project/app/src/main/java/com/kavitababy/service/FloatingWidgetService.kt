// FloatingWidgetService.kt
package com.kavitababy.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.drawable.Animatable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import androidx.core.app.NotificationCompat
import com.kavitababy.R
import com.kavitababy.ai.AIRepository
import com.kavitababy.data.RagSearchEngine
import com.kavitababy.voice.VoiceManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class FloatingWidgetService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var floatingView: View
    private lateinit var pulseView: View
    private lateinit var avatarImage: ImageView

    private var initialX = 0
    private var initialY = 0
    private var touchX = 0f
    private var touchY = 0f
    private var isDragging = false

    private lateinit var voiceManager: VoiceManager
    private lateinit var ragEngine: RagSearchEngine
    private lateinit var aiRepository: AIRepository

    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())

    private enum class WidgetState { IDLE, LISTENING, THINKING, SPEAKING }
    private var currentState = WidgetState.IDLE

    // The bubble starts in Wake Word Mode automatically as soon as the
    // service is created — mic stays continuously listening in the
    // background. Everything heard is silently discarded and re-listened
    // UNLESS it starts with the wake word ("kavita"), at which point the
    // rest of that same utterance is treated as the actual question and
    // sent to the AI. After Kavita replies, it immediately starts listening
    // again — no tap needed to keep the conversation going, the same way a
    // real back-and-forth conversation works. Tapping the bubble at any
    // point pauses/resumes this (see onBubbleTapped).
    //
    // Honesty note for future maintenance: Android's on-device
    // SpeechRecognizer isn't a true low-power wake-word engine (like a
    // dedicated "Ok Google" hardware chip) — every listening cycle actually
    // runs full speech recognition on whatever audio it captures, checks it
    // locally for the wake word, then immediately restarts listening if the
    // word wasn't present. It works, but draws more battery than a real
    // wake-word chip would, since there's no cheap always-on-audio hardware
    // detection step happening first.
    private var isPaused = false
    private val wakeWords = listOf("kavita", "कविता")

    // Phrases that pause the conversation when spoken by the user, so they
    // don't have to reach for the bubble to go quiet.
    private val conversationExitPhrases = listOf("bye", "band karo", "stop", "band kro", "bye bye")

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForegroundServiceNotification()
        setupFloatingWidget()

        voiceManager = VoiceManager(this)
        ragEngine = RagSearchEngine(applicationContext)
        aiRepository = AIRepository()

        // Start listening immediately — no tap needed. The bubble is "always
        // on" for the wake word from the moment it appears on screen.
        startListening()
    }

    private fun startForegroundServiceNotification() {
        val channelId = "kavita_baby_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Kavita Baby AI",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }

        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Kavita Baby AI")
            .setContentText("Sun rahi hoon — 'Kavita' bolo baat karne ke liye")
            .setSmallIcon(R.drawable.ic_kavita)
            .build()

        startForeground(1, notification)
    }

    private fun setupFloatingWidget() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        val layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 300
        }

        floatingView = LayoutInflater.from(this).inflate(R.layout.floating_widget, null)
        avatarImage = floatingView.findViewById(R.id.avatarImage)
        pulseView = floatingView.findViewById(R.id.pulseEffect)
        avatarImage.setImageResource(R.drawable.kavita_face)
        setWidgetState(WidgetState.IDLE)

        floatingView.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = layoutParams.x
                    initialY = layoutParams.y
                    touchX = event.rawX
                    touchY = event.rawY
                    isDragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (kotlin.math.abs(dx) > 12 || kotlin.math.abs(dy) > 12) {
                        isDragging = true
                    }
                    if (isDragging) {
                        layoutParams.x = initialX + dx
                        layoutParams.y = initialY + dy
                        windowManager.updateViewLayout(floatingView, layoutParams)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!isDragging) onBubbleTapped()
                    true
                }
                else -> false
            }
        }

        windowManager.addView(floatingView, layoutParams)
    }

    // ---- Tap handling ----
    //
    // Tap while active (listening/thinking/speaking) -> pauses everything
    // and goes idle/silent. Tap again while idle -> resumes listening for
    // the wake word. This is now the ONLY thing a tap does — starting the
    // conversation itself needs no tap at all, just saying "Kavita".

    private fun onBubbleTapped() {
        if (isPaused) {
            isPaused = false
            startListening()
        } else {
            pauseConversation()
        }
    }

    private fun pauseConversation() {
        isPaused = true
        voiceManager.stopListeningViaActivity()
        voiceManager.stopListening()
        voiceManager.stopSpeaking()
        aiRepository.clearHistory()
        setWidgetState(WidgetState.IDLE)
    }

    // ---- Speech input ----

    private fun startListening() {
        if (isPaused) return
        setWidgetState(WidgetState.LISTENING)

        voiceManager.startListeningViaActivity(
            onResult = { text ->
                if (isPaused) return@startListeningViaActivity

                // The Activity's continuous mode already filters out blank
                // results internally and keeps retrying on its own, so a
                // blank result here is unexpected — just resume listening
                // rather than going silent.
                if (text.isBlank()) {
                    startListening()
                    return@startListeningViaActivity
                }

                val trimmed = text.trim()
                val matchedWakeWord = wakeWords.firstOrNull {
                    trimmed.startsWith(it, ignoreCase = true)
                }

                when {
                    conversationExitPhrases.any { trimmed.equals(it, ignoreCase = true) } -> {
                        speak("Theek hai jaani, bye! Jab bhi baat karni ho, bas \"Kavita\" bol dena.") {
                            startListening()
                        }
                    }
                    matchedWakeWord != null -> {
                        // Strip the wake word itself off the front, leaving
                        // just the actual question. If nothing's left after
                        // stripping it (person just said "Kavita" alone),
                        // prompt them instead of sending an empty question.
                        val question = trimmed.removePrefix(matchedWakeWord)
                            .trimStart(',', '.', '!', '?', ' ', ':')
                            .trim()

                        if (question.isBlank()) {
                            speak("Ji jaani, bolo kya poochna hai?") {
                                startListening()
                            }
                        } else {
                            handleQuestion(question)
                        }
                    }
                    else -> {
                        // Wake word wasn't heard — this wasn't meant for
                        // Kavita, so silently keep listening in the
                        // background without reacting at all.
                        startListening()
                    }
                }
            },
            onError = { errorCode ->
                // Transient errors are retried inside the Activity itself.
                // This only fires for a genuinely permanent failure (e.g.
                // missing mic permission).
                isPaused = true
                setWidgetState(WidgetState.IDLE)
                speak("Mic access nahi mil raha. Phone Settings mein Kavita Baby ko microphone permission do.") {
                    setWidgetState(WidgetState.IDLE)
                }
            },
            continuous = true
        )
    }

    // ---- Question handling (RAG + Grok/Gemini) ----

    private fun handleQuestion(question: String) {
        setWidgetState(WidgetState.THINKING)
        serviceScope.launch {
            try {
                val relevantChunks = withContext(Dispatchers.IO) {
                    ragEngine.findRelevantChunks(question)
                }
                val answer = aiRepository.getResponse(question, relevantChunks)
                speak(answer) { startListening() }
            } catch (e: Exception) {
                speak("Sorry baby, abhi answer nahi mil paaya. Dobara try karo.") { startListening() }
            }
        }
    }

    // ---- Speech output ----

    /**
     * Speaks [text], then calls [onDone] once speech finishes — defaults to
     * resuming listening automatically, which is what keeps the whole thing
     * feeling like one continuous conversation instead of tap-ask-tap-ask.
     */
    private fun speak(text: String, onDone: () -> Unit = { startListening() }) {
        setWidgetState(WidgetState.SPEAKING)
        voiceManager.speak(text) {
            if (isPaused) {
                setWidgetState(WidgetState.IDLE)
            } else {
                onDone()
            }
        }
    }

    // ---- Visual state ----

    private fun setWidgetState(state: WidgetState) {
        currentState = state
        val shouldPulse = state != WidgetState.IDLE
        pulseView.visibility = if (shouldPulse) View.VISIBLE else View.INVISIBLE

        val drawable = pulseView.background
        if (drawable is Animatable) {
            if (shouldPulse) drawable.start() else drawable.stop()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        isPaused = true
        voiceManager.stopListeningViaActivity()
        serviceScope.coroutineContext[Job]?.cancel()
        voiceManager.destroy()
        if (::floatingView.isInitialized) {
            windowManager.removeView(floatingView)
        }
    }
}
