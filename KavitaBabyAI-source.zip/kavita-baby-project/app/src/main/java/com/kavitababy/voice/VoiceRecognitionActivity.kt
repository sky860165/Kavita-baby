// VoiceRecognitionActivity.kt
package com.kavitababy.voice

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/**
 * Invisible, theme-transparent Activity that exists purely to give the
 * SpeechRecognizer a proper foreground Activity context to run under.
 *
 * Why this exists: SpeechRecognizer created and driven directly from a
 * background Service (as FloatingWidgetService used to do) gets silently
 * denied by several OEM speech-recognition implementations (notably MIUI /
 * Xiaomi-Redmi devices), surfacing as ERROR_CLIENT (error code 7) even
 * though on-device recognition works fine for apps like the Google app,
 * which always drive it from an Activity/foreground window. This Activity
 * closes that gap: FloatingWidgetService launches it, it does the actual
 * listening, reports the result back via a broadcast, then finishes itself
 * (usually within a second or two, invisibly, over the widget).
 */
class VoiceRecognitionActivity : Activity() {

    companion object {
        const val ACTION_RESULT = "com.kavitababy.voice.ACTION_RESULT"
        const val EXTRA_TEXT = "extra_text"
        const val EXTRA_ERROR = "extra_error"
    }

    private var speechRecognizer: SpeechRecognizer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // No setContentView — this activity is fully transparent
        // (see Theme.KavitaBaby.Transparent in themes.xml) and shows nothing.

        // Temporary debug aid: confirms this Activity path is actually
        // being reached (vs. the launch silently failing/being blocked,
        // in which case this toast would never appear).
        android.widget.Toast.makeText(this, "Voice activity started", android.widget.Toast.LENGTH_SHORT).show()

        // Give the window a beat to fully attach before starting the
        // recognizer — starting it in the same frame as onCreate() on a
        // transparent/floating window has been unreliable on some OEM
        // builds. 150ms is imperceptible but avoids a race.
        android.os.Handler(mainLooper).postDelayed({ startListening() }, 150)
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            sendResultAndFinish(error = SpeechRecognizer.ERROR_CLIENT)
            return
        }

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            // Longer silence tolerance: the widget UI says "Bolo jaani..."
            // as soon as the tap happens, but the recognizer only actually
            // opens the mic a beat later (activity launch + window attach).
            // If the user starts talking right when the UI says so, the
            // first part of their speech can land before the recognizer
            // considers itself "started", which was causing it to treat
            // that gap as leading silence and cut off almost immediately.
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 3500)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 3500)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 5000)
        }

        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                // This fires when the mic is genuinely open and listening —
                // debug aid to confirm the mic actually became active at all
                // (vs. failing before ever reaching this point).
                android.widget.Toast.makeText(
                    this@VoiceRecognitionActivity, "Mic ready — bolo ab", android.widget.Toast.LENGTH_SHORT
                ).show()
            }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}

            override fun onError(error: Int) {
                sendResultAndFinish(error = error)
            }

            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                sendResultAndFinish(text = matches?.firstOrNull() ?: "")
            }

            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        speechRecognizer?.startListening(intent)
    }

    private fun sendResultAndFinish(text: String? = null, error: Int? = null) {
        val broadcast = Intent(ACTION_RESULT).apply {
            setPackage(packageName)
            if (text != null) putExtra(EXTRA_TEXT, text)
            if (error != null) putExtra(EXTRA_ERROR, error)
        }
        sendBroadcast(broadcast)
        speechRecognizer?.destroy()
        speechRecognizer = null
        finish()
        // No enter/exit transition — keeps this invisible over the widget.
        overridePendingTransition(0, 0)
    }

    override fun onDestroy() {
        super.onDestroy()
        speechRecognizer?.destroy()
        speechRecognizer = null
    }
}
