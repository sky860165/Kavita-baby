// VoiceRecognitionActivity.kt
package com.kavitababy.voice

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/**
 * Invisible, theme-transparent Activity that exists purely to give the
 * SpeechRecognizer a proper foreground Activity context to run under.
 *
 * Why this exists: SpeechRecognizer created and driven directly from a
 * background Service gets silently denied by several OEM speech-recognition
 * implementations (notably MIUI/Xiaomi-Redmi devices), surfacing as
 * ERROR_CLIENT (error code 7), even though on-device recognition works fine
 * for apps like the Google app, which always drive it from an Activity.
 *
 * Important: this Activity stays alive and keeps retrying INTERNALLY across
 * blank results / transient errors (see [CONTINUOUS_MODE_EXTRA]), rather
 * than finishing and being relaunched by the caller every cycle. Relaunching
 * a fresh Activity instance every few seconds was stealing window focus from
 * whatever else was on screen (including the keyboard) each time, which is
 * far more disruptive than a single Activity looping quietly in the
 * background. It only reports back and finishes once it has a genuine
 * result, hits a permanent error, or is explicitly asked to stop.
 */
class VoiceRecognitionActivity : Activity() {

    companion object {
        const val ACTION_RESULT = "com.kavitababy.voice.ACTION_RESULT"
        const val ACTION_STOP = "com.kavitababy.voice.ACTION_STOP"
        const val EXTRA_TEXT = "extra_text"
        const val EXTRA_ERROR = "extra_error"
        const val CONTINUOUS_MODE_EXTRA = "continuous_mode"
    }

    private var speechRecognizer: SpeechRecognizer? = null
    private var usedGoogleRecognizer = false
    private var hasFallenBack = false
    private var continuousMode = false
    private var stopRequested = false

    // Language candidates to cycle through when the current one keeps
    // failing/returning blank. Device default first (usually the user's
    // actual language), then broadly-supported fallbacks — this way the
    // app isn't hard-locked to one language, and self-recovers if a
    // specific locale isn't well supported by whichever recognizer the
    // device resolved.
    private val languageCandidates: List<String> by lazy {
        val default = java.util.Locale.getDefault().toString()
        listOf(default, "en-IN", "hi-IN").distinct()
    }
    private var languageIndex = 0
    private var attemptsOnCurrentLanguage = 0
    private val maxAttemptsPerLanguage = 3

    private val stopReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(ctx: android.content.Context?, intent: Intent?) {
            stopRequested = true
            speechRecognizer?.destroy()
            speechRecognizer = null
            finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // No setContentView — this activity is fully transparent
        // (see Theme.KavitaBaby.Transparent in themes.xml) and shows nothing.
        continuousMode = intent?.getBooleanExtra(CONTINUOUS_MODE_EXTRA, false) ?: false

        val stopFilter = android.content.IntentFilter(ACTION_STOP)
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(stopReceiver, stopFilter, RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            registerReceiver(stopReceiver, stopFilter)
        }

        // Give the window a beat to fully attach before starting the
        // recognizer — starting it in the same frame as onCreate() on a
        // transparent window has been unreliable on some OEM builds.
        android.os.Handler(mainLooper).postDelayed({ startListening() }, 150)
    }

    private fun startListening() {
        if (stopRequested) return

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            sendResultAndFinish(error = SpeechRecognizer.ERROR_CLIENT)
            return
        }

        val googleRecognizer = android.content.ComponentName(
            "com.google.android.googlequicksearchbox",
            "com.google.android.voicesearch.serviceapi.GoogleRecognitionService"
        )
        val googleAvailable = packageManager.resolveService(
            Intent("android.speech.RecognitionService").setComponent(googleRecognizer), 0
        ) != null

        usedGoogleRecognizer = googleAvailable && !hasFallenBack
        speechRecognizer?.destroy()
        speechRecognizer = if (usedGoogleRecognizer) {
            SpeechRecognizer.createSpeechRecognizer(this, googleRecognizer)
        } else {
            SpeechRecognizer.createSpeechRecognizer(this)
        }

        val recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageCandidates[languageIndex % languageCandidates.size])
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            // Deliberately NOT setting EXTRA_CALLING_PACKAGE — apps
            // shouldn't set this; the system fills it from the real caller
            // UID, and setting it ourselves triggered rejects on MIUI.
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 3500)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 3500)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 5000)
        }

        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}

            override fun onError(error: Int) {
                if (stopRequested) return

                // Try the other recognizer once before giving up on this pass.
                if (usedGoogleRecognizer && !hasFallenBack) {
                    hasFallenBack = true
                    retryAfterDelay()
                    return
                }

                val isPermanent = error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS

                if (continuousMode && !isPermanent) {
                    // Stay alive and retry internally instead of finishing —
                    // finishing here would mean the caller has to relaunch
                    // us, which steals window/keyboard focus every cycle.
                    hasFallenBack = false
                    retryAfterDelay()
                } else {
                    sendResultAndFinish(error = error)
                }
            }

            override fun onResults(results: Bundle?) {
                if (stopRequested) return
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = matches?.firstOrNull() ?: ""

                if (text.isBlank() && continuousMode) {
                    // Nothing understood — keep listening internally rather
                    // than reporting a blank result back up and waiting to
                    // be relaunched.
                    hasFallenBack = false
                    retryAfterDelay()
                } else {
                    attemptsOnCurrentLanguage = 0
                    sendResultAndFinish(text = text)
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        speechRecognizer?.startListening(recognizerIntent)
    }

    private fun retryAfterDelay() {
        attemptsOnCurrentLanguage++
        if (attemptsOnCurrentLanguage >= maxAttemptsPerLanguage) {
            // This language hasn't worked in several tries — move to the
            // next candidate instead of retrying the same one forever.
            attemptsOnCurrentLanguage = 0
            languageIndex++
        }
        speechRecognizer?.destroy()
        speechRecognizer = null
        android.os.Handler(mainLooper).postDelayed({
            if (!stopRequested) startListening()
        }, 900)
    }

    private fun sendResultAndFinish(text: String? = null, error: Int? = null) {
        val broadcast = Intent(ACTION_RESULT).apply {
            setPackage(packageName)
            if (text != null) putExtra(EXTRA_TEXT, text)
            if (error != null) putExtra(EXTRA_ERROR, error)
        }
        sendBroadcast(broadcast)
        speechRecognizer?.destroy()
        speechRecognizer = null
        finish()
        // No enter/exit transition — keeps this invisible over the widget.
        overridePendingTransition(0, 0)
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(stopReceiver)
        } catch (_: IllegalArgumentException) {
            // Already unregistered — fine.
        }
        speechRecognizer?.destroy()
        speechRecognizer = null
    }
}
