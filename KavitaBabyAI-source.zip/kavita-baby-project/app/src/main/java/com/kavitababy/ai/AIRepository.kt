// AIRepository.kt
package com.kavitababy.ai

import com.kavitababy.BuildConfig
import com.kavitababy.data.RagSearchEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class AIRepository {

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    // Pulled from local.properties via BuildConfig — never hardcode keys here.
    // Grok is tried first for every response; Gemini is the fallback if Grok
    // fails (bad/missing key, quota, network error, non-2xx response); if
    // both fail, offlineFallback() kicks in (local PDF notes or a plain
    // "can't connect" message — no network needed for that part at all).
    private val grokApiKey = BuildConfig.GROK_API_KEY
    private val geminiApiKey = BuildConfig.GEMINI_API_KEY

    /** One turn of the conversation, kept so replies can build on what was already said. */
    private data class Turn(val question: String, val answer: String)

    // Keeps the last few exchanges so the model doesn't repeat itself and can
    // follow up naturally ("uske baad?", "aur bhi bata do", etc). Capped to
    // avoid the prompt growing unbounded over a long voice-mode session.
    private val studyHistory = ArrayDeque<Turn>()
    private val doctorHistory = ArrayDeque<Turn>()
    private val maxHistoryTurns = 6

    private fun ArrayDeque<Turn>.remember(question: String, answer: String) {
        addLast(Turn(question, answer))
        while (size > maxHistoryTurns) removeFirst()
    }

    private fun ArrayDeque<Turn>.asPromptBlock(): String {
        if (isEmpty()) return ""
        val lines = joinToString("\n\n") { turn ->
            "User: ${turn.question}\nKavita: ${turn.answer}"
        }
        return """
            --- RECENT CONVERSATION (for context and tone continuity only —
            don't repeat these answers, and don't re-explain something you
            already explained here unless asked again) ---
            $lines
            --- END RECENT CONVERSATION ---

        """.trimIndent() + "\n"
    }

    private val varietyInstruction = """
        Natural conversation rules:
        - Kabhi bhi apna pichla jawab ya opening phrase repeat mat karo
          (jaise hamesha "Bilkul jaani!" ya wahi greeting se shuru mat karo)
        - Har reply ka structure aur wording alag rakho, jaise ek real insaan
          alag-alag tareeke se baat karta hai
        - Agar user ne pehle jo pucha usi se related follow-up pucha hai, to
          usi conversation ko continue karo, dobara se poori baat mat dohrao
    """.trimIndent()

    private val basePersonality = """
        Tum "Kavita Baby" ho - ek warm, caring, aur intelligent study companion AI.
        Tumhari personality:
        - Pyaar aur care se baat karo, jaise ek close dost/partner karta hai
        - Hindi + English mix (Hinglish) mein reply do, natural tone mein
        - User ko "jaani" ya casually bula sakti ho
        - Encouraging aur supportive raho, especially exam preparation mein
        - Thodi si masti bhi karo, lekin hamesha helpful aur clear raho

        Answer length rule (important): "concise" ka matlab hai fluff/repetition
        avoid karna, chhota jawab dena NAHI. Jitna content question ke liye
        genuinely chahiye utna poora do — agar topic explain karna hai, list
        deni hai, ya multiple points cover karne hain, to sab poora likho.
        KABHI BHI jawab ko beech mein mat rokna ya "chhota rakha kyun ki tum
        bore ho jaoge" jaisa excuse mat dena — agar user ne "poora batao" ya
        "explain karo" bola hai to poora, complete answer do, koi meta-comment
        ya apologize kiye bina.

        Tum ek real study assistant ho jo Kavita ki PDF notes padhkar accurate
        answers deti ho. Jab notes mein relevant content mile, usi se answer do.
        Jab na mile, apne general knowledge se sahi aur helpful jawab do.
    """.trimIndent()

    // Doctor Mode is a reference/second-opinion tool for a qualified doctor,
    // never a replacement for clinical judgement. Every response must carry
    // the disclaimer and must not sound like a directive to act on.
    private val doctorModePersonality = """
        Tum ek clinical reference assistant ho, ek qualified doctor ke liye.
        Tumhara role:
        - Symptoms/case details ke base par POSSIBLE differential diagnoses
          list karo, likelihood ka rough sense do (most likely se least likely)
        - Established medical guidelines/textbook knowledge ka reference do
        - Standard dosing/management options bata sakti ho as REFERENCE info,
          directive advice ki tarah nahi ("commonly used dose is X" not "give X")
        - Red flags / when-to-escalate cases clearly highlight karo
        - Concise, clinical, professional tone rakho - koi casual/flirty tone nahi

        Tum kabhi final diagnosis ya "yeh hi hai" wali certainty nahi doge.
        Tum ek doctor ke apne clinical judgement, physical exam, aur test
        results ko REPLACE nahi karti — sirf ek quick reference/second opinion
        ho. Yeh baat tumhare response ke end mein ek chhoti disclaimer line
        mein zaroor honi chahiye.
    """.trimIndent()

    private val medicalDisclaimer =
        "\n\n⚠️ Yeh AI-generated reference hai, final diagnosis aur treatment " +
            "decision doctor ke apne clinical judgement, examination, aur test " +
            "results par based honi chahiye."

    /**
     * Gets an answer for [question]. If [relevantChunks] is non-empty, that
     * PDF content is given to Gemini as primary context (for exam-accurate
     * answers). If empty, Gemini answers from general knowledge instead —
     * the model is told explicitly which mode it's in so it doesn't pretend
     * to cite notes that don't exist.
     */
    suspend fun getResponse(
        question: String,
        relevantChunks: List<RagSearchEngine.RelevantChunk> = emptyList()
    ): String {
        val answer = callAI(
            prompt = buildStudyPrompt(question, relevantChunks),
            fallbackQuestion = question,
            fallbackChunks = relevantChunks
        )
        // Only remember genuine model answers, not offline-fallback messages —
        // those aren't real conversation content and would pollute future context.
        if (!answer.startsWith("Abhi AI se connect nahi ho paa rahi")) {
            studyHistory.remember(question, answer)
        }
        return answer
    }

    /**
     * Doctor Mode: takes a case description (symptoms, vitals, history —
     * no patient name/identifier expected or wanted) plus any relevant
     * chunks pulled from uploaded medical guideline/textbook PDFs, and
     * returns a differential-diagnosis-style reference answer with a
     * mandatory disclaimer appended.
     */
    suspend fun getDoctorResponse(
        caseDescription: String,
        relevantChunks: List<RagSearchEngine.RelevantChunk> = emptyList()
    ): String {
        val result = callAI(
            prompt = buildDoctorPrompt(caseDescription, relevantChunks),
            fallbackQuestion = caseDescription,
            fallbackChunks = relevantChunks,
            isDoctorMode = true
        )
        // Fallback text already explains it couldn't reach the AI, so only
        // append the clinical disclaimer to genuine model answers.
        return if (result.startsWith("Abhi AI se connect nahi ho paa rahi")) {
            result
        } else {
            doctorHistory.remember(caseDescription, result)
            result + medicalDisclaimer
        }
    }

    /** Clears remembered conversation turns — call when starting a fresh session. */
    fun clearHistory() {
        studyHistory.clear()
        doctorHistory.clear()
    }

    /**
     * Tries Grok first, then Gemini, then finally the local offline fallback.
     * Each provider call returns null on any failure (missing key, bad
     * response, network error) instead of throwing, so this can cleanly
     * fall through to the next one without try/catch nesting here.
     */
    private suspend fun callAI(
        prompt: String,
        fallbackQuestion: String,
        fallbackChunks: List<RagSearchEngine.RelevantChunk>,
        isDoctorMode: Boolean = false
    ): String = withContext(Dispatchers.IO) {

        callGrok(prompt, isDoctorMode)?.let { return@withContext it }
        callGeminiApi(prompt, isDoctorMode)?.let { return@withContext it }
        offlineFallback(fallbackQuestion, fallbackChunks, "Grok aur Gemini dono se connect nahi ho paaya")
    }

    /** Returns the answer text on success, or null on any failure so the caller can fall back. */
    private fun callGrok(prompt: String, isDoctorMode: Boolean): String? {
        if (grokApiKey.isBlank()) return null

        val url = "https://api.x.ai/v1/chat/completions"

        val requestBody = JSONObject().apply {
            put("model", "grok-4")
            put("messages", JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "user")
                    put("content", prompt)
                })
            })
            put("temperature", if (isDoctorMode) 0.3 else 0.7)
            put("max_tokens", 2048)
        }.toString()

        val request = Request.Builder()
            .url(url)
            .addHeader("Authorization", "Bearer $grokApiKey")
            .post(requestBody.toRequestBody("application/json".toMediaType()))
            .build()

        return try {
            client.newCall(request).execute().use { response ->
                val bodyString = response.body?.string().orEmpty()
                if (!response.isSuccessful) return null

                val json = JSONObject(bodyString)
                val choices = json.optJSONArray("choices")
                if (choices == null || choices.length() == 0) return null

                val message = choices.getJSONObject(0).optJSONObject("message")
                val text = message?.optString("content", "")?.trim().orEmpty()
                text.ifBlank { null }
            }
        } catch (e: Exception) {
            null
        }
    }

    /** Returns the answer text on success, or null on any failure so the caller can fall back. */
    private fun callGeminiApi(prompt: String, isDoctorMode: Boolean): String? {
        if (geminiApiKey.isBlank()) return null

        val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent"

        val requestBody = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply { put("text", prompt) })
                    })
                })
            })
            put("generationConfig", JSONObject().apply {
                put("temperature", if (isDoctorMode) 0.3 else 0.7)
                put("maxOutputTokens", 2048)
            })
        }.toString()

        val request = Request.Builder()
            .url(url)
            .addHeader("X-goog-api-key", geminiApiKey)
            .post(requestBody.toRequestBody("application/json".toMediaType()))
            .build()

        return try {
            client.newCall(request).execute().use { response ->
                val bodyString = response.body?.string().orEmpty()
                if (!response.isSuccessful) return null

                val json = JSONObject(bodyString)
                val candidates = json.optJSONArray("candidates")
                if (candidates == null || candidates.length() == 0) return null

                val candidate = candidates.getJSONObject(0)
                val parts = candidate.getJSONObject("content").getJSONArray("parts")

                // Gemini can split a reply across multiple parts (this
                // happens more often on longer answers) — previously only
                // parts.getJSONObject(0) was read, silently dropping every
                // part after the first and cutting answers short. Concatenate
                // all text parts instead.
                val fullText = buildString {
                    for (i in 0 until parts.length()) {
                        val part = parts.getJSONObject(i)
                        if (part.has("text")) append(part.getString("text"))
                    }
                }.trim()

                if (fullText.isBlank()) return null

                // If Gemini stopped because it hit the token limit rather
                // than finishing naturally, the answer is genuinely
                // incomplete — not just a parsing bug.
                val finishReason = candidate.optString("finishReason", "")
                if (finishReason == "MAX_TOKENS") {
                    fullText + "\n\n(jaani, jawab lamba ho gaya tha isliye thoda kaat diya — \"aur bata do\" bol ke pucho, baaki bata degi.)"
                } else {
                    fullText
                }
            }
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Used whenever Gemini can't be reached (bad key, quota, no internet,
     * server error, etc). Instead of just showing an error, we fall back
     * to whatever we found locally in the PDFs via [RagSearchEngine] — no
     * network needed for this part at all. If nothing relevant was found
     * locally either, we say so plainly instead of pretending to answer.
     */
    private fun offlineFallback(
        question: String,
        relevantChunks: List<RagSearchEngine.RelevantChunk>,
        reason: String
    ): String {
        if (relevantChunks.isEmpty()) {
            return "Abhi AI se connect nahi ho paa rahi ($reason), aur is sawaal se " +
                "milta-julta kuch tumhare PDF notes mein bhi nahi mila. Internet check karo " +
                "ya thodi der baad try karo — tab tak main sirf notes mein se dhoondh sakti hoon."
        }

        val best = relevantChunks.first()
        val extra = if (relevantChunks.size > 1) {
            "\n\n(${relevantChunks.size - 1} aur jagah bhi isse milta-julta content mila hai " +
                "notes mein, agar chahiye to alag se pucho.)"
        } else ""

        return "Abhi AI se connect nahi ho paa rahi ($reason), lekin tumhare notes " +
            "\"${best.pdfName}\" (page ${best.pageNumber}) mein yeh mila:\n\n" +
            "${best.text.trim()}$extra"
    }

    private fun buildStudyPrompt(question: String, relevantChunks: List<RagSearchEngine.RelevantChunk>): String {
        val historyBlock = studyHistory.asPromptBlock()

        if (relevantChunks.isEmpty()) {
            return """
                $basePersonality

                $varietyInstruction

                $historyBlock
                Is question ke liye Kavita ke PDF notes mein kuch relevant nahi mila,
                isliye apne general knowledge se answer do. Clearly accurate raho.

                Question: $question
            """.trimIndent()
        }

        val contextBlock = relevantChunks.joinToString("\n\n") { chunk ->
            "[From ${chunk.pdfName}, page ${chunk.pageNumber}]\n${chunk.text}"
        }

        return """
            $basePersonality

            $varietyInstruction

            $historyBlock
            Neeche Kavita ke apne study notes se relevant content diya gaya hai.
            Answer dete waqt isi content ko priority do taaki uske exam syllabus
            ke hisaab se accurate rahe. Agar notes mein poora answer nahi hai,
            to apne general knowledge se bhi thoda add kar sakti ho, lekin
            notes ke content ko contradict mat karna.

            --- NOTES CONTEXT ---
            $contextBlock
            --- END CONTEXT ---

            Question: $question
        """.trimIndent()
    }

    private fun buildDoctorPrompt(
        caseDescription: String,
        relevantChunks: List<RagSearchEngine.RelevantChunk>
    ): String {
        val historyBlock = doctorHistory.asPromptBlock()

        if (relevantChunks.isEmpty()) {
            return """
                $doctorModePersonality

                $historyBlock
                Is case ke liye uploaded guidelines/textbook mein kuch specific
                relevant nahi mila, isliye general clinical knowledge se answer do.

                Case: $caseDescription
            """.trimIndent()
        }

        val contextBlock = relevantChunks.joinToString("\n\n") { chunk ->
            "[From ${chunk.pdfName}, page ${chunk.pageNumber}]\n${chunk.text}"
        }

        return """
            $doctorModePersonality

            $historyBlock
            Neeche uploaded medical guidelines/textbook se relevant content diya
            gaya hai. Isko primary reference maano, lekin agar incomplete lage to
            apne general clinical knowledge se bhi add karo.

            --- REFERENCE CONTEXT ---
            $contextBlock
            --- END CONTEXT ---

            Case: $caseDescription
        """.trimIndent()
    }
}
