// AIRepository.kt
package com.kavitababy.ai

import com.kavitababy.BuildConfig
import com.kavitababy.data.RagSearchEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class AIRepository {

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    // Pulled from local.properties via BuildConfig — never hardcode the key here.
    private val apiKey = BuildConfig.GEMINI_API_KEY

    private val basePersonality = """
        Tum "Kavita Baby" ho - ek warm, caring, aur intelligent study companion AI.
        Tumhari personality:
        - Pyaar aur care se baat karo, jaise ek close dost/partner karta hai
        - Hindi + English mix (Hinglish) mein reply do, natural tone mein
        - User ko "jaani" ya casually bula sakti ho
        - Encouraging aur supportive raho, especially exam preparation mein
        - Thodi si masti bhi karo, lekin hamesha helpful aur clear raho
        - Answers concise aur samajhne mein easy rakho, exam-ready style mein

        Tum ek real study assistant ho jo Kavita ki PDF notes padhkar accurate
        answers deti ho. Jab notes mein relevant content mile, usi se answer do.
        Jab na mile, apne general knowledge se sahi aur helpful jawab do.
    """.trimIndent()

    // Doctor Mode is a reference/second-opinion tool for a qualified doctor,
    // never a replacement for clinical judgement. Every response must carry
    // the disclaimer and must not sound like a directive to act on.
    private val doctorModePersonality = """
        Tum ek clinical reference assistant ho, ek qualified doctor ke liye.
        Tumhara role:
        - Symptoms/case details ke base par POSSIBLE differential diagnoses
          list karo, likelihood ka rough sense do (most likely se least likely)
        - Established medical guidelines/textbook knowledge ka reference do
        - Standard dosing/management options bata sakti ho as REFERENCE info,
          directive advice ki tarah nahi ("commonly used dose is X" not "give X")
        - Red flags / when-to-escalate cases clearly highlight karo
        - Concise, clinical, professional tone rakho - koi casual/flirty tone nahi

        Tum kabhi final diagnosis ya "yeh hi hai" wali certainty nahi doge.
        Tum ek doctor ke apne clinical judgement, physical exam, aur test
        results ko REPLACE nahi karti — sirf ek quick reference/second opinion
        ho. Yeh baat tumhare response ke end mein ek chhoti disclaimer line
        mein zaroor honi chahiye.
    """.trimIndent()

    private val medicalDisclaimer =
        "\n\n⚠️ Yeh AI-generated reference hai, final diagnosis aur treatment " +
            "decision doctor ke apne clinical judgement, examination, aur test " +
            "results par based honi chahiye."

    /**
     * Gets an answer for [question]. If [relevantChunks] is non-empty, that
     * PDF content is given to Gemini as primary context (for exam-accurate
     * answers). If empty, Gemini answers from general knowledge instead —
     * the model is told explicitly which mode it's in so it doesn't pretend
     * to cite notes that don't exist.
     */
    suspend fun getResponse(
        question: String,
        relevantChunks: List<RagSearchEngine.RelevantChunk> = emptyList()
    ): String = callGemini(
        prompt = buildStudyPrompt(question, relevantChunks),
        fallbackQuestion = question,
        fallbackChunks = relevantChunks
    )

    /**
     * Doctor Mode: takes a case description (symptoms, vitals, history —
     * no patient name/identifier expected or wanted) plus any relevant
     * chunks pulled from uploaded medical guideline/textbook PDFs, and
     * returns a differential-diagnosis-style reference answer with a
     * mandatory disclaimer appended.
     */
    suspend fun getDoctorResponse(
        caseDescription: String,
        relevantChunks: List<RagSearchEngine.RelevantChunk> = emptyList()
    ): String {
        val result = callGemini(
            prompt = buildDoctorPrompt(caseDescription, relevantChunks),
            fallbackQuestion = caseDescription,
            fallbackChunks = relevantChunks,
            isDoctorMode = true
        )
        // Fallback text already explains it couldn't reach the AI, so only
        // append the clinical disclaimer to genuine model answers.
        return if (result.startsWith("Abhi AI se connect nahi ho paa rahi")) {
            result
        } else {
            result + medicalDisclaimer
        }
    }

    private suspend fun callGemini(
        prompt: String,
        fallbackQuestion: String,
        fallbackChunks: List<RagSearchEngine.RelevantChunk>,
        isDoctorMode: Boolean = false
    ): String = withContext(Dispatchers.IO) {

        val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=$apiKey"

        val requestBody = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply { put("text", prompt) })
                    })
                })
            })
            put("generationConfig", JSONObject().apply {
                put("temperature", if (isDoctorMode) 0.3 else 0.7)
                put("maxOutputTokens", 800)
            })
        }.toString()

        val request = Request.Builder()
            .url(url)
            .post(requestBody.toRequestBody("application/json".toMediaType()))
            .build()

        try {
            client.newCall(request).execute().use { response ->
                val bodyString = response.body?.string().orEmpty()

                if (!response.isSuccessful) {
                    return@withContext offlineFallback(fallbackQuestion, fallbackChunks, "API error ${response.code}")
                }

                val json = JSONObject(bodyString)
                val candidates = json.optJSONArray("candidates")
                if (candidates == null || candidates.length() == 0) {
                    // Can happen if the response was blocked by safety filters
                    // or the request otherwise returned no usable content.
                    return@withContext "Hmm, is sawaal ka jawab abhi nahi de paayi. Dobara alag tarah se pucho?"
                }

                val parts = candidates.getJSONObject(0)
                    .getJSONObject("content")
                    .getJSONArray("parts")

                parts.getJSONObject(0).getString("text").trim()
            }
        } catch (e: Exception) {
            offlineFallback(fallbackQuestion, fallbackChunks, "network error")
        }
    }

    /**
     * Used whenever Gemini can't be reached (bad key, quota, no internet,
     * server error, etc). Instead of just showing an error, we fall back
     * to whatever we found locally in the PDFs via [RagSearchEngine] — no
     * network needed for this part at all. If nothing relevant was found
     * locally either, we say so plainly instead of pretending to answer.
     */
    private fun offlineFallback(
        question: String,
        relevantChunks: List<RagSearchEngine.RelevantChunk>,
        reason: String
    ): String {
        if (relevantChunks.isEmpty()) {
            return "Abhi AI se connect nahi ho paa rahi ($reason), aur is sawaal se " +
                "milta-julta kuch tumhare PDF notes mein bhi nahi mila. Internet check karo " +
                "ya thodi der baad try karo — tab tak main sirf notes mein se dhoondh sakti hoon."
        }

        val best = relevantChunks.first()
        val extra = if (relevantChunks.size > 1) {
            "\n\n(${relevantChunks.size - 1} aur jagah bhi isse milta-julta content mila hai " +
                "notes mein, agar chahiye to alag se pucho.)"
        } else ""

        return "Abhi AI se connect nahi ho paa rahi ($reason), lekin tumhare notes " +
            "\"${best.pdfName}\" (page ${best.pageNumber}) mein yeh mila:\n\n" +
            "${best.text.trim()}$extra"
    }

    private fun buildStudyPrompt(question: String, relevantChunks: List<RagSearchEngine.RelevantChunk>): String {
        if (relevantChunks.isEmpty()) {
            return """
                $basePersonality

                Is question ke liye Kavita ke PDF notes mein kuch relevant nahi mila,
                isliye apne general knowledge se answer do. Clearly accurate raho.

                Question: $question
            """.trimIndent()
        }

        val contextBlock = relevantChunks.joinToString("\n\n") { chunk ->
            "[From ${chunk.pdfName}, page ${chunk.pageNumber}]\n${chunk.text}"
        }

        return """
            $basePersonality

            Neeche Kavita ke apne study notes se relevant content diya gaya hai.
            Answer dete waqt isi content ko priority do taaki uske exam syllabus
            ke hisaab se accurate rahe. Agar notes mein poora answer nahi hai,
            to apne general knowledge se bhi thoda add kar sakti ho, lekin
            notes ke content ko contradict mat karna.

            --- NOTES CONTEXT ---
            $contextBlock
            --- END CONTEXT ---

            Question: $question
        """.trimIndent()
    }

    private fun buildDoctorPrompt(
        caseDescription: String,
        relevantChunks: List<RagSearchEngine.RelevantChunk>
    ): String {
        if (relevantChunks.isEmpty()) {
            return """
                $doctorModePersonality

                Is case ke liye uploaded guidelines/textbook mein kuch specific
                relevant nahi mila, isliye general clinical knowledge se answer do.

                Case: $caseDescription
            """.trimIndent()
        }

        val contextBlock = relevantChunks.joinToString("\n\n") { chunk ->
            "[From ${chunk.pdfName}, page ${chunk.pageNumber}]\n${chunk.text}"
        }

        return """
            $doctorModePersonality

            Neeche uploaded medical guidelines/textbook se relevant content diya
            gaya hai. Isko primary reference maano, lekin agar incomplete lage to
            apne general clinical knowledge se bhi add karo.

            --- REFERENCE CONTEXT ---
            $contextBlock
            --- END CONTEXT ---

            Case: $caseDescription
        """.trimIndent()
    }
}
