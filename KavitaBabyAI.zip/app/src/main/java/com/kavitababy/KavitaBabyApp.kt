// KavitaBabyApp.kt
package com.kavitababy

import android.app.Application
import com.kavitababy.data.CrashHandler
import com.kavitababy.data.PdfScanScheduler

class KavitaBabyApp : Application() {
    override fun onCreate() {
        super.onCreate()

        // As early as possible, before anything else can crash unlogged.
        CrashHandler.install(this)

        // Keeps a big PDF backlog (e.g. 20GB worth) making steady progress
        // in the background even when the app itself isn't open, instead
        // of only ever scanning while ChatScreen is on screen.
        PdfScanScheduler.schedulePeriodic(this)
    }
}
