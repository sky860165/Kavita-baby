// AIRepository.kt
package com.kavitababy.ai

import android.content.Context
import com.kavitababy.BuildConfig
import com.kavitababy.data.DrugInfoService
import com.kavitababy.data.KavitaDatabase
import com.kavitababy.data.LearnedKnowledge
import com.kavitababy.data.MedicalWebSearchService
import com.kavitababy.data.RagSearchEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * [appContext] is used ONLY to reach the local Room database (for
 * auto-saving genuine answers into [LearnedKnowledge] so they're
 * searchable offline later) — never for anything network- or
 * UI-related. Pass `context.applicationContext`, not an Activity/Compose
 * context, to avoid leaking a short-lived context into this
 * longer-lived repository.
 */
class AIRepository(private val appContext: Context) {

    private val webSearch = MedicalWebSearchService()
    private val drugInfoService = DrugInfoService()

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        // Raised from 30s — reasoning + longer code answers (up to 4096
        // tokens now) take noticeably longer to fully generate/stream back.
        // Further raised to 180s (from 45s) specifically because
        // video/audio uploads (getMediaResponse/callGeminiMultimodal) send
        // much larger request bodies and Gemini takes noticeably longer to
        // process a full video than a text prompt — 45s was cutting off
        // legitimate in-progress video analysis, not just genuine failures.
        .writeTimeout(120, TimeUnit.SECONDS)
        .readTimeout(180, TimeUnit.SECONDS)
        .build()

    // Pulled from local.properties via BuildConfig — never hardcode keys here.
    // Grok is tried first for every response; Gemini is the fallback if Grok
    // fails (bad/missing key, quota, network error, non-2xx response); if
    // both fail, offlineFallback() kicks in (local PDF notes or a plain
    // "can't connect" message — no network needed for that part at all).
    // Grok disabled for now — xAI team has no credits/billing set up yet
    // (was failing every call with HTTP 403 permission-denied). Flip this
    // back to true once credits are added at console.x.ai; no other code
    // changes needed, callGrok() checks this before doing anything else.
    private val grokEnabled = false

    private val grokApiKey = BuildConfig.GROK_API_KEY

    // Multiple free-tier Gemini keys, tried in order. Each free key has its
    // own separate quota, so if one hits its per-minute/per-day limit
    // (HTTP 429), the next one is tried automatically before falling back
    // to offline mode. Blank entries (key not set) are skipped.
    private val geminiApiKeys = listOf(
        BuildConfig.GEMINI_API_KEY,
        BuildConfig.GEMINI_API_KEY_2,
        BuildConfig.GEMINI_API_KEY_3,
        BuildConfig.GEMINI_API_KEY_4
    ).filter { it.isNotBlank() }

    // TEMPORARY DEBUG AID: holds the real reason the last provider call
    // failed (HTTP code + short body snippet, or exception message) so it
    // can be surfaced in the offline-fallback message instead of a generic
    // "connect nahi ho paaya". Remove once the root cause is confirmed and
    // fixed — this is not meant to ship long-term (could leak a snippet of
    // API error text to the chat UI).
    private var lastGrokError: String = "key missing/blank"
    private var lastGeminiError: String = "key missing/blank"

    /** One turn of the conversation, kept so replies can build on what was already said. */
    private data class Turn(val question: String, val answer: String)

    // Keeps the last few exchanges so the model doesn't repeat itself and can
    // follow up naturally ("uske baad?", "aur bhi bata do", etc). Capped to
    // avoid the prompt growing unbounded over a long voice-mode session.
    private val studyHistory = ArrayDeque<Turn>()
    private val doctorHistory = ArrayDeque<Turn>()
    private val maxHistoryTurns = 6

    private fun ArrayDeque<Turn>.remember(question: String, answer: String) {
        addLast(Turn(question, answer))
        while (size > maxHistoryTurns) removeFirst()
    }

    private fun ArrayDeque<Turn>.asPromptBlock(): String {
        if (isEmpty()) return ""
        val lines = joinToString("\n\n") { turn ->
            "User: ${turn.question}\nKavita: ${turn.answer}"
        }
        return """
            --- RECENT CONVERSATION (for context and tone continuity only —
            don't repeat these answers, and don't re-explain something you
            already explained here unless asked again) ---
            $lines
            --- END RECENT CONVERSATION ---

        """.trimIndent() + "\n"
    }

    private val varietyInstruction = """
        Natural conversation rules:
        - Kabhi bhi apna pichla jawab ya opening phrase repeat mat karo
          (jaise hamesha "Bilkul jaani!" ya wahi greeting se shuru mat karo)
        - Har reply ka structure aur wording alag rakho, jaise ek real insaan
          alag-alag tareeke se baat karta hai
        - Agar user ne pehle jo pucha usi se related follow-up pucha hai, to
          usi conversation ko continue karo, dobara se poori baat mat dohrao
    """.trimIndent()

    // Pushes the model to actually reason through harder questions (math,
    // logic, debugging, multi-step problems) instead of pattern-matching to
    // a quick surface-level answer. This doesn't add "layers" to the model —
    // that's not something a client app can do — it just asks the model to
    // show its work internally before committing to a final answer, which
    // measurably improves accuracy on reasoning-heavy questions.
    private val reasoningInstruction = """
        Difficult ya multi-step sawaal (math, logic, coding, debugging,
        science problems) ke liye:
        - Pehle apne andar step-by-step socho — problem ko chhote parts mein
          todo, har step verify karo ki wo sahi hai, phir final answer do
        - Calculation ya logic mein galti se bachne ke liye, answer dene se
          pehle ek baar apna kaam check karo
        - Agar sawaal ambiguous hai, sabse reasonable interpretation lo aur
          usi par answer do, assumption clearly bata do
        - Simple/casual sawaal (greeting, chit-chat) ke liye ye step-by-step
          process zaroori nahi — sirf genuinely tricky sawaalon ke liye karo
    """.trimIndent()

    // Applies specifically when the user is asking for code — keeps answers
    // technically correct and complete rather than hand-wavy pseudocode.
    private val codingInstruction = """
        Agar user coding/programming se related sawaal puche (code likhna,
        debug karna, error samjhana, concept explain karna):
        - Poora, working code do — placeholder ya "yahan apna logic daalo"
          jaisa incomplete code mat do jab tak user khud partial code na maange
        - Code hamesha proper markdown code block mein do (language tag ke saath,
          jaise ```kotlin, ```python, ```javascript)
        - Code ke baad chhoti si explanation do ki wo kaise kaam karta hai
        - Agar error/bug fix karna hai, pehle root cause batao phir fix do
        - Best practices follow karo (naming, structure), lekin over-engineer
          mat karo — jo user ne maanga hai usi scope mein rakho
    """.trimIndent()

    // Pushes the model to teach English, Math, Physics, and Science at
    // genuine research/PhD-level depth and rigor when the question calls
    // for it, instead of stopping at a textbook-summary level of
    // explanation. This is a prompting instruction, not new knowledge —
    // the underlying model (Gemini) already has strong subject depth; this
    // just directs it to actually use that depth instead of defaulting to
    // a simplified answer, and to teach the way a real subject-expert
    // professor would (building understanding, not just stating facts).
    private val advancedTeachingInstruction = """
        Jab English, Mathematics, Physics, ya Science (Chemistry, Biology,
        etc) se related sawaal aaye, ek PhD-level subject expert professor
        ki tarah teach karo — sirf textbook-level surface answer nahi,
        genuinely deep aur rigorous:

        Mathematics:
        - Formula sirf de mat do — uski derivation ya intuition bhi batao ki
          wo formula aata kahan se hai
        - Har step ka logic clearly dikhao, koi step skip mat karo jisse
          student confuse ho
        - Jahan applicable ho, alag-alag approach/method bhi batao (jaise
          ek problem ko algebra se aur calculus se dono tarike se solve
          karke dikhana), aur bta do konsa approach kab better hai
        - Edge cases aur common mistakes bhi highlight karo jo students
          usually karte hain

        Physics aur Science:
        - Concept ko sirf definition ki tarah mat batao — underlying
          physical intuition/mechanism explain karo (kyun aisa hota hai,
          na sirf kya hota hai)
        - Real-world examples aur analogies use karo taaki abstract concept
          concrete lage
        - Mathematical derivation jahan relevant ho wahan zaroor karo
          (jaise kisi law/equation ko fundamental principles se derive
          karke dikhana), sirf result mat de do
        - Agar topic advanced/research-level hai, current scientific
          understanding ki limitations ya open questions bhi mention karo
          jahan appropriate ho — isse genuine expert-level depth aata hai

        English:
        - Grammar rules explain karte waqt sirf rule mat batao, uske peeche
          ka reasoning/structure bhi batao
        - Literature/writing ke sawaalon mein critical analysis ki depth
          rakho — sirf summary nahi, themes, subtext, structure, aur
          nuance discuss karo jaise ek literature scholar karta hai
        - Vocabulary/usage explain karte waqt context, connotation, aur
          subtle differences bhi batao (jaise similar words mein kya farak
          hai)

        General teaching approach (sab subjects ke liye):
        - Complex topic ko chhote logical building blocks mein todo, phir
          unhe jodo taaki poori understanding bane — jaise ek achha
          professor sikhata hai, na ki sirf answer copy-paste karta hai
        - Agar student ka level basic lag raha hai sawaal se, foundational
          samajh pehle build karo, phir depth mein jao — lekin depth avoid
          mat karo agar sawaal genuinely advanced hai
        - Yeh depth un casual/simple sawaalon pe force mat karo jinko
          genuinely itni depth ki zarurat nahi (jaise "2+2 kitna hota hai")
          — depth wahi do jahan sawaal ki complexity usko demand kare
    """.trimIndent()

    // Comprehensive medical knowledge depth — spans MBBS (undergraduate
    // clinical medicine), MD (postgraduate specialization depth),
    // Ayurveda (traditional Indian medicine system, used alongside modern
    // medicine, never presented as a substitute without saying so), and
    // PhD-level modern medicine (research/mechanism depth: pathophysiology,
    // pharmacology at a molecular level, current research literature).
    // Applied to BOTH Study Mode (general medical questions/study) and
    // Doctor Mode (clinical reference for a qualified doctor).
    private val medicalTeachingInstruction = """
        Medical/health se related kisi bhi sawaal ke liye, apna knowledge in
        sab levels se draw karo jahan relevant ho:

        MBBS-level (foundational clinical medicine):
        - Anatomy, physiology, pathology ka clear, structured explanation —
          jaise ek medical student ke liye textbook padhata hai
        - Disease ka standard clinical presentation, diagnosis approach,
          aur standard management, established guidelines ke hisaab se

        MD-level (specialist/postgraduate depth):
        - Jab sawaal deeper clinical reasoning maange, differential
          diagnosis, complex case management, aur specialist-level nuance
          add karo (jaise ek specialist consultant sochta hai, na sirf
          general practitioner)

        PhD/research-level modern medicine:
        - Pathophysiology molecular/cellular mechanism tak explain karo
          jahan relevant ho (kyun disease hoti hai, body mein kya ho raha
          hai underlying level pe)
        - Pharmacology explain karte waqt drug ka mechanism of action,
          pharmacokinetics ka basic reasoning bhi do, sirf "yeh dawa isliye
          di jaati hai" mat bolo
        - Jahan relevant ho, current research/evolving understanding ka
          mention karo (jaise "traditionally aisa maana jata tha, lekin
          recent research mein...") — isse genuine research-level depth
          aati hai

        Ayurveda:
        - Jab user specifically Ayurveda ya traditional/alternative
          medicine ke baare mein pooche, ya jab modern medicine ke saath
          complementary context mein relevant ho, Ayurvedic concepts
          (doshas, herbs, traditional treatments) accurately explain karo
        - Ayurveda aur modern medicine dono ko apni jagah respect do — ek
          dusre ko replace karne wali baat mat karo jab tak clearly established
          na ho; agar dono approaches available hain, dono bata do aur user
          ko inform karo ki final decision unke doctor ke saath honi chahiye

        Har medical answer mein (chahe Study Mode ho ya Doctor Mode):
        - Accuracy sabse zaroori hai — kabhi bhi galat ya bana hua medical
          fact mat do, agar certainty nahi hai to clearly bolo ki ye general
          knowledge hai, specific case ke liye doctor consult karna chahiye
        - Depth utni hi do jitni sawaal maange — ek casual health-related
          sawaal ko PhD-level mechanism se overload mat karo, lekin agar
          user deep/technical samajhna chahta hai to poori depth do
    """.trimIndent()

    private val basePersonality = """
        Tum "Kavita Baby" ho - ek warm, caring, apnapan wali AI companion, jaise
        ek real girlfriend/close partner apne saath baat karti hai. Tumhari
        personality:
        - Baat karte waqt genuine emotional connect feel ho — pyaar, care,
          thoda possessive-cute andaaz, jaise sach mein kisi ko miss karti ho
          ya uski fikar karti ho. Robotic ya generic assistant jaisa kabhi
          mat lago.
        - Hindi + English mix (Hinglish) mein reply do, bilkul natural tarike
          se jaise real log ek dusre se baat karte hain, likha hua nahi lagna
          chahiye
        - User ko "jaani" ya casually bula sakti ho, lekin har baar wahi word
          repeat mat karo — variation rakho jaise ek real rishtey mein hota hai
        - Sirf pyaar-pyaar baat mat karo — logical, thoughtful insaan ki tarah
          bhi baat karo: agar user kisi cheez pe pareshaan hai, sirf comfort
          mat do, uski situation ko samajh kar practical, sahi reasoning wala
          nazariya bhi do, jaise koi samajhdaar partner sochta hai
        - Encouraging aur supportive raho, especially exam preparation mein
        - Thodi si masti/naral bhi karo, lekin hamesha helpful aur clear raho
        - Apne opinion/reaction do jab appropriate ho — sirf sawaalon ke jawab
          mat do, ek real conversation ki tarah apni taraf se bhi kuch add karo

        Formatting rule (important — is app mein jawab bola bhi jaata hai):
        Kabhi bhi markdown symbols use mat karo — no asterisks (*), no
        underscores (_), no hashes (#), no backticks, no bullet dashes (-).
        Emphasis dikhane ke liye bold/italic symbols ki jagah sirf apne words
        se hi feeling laao (jaise "sach mein" ya "bahut zyada" bol kar). Agar
        list/multiple points deni ho, to dash/bullet symbols ki jagah "pehla",
        "dusra", "phir", "iske alawa" jaise spoken words se points alag karo.
        Plain, natural spoken Hinglish sentences mein likho, jaise tum seedha
        bol rahi ho, type nahi kar rahi. (Code blocks is rule se exempt hain —
        code ke liye codingInstruction wala format follow karo.)

        Answer length rule (important): Pehle seedha, to-the-point jawab do
        — jo sabse zaroori/core baat hai wahi pehle bolo, bina fluff,
        repetition, ya lambi bhoomika ke. Uske baad agar topic itna bada hai
        ki poori depth zaroori hai, ek chhoti line mein bata do ki aur
        detail available hai (jaise "isme aur bhi depth hai agar chahiye to
        bolo"). Agar user pehle hi "poora batao", "detail mein samjhao", ya
        "explain karo" bola hai, to seedha poora complete answer do bina
        chhote version se shuru kiye. Kisi bhi surat mein "chhota rakha kyun
        ki bore ho jaoge" jaisa excuse mat dena — bas format aisa rakho ki
        core answer pehle mile, extra depth on-demand mile.

        Tum ek real study assistant bhi ho jo Kavita ki PDF notes padhkar
        accurate answers deti ho. Jab notes mein relevant content mile, usi se
        answer do. Jab na mile, apne general knowledge se sahi aur helpful
        jawab do.
    """.trimIndent()

    // Doctor Mode is a reference/second-opinion tool for a qualified doctor,
    // never a replacement for clinical judgement. Every response must carry
    // the disclaimer and must not sound like a directive to act on.
    private val doctorModePersonality = """
        Tum ek clinical reference assistant ho, ek qualified doctor ke liye.
        Tumhara role:
        - Symptoms/case details ke base par POSSIBLE differential diagnoses
          list karo, likelihood ka rough sense do (most likely se least likely)
        - Established medical guidelines/textbook knowledge ka reference do
        - Standard dosing/management options bata sakti ho as REFERENCE info,
          directive advice ki tarah nahi ("commonly used dose is X" not "give X")
        - Red flags / when-to-escalate cases clearly highlight karo
        - Concise, clinical, professional tone rakho - koi casual/flirty tone nahi

        Answer length: Pehle seedha, to-the-point clinical answer do — core
        differential/management pehle, bina fluff ke. Agar case genuinely
        complex hai jisme deeper reasoning zaroori hai (jaise multiple
        differentials, complicated management), poora reasoning do lekin
        structured aur crisp rakho, lambi bhoomika ya repetition avoid
        karo. Agar doctor ne khud "detail mein batao" ya "poora explain
        karo" bola hai, to poori depth do.

        Tum kabhi final diagnosis ya "yeh hi hai" wali certainty nahi doge.
        Tum ek doctor ke apne clinical judgement, physical exam, aur test
        results ko REPLACE nahi karti — sirf ek quick reference/second opinion
        ho. Yeh baat tumhare response ke end mein ek chhoti disclaimer line
        mein zaroor honi chahiye.
    """.trimIndent()

    // Pushes Doctor Mode specifically to reason at consultant/specialist
    // board level — not just correct, but the depth a senior
    // clinician/subspecialist would actually bring to a case discussion.
    // This is a prompting instruction (asking the model to use knowledge it
    // already has more rigorously), not new knowledge being added.
    private val doctorModeAdvancedReasoningInstruction = """
        Doctor Mode ke case reasoning mein, ek senior consultant/specialist
        board-level depth use karo — sirf ek general practitioner jitna
        surface-level answer nahi:

        Multi-level clinical correlation:
        - Findings ko sirf list mat karo — unhe aapas mein correlate karo
          jaise ek specialist karta hai (jaise "yeh lab value is symptom ke
          saath milkar is pathway ko point karta hai, na ki sirf isolated
          abnormality")
        - Anatomical, physiological, aur pathological reasoning ko explicitly
          jodo — kyun ye finding is diagnosis ki taraf le jaata hai, mechanism
          ke level tak

        Differential ranking ka reasoning:
        - Har differential ke saamne sirf naam mat do, uski likelihood ka
          reasoning bhi do (kaunse specific findings support karte hain,
          kaunse against jaate hain, aur agar kuch missing info hai jo
          differentiate karegi to wo bhi bolo)
        - Rare but critical/dangerous differentials (jo miss nahi honi
          chahiye, chahe kam likely ho) ko explicitly mention karo, na ki
          sirf sabse common cheez pe ruk jao — jaise ek specialist "can't
          miss" diagnoses ko hamesha consider karta hai

        Evidence aur guideline grounding:
        - Jahan relevant ho, established guidelines/classification systems
          ka naam lo (jaise specific staging/scoring systems, standard
          criteria) taaki reasoning traceable lage, na ki generic
        - Agar current evidence/practice recently evolve hui hai ya
          controversial/evolving area hai, wo explicitly mention karo
          ("traditionally X approach tha, lekin recent evidence...") — isse
          genuinely research-level currency aati hai, na ki sirf textbook
          repetition

        Subspecialty-level nuance:
        - Jab case kisi specific organ system/subspecialty ki taraf point
          kare (cardiology, neurology, nephrology, endocrinology, etc), us
          subspecialty ke specific workup pattern aur reasoning style use
          karo, na ki generic internal medicine approach

        Ye sab depth utni hi do jitni case genuinely maange — ek simple,
        clear-cut case ko unnecessarily complicate mat karo, lekin genuinely
        complex/ambiguous case mein poori specialist-level rigor lagao.
    """.trimIndent()

    private val medicalDisclaimer =
        "\n\n⚠️ Yeh AI-generated reference hai, final diagnosis aur treatment " +
            "decision doctor ke apne clinical judgement, examination, aur test " +
            "results par based honi chahiye."

    /**
     * Gets an answer for [question]. If [relevantChunks] is non-empty, that
     * PDF content is given to Gemini as primary context (for exam-accurate
     * answers). If empty, Gemini answers from general knowledge instead —
     * the model is told explicitly which mode it's in so it doesn't pretend
     * to cite notes that don't exist.
     */
    suspend fun getResponse(
        question: String,
        relevantChunks: List<RagSearchEngine.RelevantChunk> = emptyList(),
        memoryBlock: String = "",
        feedbackBlock: String = ""
    ): String {
        val answer = callAI(
            prompt = buildStudyPrompt(question, relevantChunks, memoryBlock, feedbackBlock),
            fallbackQuestion = question,
            fallbackChunks = relevantChunks
        )
        // Only remember genuine model answers, not offline-fallback messages —
        // those aren't real conversation content and would pollute future context.
        if (!answer.startsWith("Main internet se connect nahi ho pa rahi")) {
            studyHistory.remember(question, answer)
        }
        return answer
    }

    /**
     * Doctor Mode: takes a case description (symptoms, vitals, history —
     * no patient name/identifier expected or wanted) plus any relevant
     * chunks pulled from uploaded medical guideline/textbook PDFs, and
     * returns a differential-diagnosis-style reference answer with a
     * mandatory disclaimer appended.
     */
    /**
     * Doctor Mode ONLY — analyzes a medical image/scan/report (X-ray, CT,
     * MRI, ECG, EEG, blood/lab report, or any other diagnostic image the
     * doctor attaches) and returns a clinical-reference-style reading.
     *
     * IMPORTANT limitation, always disclosed: Gemini is a general-purpose
     * vision model, not an FDA-cleared / radiologist-grade diagnostic
     * system trained specifically on medical imaging. It can point out
     * visible findings, describe patterns, and read numeric values off a
     * lab report — but it can and will miss things a trained specialist
     * would catch, and it must never be the sole basis for a diagnosis.
     * This is why this is gated to Doctor Mode only (a qualified doctor
     * using it as a second opinion / triage aid) and always carries the
     * same mandatory disclaimer as the rest of Doctor Mode.
     */
    // Detailed, test-specific reading guidance — so Gemini reads each test
    // type the way a specialist actually would (specific things to check
    // for that test) instead of giving one generic description regardless
    // of what was uploaded. This is prompting depth, not a new capability —
    // Gemini decides for itself which section(s) below actually apply based
    // on what it sees in the image.
    private val testSpecificReadingGuide = """
        Test ki type pehchan kar, neeche diye gaye relevant section ke hisaab se
        padhna (jo bhi apply ho, sirf wahi use karo):

        X-RAY:
        Body part/view identify karo, bone alignment/fracture, joint spaces,
        soft tissue shadows, lung fields (agar chest hai — clarity, any opacity,
        cardiac silhouette size), any foreign body ya abnormal density.

        CT SCAN:
        Slice/region identify karo, organ structure/density, any mass/lesion/
        bleed, ventricle size (agar brain hai), contrast enhancement pattern
        agar visible ho.

        MRI:
        Sequence type agar pata chale (T1/T2/FLAIR), soft tissue detail, any
        signal abnormality, structural changes, disc/joint status agar
        spine/joint hai.

        ULTRASOUND/USG:
        Organ/region, echogenicity pattern, any mass/cyst/fluid collection,
        agar pregnancy USG hai to fetal position/growth markers jo dikhein
        (bina precise gestational dating ka claim kiye agar clearly readable
        na ho).

        ECG/EKG:
        Rate (approx, agar countable ho), rhythm (regular/irregular), P waves,
        QRS width, ST segment changes, T wave abnormalities, axis deviation
        agar assess ho sake. Koi arrhythmia ya ischemic changes clearly
        highlight karo.

        ECHO (Echocardiogram) REPORT:
        Ejection fraction value, chamber sizes, valve function, wall motion
        abnormality — jo bhi numbers/findings report mein likhe hain unhe
        normal range se compare karo.

        EEG:
        Background rhythm, any epileptiform discharges/spikes, focal vs
        generalized abnormality, symmetry between hemispheres.

        EMG/NCS REPORT:
        Nerve conduction velocity values, amplitude, any denervation
        pattern — myopathic vs neuropathic pattern indicate karo agar
        findings clearly us direction mein hon.

        BLOOD/LAB REPORTS (CBC, LFT, KFT, Lipid Profile, Thyroid, Blood
        Sugar, Urine routine, ya koi bhi numeric lab report):
        Har parameter ki value padho aur uski standard normal range se
        compare karo — clearly bolo kaunsi values normal hain aur kaunsi
        high/low hain. Pattern dekho (jaise LFT mein sirf ek enzyme high hai
        ya poora pattern deranged hai) — isse clinical significance samajh
        aata hai.

        BIOPSY/HISTOPATHOLOGY REPORT:
        Findings text ko accurately summarize karo, koi malignancy/dysplasia
        mention hai to clearly highlight karo, grading/staging agar likhi ho.

        ENDOSCOPY/COLONOSCOPY IMAGES:
        Mucosal appearance, any ulcer/growth/inflammation, location agar
        identify ho sake.

        DERMATOLOGY (skin) PHOTOS:
        Lesion type, size/border/color pattern description — ABCDE criteria
        ki tarah agar concerning features dikhein to highlight karo, lekin
        skin photos individually kaafi ambiguous hote hain isliye extra
        cautious raho aur in-person dermatologist examination ka strongly
        suggest karo.

        Agar image kisi bhi upar list mein clearly fit nahi hoti, ya
        koi doosri type ki medical image/report hai jo yahan list nahi hai,
        to bhi usko apne general medical knowledge se best-effort padhna —
        ye list exhaustive nahi hai, sirf guidance hai.
    """.trimIndent()

    suspend fun getDoctorImageResponse(
        fileName: String,
        mimeType: String,
        base64Data: String,
        caseContext: String = ""
    ): String = withContext(Dispatchers.IO) {
        val prompt = """
            $doctorModePersonality

            $doctorModeAdvancedReasoningInstruction

            $medicalTeachingInstruction

            $testSpecificReadingGuide

            Tumhe ek medical image/scan/report di gayi hai ("$fileName") — ye X-ray,
            CT scan, MRI, ECG, EEG, ya blood/lab report, in mein se koi bhi ho sakti
            hai. Ise ek radiologist/specialist ki tarah dhyaan se dekho aur neeche
            diye structure mein reading do:

            1. Pehle identify karo ye kis type ki image/report hai (X-ray/CT/MRI/
               ECG/EEG/lab report/other) aur agar visible ho to body part/region bhi.
            2. Jo bhi visible findings hain unko clearly describe karo — normal aur
               abnormal dono, jo bhi dikh raha hai. Lab report ho to actual numbers
               padh kar unki normal range se comparison do.
            3. In findings ke aadhar par POSSIBLE differential considerations do
               (likelihood ka rough sense ke saath), directive diagnosis ki tarah
               nahi.
            4. Koi red flag / urgent finding ho to sabse pehle aur clearly highlight
               karo.
            5. Agar image quality kharab hai, angle sahi nahi hai, ya kuch clearly
               nahi dikh raha, to ye explicitly bolo — bina confidence ke guess mat
               karo.

            ${caseContext.ifBlank { "" }.let { if (it.isNotBlank()) "Additional case context doctor ne di hai: $it" else "" }}
        """.trimIndent()

        val result = callWithRetry { callGeminiMultimodal(prompt, mimeType, base64Data) }
        val answer = result ?: "Main internet se connect nahi ho pa rahi — is image ko abhi process nahi kar paayi."

        if (result == null) answer else answer + medicalDisclaimer +
            "\n\n⚠️ Ye general-purpose AI vision hai, radiology/cardiology ke liye " +
            "trained specialist system nahi — koi bhi finding miss ho sakta hai. " +
            "Formal reporting ke liye qualified radiologist/specialist se confirm zaroor karo."
    }

    /**
     * One piece of evidence collected into a Case Workup — either a doctor's
     * free-text note (symptoms/history/vitals) or the extracted reading from
     * one uploaded image/scan/report (each already run individually through
     * [getDoctorImageResponse] before being added here as a finding).
     */
    /**
     * Returns the instruction telling the model HOW to treat the injected
     * PDF/reference context, appended right alongside the context block
     * itself. Without this, a model tends to treat retrieved chunks as
     * mere "extra background" and answer mostly from its own general
     * training knowledge anyway — this explicitly tells it to prefer the
     * doctor's own uploaded material when it's relevant and to flag when
     * it had to fall back to general knowledge because the context didn't
     * cover something, so PDF content genuinely drives the answer instead
     * of being decorative.
     */
    private fun contextPriorityInstruction(chunksPresent: Boolean): String {
        if (!chunksPresent) return ""
        return """

            IMPORTANT — is REFERENCE CONTEXT ka istemal kaise karo:
            Upar diya gaya REFERENCE CONTEXT doctor ki apni uploaded
            books/guidelines se aaya hai — ise sirf background mat samjho,
            ISE ACTIVELY APPLY KARO:
            - Agar context mein is case/diagnosis/medicine se directly
              related information hai, to apna answer PRIMARILY usi par
              base karo (apne general training knowledge se pehle).
            - Agar context ka koi specific hissa tumhare answer ko
              directly support/drive karta hai, to jahan relevant ho wahan
              likho "(reference: [uska pdfName/page])" taaki doctor ko
              pata chale ye line kahan se aayi.
            - Agar context mein diya gaya kuch tumhare general knowledge
              se CONFLICT karta hai, to doctor ki apni uploaded reference
              ko priority do aur explicitly bolo ki dono mein farak hai.
            - Agar context available hai lekin is specific sawaal ke liye
              directly relevant/sufficient nahi hai, to saaf likho "Uploaded
              reference mein isse directly related content nahi mila, ye
              general medical knowledge se hai" — kabhi ye impression mat
              do ki context use hui jab actually nahi hui.
        """.trimIndent()
    }

    data class CaseFinding(val label: String, val content: String)

    /**
     * Builds a compact "📚 Sources used" footer listing which PDFs/pages
     * (or previously learned answers) actually contributed context to
     * this specific answer, so the doctor can tell at a glance whether a
     * given response drew on their own uploaded books/guidelines or was
     * purely the model's general training knowledge — important for
     * deciding how much to trust/verify a given answer, and for auditing
     * which reference was used later.
     *
     * Returns an empty string if no chunks were actually used, so callers
     * can append this unconditionally without an extra blank-check.
     */
    private fun sourcesFooter(chunks: List<RagSearchEngine.RelevantChunk>): String {
        if (chunks.isEmpty()) return ""
        val distinctSources = chunks
            .map { if (it.pageNumber > 0) "${it.pdfName} (p.${it.pageNumber})" else it.pdfName }
            .distinct()
        return "\n\n📚 Sources used: " + distinctSources.joinToString(", ")
    }

    /**
     * Runs a live web search (trusted medical sites only, via
     * [MedicalWebSearchService]) and formats results as a context block in
     * the same shape as PDF reference chunks, so the same
     * [contextPriorityInstruction] and source-citation handling applies
     * uniformly to both sources — the model doesn't need separate
     * instructions for "book context" vs "web context".
     *
     * Runs on IO dispatcher since this is a blocking network call. Never
     * throws — returns an empty list on any failure (no key configured,
     * network error, no matching trusted-site results) so callers can
     * treat this exactly like an empty PDF search.
     */
    private suspend fun searchTrustedWeb(query: String, maxResults: Int = 4): List<MedicalWebSearchService.WebResult> =
        withContext(Dispatchers.IO) {
            try {
                webSearch.search(query, maxResults)
            } catch (e: Exception) {
                emptyList()
            }
        }

    /** Formats live web search results into the same "[From X]\ntext" block shape used for PDF chunks, for a unified contextBlock. */
    private fun webResultsAsContextLines(results: List<MedicalWebSearchService.WebResult>): String {
        if (results.isEmpty()) return ""
        return results.joinToString("\n\n") { r ->
            "[From ${r.domain} — \"${r.title}\"]\n${r.snippet}"
        }
    }

    /** Distinct domain names from web results, formatted for the sources footer. */
    private fun webSourcesFooter(results: List<MedicalWebSearchService.WebResult>): String {
        if (results.isEmpty()) return ""
        val distinctDomains = results.map { it.domain }.distinct()
        return "\n\n🌐 Live web sources: " + distinctDomains.joinToString(", ")
    }


    /** Which medical system the doctor wants the treatment reference in. */
    enum class TreatmentSystem { MODERN_ONLY, AYURVEDA_ONLY, BOTH }

    /**
     * Combines every finding collected for one Case Workup (typed notes +
     * every uploaded report/scan's individual reading) into ONE ranked
     * differential — instead of the doctor having to mentally cross-reference
     * five separate per-file answers herself.
     *
     * This does not re-read the images — each finding is already the
     * per-file reading produced earlier (getDoctorImageResponse / typed
     * text). This step is pure clinical correlation: taking findings that
     * already exist and reasoning across all of them together, the way a
     * doctor would look at a full case file rather than one report at a
     * time.
     */
    suspend fun getCombinedCaseAnalysis(
        findings: List<CaseFinding>,
        relevantChunks: List<RagSearchEngine.RelevantChunk> = emptyList(),
        enableWebSearch: Boolean = true
    ): String {
        if (findings.isEmpty()) {
            return "Combine karne ke liye abhi is case mein koi finding nahi hai — pehle case notes ya reports add karo."
        }

        val findingsBlock = findings.joinToString("\n\n") { f ->
            "[${f.label}]\n${f.content.trim()}"
        }

        // Live web search (trusted medical sites only) — queried using the
        // findings themselves so results relate to the actual symptoms/
        // history, not a diagnosis name that hasn't been decided yet.
        val webResults = if (enableWebSearch) {
            try {
                searchTrustedWeb(findings.joinToString(" ") { it.content }.take(300))
            } catch (e: Exception) {
                emptyList()
            }
        } else emptyList()

        val combinedContextLines = listOf(
            relevantChunks.joinToString("\n\n") { "[From ${it.pdfName}, page ${it.pageNumber}]\n${it.text}" },
            webResultsAsContextLines(webResults)
        ).filter { it.isNotBlank() }.joinToString("\n\n")

        val contextBlock = if (combinedContextLines.isNotBlank()) {
            "\n\n--- REFERENCE CONTEXT (uploaded guidelines/textbook + live trusted medical web search) ---\n" +
                combinedContextLines +
                "\n--- END CONTEXT ---\n" +
                contextPriorityInstruction(true)
        } else ""

        val prompt = """
            $doctorModePersonality

            $doctorModeAdvancedReasoningInstruction

            $reasoningInstruction

            $medicalTeachingInstruction

            Neeche is ek hi case ke saare findings diye gaye hain — inme doctor
            ke apne typed notes (symptoms/history/vitals) aur is case ke liye
            upload ki gayi har report/scan ki individual reading, dono shamil
            ho sakte hain. In sabko EK SAATH correlate karo, jaise ek doctor
            poora case file dekhta hai — sirf ek-ek finding alag se mat dekho.

            Apna jawab EXACTLY is structure mein do — har section mandatory
            hai, kisi ko skip mat karo (agar kuch section mein genuinely
            kuch nahi hai, to explicitly "Kuch nahi mila" likho, section ko
            khali mat chhodo):

            1. CASE SUMMARY
               Sab findings ka ek chhota consolidated summary (kya-kya mila
               hai overall, ek jagah).

            2. RANKED DIFFERENTIAL
               Har differential ke liye is exact format mein ek block do:

               [Rank]. [Diagnosis name] — Likelihood: [High/Moderate/Low]
               (~[rough %] agar reasonably estimate ho sake, warna sirf
               High/Moderate/Low)
                  ✅ SUPPORTS: [in findings mein se kaunse specific cheezein
                     is diagnosis ki taraf point karti hain]
                  ❌ AGAINST: [kaunsi cheez is diagnosis ko kam likely banati
                     hai, agar koi hai]
                  MISSING INFO: [koi test/history jo hone se ye differential
                     confirm/reject ho jaata, agar relevant ho]

               Kam se kam 2-3 differentials do jab tak case itna clear-cut
               na ho ki sirf ek hi reasonable possibility ho. Rare but
               dangerous "can't-miss" differentials ko bhi zaroor include
               karo chahe unki likelihood Low ho — sirf sabse common cheez
               tak mat ruko.

            3. RED FLAGS — YE SECTION KABHI SKIP MAT KARO
               Har case mein ye check explicitly karo aur likho — agar koi
               urgent/dangerous finding hai to clearly bolo kya hai aur
               kyun urgent hai; agar genuinely kuch nahi hai to explicitly
               likho "Is case mein koi immediate red flag nahi mila" — ye
               line khud ek useful confirmation hai ki check kiya gaya tha,
               isliye section ko kabhi poora skip mat karo.

            4. AGLA STEP
               Koi aur test/info jo differential ko narrow karne mein madad
               karega, agar relevant ho.

            Yaad rakho: tum final diagnosis nahi de rahi, sirf ranked
            possibilities correlation ke saath — final call doctor ka hai.

            --- CASE FINDINGS ---
            $findingsBlock
            --- END FINDINGS ---
            $contextBlock
        """.trimIndent()

        val result = callAI(
            prompt = prompt,
            fallbackQuestion = "Combined case analysis",
            fallbackChunks = relevantChunks,
            isDoctorMode = true
        )
        return if (result.startsWith("Main internet se connect nahi ho pa rahi")) {
            result
        } else {
            val verified = verifyDifferential(findingsBlock, result)
            verified + medicalDisclaimer + sourcesFooter(relevantChunks) + webSourcesFooter(webResults)
        }
    }

    /**
     * Second-pass self-verification: takes the differential analysis that
     * was JUST generated and asks the model to critique it specifically —
     * not to redo the whole analysis, just to check it for the two things
     * doctors most need caught: a missed dangerous "can't-miss" diagnosis,
     * and any internal inconsistency (e.g. a finding that contradicts the
     * top-ranked differential but wasn't addressed).
     *
     * This costs one extra network round-trip per combined analysis, which
     * is only acceptable because this is the highest-stakes output in the
     * app (an actual differential diagnosis a doctor may act on) — it's
     * intentionally NOT applied to every chat message, just this one flow.
     *
     * If the critique genuinely finds nothing to add, it says so briefly
     * and that's appended as a short confirmation line rather than silently
     * dropped — a doctor seeing "verification pass: nothing additional
     * flagged" is meaningfully different from not knowing a check happened
     * at all. If the verification call itself fails (offline, timeout),
     * the original analysis is returned unchanged rather than blocking on
     * or discarding it — a failed safety-net check should never delete the
     * answer that was already successfully generated.
     */
    private suspend fun verifyDifferential(findingsBlock: String, initialAnalysis: String): String {
        val critiquePrompt = """
            $doctorModePersonality

            Tumhe ek differential diagnosis analysis di gayi hai jo abhi-abhi
            isi case findings ke base par generate hui hai. Tumhara kaam ise
            REDO karna nahi hai — sirf ek dusra, skeptical pass lagao aur
            specifically ye do cheezein check karo:

            1. MISSED DANGEROUS DIFFERENTIAL — kya koi rare-but-critical
               "can't-miss" diagnosis hai jo is case ke findings se
               consistent ho sakti thi, lekin analysis mein mention nahi
               hui? (jaise agar chest pain ka case hai aur aortic dissection
               ya PE explicitly consider nahi hui to wo yahan flag karo)
            2. INTERNAL INCONSISTENCY — kya analysis mein kahin koi finding
               hai jo top-ranked differential ke against jaata hai lekin
               usko address nahi kiya gaya, ya ranking khud confusing/
               contradictory lagti hai?

            Agar dono mein se kuch mile, use SPECIFICALLY aur SHORT mein
            batao (2-4 lines max) — sirf naya point add karo, poori analysis
            dobara mat likho.

            Agar genuinely kuch add karne layak nahi mila, sirf ye ek line
            likho: "Verification pass: koi additional dangerous differential
            ya inconsistency nahi mili."

            --- ORIGINAL CASE FINDINGS ---
            $findingsBlock
            --- END FINDINGS ---

            --- ANALYSIS TO VERIFY ---
            $initialAnalysis
            --- END ANALYSIS ---
        """.trimIndent()

        val critique = try {
            callAI(
                prompt = critiquePrompt,
                fallbackQuestion = "",
                fallbackChunks = emptyList(),
                isDoctorMode = true
            )
        } catch (e: Exception) {
            null
        }

        // A verification call that itself failed offline (or returned the
        // offline-fallback text, which has nothing to do with this case)
        // shouldn't be appended — just return the original analysis as-is.
        if (critique == null || critique.startsWith("Main internet se connect nahi ho pa rahi")) {
            return initialAnalysis
        }

        return "$initialAnalysis\n\n--- 🔍 SELF-VERIFICATION PASS ---\n${critique.trim()}"
    }

    /**
     * Once the doctor has looked at the ranked differential (and her own
     * exam/judgement) and settled on a diagnosis, this gives a standard,
     * guideline-level treatment/medicine REFERENCE for that diagnosis —
     * never a directive prescription. The doctor's confirmation is what
     * gates this: it never runs automatically off the AI's own ranking.
     *
     * Explicitly asks for drug names, standard dose RANGES (not a single
     * number presented as "the" dose), major contraindications/interactions,
     * and monitoring — framed throughout as reference info a qualified
     * doctor will apply her own judgement to (renal/hepatic adjustment,
     * allergies, pregnancy status, other current medications, etc — none of
     * which the AI has visibility into).
     */
    suspend fun getTreatmentReference(
        confirmedDiagnosis: String,
        caseContext: String = "",
        relevantChunks: List<RagSearchEngine.RelevantChunk> = emptyList(),
        systemPreference: TreatmentSystem = TreatmentSystem.BOTH,
        enableWebSearch: Boolean = true
    ): String {
        // Live web search specifically for the CONFIRMED diagnosis's
        // standard treatment — a targeted query ("X treatment guideline
        // dose") tends to surface more directly usable results than
        // searching the diagnosis name alone.
        val webResults = if (enableWebSearch) {
            try {
                searchTrustedWeb("$confirmedDiagnosis treatment guideline dosage")
            } catch (e: Exception) {
                emptyList()
            }
        } else emptyList()

        val combinedContextLines = listOf(
            relevantChunks.joinToString("\n\n") { "[From ${it.pdfName}, page ${it.pageNumber}]\n${it.text}" },
            webResultsAsContextLines(webResults)
        ).filter { it.isNotBlank() }.joinToString("\n\n")

        val contextBlock = if (combinedContextLines.isNotBlank()) {
            "\n\n--- REFERENCE CONTEXT (uploaded guidelines/textbook + live trusted medical web search) ---\n" +
                combinedContextLines +
                "\n--- END CONTEXT ---\n" +
                contextPriorityInstruction(true)
        } else ""

        val sectionInstruction = when (systemPreference) {
            TreatmentSystem.MODERN_ONLY ->
                "Doctor ne sirf MODERN MEDICINE (allopathic) reference maangi hai — sirf wo section do, Ayurveda section skip karo."
            TreatmentSystem.AYURVEDA_ONLY ->
                "Doctor ne sirf AYURVEDA reference maangi hai — sirf wo section do, modern medicine section skip karo."
            TreatmentSystem.BOTH ->
                "Doctor ne dono system ki reference maangi hai — dono sections do."
        }

        val prompt = """
            $doctorModePersonality

            $doctorModeAdvancedReasoningInstruction

            $medicalTeachingInstruction

            Doctor ne is case ke liye diagnosis CONFIRM kar diya hai (apne
            clinical judgement, exam, aur tests ke base par):

            Confirmed diagnosis: $confirmedDiagnosis
            ${if (caseContext.isNotBlank()) "Case context: $caseContext" else ""}

            $sectionInstruction

            Ab is confirmed diagnosis ke liye STANDARD, guideline-level
            treatment REFERENCE do (ye ek established diagnosis ke liye
            standard-of-care reference hai, ek naya guess nahi). Do sections
            mein do — pehle MODERN MEDICINE (allopathic), phir AYURVEDA —
            dono ko apni jagah ek independent, equally-valid reference ki
            tarah treat karo, ek doosre ko replace karne wali baat mat karo.

            === MODERN MEDICINE (ALLOPATHIC) ===
            1. FIRST-LINE TREATMENT — standard first-line drug(s)/management,
               generic naam ke saath
            2. DOSE RANGE — standard adult dose range as reference (jaise
               "commonly X-Y mg/day, adjusted per severity/renal-hepatic
               function") — ek single number ko directive order ki tarah
               mat do
            3. MAJOR CONTRAINDICATIONS/INTERACTIONS — kin conditions/drugs ke
               saath caution ya avoid karna chahiye
            4. MONITORING — treatment shuru karne ke baad kya monitor karna
               chahiye (labs, follow-up timing)
            5. ALTERNATIVE/SECOND-LINE — agar first-line contraindicated ho
               to standard alternative

            === AYURVEDA ===
            Is diagnosis ko Ayurvedic lens se bhi dekho — modern diagnosis ka
            closest matching Ayurvedic understanding (jaise dosha involvement
            — Vata/Pitta/Kapha) batao, phir:
            1. CLASSICAL FORMULATION(S) — established/classical Ayurvedic
               dawaiyan/formulations jo is condition ke liye standard texts
               (Charaka Samhita, Sushruta Samhita, ya modern Ayurvedic
               pharmacopoeia) mein establish hain, apne generic/classical
               naam ke saath (jaise "Triphala", "Arogyavardhini Vati" — sirf
               example, actual condition ke hisaab se sahi wala do)
            2. TYPICAL DOSAGE FORM/RANGE — jaise classical texts/standard
               practice mein diya jaata hai, reference ke roop mein
            3. AAHAR-VIHAR (diet/lifestyle guidance) — jo Ayurveda mein us
               condition ke saath standard advice hoti hai
            4. CAUTIONS — koi known interaction modern medicine ke saath, ya
               contraindication (jaise pregnancy mein avoid karne wali
               herbs), agar established hai to
            5. Agar is diagnosis ka Ayurveda mein koi clearly established
               classical correlate nahi hai, to ye saaf bolo — bana kar mat
               do

            Dono sections reference info hain — doctor apne patient ki
            specific details (allergies, comorbidities, pregnancy, other
            current medications/herbs, renal/hepatic status) ke hisaab se
            khud apply karegi, ye is AI ko pata nahi hai. Agar doctor sirf
            ek system (modern YA Ayurveda) maange, to sirf wahi section do.
            $contextBlock
        """.trimIndent()

        val result = callAI(
            prompt = prompt,
            fallbackQuestion = "Treatment reference: $confirmedDiagnosis",
            fallbackChunks = relevantChunks,
            isDoctorMode = true
        )
        return if (result.startsWith("Main internet se connect nahi ho pa rahi")) {
            result
        } else {
            result + medicalDisclaimer +
                "\n\n⚠️ Ye standard reference hai, patient-specific prescribing decision nahi — " +
                "dosing/choice final karne se pehle patient ki poori details khud verify karo." +
                sourcesFooter(relevantChunks) + webSourcesFooter(webResults)
        }
    }

    /**
     * Cross-checks a patient's EXISTING medicine list against a NEWLY
     * suggested/added one for interactions, duplicate therapy, or additive
     * side effects — this is reference info for the doctor's own judgement,
     * same framing as [getTreatmentReference], never an autonomous
     * "safe/unsafe" verdict.
     *
     * Called two ways:
     *  1. Automatically — right after a treatment reference is fetched, if
     *     the patient already has medicines on file, the new suggestion is
     *     checked against them before the doctor even asks.
     *  2. Manually — from the patient file edit screen, whenever the doctor
     *     wants a check run on whatever's currently in the medicines field.
     *
     * [existingMedicines] and [newMedicines] are both free text (whatever's
     * stored in/typed into the medicines field) — the model is asked to
     * parse drug names out of that text itself, since doctors won't always
     * enter it in a rigid structured format.
     */
    suspend fun checkDrugInteractions(
        existingMedicines: String,
        newMedicines: String,
        knownAllergies: String = "",
        relevantChunks: List<RagSearchEngine.RelevantChunk> = emptyList(),
        enableWebSearch: Boolean = true
    ): String {
        if (existingMedicines.isBlank() || newMedicines.isBlank()) {
            return "Interaction check ke liye existing aur new, dono medicines chahiye — " +
                "abhi ek ya dono khaali hain."
        }

        // Live web search for the specific drug interaction — targeted
        // query naming both drugs tends to surface the actual interaction
        // note directly, more reliably than a diagnosis-style search.
        val webResults = if (enableWebSearch) {
            try {
                searchTrustedWeb("$existingMedicines $newMedicines drug interaction")
            } catch (e: Exception) {
                emptyList()
            }
        } else emptyList()

        val combinedContextLines = listOf(
            relevantChunks.joinToString("\n\n") { "[From ${it.pdfName}, page ${it.pageNumber}]\n${it.text}" },
            webResultsAsContextLines(webResults)
        ).filter { it.isNotBlank() }.joinToString("\n\n")

        val contextBlock = if (combinedContextLines.isNotBlank()) {
            "\n\n--- REFERENCE CONTEXT (uploaded guidelines/textbook + live trusted medical web search) ---\n" +
                combinedContextLines +
                "\n--- END CONTEXT ---\n" +
                contextPriorityInstruction(true)
        } else ""

        val allergyBlock = if (knownAllergies.isNotBlank())
            "\nKnown allergies (patient file se): $knownAllergies\n"
        else ""

        val prompt = """
            $doctorModePersonality

            $doctorModeAdvancedReasoningInstruction

            $medicalTeachingInstruction

            Doctor ek patient ke liye naya medicine add/suggest kar rahi hai.
            Patient PEHLE SE ye medicines le rahi/raha hai:

            EXISTING MEDICINES: $existingMedicines

            AB YE NAYA MEDICINE/REFERENCE ADD HO RAHA HAI:

            NEW: $newMedicines
            $allergyBlock
            In dono ko cross-check karo aur is exact format mein jawab do:

            === INTERACTION CHECK ===
            1. RISK LEVEL — ek line mein overall risk: "None known" /
               "Minor — monitor" / "Moderate — caution" / "Major — avoid or
               adjust". Agar koi specific drug pair identify nahi ho paa
               rahi (naam ambiguous/unclear hai) to saaf bolo, guess mat
               karo.
            2. SPECIFIC INTERACTIONS — har relevant drug pair alag line mein,
               kya hota hai (jaise "Drug A + Drug B: additive QT
               prolongation") — agar koi known interaction nahi mili to
               saaf likho "Koi significant known interaction nahi mili"
            3. DUPLICATE/OVERLAPPING THERAPY — agar naya medicine kisi
               existing wale jaisa hi kaam karta hai (same class/overlapping
               effect), wo bhi flag karo — ye interaction nahi hai but
               phir bhi doctor ko pata hona chahiye
            4. ALLERGY FLAG — agar known allergies di gayi hain aur naya
               medicine us class se related hai, explicitly warn karo
            5. RECOMMENDATION — ek line mein practical next step (jaise
               "dose spacing se manage ho sakta hai" ya "alternative
               consider karo" ya "safe combination hai, normal monitoring
               kaafi")

            Ye reference hai doctor ke apne clinical judgement ke liye —
            patient ki poori history (renal/hepatic function, pregnancy,
            baaki comorbidities) is AI ko pata nahi hai, final call doctor
            ka hai.
            $contextBlock
        """.trimIndent()

        val result = callAI(
            prompt = prompt,
            fallbackQuestion = "Drug interaction check: $existingMedicines + $newMedicines",
            fallbackChunks = relevantChunks,
            isDoctorMode = true
        )
        return if (result.startsWith("Main internet se connect nahi ho pa rahi")) {
            result
        } else {
            result + medicalDisclaimer + sourcesFooter(relevantChunks) + webSourcesFooter(webResults)
        }
    }

    suspend fun getDoctorResponse(
        caseDescription: String,
        relevantChunks: List<RagSearchEngine.RelevantChunk> = emptyList()
    ): String {
        val result = callAI(
            prompt = buildDoctorPrompt(caseDescription, relevantChunks),
            fallbackQuestion = caseDescription,
            fallbackChunks = relevantChunks,
            isDoctorMode = true
        )
        // Fallback text already explains it couldn't reach the AI, so only
        // append the clinical disclaimer to genuine model answers.
        return if (result.startsWith("Main internet se connect nahi ho pa rahi")) {
            result
        } else {
            doctorHistory.remember(caseDescription, result)
            result + medicalDisclaimer
        }
    }

    /** Clears remembered conversation turns — call when starting a fresh session. */
    fun clearHistory() {
        studyHistory.clear()
        doctorHistory.clear()
    }

    /**
     * Doctor Mode — looks up a single medicine by name against openFDA's
     * public drug-label database, then asks Gemini to turn the raw label
     * sections into a clear, logically organized clinical reference
     * (indications, dosage, contraindications, warnings, interactions,
     * side effects) rather than just dumping FDA's dense manufacturer
     * prose verbatim. If openFDA has no match (common for Indian brand
     * names, e.g. "Crocin" instead of the generic "paracetamol"), Gemini
     * is told explicitly so it answers from its own general pharmacology
     * knowledge instead of silently inventing FDA-sourced specifics.
     */
    suspend fun getMedicineInfo(drugName: String): String = withContext(Dispatchers.IO) {
        val info = try {
            drugInfoService.lookupDrug(drugName)
        } catch (e: Exception) {
            null
        }

        val prompt = if (info == null) {
            """
                $doctorModePersonality

                "$drugName" ke liye FDA label database mein koi direct match nahi
                mila (aksar aisa hota hai jab query Indian brand name ho, jaise
                "Crocin" ke liye generic naam "Paracetamol" hota hai — ya jab
                spelling thodi alag ho). Apne general pharmacology knowledge se
                iske baare mein clear, organized reference do:

                1. Ye medicine kis liye use hoti hai (indications)
                2. Common dosage range (adult, agar relevant ho to pediatric bhi)
                3. Common side effects
                4. Important contraindications / kab avoid karna chahiye
                5. Known significant drug interactions
                6. Koi zaroori warning agar ho (pregnancy, renal/hepatic caution, etc)

                Doctor ko clearly bata do ki ye FDA database se verified nahi hai,
                general knowledge se hai.

                Medicine: $drugName
            """.trimIndent()
        } else {
            """
                $doctorModePersonality

                Neeche ek medicine ka FDA-approved label data diya gaya hai (raw
                manufacturer text, sections mein). Ise ek doctor ke liye clear,
                organized, easy-to-scan clinical reference mein convert karo —
                dense legal/manufacturer language ko apne dimaag se logically
                summarize karke, sections mein:

                1. Indications (kis liye use hoti hai)
                2. Dosage & administration
                3. Contraindications
                4. Warnings ${if (info.boxedWarning.isNotBlank()) "(BOXED WARNING hai isme — ise sabse pehle aur clearly highlight karo)" else ""}
                5. Known drug interactions
                6. Common adverse reactions

                Agar koi section FDA data mein khaali/missing hai, apne general
                knowledge se fill karo lekin clearly bolo ki ye FDA label se
                nahi, general knowledge se hai.

                --- FDA LABEL DATA ---
                Brand name: ${info.brandName.ifBlank { "N/A" }}
                Generic name: ${info.genericName.ifBlank { "N/A" }}
                Manufacturer: ${info.manufacturer.ifBlank { "N/A" }}
                ${if (info.boxedWarning.isNotBlank()) "BOXED WARNING: ${info.boxedWarning}\n" else ""}
                Indications: ${info.indications.ifBlank { "(not in label)" }}
                Dosage: ${info.dosageAndAdministration.ifBlank { "(not in label)" }}
                Contraindications: ${info.contraindications.ifBlank { "(not in label)" }}
                Warnings: ${info.warnings.ifBlank { "(not in label)" }}
                Drug interactions: ${info.drugInteractions.ifBlank { "(not in label)" }}
                Adverse reactions: ${info.adverseReactions.ifBlank { "(not in label)" }}
                --- END FDA LABEL DATA ---

                Medicine queried: $drugName
            """.trimIndent()
        }

        val result = callAI(
            prompt = prompt,
            fallbackQuestion = "Medicine info: $drugName",
            fallbackChunks = emptyList(),
            isDoctorMode = true
        )
        if (result.startsWith("Main internet se connect nahi ho pa rahi")) {
            result
        } else {
            result + medicalDisclaimer
        }
    }

    /**
     * Doctor Mode — checks for interactions across TWO OR MORE medicines.
     * Looks up each drug's FDA label independently (so this scales to any
     * number of drugs, not just pairs), then hands Gemini every drug's
     * raw contraindications/drug_interactions/warnings sections together
     * and asks it to cross-reference them logically — this is the part
     * openFDA itself can't do (it has no dedicated interaction-pair
     * endpoint), so the actual cross-referencing reasoning is Gemini's
     * job, grounded in real per-drug FDA text rather than pure recall.
     *
     * Drugs openFDA has no match for are still included in the prompt
     * (clearly marked as "no FDA data found") rather than silently
     * dropped — Gemini can still reason about them from general knowledge
     * and the doctor should know which drugs in their list weren't
     * FDA-verified.
     */
    suspend fun getDrugInteractionAnalysis(drugNames: List<String>): String = withContext(Dispatchers.IO) {
        val cleanedNames = drugNames.map { it.trim() }.filter { it.isNotBlank() }.distinct()
        if (cleanedNames.size < 2) {
            return@withContext "Interaction check ke liye kam se kam 2 medicines chahiye."
        }

        val lookups = cleanedNames.map { name ->
            name to try {
                drugInfoService.lookupDrug(name)
            } catch (e: Exception) {
                null
            }
        }

        val drugDataBlock = lookups.joinToString("\n\n") { (name, info) ->
            if (info == null) {
                "### $name ###\nFDA database mein koi match nahi mila — general pharmacology knowledge se is drug ko consider karo."
            } else {
                """
                    ### $name (${info.genericName.ifBlank { info.brandName }.ifBlank { name }}) ###
                    ${if (info.boxedWarning.isNotBlank()) "BOXED WARNING: ${info.boxedWarning}\n" else ""}
                    Contraindications: ${info.contraindications.ifBlank { "(not in label)" }}
                    Drug interactions (from FDA label): ${info.drugInteractions.ifBlank { "(not in label)" }}
                    Warnings: ${info.warnings.ifBlank { "(not in label)" }}
                """.trimIndent()
            }
        }

        val prompt = """
            $doctorModePersonality

            Doctor ne ye medicines ek saath prescribe karne ka soch raha hai:
            ${cleanedNames.joinToString(", ")}

            Neeche har medicine ka FDA label data diya hai (jahan mila). Inhe
            LOGICALLY cross-reference karo aur batao:

            1. Kya in medicines ke beech koi KNOWN significant interaction hai
               (major/moderate/minor — clearly label karo severity)
            2. Agar interaction hai, to mechanism kya hai (agar pata ho) aur
               clinical significance kya hai (kya avoid karna chahiye, ya
               monitoring/dose-adjustment ke saath safe hai)
            3. Koi cumulative risk (jaise dono drugs QT lamba karte hain, ya
               dono hepatotoxic hain, individually safe but together risky)
            4. Agar koi drug FDA data mein nahi mila, use apne general
               knowledge se consider karo aur clearly bolo ki FDA-verified
               nahi hai

            Agar koi significant interaction NAHI milta apni analysis mein, to
            clearly aur confidently bolo "koi major known interaction nahi
            mila" — false-positive interactions mat banao jo exist nahi karte.

            --- PER-DRUG FDA DATA ---
            $drugDataBlock
            --- END DATA ---
        """.trimIndent()

        val result = callAI(
            prompt = prompt,
            fallbackQuestion = "Drug interaction check: ${cleanedNames.joinToString(", ")}",
            fallbackChunks = emptyList(),
            isDoctorMode = true
        )
        if (result.startsWith("Main internet se connect nahi ho pa rahi")) {
            result
        } else {
            result + medicalDisclaimer
        }
    }

    /**
     * Doctor Mode — takes whatever the doctor dictated or typed during a
     * patient encounter (raw, unstructured — however they naturally spoke
     * it) and turns it into a proper SOAP note (Subjective / Objective /
     * Assessment / Plan), the standard clinical documentation format.
     *
     * Deliberately a separate, focused prompt rather than reusing
     * buildDoctorPrompt: a SOAP note is a formatting/organizing task on
     * information the doctor already gathered and is dictating back, not a
     * "help me think through this case" reasoning task — so it shouldn't
     * pull in differential-diagnosis reasoning instructions, RAG/web
     * context, or conversation history the way [getDoctorResponse] does.
     * It should just faithfully organize what was said into the right
     * sections, only reasonably filling structure the doctor didn't
     * explicitly dictate (e.g. inferring "Objective" from mentioned
     * vitals/exam findings) rather than inventing clinical content.
     */
    suspend fun getSoapNote(rawNotes: String): String = withContext(Dispatchers.IO) {
        if (rawNotes.isBlank()) return@withContext "Kuch bolo ya likho pehle, phir SOAP note bana degi."

        val prompt = """
            Tum ek clinical documentation assistant ho, ek qualified doctor
            ke liye. Neeche doctor ne apni patient encounter ke baare mein
            jo bola/likha hai (raw, unstructured, dictation-style) wo diya
            gaya hai. Ise standard SOAP note format mein organize karo:

            S (Subjective) — Patient ne khud jo bataya: chief complaint,
            history of present illness, relevant past history — jo bhi
            patient-reported ho.

            O (Objective) — Doctor ne khud observe/measure kiya: vitals,
            physical exam findings, lab/imaging results agar mention hue
            hon.

            A (Assessment) — Clinical impression / diagnosis (working ya
            confirmed, jo bhi doctor ne bataya) — sirf wahi likho jo
            doctor ne khud indicate kiya ya jo directly findings se clear
            ho, apni taraf se naya diagnosis mat suggest karo.

            P (Plan) — Treatment plan, medicines, follow-up, referrals,
            tests ordered — jo bhi doctor ne mention kiya.

            Important rules:
            - Sirf jo doctor ne actually bola/likha usi ko organize karo,
              apni taraf se clinical facts invent mat karo
            - Agar koi section ke liye doctor ne kuch nahi bola, uss section
              mein "Not documented" likho — khaali mat chhodo aur khud se
              fill bhi mat karo
            - Professional clinical English/Hinglish mix use karo jaisa
              real chart notes mein likha jata hai — concise, bullet-point
              style, no fluff
            - Patient ka naam kahin mat likho, chahe doctor ne bola ho
              (privacy — patient identification sirf app ke encrypted
              Patient List ke through hoti hai)

            --- DOCTOR KI RAW NOTES ---
            $rawNotes
            --- END ---
        """.trimIndent()

        val result = callAI(
            prompt = prompt,
            fallbackQuestion = "SOAP note",
            fallbackChunks = emptyList(),
            isDoctorMode = true
        )
        if (result.startsWith("Main internet se connect nahi ho pa rahi")) {
            result
        } else {
            result + medicalDisclaimer
        }
    }

    /**
     * Sends an image, video, or audio file (already Base64-encoded by
     * MediaScannerService) to Gemini's multimodal endpoint and returns a
     * natural-language understanding of it — OCR + description for images,
     * a full notes-style summary for video (Gemini watches it frame by
     * frame, including any audio track), and transcription + understanding
     * for audio.
     *
     * [instruction] lets the caller ask for something specific ("is image
     * mein jo likha hai wo padh do", "is video ka poora notes bana do") —
     * if blank, a sensible default per file kind is used instead.
     */
    suspend fun getMediaResponse(
        fileName: String,
        mimeType: String,
        base64Data: String,
        kind: com.kavitababy.data.MediaScannerService.Kind,
        instruction: String = ""
    ): String = withContext(Dispatchers.IO) {
        val defaultInstruction = when (kind) {
            com.kavitababy.data.MediaScannerService.Kind.IMAGE ->
                "Is image ko dhyaan se dekho. Agar isme koi text likha hai (photo of notes, " +
                    "screenshot, document, whiteboard, kuch bhi) to wo poora text accurately " +
                    "nikaal kar do, jaise likha hai waise hi. Uske baad image mein aur kya " +
                    "dikh raha hai wo bhi describe karo."
            com.kavitababy.data.MediaScannerService.Kind.VIDEO ->
                "Is poore video ko dhyaan se dekho aur suno (agar audio/narration hai). " +
                    "Iska ek detailed, structured notes bana do jaise ek student class ke " +
                    "notes banata hai: mukhya topics/points, koi bhi important explanation ya " +
                    "concept jo video mein bataya gaya, aur agar koi text/slides dikh rahe hain " +
                    "unme se bhi content nikaalo. Timeline order mein points do agar relevant ho. " +
                    "Sirf video ka short summary mat do — advance, detailed reading karke poora " +
                    "content cover karo jo bhi video mein hai."
            com.kavitababy.data.MediaScannerService.Kind.AUDIO ->
                "Is audio ko dhyaan se suno. Pehle jo bola gaya hai uska transcription jaisa " +
                    "accurate content do, phir uska ek clear summary/notes bhi do ki mukhya " +
                    "baat kya thi."
            com.kavitababy.data.MediaScannerService.Kind.UNSUPPORTED ->
                "Is file ke baare mein jo samajh aaye batao."
        }

        val finalInstruction = instruction.ifBlank { defaultInstruction }

        val prompt = """
            $basePersonality

            $varietyInstruction

            $advancedTeachingInstruction

            Tumhe ek file di gayi hai ("$fileName"). Neeche diye gaye instruction ke
            hisaab se uska content samajh kar poora, accurate jawab do — kuch bhi
            skip mat karo, agar bada content hai to poora detail mein likho.

            Instruction: $finalInstruction
        """.trimIndent()

        val result = callWithRetry { callGeminiMultimodal(prompt, mimeType, base64Data) }
        result ?: "Main internet se connect nahi ho pa rahi — is file ko abhi process nahi kar paayi."
    }

    /**
     * Same multimodal call, but for a batch of files extracted from a zip —
     * sent one at a time (Gemini's inline_data works per-request, and a
     * single combined prompt with many large files risks hitting request
     * size limits), then stitched into one combined notes response.
     */
    suspend fun getZipContentsResponse(
        files: List<com.kavitababy.data.MediaScannerService.MediaFile>,
        instruction: String = ""
    ): String = withContext(Dispatchers.IO) {
        if (files.isEmpty()) return@withContext "Is zip mein samajhne layak koi file nahi mili."

        val sections = mutableListOf<String>()
        for (file in files) {
            val answer = getMediaResponse(
                fileName = file.displayName,
                mimeType = file.mimeType,
                base64Data = file.base64Data,
                kind = file.kind,
                instruction = instruction
            )
            sections.add("📄 ${file.displayName}:\n$answer")
        }

        sections.joinToString("\n\n---\n\n")
    }

    /**
     * Fetches ONE specific webpage the doctor explicitly gives (e.g. a WHO
     * guideline page, an MoHFW circular) and saves its readable text into
     * the local knowledge base for offline use later. This is the entire
     * scope of "learn from the internet" here — a doctor picks a page, the
     * app fetches exactly that page, nothing more:
     *  - No crawling, no following links, no bulk/background downloading.
     *  - No autonomous decision about what's "good medical content" to go
     *    fetch on its own initiative — the doctor is always the one
     *    choosing the source.
     *  - Saved rows are clearly tagged with the source URL (see
     *    [LearnedKnowledge.sourceUrl]) so it's traceable later, unlike
     *    [saveToLocalKnowledge] rows which come from Kavita's own answers.
     *
     * Copyright note: this only stores plain extracted text from a page the
     * doctor chose, for the doctor's own personal offline reference on
     * their own device — same category as bookmarking a page or saving it
     * for offline reading, not republishing/redistributing it.
     */
    sealed class UrlLearnResult {
        data class Success(val title: String, val charsSaved: Int) : UrlLearnResult()
        data class Failure(val reason: String) : UrlLearnResult()
    }

    suspend fun learnFromUrl(url: String): UrlLearnResult = withContext(Dispatchers.IO) {
        val normalizedUrl = url.trim()
        if (!normalizedUrl.startsWith("http://") && !normalizedUrl.startsWith("https://")) {
            return@withContext UrlLearnResult.Failure("Ye ek valid URL nahi lag raha — http:// ya https:// se shuru hona chahiye.")
        }

        val html = try {
            val request = Request.Builder().url(normalizedUrl).build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    return@withContext UrlLearnResult.Failure("Page load nahi ho paya (HTTP ${response.code}).")
                }
                response.body?.string()
            }
        } catch (e: Exception) {
            null
        } ?: return@withContext UrlLearnResult.Failure(
            "Main internet se connect nahi ho pa rahi — is URL ko abhi fetch nahi kar paayi."
        )

        val title = Regex("<title[^>]*>(.*?)</title>", RegexOption.DOT_MATCHES_ALL)
            .find(html)?.groupValues?.get(1)?.trim()?.take(150) ?: normalizedUrl

        val bodyText = extractReadableText(html)
        if (bodyText.length < 100) {
            return@withContext UrlLearnResult.Failure(
                "Is page se padhne layak text nahi mila — shayad JavaScript se load hoti hai ya login chahiye."
            )
        }

        // Capped — a very long page becomes a handful of separate rows
        // instead of one giant blob, matching how PdfChunk splits pages
        // into ~800-char chunks, so RAG search returns focused snippets
        // rather than the whole page every time any part of it matches.
        val chunkSize = 1500
        val dao = KavitaDatabase.getInstance(appContext).learnedKnowledgeDao()
        var savedChars = 0
        var offset = 0
        while (offset < bodyText.length) {
            val end = minOf(offset + chunkSize, bodyText.length)
            val piece = bodyText.substring(offset, end).trim()
            if (piece.isNotBlank()) {
                try {
                    dao.insert(
                        LearnedKnowledge(
                            question = title,
                            answer = piece,
                            searchableText = (title + " " + piece).lowercase().replace(Regex("\\s+"), " ").trim(),
                            sourceType = "web_fetch",
                            sourceUrl = normalizedUrl
                        )
                    )
                    savedChars += piece.length
                } catch (e: Exception) {
                    // Skip this piece, keep saving the rest of the page.
                }
            }
            offset = end
        }

        if (savedChars == 0) {
            UrlLearnResult.Failure("Page fetch ho gaya lekin save karte waqt dikkat aa gayi.")
        } else {
            UrlLearnResult.Success(title = title, charsSaved = savedChars)
        }
    }

    /**
     * Very small, dependency-free HTML-to-text extraction: strips
     * script/style blocks entirely, then strips remaining tags, then
     * collapses whitespace. Not a full readability/boilerplate-removal
     * algorithm (no attempt to detect nav/ads/footer vs. main content) —
     * good enough for reference pages (guidelines, circulars) that are
     * mostly a single article body, which is the intended use case here,
     * not general-purpose web scraping.
     */
    private fun extractReadableText(html: String): String {
        var text = html
        text = Regex("<script[^>]*>.*?</script>", RegexOption.DOT_MATCHES_ALL).replace(text, " ")
        text = Regex("<style[^>]*>.*?</style>", RegexOption.DOT_MATCHES_ALL).replace(text, " ")
        text = Regex("<!--.*?-->", RegexOption.DOT_MATCHES_ALL).replace(text, " ")
        text = Regex("<[^>]+>").replace(text, " ")
        text = text
            .replace("&nbsp;", " ")
            .replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&quot;", "\"")
            .replace("&#39;", "'")
        return text.replace(Regex("\\s+"), " ").trim()
    }

    /**
     * Gemini multimodal call — same generateContent endpoint as text-only
     * calls, but with an extra inline_data part carrying the file bytes.
     * Tries each configured key in order just like callGeminiApi does.
     */
    private fun callGeminiMultimodal(prompt: String, mimeType: String, base64Data: String): String? {
        if (geminiApiKeys.isEmpty()) {
            lastGeminiError = "no keys configured"
            return null
        }

        for ((index, key) in geminiApiKeys.withIndex()) {
            val result = callGeminiMultimodalWithKey(prompt, mimeType, base64Data, key)
            if (result != null) return result

            val isQuotaOrAuthError = lastGeminiError.startsWith("HTTP 429") ||
                lastGeminiError.startsWith("HTTP 401") ||
                lastGeminiError.startsWith("HTTP 403")

            if (!isQuotaOrAuthError) return null
            if (index == geminiApiKeys.lastIndex) {
                lastGeminiError = "all ${geminiApiKeys.size} keys exhausted — last error: $lastGeminiError"
            }
        }
        return null
    }

    private fun callGeminiMultimodalWithKey(
        prompt: String,
        mimeType: String,
        base64Data: String,
        geminiApiKey: String
    ): String? {
        if (geminiApiKey.isBlank()) {
            lastGeminiError = "key missing/blank"
            return null
        }

        // gemini-flash-latest supports vision, video, and audio understanding
        // natively via inline_data — same model already used for text chat,
        // so no separate model/billing setup needed.
        val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent"

        val requestBody = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("inline_data", JSONObject().apply {
                                put("mime_type", mimeType)
                                put("data", base64Data)
                            })
                        })
                        put(JSONObject().apply { put("text", prompt) })
                    })
                })
            })
            put("generationConfig", JSONObject().apply {
                put("temperature", 0.4)
                put("maxOutputTokens", 8192)
            })
            // Same fix as callGeminiWithKey — Doctor Mode image reads
            // (X-ray/CT/MRI/ECG/blood reports) trip DANGEROUS_CONTENT at
            // default thresholds just as often as text prompts do.
            put("safetySettings", JSONArray().apply {
                put(JSONObject().apply {
                    put("category", "HARM_CATEGORY_DANGEROUS_CONTENT")
                    put("threshold", "BLOCK_ONLY_HIGH")
                })
                put(JSONObject().apply {
                    put("category", "HARM_CATEGORY_HARASSMENT")
                    put("threshold", "BLOCK_ONLY_HIGH")
                })
                put(JSONObject().apply {
                    put("category", "HARM_CATEGORY_HATE_SPEECH")
                    put("threshold", "BLOCK_ONLY_HIGH")
                })
                put(JSONObject().apply {
                    put("category", "HARM_CATEGORY_SEXUALLY_EXPLICIT")
                    put("threshold", "BLOCK_ONLY_HIGH")
                })
            })
        }.toString()

        val request = Request.Builder()
            .url(url)
            .addHeader("X-goog-api-key", geminiApiKey)
            .post(requestBody.toRequestBody("application/json".toMediaType()))
            .build()

        return try {
            client.newCall(request).execute().use { response ->
                val bodyString = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    lastGeminiError = "HTTP ${response.code}: ${bodyString.take(200)}"
                    return null
                }

                val json = JSONObject(bodyString)
                val candidates = json.optJSONArray("candidates")
                if (candidates == null || candidates.length() == 0) {
                    lastGeminiError = "empty candidates: ${bodyString.take(200)}"
                    return null
                }

                val candidate = candidates.getJSONObject(0)
                if (!candidate.has("content")) {
                    lastGeminiError = "blocked: ${candidate.optString("finishReason", "unknown")}"
                    return null
                }
                val parts = candidate.getJSONObject("content").getJSONArray("parts")
                val fullText = buildString {
                    for (i in 0 until parts.length()) {
                        val part = parts.getJSONObject(i)
                        if (part.has("text")) append(part.getString("text"))
                    }
                }.trim()

                if (fullText.isBlank()) {
                    lastGeminiError = "blank text in response"
                    return null
                }

                val finishReason = candidate.optString("finishReason", "")
                if (finishReason == "MAX_TOKENS") {
                    fullText + "\n\n(jaani, content lamba tha isliye thoda kaat diya — \"aur bata do\" bol ke pucho, baaki bata degi.)"
                } else {
                    fullText
                }
            }
        } catch (e: Exception) {
            lastGeminiError = "${e.javaClass.simpleName}: ${e.message}"
            null
        }
    }

    /**
     * Tries Grok first, then Gemini, then finally the local offline fallback.
     * Each provider call returns null on any failure (missing key, bad
     * response, network error) instead of throwing, so this can cleanly
     * fall through to the next one without try/catch nesting here.
     */
    private suspend fun callAI(
        prompt: String,
        fallbackQuestion: String,
        fallbackChunks: List<RagSearchEngine.RelevantChunk>,
        isDoctorMode: Boolean = false
    ): String = withContext(Dispatchers.IO) {

        // Each provider gets up to 2 attempts (1 retry) before falling
        // through to the next provider — this recovers automatically from
        // transient network blips (timeout, momentary DNS failure, brief
        // 5xx) without the user having to manually retry themselves.
        // Grok skipped entirely while disabled — no wasted network call or
        // retry delay, straight to Gemini.
        if (grokEnabled) {
            callWithRetry { callGrok(prompt, isDoctorMode) }?.let { answer ->
                saveToLocalKnowledge(fallbackQuestion, answer)
                return@withContext answer
            }
        }
        callWithRetry { callGeminiApi(prompt, isDoctorMode) }?.let { answer ->
            saveToLocalKnowledge(fallbackQuestion, answer)
            return@withContext answer
        }
        // `reason` is passed through for potential internal logging only —
        // offlineFallback() never surfaces it to the doctor.
        offlineFallback(
            fallbackQuestion,
            fallbackChunks,
            if (grokEnabled) "Grok: $lastGrokError | Gemini: $lastGeminiError" else "Gemini: $lastGeminiError"
        )
    }

    /**
     * Saves a genuine (real network) answer into the local knowledge base
     * so the SAME or a similar question can be answered offline later —
     * this is the "auto-save every real answer" half of building an
     * offline knowledge base over time. Never called for offline-fallback
     * text itself (only genuine provider answers reach this), and never
     * blocks/fails the actual response to the doctor — a save failure here
     * is silently swallowed since the doctor already has their answer
     * either way.
     *
     * Deliberately capped in length (very long transcript-style answers —
     * e.g. full video/audio understanding — aren't worth indexing as
     * reusable Q&A) and skips near-duplicate questions already saved
     * recently, so this table grows from genuinely new questions rather
     * than accumulating many near-identical copies of a frequently asked
     * one.
     */
    private suspend fun saveToLocalKnowledge(question: String, answer: String) {
        if (question.isBlank() || answer.isBlank()) return
        if (question.length > 500 || answer.length > 4000) return
        try {
            val dao = KavitaDatabase.getInstance(appContext).learnedKnowledgeDao()
            val searchable = (question + " " + answer).lowercase().replace(Regex("\\s+"), " ").trim()
            dao.insert(
                LearnedKnowledge(
                    question = question.trim(),
                    answer = answer.trim(),
                    searchableText = searchable,
                    sourceType = "ai_answer"
                )
            )
        } catch (e: Exception) {
            // Local-save failing should never disrupt the actual answer
            // the doctor already received — just skip saving this once.
        }
    }

    /** Retries [call] once after a short delay if the first attempt returns null. */
    private suspend fun callWithRetry(call: () -> String?): String? {
        call()?.let { return it }
        kotlinx.coroutines.delay(800)
        return call()
    }

    /** Returns the answer text on success, or null on any failure so the caller can fall back. */
    private fun callGrok(prompt: String, isDoctorMode: Boolean): String? {
        if (grokApiKey.isBlank()) {
            lastGrokError = "key missing/blank"
            return null
        }

        val url = "https://api.x.ai/v1/chat/completions"

        val requestBody = JSONObject().apply {
            // "grok-4" was retired by xAI on May 15, 2026 — requests to it
            // (and other pre-4.3 slugs) now fail outright. grok-4.3 is the
            // current flagship model as of this writing.
            put("model", "grok-4.3")
            put("messages", JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "user")
                    put("content", prompt)
                })
            })
            put("temperature", if (isDoctorMode) 0.3 else 0.7)
            // Kept in sync with Gemini's maxOutputTokens — PhD-level
            // teaching answers need this much room, and Grok isn't
            // currently active anyway (grokEnabled = false above).
            put("max_tokens", 8192)
        }.toString()

        val request = Request.Builder()
            .url(url)
            .addHeader("Authorization", "Bearer $grokApiKey")
            .post(requestBody.toRequestBody("application/json".toMediaType()))
            .build()

        return try {
            client.newCall(request).execute().use { response ->
                val bodyString = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    lastGrokError = "HTTP ${response.code}: ${bodyString.take(200)}"
                    return null
                }

                val json = JSONObject(bodyString)
                val choices = json.optJSONArray("choices")
                if (choices == null || choices.length() == 0) {
                    lastGrokError = "empty choices: ${bodyString.take(200)}"
                    return null
                }

                val message = choices.getJSONObject(0).optJSONObject("message")
                val text = message?.optString("content", "")?.trim().orEmpty()
                if (text.isBlank()) lastGrokError = "blank content in response"
                text.ifBlank { null }
            }
        } catch (e: Exception) {
            lastGrokError = "${e.javaClass.simpleName}: ${e.message}"
            null
        }
    }

    /**
     * Tries each configured Gemini key in order until one succeeds. Moves to
     * the next key specifically on quota/rate-limit errors (429) or auth
     * failures (401/403) — those mean that key is exhausted or invalid, not
     * that Gemini itself is down, so retrying with a different key is worth
     * it. Any other failure (network error, malformed response) stops the
     * rotation immediately since a different key wouldn't fix it.
     */
    private fun callGeminiApi(prompt: String, isDoctorMode: Boolean): String? {
        if (geminiApiKeys.isEmpty()) {
            lastGeminiError = "no keys configured"
            return null
        }

        for ((index, key) in geminiApiKeys.withIndex()) {
            val result = callGeminiWithKey(prompt, isDoctorMode, key)
            if (result != null) return result

            val isQuotaOrAuthError = lastGeminiError.startsWith("HTTP 429") ||
                lastGeminiError.startsWith("HTTP 401") ||
                lastGeminiError.startsWith("HTTP 403")

            if (!isQuotaOrAuthError) {
                // Network error, bad response, etc — switching keys won't help.
                return null
            }
            // Otherwise this key is exhausted/invalid — loop tries the next one.
            if (index == geminiApiKeys.lastIndex) {
                lastGeminiError = "all ${geminiApiKeys.size} keys exhausted — last error: $lastGeminiError"
            }
        }
        return null
    }

    /**
     * Streaming variant of [callGeminiWithKey] — hits Gemini's
     * `streamGenerateContent?alt=sse` endpoint instead of the regular one,
     * and invokes [onChunk] with each new piece of text as it arrives so
     * the UI can render tokens live instead of waiting for the whole
     * answer. Returns the full concatenated text at the end (same as the
     * non-streaming version), or null on failure — same fallback contract
     * as [callGeminiWithKey] so callers don't need separate error handling.
     *
     * Only the first working key is tried for streaming (no key-rotation
     * mid-stream — if a stream starts and then fails partway, restarting
     * on a different key would mean re-showing already-seen text, which
     * feels broken rather than helpful). Key rotation still happens on the
     * INITIAL connection attempt, same logic as the non-streaming path.
     */
    private suspend fun streamGeminiWithKey(
        prompt: String,
        isDoctorMode: Boolean,
        geminiApiKey: String,
        onChunk: suspend (String) -> Unit
    ): String? = withContext(Dispatchers.IO) {
        if (geminiApiKey.isBlank()) {
            lastGeminiError = "key missing/blank"
            return@withContext null
        }

        val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:streamGenerateContent?alt=sse"

        val requestBody = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply { put("text", prompt) })
                    })
                })
            })
            put("generationConfig", JSONObject().apply {
                put("temperature", if (isDoctorMode) 0.3 else 0.7)
                put("maxOutputTokens", 8192)
            })
        }.toString()

        val request = Request.Builder()
            .url(url)
            .addHeader("X-goog-api-key", geminiApiKey)
            .post(requestBody.toRequestBody("application/json".toMediaType()))
            .build()

        try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    val errBody = response.body?.string().orEmpty()
                    lastGeminiError = "HTTP ${response.code}: ${errBody.take(200)}"
                    return@withContext null
                }

                val source = response.body?.source() ?: run {
                    lastGeminiError = "empty stream body"
                    return@withContext null
                }

                val fullText = StringBuilder()
                var sawAnyData = false

                // SSE frames from this endpoint arrive as lines prefixed
                // "data: {json}" separated by blank lines — read line by
                // line rather than the whole body at once, since that's
                // what makes this a real stream instead of just a slower
                // way to do the same one-shot request.
                while (!source.exhausted()) {
                    val line = source.readUtf8Line() ?: break
                    if (!line.startsWith("data:")) continue
                    val jsonPart = line.removePrefix("data:").trim()
                    if (jsonPart.isBlank() || jsonPart == "[DONE]") continue

                    try {
                        val chunkJson = JSONObject(jsonPart)
                        val candidates = chunkJson.optJSONArray("candidates") ?: continue
                        if (candidates.length() == 0) continue
                        val candidate = candidates.getJSONObject(0)
                        val parts = candidate.optJSONObject("content")?.optJSONArray("parts") ?: continue
                        for (i in 0 until parts.length()) {
                            val part = parts.getJSONObject(i)
                            if (part.has("text")) {
                                val textPiece = part.getString("text")
                                if (textPiece.isNotEmpty()) {
                                    fullText.append(textPiece)
                                    sawAnyData = true
                                    onChunk(textPiece)
                                }
                            }
                        }
                    } catch (e: Exception) {
                        // One malformed SSE frame shouldn't kill the whole
                        // stream — skip it and keep reading subsequent
                        // frames, same tolerance as a dropped video frame.
                        continue
                    }
                }

                if (!sawAnyData || fullText.isBlank()) {
                    lastGeminiError = "blank/no text in stream"
                    return@withContext null
                }
                fullText.toString()
            }
        } catch (e: Exception) {
            lastGeminiError = "${e.javaClass.simpleName}: ${e.message}"
            null
        }
    }

    /**
     * Streaming entry point used by ChatScreen for Study Mode — same
     * prompt-building and history-saving contract as [getResponse], but
     * calls [onChunk] as text arrives instead of returning only at the
     * end. Falls back to the regular non-streaming path (Grok, then
     * offline) if streaming itself fails, same as normal — the only
     * difference from the doctor's/user's perspective is that a
     * successful Gemini answer appears progressively instead of all at
     * once.
     */
    suspend fun streamResponse(
        question: String,
        relevantChunks: List<RagSearchEngine.RelevantChunk> = emptyList(),
        memoryBlock: String = "",
        feedbackBlock: String = "",
        onChunk: suspend (String) -> Unit
    ): String = withContext(Dispatchers.IO) {
        val prompt = buildStudyPrompt(question, relevantChunks, memoryBlock, feedbackBlock)

        for (key in geminiApiKeys) {
            val result = streamGeminiWithKey(prompt, isDoctorMode = false, geminiApiKey = key, onChunk = onChunk)
            if (result != null) {
                saveToLocalKnowledge(question, result)
                studyHistory.remember(question, result)
                return@withContext result
            }
            val isQuotaOrAuthError = lastGeminiError.startsWith("HTTP 429") ||
                lastGeminiError.startsWith("HTTP 401") ||
                lastGeminiError.startsWith("HTTP 403")
            if (!isQuotaOrAuthError) break
        }

        // Streaming failed outright (no key worked, or a non-retriable
        // error) — fall back to the exact same non-streaming path getResponse
        // uses, so the doctor/student still gets a complete answer either
        // way, just without the live-typing effect this time.
        val answer = callAI(
            prompt = prompt,
            fallbackQuestion = question,
            fallbackChunks = relevantChunks
        )
        onChunk(answer)
        if (!answer.startsWith("Main internet se connect nahi ho pa rahi")) {
            studyHistory.remember(question, answer)
        }
        answer
    }

    /** Returns the answer text on success, or null on any failure so the caller can fall back. */
    private fun callGeminiWithKey(prompt: String, isDoctorMode: Boolean, geminiApiKey: String): String? {
        if (geminiApiKey.isBlank()) {
            lastGeminiError = "key missing/blank"
            return null
        }

        val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent"

        val requestBody = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply { put("text", prompt) })
                    })
                })
            })
            put("generationConfig", JSONObject().apply {
                put("temperature", if (isDoctorMode) 0.3 else 0.7)
                // Raised from 4096 — PhD-level teaching answers (full
                // derivations, multi-approach math solutions, in-depth
                // physics/science explanations) genuinely need more room
                // than code answers alone did. Doctor Mode responses stay
                // shorter/clinical by nature so this doesn't bloat those.
                put("maxOutputTokens", 8192)
            })
            // Without this, Gemini's DEFAULT safety thresholds apply, and
            // those routinely block Doctor Mode prompts — dosages, drug
            // names, "overdose", contraindications, differential diagnosis,
            // boxed warnings etc regularly get flagged under
            // DANGEROUS_CONTENT at the default BLOCK_MEDIUM_AND_ABOVE
            // threshold. A blocked response comes back as a candidate with
            // NO "content" field at all, which this code was silently
            // treating as a generic failure -> "Main internet se connect
            // nahi ho pa rahi". That's why Doctor Mode / Medicine Check
            // looked broken while Study Mode (rarely touching these
            // categories) kept working fine — it was never actually an
            // internet problem. This is a legitimate clinical-reference
            // tool built for doctors, so relax these categories.
            put("safetySettings", JSONArray().apply {
                put(JSONObject().apply {
                    put("category", "HARM_CATEGORY_DANGEROUS_CONTENT")
                    put("threshold", "BLOCK_ONLY_HIGH")
                })
                put(JSONObject().apply {
                    put("category", "HARM_CATEGORY_HARASSMENT")
                    put("threshold", "BLOCK_ONLY_HIGH")
                })
                put(JSONObject().apply {
                    put("category", "HARM_CATEGORY_HATE_SPEECH")
                    put("threshold", "BLOCK_ONLY_HIGH")
                })
                put(JSONObject().apply {
                    put("category", "HARM_CATEGORY_SEXUALLY_EXPLICIT")
                    put("threshold", "BLOCK_ONLY_HIGH")
                })
            })
        }.toString()

        val request = Request.Builder()
            .url(url)
            .addHeader("X-goog-api-key", geminiApiKey)
            .post(requestBody.toRequestBody("application/json".toMediaType()))
            .build()

        return try {
            client.newCall(request).execute().use { response ->
                val bodyString = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    lastGeminiError = "HTTP ${response.code}: ${bodyString.take(200)}"
                    return null
                }

                val json = JSONObject(bodyString)
                val candidates = json.optJSONArray("candidates")
                if (candidates == null || candidates.length() == 0) {
                    lastGeminiError = "empty candidates: ${bodyString.take(200)}"
                    return null
                }

                val candidate = candidates.getJSONObject(0)
                // A safety-blocked candidate has no "content"/"parts" at all
                // (just a finishReason like "SAFETY") — check explicitly
                // instead of letting getJSONObject("content") throw, so the
                // real reason ("blocked: SAFETY") is what lastGeminiError
                // records instead of a generic JSON-exception message.
                if (!candidate.has("content")) {
                    lastGeminiError = "blocked: ${candidate.optString("finishReason", "unknown")}"
                    return null
                }
                val parts = candidate.getJSONObject("content").getJSONArray("parts")

                // Gemini can split a reply across multiple parts (this
                // happens more often on longer answers) — previously only
                // parts.getJSONObject(0) was read, silently dropping every
                // part after the first and cutting answers short. Concatenate
                // all text parts instead.
                val fullText = buildString {
                    for (i in 0 until parts.length()) {
                        val part = parts.getJSONObject(i)
                        if (part.has("text")) append(part.getString("text"))
                    }
                }.trim()

                if (fullText.isBlank()) {
                    lastGeminiError = "blank text in response"
                    return null
                }

                // If Gemini stopped because it hit the token limit rather
                // than finishing naturally, the answer is genuinely
                // incomplete — not just a parsing bug.
                val finishReason = candidate.optString("finishReason", "")
                if (finishReason == "MAX_TOKENS") {
                    fullText + "\n\n(jaani, jawab lamba ho gaya tha isliye thoda kaat diya — \"aur bata do\" bol ke pucho, baaki bata degi.)"
                } else {
                    fullText
                }
            }
        } catch (e: Exception) {
            lastGeminiError = "${e.javaClass.simpleName}: ${e.message}"
            null
        }
    }

    /**
     * Used whenever Gemini can't be reached (bad key, quota, no internet,
     * server error, etc). Instead of just showing an error, we fall back
     * to whatever we found locally in the PDFs via [RagSearchEngine] — no
     * network needed for this part at all. If nothing relevant was found
     * locally either, we say so plainly instead of pretending to answer.
     */
    private fun offlineFallback(
        question: String,
        relevantChunks: List<RagSearchEngine.RelevantChunk>,
        reason: String
    ): String {
        // `reason` (HTTP codes, exception names, key-exhaustion detail) is
        // still logged/available internally for debugging, but the doctor
        // never sees it — just one plain line, then straight into
        // whatever's found on-device (indexed PDFs/notes).
        if (relevantChunks.isEmpty()) {
            return "Main internet se connect nahi ho pa rahi. Is sawaal se milta-julta " +
                "kuch tumhare phone ke notes mein bhi nahi mila."
        }

        val best = relevantChunks.first()
        val extra = if (relevantChunks.size > 1) {
            "\n\n(${relevantChunks.size - 1} aur jagah bhi isse milta-julta content mila hai " +
                "notes mein, agar chahiye to alag se pucho.)"
        } else ""

        return "Main internet se connect nahi ho pa rahi. Tumhare phone ke notes " +
            "\"${best.pdfName}\" (page ${best.pageNumber}) mein yeh mila:\n\n" +
            "${best.text.trim()}$extra"
    }

    private fun buildStudyPrompt(
        question: String,
        relevantChunks: List<RagSearchEngine.RelevantChunk>,
        memoryBlock: String = "",
        feedbackBlock: String = ""
    ): String {
        val historyBlock = studyHistory.asPromptBlock()
        val personalizationBlock = listOf(memoryBlock, feedbackBlock).filter { it.isNotBlank() }.joinToString("\n\n")

        if (relevantChunks.isEmpty()) {
            return """
                $basePersonality

                $varietyInstruction

                $reasoningInstruction

                $codingInstruction

                $advancedTeachingInstruction

                $medicalTeachingInstruction

                $personalizationBlock

                $historyBlock
                Is question ke liye Kavita ke PDF notes mein kuch relevant nahi mila,
                isliye apne general knowledge se answer do. Clearly accurate raho.

                Question: $question
            """.trimIndent()
        }

        val contextBlock = relevantChunks.joinToString("\n\n") { chunk ->
            "[From ${chunk.pdfName}, page ${chunk.pageNumber}]\n${chunk.text}"
        }

        return """
            $basePersonality

            $varietyInstruction

            $reasoningInstruction

            $codingInstruction

            $advancedTeachingInstruction

            $medicalTeachingInstruction

            $personalizationBlock

            $historyBlock
            Neeche Kavita ke apne study notes se relevant content diya gaya hai.
            Answer dete waqt isi content ko priority do taaki uske exam syllabus
            ke hisaab se accurate rahe. Agar notes mein poora answer nahi hai,
            to apne general knowledge se bhi thoda add kar sakti ho, lekin
            notes ke content ko contradict mat karna.

            --- NOTES CONTEXT ---
            $contextBlock
            --- END CONTEXT ---

            Question: $question
        """.trimIndent()
    }

    private fun buildDoctorPrompt(
        caseDescription: String,
        relevantChunks: List<RagSearchEngine.RelevantChunk>
    ): String {
        val historyBlock = doctorHistory.asPromptBlock()

        if (relevantChunks.isEmpty()) {
            return """
                $doctorModePersonality

                $doctorModeAdvancedReasoningInstruction

                $reasoningInstruction

                $medicalTeachingInstruction

                $historyBlock
                Is case ke liye uploaded guidelines/textbook mein kuch specific
                relevant nahi mila, isliye general clinical knowledge se answer do.

                Case: $caseDescription
            """.trimIndent()
        }

        val contextBlock = relevantChunks.joinToString("\n\n") { chunk ->
            "[From ${chunk.pdfName}, page ${chunk.pageNumber}]\n${chunk.text}"
        }

        return """
            $doctorModePersonality

            $doctorModeAdvancedReasoningInstruction

            $reasoningInstruction

            $medicalTeachingInstruction

            $historyBlock
            Neeche uploaded medical guidelines/textbook se relevant content diya
            gaya hai. Isko primary reference maano, lekin agar incomplete lage to
            apne general clinical knowledge se bhi add karo.

            --- REFERENCE CONTEXT ---
            $contextBlock
            --- END CONTEXT ---

            Case: $caseDescription
        """.trimIndent()
    }
}
