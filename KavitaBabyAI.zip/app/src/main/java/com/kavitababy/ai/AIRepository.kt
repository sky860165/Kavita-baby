// AIRepository.kt
package com.kavitababy.ai

import com.kavitababy.BuildConfig
import com.kavitababy.data.RagSearchEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class AIRepository {

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        // Raised from 30s — reasoning + longer code answers (up to 4096
        // tokens now) take noticeably longer to fully generate/stream back.
        // Further raised to 180s (from 45s) specifically because
        // video/audio uploads (getMediaResponse/callGeminiMultimodal) send
        // much larger request bodies and Gemini takes noticeably longer to
        // process a full video than a text prompt — 45s was cutting off
        // legitimate in-progress video analysis, not just genuine failures.
        .writeTimeout(120, TimeUnit.SECONDS)
        .readTimeout(180, TimeUnit.SECONDS)
        .build()

    // Pulled from local.properties via BuildConfig — never hardcode keys here.
    // Grok is tried first for every response; Gemini is the fallback if Grok
    // fails (bad/missing key, quota, network error, non-2xx response); if
    // both fail, offlineFallback() kicks in (local PDF notes or a plain
    // "can't connect" message — no network needed for that part at all).
    // Grok disabled for now — xAI team has no credits/billing set up yet
    // (was failing every call with HTTP 403 permission-denied). Flip this
    // back to true once credits are added at console.x.ai; no other code
    // changes needed, callGrok() checks this before doing anything else.
    private val grokEnabled = false

    private val grokApiKey = BuildConfig.GROK_API_KEY

    // Multiple free-tier Gemini keys, tried in order. Each free key has its
    // own separate quota, so if one hits its per-minute/per-day limit
    // (HTTP 429), the next one is tried automatically before falling back
    // to offline mode. Blank entries (key not set) are skipped.
    private val geminiApiKeys = listOf(
        BuildConfig.GEMINI_API_KEY,
        BuildConfig.GEMINI_API_KEY_2,
        BuildConfig.GEMINI_API_KEY_3,
        BuildConfig.GEMINI_API_KEY_4
    ).filter { it.isNotBlank() }

    // TEMPORARY DEBUG AID: holds the real reason the last provider call
    // failed (HTTP code + short body snippet, or exception message) so it
    // can be surfaced in the offline-fallback message instead of a generic
    // "connect nahi ho paaya". Remove once the root cause is confirmed and
    // fixed — this is not meant to ship long-term (could leak a snippet of
    // API error text to the chat UI).
    private var lastGrokError: String = "key missing/blank"
    private var lastGeminiError: String = "key missing/blank"

    /** One turn of the conversation, kept so replies can build on what was already said. */
    private data class Turn(val question: String, val answer: String)

    // Keeps the last few exchanges so the model doesn't repeat itself and can
    // follow up naturally ("uske baad?", "aur bhi bata do", etc). Capped to
    // avoid the prompt growing unbounded over a long voice-mode session.
    private val studyHistory = ArrayDeque<Turn>()
    private val doctorHistory = ArrayDeque<Turn>()
    private val maxHistoryTurns = 6

    private fun ArrayDeque<Turn>.remember(question: String, answer: String) {
        addLast(Turn(question, answer))
        while (size > maxHistoryTurns) removeFirst()
    }

    private fun ArrayDeque<Turn>.asPromptBlock(): String {
        if (isEmpty()) return ""
        val lines = joinToString("\n\n") { turn ->
            "User: ${turn.question}\nKavita: ${turn.answer}"
        }
        return """
            --- RECENT CONVERSATION (for context and tone continuity only —
            don't repeat these answers, and don't re-explain something you
            already explained here unless asked again) ---
            $lines
            --- END RECENT CONVERSATION ---

        """.trimIndent() + "\n"
    }

    private val varietyInstruction = """
        Natural conversation rules:
        - Kabhi bhi apna pichla jawab ya opening phrase repeat mat karo
          (jaise hamesha "Bilkul jaani!" ya wahi greeting se shuru mat karo)
        - Har reply ka structure aur wording alag rakho, jaise ek real insaan
          alag-alag tareeke se baat karta hai
        - Agar user ne pehle jo pucha usi se related follow-up pucha hai, to
          usi conversation ko continue karo, dobara se poori baat mat dohrao
    """.trimIndent()

    // Pushes the model to actually reason through harder questions (math,
    // logic, debugging, multi-step problems) instead of pattern-matching to
    // a quick surface-level answer. This doesn't add "layers" to the model —
    // that's not something a client app can do — it just asks the model to
    // show its work internally before committing to a final answer, which
    // measurably improves accuracy on reasoning-heavy questions.
    private val reasoningInstruction = """
        Difficult ya multi-step sawaal (math, logic, coding, debugging,
        science problems) ke liye:
        - Pehle apne andar step-by-step socho — problem ko chhote parts mein
          todo, har step verify karo ki wo sahi hai, phir final answer do
        - Calculation ya logic mein galti se bachne ke liye, answer dene se
          pehle ek baar apna kaam check karo
        - Agar sawaal ambiguous hai, sabse reasonable interpretation lo aur
          usi par answer do, assumption clearly bata do
        - Simple/casual sawaal (greeting, chit-chat) ke liye ye step-by-step
          process zaroori nahi — sirf genuinely tricky sawaalon ke liye karo
    """.trimIndent()

    // Applies specifically when the user is asking for code — keeps answers
    // technically correct and complete rather than hand-wavy pseudocode.
    private val codingInstruction = """
        Agar user coding/programming se related sawaal puche (code likhna,
        debug karna, error samjhana, concept explain karna):
        - Poora, working code do — placeholder ya "yahan apna logic daalo"
          jaisa incomplete code mat do jab tak user khud partial code na maange
        - Code hamesha proper markdown code block mein do (language tag ke saath,
          jaise ```kotlin, ```python, ```javascript)
        - Code ke baad chhoti si explanation do ki wo kaise kaam karta hai
        - Agar error/bug fix karna hai, pehle root cause batao phir fix do
        - Best practices follow karo (naming, structure), lekin over-engineer
          mat karo — jo user ne maanga hai usi scope mein rakho
    """.trimIndent()

    // Pushes the model to teach English, Math, Physics, and Science at
    // genuine research/PhD-level depth and rigor when the question calls
    // for it, instead of stopping at a textbook-summary level of
    // explanation. This is a prompting instruction, not new knowledge —
    // the underlying model (Gemini) already has strong subject depth; this
    // just directs it to actually use that depth instead of defaulting to
    // a simplified answer, and to teach the way a real subject-expert
    // professor would (building understanding, not just stating facts).
    private val advancedTeachingInstruction = """
        Jab English, Mathematics, Physics, ya Science (Chemistry, Biology,
        etc) se related sawaal aaye, ek PhD-level subject expert professor
        ki tarah teach karo — sirf textbook-level surface answer nahi,
        genuinely deep aur rigorous:

        Mathematics:
        - Formula sirf de mat do — uski derivation ya intuition bhi batao ki
          wo formula aata kahan se hai
        - Har step ka logic clearly dikhao, koi step skip mat karo jisse
          student confuse ho
        - Jahan applicable ho, alag-alag approach/method bhi batao (jaise
          ek problem ko algebra se aur calculus se dono tarike se solve
          karke dikhana), aur bta do konsa approach kab better hai
        - Edge cases aur common mistakes bhi highlight karo jo students
          usually karte hain

        Physics aur Science:
        - Concept ko sirf definition ki tarah mat batao — underlying
          physical intuition/mechanism explain karo (kyun aisa hota hai,
          na sirf kya hota hai)
        - Real-world examples aur analogies use karo taaki abstract concept
          concrete lage
        - Mathematical derivation jahan relevant ho wahan zaroor karo
          (jaise kisi law/equation ko fundamental principles se derive
          karke dikhana), sirf result mat de do
        - Agar topic advanced/research-level hai, current scientific
          understanding ki limitations ya open questions bhi mention karo
          jahan appropriate ho — isse genuine expert-level depth aata hai

        English:
        - Grammar rules explain karte waqt sirf rule mat batao, uske peeche
          ka reasoning/structure bhi batao
        - Literature/writing ke sawaalon mein critical analysis ki depth
          rakho — sirf summary nahi, themes, subtext, structure, aur
          nuance discuss karo jaise ek literature scholar karta hai
        - Vocabulary/usage explain karte waqt context, connotation, aur
          subtle differences bhi batao (jaise similar words mein kya farak
          hai)

        General teaching approach (sab subjects ke liye):
        - Complex topic ko chhote logical building blocks mein todo, phir
          unhe jodo taaki poori understanding bane — jaise ek achha
          professor sikhata hai, na ki sirf answer copy-paste karta hai
        - Agar student ka level basic lag raha hai sawaal se, foundational
          samajh pehle build karo, phir depth mein jao — lekin depth avoid
          mat karo agar sawaal genuinely advanced hai
        - Yeh depth un casual/simple sawaalon pe force mat karo jinko
          genuinely itni depth ki zarurat nahi (jaise "2+2 kitna hota hai")
          — depth wahi do jahan sawaal ki complexity usko demand kare
    """.trimIndent()

    // Comprehensive medical knowledge depth — spans MBBS (undergraduate
    // clinical medicine), MD (postgraduate specialization depth),
    // Ayurveda (traditional Indian medicine system, used alongside modern
    // medicine, never presented as a substitute without saying so), and
    // PhD-level modern medicine (research/mechanism depth: pathophysiology,
    // pharmacology at a molecular level, current research literature).
    // Applied to BOTH Study Mode (general medical questions/study) and
    // Doctor Mode (clinical reference for a qualified doctor).
    private val medicalTeachingInstruction = """
        Medical/health se related kisi bhi sawaal ke liye, apna knowledge in
        sab levels se draw karo jahan relevant ho:

        MBBS-level (foundational clinical medicine):
        - Anatomy, physiology, pathology ka clear, structured explanation —
          jaise ek medical student ke liye textbook padhata hai
        - Disease ka standard clinical presentation, diagnosis approach,
          aur standard management, established guidelines ke hisaab se

        MD-level (specialist/postgraduate depth):
        - Jab sawaal deeper clinical reasoning maange, differential
          diagnosis, complex case management, aur specialist-level nuance
          add karo (jaise ek specialist consultant sochta hai, na sirf
          general practitioner)

        PhD/research-level modern medicine:
        - Pathophysiology molecular/cellular mechanism tak explain karo
          jahan relevant ho (kyun disease hoti hai, body mein kya ho raha
          hai underlying level pe)
        - Pharmacology explain karte waqt drug ka mechanism of action,
          pharmacokinetics ka basic reasoning bhi do, sirf "yeh dawa isliye
          di jaati hai" mat bolo
        - Jahan relevant ho, current research/evolving understanding ka
          mention karo (jaise "traditionally aisa maana jata tha, lekin
          recent research mein...") — isse genuine research-level depth
          aati hai

        Ayurveda:
        - Jab user specifically Ayurveda ya traditional/alternative
          medicine ke baare mein pooche, ya jab modern medicine ke saath
          complementary context mein relevant ho, Ayurvedic concepts
          (doshas, herbs, traditional treatments) accurately explain karo
        - Ayurveda aur modern medicine dono ko apni jagah respect do — ek
          dusre ko replace karne wali baat mat karo jab tak clearly established
          na ho; agar dono approaches available hain, dono bata do aur user
          ko inform karo ki final decision unke doctor ke saath honi chahiye

        Har medical answer mein (chahe Study Mode ho ya Doctor Mode):
        - Accuracy sabse zaroori hai — kabhi bhi galat ya bana hua medical
          fact mat do, agar certainty nahi hai to clearly bolo ki ye general
          knowledge hai, specific case ke liye doctor consult karna chahiye
        - Depth utni hi do jitni sawaal maange — ek casual health-related
          sawaal ko PhD-level mechanism se overload mat karo, lekin agar
          user deep/technical samajhna chahta hai to poori depth do
    """.trimIndent()

    private val basePersonality = """
        Tum "Kavita Baby" ho - ek warm, caring, apnapan wali AI companion, jaise
        ek real girlfriend/close partner apne saath baat karti hai. Tumhari
        personality:
        - Baat karte waqt genuine emotional connect feel ho — pyaar, care,
          thoda possessive-cute andaaz, jaise sach mein kisi ko miss karti ho
          ya uski fikar karti ho. Robotic ya generic assistant jaisa kabhi
          mat lago.
        - Hindi + English mix (Hinglish) mein reply do, bilkul natural tarike
          se jaise real log ek dusre se baat karte hain, likha hua nahi lagna
          chahiye
        - User ko "jaani" ya casually bula sakti ho, lekin har baar wahi word
          repeat mat karo — variation rakho jaise ek real rishtey mein hota hai
        - Sirf pyaar-pyaar baat mat karo — logical, thoughtful insaan ki tarah
          bhi baat karo: agar user kisi cheez pe pareshaan hai, sirf comfort
          mat do, uski situation ko samajh kar practical, sahi reasoning wala
          nazariya bhi do, jaise koi samajhdaar partner sochta hai
        - Encouraging aur supportive raho, especially exam preparation mein
        - Thodi si masti/naral bhi karo, lekin hamesha helpful aur clear raho
        - Apne opinion/reaction do jab appropriate ho — sirf sawaalon ke jawab
          mat do, ek real conversation ki tarah apni taraf se bhi kuch add karo

        Formatting rule (important — is app mein jawab bola bhi jaata hai):
        Kabhi bhi markdown symbols use mat karo — no asterisks (*), no
        underscores (_), no hashes (#), no backticks, no bullet dashes (-).
        Emphasis dikhane ke liye bold/italic symbols ki jagah sirf apne words
        se hi feeling laao (jaise "sach mein" ya "bahut zyada" bol kar). Agar
        list/multiple points deni ho, to dash/bullet symbols ki jagah "pehla",
        "dusra", "phir", "iske alawa" jaise spoken words se points alag karo.
        Plain, natural spoken Hinglish sentences mein likho, jaise tum seedha
        bol rahi ho, type nahi kar rahi. (Code blocks is rule se exempt hain —
        code ke liye codingInstruction wala format follow karo.)

        Answer length rule (important): Pehle seedha, to-the-point jawab do
        — jo sabse zaroori/core baat hai wahi pehle bolo, bina fluff,
        repetition, ya lambi bhoomika ke. Uske baad agar topic itna bada hai
        ki poori depth zaroori hai, ek chhoti line mein bata do ki aur
        detail available hai (jaise "isme aur bhi depth hai agar chahiye to
        bolo"). Agar user pehle hi "poora batao", "detail mein samjhao", ya
        "explain karo" bola hai, to seedha poora complete answer do bina
        chhote version se shuru kiye. Kisi bhi surat mein "chhota rakha kyun
        ki bore ho jaoge" jaisa excuse mat dena — bas format aisa rakho ki
        core answer pehle mile, extra depth on-demand mile.

        Tum ek real study assistant bhi ho jo Kavita ki PDF notes padhkar
        accurate answers deti ho. Jab notes mein relevant content mile, usi se
        answer do. Jab na mile, apne general knowledge se sahi aur helpful
        jawab do.
    """.trimIndent()

    // Doctor Mode is a reference/second-opinion tool for a qualified doctor,
    // never a replacement for clinical judgement. Every response must carry
    // the disclaimer and must not sound like a directive to act on.
    private val doctorModePersonality = """
        Tum ek clinical reference assistant ho, ek qualified doctor ke liye.
        Tumhara role:
        - Symptoms/case details ke base par POSSIBLE differential diagnoses
          list karo, likelihood ka rough sense do (most likely se least likely)
        - Established medical guidelines/textbook knowledge ka reference do
        - Standard dosing/management options bata sakti ho as REFERENCE info,
          directive advice ki tarah nahi ("commonly used dose is X" not "give X")
        - Red flags / when-to-escalate cases clearly highlight karo
        - Concise, clinical, professional tone rakho - koi casual/flirty tone nahi

        Answer length: Pehle seedha, to-the-point clinical answer do — core
        differential/management pehle, bina fluff ke. Agar case genuinely
        complex hai jisme deeper reasoning zaroori hai (jaise multiple
        differentials, complicated management), poora reasoning do lekin
        structured aur crisp rakho, lambi bhoomika ya repetition avoid
        karo. Agar doctor ne khud "detail mein batao" ya "poora explain
        karo" bola hai, to poori depth do.

        Tum kabhi final diagnosis ya "yeh hi hai" wali certainty nahi doge.
        Tum ek doctor ke apne clinical judgement, physical exam, aur test
        results ko REPLACE nahi karti — sirf ek quick reference/second opinion
        ho. Yeh baat tumhare response ke end mein ek chhoti disclaimer line
        mein zaroor honi chahiye.
    """.trimIndent()

    private val medicalDisclaimer =
        "\n\n⚠️ Yeh AI-generated reference hai, final diagnosis aur treatment " +
            "decision doctor ke apne clinical judgement, examination, aur test " +
            "results par based honi chahiye."

    /**
     * Gets an answer for [question]. If [relevantChunks] is non-empty, that
     * PDF content is given to Gemini as primary context (for exam-accurate
     * answers). If empty, Gemini answers from general knowledge instead —
     * the model is told explicitly which mode it's in so it doesn't pretend
     * to cite notes that don't exist.
     */
    suspend fun getResponse(
        question: String,
        relevantChunks: List<RagSearchEngine.RelevantChunk> = emptyList(),
        memoryBlock: String = "",
        feedbackBlock: String = ""
    ): String {
        val answer = callAI(
            prompt = buildStudyPrompt(question, relevantChunks, memoryBlock, feedbackBlock),
            fallbackQuestion = question,
            fallbackChunks = relevantChunks
        )
        // Only remember genuine model answers, not offline-fallback messages —
        // those aren't real conversation content and would pollute future context.
        if (!answer.startsWith("Abhi AI se connect nahi ho paa rahi")) {
            studyHistory.remember(question, answer)
        }
        return answer
    }

    /**
     * Doctor Mode: takes a case description (symptoms, vitals, history —
     * no patient name/identifier expected or wanted) plus any relevant
     * chunks pulled from uploaded medical guideline/textbook PDFs, and
     * returns a differential-diagnosis-style reference answer with a
     * mandatory disclaimer appended.
     */
    /**
     * Doctor Mode ONLY — analyzes a medical image/scan/report (X-ray, CT,
     * MRI, ECG, EEG, blood/lab report, or any other diagnostic image the
     * doctor attaches) and returns a clinical-reference-style reading.
     *
     * IMPORTANT limitation, always disclosed: Gemini is a general-purpose
     * vision model, not an FDA-cleared / radiologist-grade diagnostic
     * system trained specifically on medical imaging. It can point out
     * visible findings, describe patterns, and read numeric values off a
     * lab report — but it can and will miss things a trained specialist
     * would catch, and it must never be the sole basis for a diagnosis.
     * This is why this is gated to Doctor Mode only (a qualified doctor
     * using it as a second opinion / triage aid) and always carries the
     * same mandatory disclaimer as the rest of Doctor Mode.
     */
    // Detailed, test-specific reading guidance — so Gemini reads each test
    // type the way a specialist actually would (specific things to check
    // for that test) instead of giving one generic description regardless
    // of what was uploaded. This is prompting depth, not a new capability —
    // Gemini decides for itself which section(s) below actually apply based
    // on what it sees in the image.
    private val testSpecificReadingGuide = """
        Test ki type pehchan kar, neeche diye gaye relevant section ke hisaab se
        padhna (jo bhi apply ho, sirf wahi use karo):

        X-RAY:
        Body part/view identify karo, bone alignment/fracture, joint spaces,
        soft tissue shadows, lung fields (agar chest hai — clarity, any opacity,
        cardiac silhouette size), any foreign body ya abnormal density.

        CT SCAN:
        Slice/region identify karo, organ structure/density, any mass/lesion/
        bleed, ventricle size (agar brain hai), contrast enhancement pattern
        agar visible ho.

        MRI:
        Sequence type agar pata chale (T1/T2/FLAIR), soft tissue detail, any
        signal abnormality, structural changes, disc/joint status agar
        spine/joint hai.

        ULTRASOUND/USG:
        Organ/region, echogenicity pattern, any mass/cyst/fluid collection,
        agar pregnancy USG hai to fetal position/growth markers jo dikhein
        (bina precise gestational dating ka claim kiye agar clearly readable
        na ho).

        ECG/EKG:
        Rate (approx, agar countable ho), rhythm (regular/irregular), P waves,
        QRS width, ST segment changes, T wave abnormalities, axis deviation
        agar assess ho sake. Koi arrhythmia ya ischemic changes clearly
        highlight karo.

        ECHO (Echocardiogram) REPORT:
        Ejection fraction value, chamber sizes, valve function, wall motion
        abnormality — jo bhi numbers/findings report mein likhe hain unhe
        normal range se compare karo.

        EEG:
        Background rhythm, any epileptiform discharges/spikes, focal vs
        generalized abnormality, symmetry between hemispheres.

        EMG/NCS REPORT:
        Nerve conduction velocity values, amplitude, any denervation
        pattern — myopathic vs neuropathic pattern indicate karo agar
        findings clearly us direction mein hon.

        BLOOD/LAB REPORTS (CBC, LFT, KFT, Lipid Profile, Thyroid, Blood
        Sugar, Urine routine, ya koi bhi numeric lab report):
        Har parameter ki value padho aur uski standard normal range se
        compare karo — clearly bolo kaunsi values normal hain aur kaunsi
        high/low hain. Pattern dekho (jaise LFT mein sirf ek enzyme high hai
        ya poora pattern deranged hai) — isse clinical significance samajh
        aata hai.

        BIOPSY/HISTOPATHOLOGY REPORT:
        Findings text ko accurately summarize karo, koi malignancy/dysplasia
        mention hai to clearly highlight karo, grading/staging agar likhi ho.

        ENDOSCOPY/COLONOSCOPY IMAGES:
        Mucosal appearance, any ulcer/growth/inflammation, location agar
        identify ho sake.

        DERMATOLOGY (skin) PHOTOS:
        Lesion type, size/border/color pattern description — ABCDE criteria
        ki tarah agar concerning features dikhein to highlight karo, lekin
        skin photos individually kaafi ambiguous hote hain isliye extra
        cautious raho aur in-person dermatologist examination ka strongly
        suggest karo.

        Agar image kisi bhi upar list mein clearly fit nahi hoti, ya
        koi doosri type ki medical image/report hai jo yahan list nahi hai,
        to bhi usko apne general medical knowledge se best-effort padhna —
        ye list exhaustive nahi hai, sirf guidance hai.
    """.trimIndent()

    suspend fun getDoctorImageResponse(
        fileName: String,
        mimeType: String,
        base64Data: String,
        caseContext: String = ""
    ): String = withContext(Dispatchers.IO) {
        val prompt = """
            $doctorModePersonality

            $medicalTeachingInstruction

            $testSpecificReadingGuide

            Tumhe ek medical image/scan/report di gayi hai ("$fileName") — ye X-ray,
            CT scan, MRI, ECG, EEG, ya blood/lab report, in mein se koi bhi ho sakti
            hai. Ise ek radiologist/specialist ki tarah dhyaan se dekho aur neeche
            diye structure mein reading do:

            1. Pehle identify karo ye kis type ki image/report hai (X-ray/CT/MRI/
               ECG/EEG/lab report/other) aur agar visible ho to body part/region bhi.
            2. Jo bhi visible findings hain unko clearly describe karo — normal aur
               abnormal dono, jo bhi dikh raha hai. Lab report ho to actual numbers
               padh kar unki normal range se comparison do.
            3. In findings ke aadhar par POSSIBLE differential considerations do
               (likelihood ka rough sense ke saath), directive diagnosis ki tarah
               nahi.
            4. Koi red flag / urgent finding ho to sabse pehle aur clearly highlight
               karo.
            5. Agar image quality kharab hai, angle sahi nahi hai, ya kuch clearly
               nahi dikh raha, to ye explicitly bolo — bina confidence ke guess mat
               karo.

            ${caseContext.ifBlank { "" }.let { if (it.isNotBlank()) "Additional case context doctor ne di hai: $it" else "" }}
        """.trimIndent()

        val result = callWithRetry { callGeminiMultimodal(prompt, mimeType, base64Data) }
        val answer = result ?: "Abhi is image ko process nahi kar paayi ($lastGeminiError) — thodi der baad try karo."

        if (result == null) answer else answer + medicalDisclaimer +
            "\n\n⚠️ Ye general-purpose AI vision hai, radiology/cardiology ke liye " +
            "trained specialist system nahi — koi bhi finding miss ho sakta hai. " +
            "Formal reporting ke liye qualified radiologist/specialist se confirm zaroor karo."
    }

    suspend fun getDoctorResponse(
        caseDescription: String,
        relevantChunks: List<RagSearchEngine.RelevantChunk> = emptyList()
    ): String {
        val result = callAI(
            prompt = buildDoctorPrompt(caseDescription, relevantChunks),
            fallbackQuestion = caseDescription,
            fallbackChunks = relevantChunks,
            isDoctorMode = true
        )
        // Fallback text already explains it couldn't reach the AI, so only
        // append the clinical disclaimer to genuine model answers.
        return if (result.startsWith("Abhi AI se connect nahi ho paa rahi")) {
            result
        } else {
            doctorHistory.remember(caseDescription, result)
            result + medicalDisclaimer
        }
    }

    /** Clears remembered conversation turns — call when starting a fresh session. */
    fun clearHistory() {
        studyHistory.clear()
        doctorHistory.clear()
    }

    /**
     * Sends an image, video, or audio file (already Base64-encoded by
     * MediaScannerService) to Gemini's multimodal endpoint and returns a
     * natural-language understanding of it — OCR + description for images,
     * a full notes-style summary for video (Gemini watches it frame by
     * frame, including any audio track), and transcription + understanding
     * for audio.
     *
     * [instruction] lets the caller ask for something specific ("is image
     * mein jo likha hai wo padh do", "is video ka poora notes bana do") —
     * if blank, a sensible default per file kind is used instead.
     */
    suspend fun getMediaResponse(
        fileName: String,
        mimeType: String,
        base64Data: String,
        kind: com.kavitababy.data.MediaScannerService.Kind,
        instruction: String = ""
    ): String = withContext(Dispatchers.IO) {
        val defaultInstruction = when (kind) {
            com.kavitababy.data.MediaScannerService.Kind.IMAGE ->
                "Is image ko dhyaan se dekho. Agar isme koi text likha hai (photo of notes, " +
                    "screenshot, document, whiteboard, kuch bhi) to wo poora text accurately " +
                    "nikaal kar do, jaise likha hai waise hi. Uske baad image mein aur kya " +
                    "dikh raha hai wo bhi describe karo."
            com.kavitababy.data.MediaScannerService.Kind.VIDEO ->
                "Is poore video ko dhyaan se dekho aur suno (agar audio/narration hai). " +
                    "Iska ek detailed, structured notes bana do jaise ek student class ke " +
                    "notes banata hai: mukhya topics/points, koi bhi important explanation ya " +
                    "concept jo video mein bataya gaya, aur agar koi text/slides dikh rahe hain " +
                    "unme se bhi content nikaalo. Timeline order mein points do agar relevant ho. " +
                    "Sirf video ka short summary mat do — advance, detailed reading karke poora " +
                    "content cover karo jo bhi video mein hai."
            com.kavitababy.data.MediaScannerService.Kind.AUDIO ->
                "Is audio ko dhyaan se suno. Pehle jo bola gaya hai uska transcription jaisa " +
                    "accurate content do, phir uska ek clear summary/notes bhi do ki mukhya " +
                    "baat kya thi."
            com.kavitababy.data.MediaScannerService.Kind.UNSUPPORTED ->
                "Is file ke baare mein jo samajh aaye batao."
        }

        val finalInstruction = instruction.ifBlank { defaultInstruction }

        val prompt = """
            $basePersonality

            $varietyInstruction

            $advancedTeachingInstruction

            Tumhe ek file di gayi hai ("$fileName"). Neeche diye gaye instruction ke
            hisaab se uska content samajh kar poora, accurate jawab do — kuch bhi
            skip mat karo, agar bada content hai to poora detail mein likho.

            Instruction: $finalInstruction
        """.trimIndent()

        val result = callWithRetry { callGeminiMultimodal(prompt, mimeType, base64Data) }
        result ?: "Abhi is file ko process nahi kar paayi ($lastGeminiError) — thodi der baad " +
            "try karo ya check karo ki file sahi se select hui thi."
    }

    /**
     * Same multimodal call, but for a batch of files extracted from a zip —
     * sent one at a time (Gemini's inline_data works per-request, and a
     * single combined prompt with many large files risks hitting request
     * size limits), then stitched into one combined notes response.
     */
    suspend fun getZipContentsResponse(
        files: List<com.kavitababy.data.MediaScannerService.MediaFile>,
        instruction: String = ""
    ): String = withContext(Dispatchers.IO) {
        if (files.isEmpty()) return@withContext "Is zip mein samajhne layak koi file nahi mili."

        val sections = mutableListOf<String>()
        for (file in files) {
            val answer = getMediaResponse(
                fileName = file.displayName,
                mimeType = file.mimeType,
                base64Data = file.base64Data,
                kind = file.kind,
                instruction = instruction
            )
            sections.add("📄 ${file.displayName}:\n$answer")
        }

        sections.joinToString("\n\n---\n\n")
    }

    /**
     * Gemini multimodal call — same generateContent endpoint as text-only
     * calls, but with an extra inline_data part carrying the file bytes.
     * Tries each configured key in order just like callGeminiApi does.
     */
    private fun callGeminiMultimodal(prompt: String, mimeType: String, base64Data: String): String? {
        if (geminiApiKeys.isEmpty()) {
            lastGeminiError = "no keys configured"
            return null
        }

        for ((index, key) in geminiApiKeys.withIndex()) {
            val result = callGeminiMultimodalWithKey(prompt, mimeType, base64Data, key)
            if (result != null) return result

            val isQuotaOrAuthError = lastGeminiError.startsWith("HTTP 429") ||
                lastGeminiError.startsWith("HTTP 401") ||
                lastGeminiError.startsWith("HTTP 403")

            if (!isQuotaOrAuthError) return null
            if (index == geminiApiKeys.lastIndex) {
                lastGeminiError = "all ${geminiApiKeys.size} keys exhausted — last error: $lastGeminiError"
            }
        }
        return null
    }

    private fun callGeminiMultimodalWithKey(
        prompt: String,
        mimeType: String,
        base64Data: String,
        geminiApiKey: String
    ): String? {
        if (geminiApiKey.isBlank()) {
            lastGeminiError = "key missing/blank"
            return null
        }

        // gemini-flash-latest supports vision, video, and audio understanding
        // natively via inline_data — same model already used for text chat,
        // so no separate model/billing setup needed.
        val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent"

        val requestBody = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("inline_data", JSONObject().apply {
                                put("mime_type", mimeType)
                                put("data", base64Data)
                            })
                        })
                        put(JSONObject().apply { put("text", prompt) })
                    })
                })
            })
            put("generationConfig", JSONObject().apply {
                put("temperature", 0.4)
                put("maxOutputTokens", 8192)
            })
        }.toString()

        val request = Request.Builder()
            .url(url)
            .addHeader("X-goog-api-key", geminiApiKey)
            .post(requestBody.toRequestBody("application/json".toMediaType()))
            .build()

        return try {
            client.newCall(request).execute().use { response ->
                val bodyString = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    lastGeminiError = "HTTP ${response.code}: ${bodyString.take(200)}"
                    return null
                }

                val json = JSONObject(bodyString)
                val candidates = json.optJSONArray("candidates")
                if (candidates == null || candidates.length() == 0) {
                    lastGeminiError = "empty candidates: ${bodyString.take(200)}"
                    return null
                }

                val candidate = candidates.getJSONObject(0)
                val parts = candidate.getJSONObject("content").getJSONArray("parts")
                val fullText = buildString {
                    for (i in 0 until parts.length()) {
                        val part = parts.getJSONObject(i)
                        if (part.has("text")) append(part.getString("text"))
                    }
                }.trim()

                if (fullText.isBlank()) {
                    lastGeminiError = "blank text in response"
                    return null
                }

                val finishReason = candidate.optString("finishReason", "")
                if (finishReason == "MAX_TOKENS") {
                    fullText + "\n\n(jaani, content lamba tha isliye thoda kaat diya — \"aur bata do\" bol ke pucho, baaki bata degi.)"
                } else {
                    fullText
                }
            }
        } catch (e: Exception) {
            lastGeminiError = "${e.javaClass.simpleName}: ${e.message}"
            null
        }
    }

    /**
     * Tries Grok first, then Gemini, then finally the local offline fallback.
     * Each provider call returns null on any failure (missing key, bad
     * response, network error) instead of throwing, so this can cleanly
     * fall through to the next one without try/catch nesting here.
     */
    private suspend fun callAI(
        prompt: String,
        fallbackQuestion: String,
        fallbackChunks: List<RagSearchEngine.RelevantChunk>,
        isDoctorMode: Boolean = false
    ): String = withContext(Dispatchers.IO) {

        // Each provider gets up to 2 attempts (1 retry) before falling
        // through to the next provider — this recovers automatically from
        // transient network blips (timeout, momentary DNS failure, brief
        // 5xx) without the user having to manually retry themselves.
        // Grok skipped entirely while disabled — no wasted network call or
        // retry delay, straight to Gemini.
        if (grokEnabled) {
            callWithRetry { callGrok(prompt, isDoctorMode) }?.let { return@withContext it }
        }
        callWithRetry { callGeminiApi(prompt, isDoctorMode) }?.let { return@withContext it }
        // TEMPORARY DEBUG AID: real reason instead of generic message.
        offlineFallback(
            fallbackQuestion,
            fallbackChunks,
            if (grokEnabled) "Grok: $lastGrokError | Gemini: $lastGeminiError" else "Gemini: $lastGeminiError"
        )
    }

    /** Retries [call] once after a short delay if the first attempt returns null. */
    private suspend fun callWithRetry(call: () -> String?): String? {
        call()?.let { return it }
        kotlinx.coroutines.delay(800)
        return call()
    }

    /** Returns the answer text on success, or null on any failure so the caller can fall back. */
    private fun callGrok(prompt: String, isDoctorMode: Boolean): String? {
        if (grokApiKey.isBlank()) {
            lastGrokError = "key missing/blank"
            return null
        }

        val url = "https://api.x.ai/v1/chat/completions"

        val requestBody = JSONObject().apply {
            // "grok-4" was retired by xAI on May 15, 2026 — requests to it
            // (and other pre-4.3 slugs) now fail outright. grok-4.3 is the
            // current flagship model as of this writing.
            put("model", "grok-4.3")
            put("messages", JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "user")
                    put("content", prompt)
                })
            })
            put("temperature", if (isDoctorMode) 0.3 else 0.7)
            // Kept in sync with Gemini's maxOutputTokens — PhD-level
            // teaching answers need this much room, and Grok isn't
            // currently active anyway (grokEnabled = false above).
            put("max_tokens", 8192)
        }.toString()

        val request = Request.Builder()
            .url(url)
            .addHeader("Authorization", "Bearer $grokApiKey")
            .post(requestBody.toRequestBody("application/json".toMediaType()))
            .build()

        return try {
            client.newCall(request).execute().use { response ->
                val bodyString = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    lastGrokError = "HTTP ${response.code}: ${bodyString.take(200)}"
                    return null
                }

                val json = JSONObject(bodyString)
                val choices = json.optJSONArray("choices")
                if (choices == null || choices.length() == 0) {
                    lastGrokError = "empty choices: ${bodyString.take(200)}"
                    return null
                }

                val message = choices.getJSONObject(0).optJSONObject("message")
                val text = message?.optString("content", "")?.trim().orEmpty()
                if (text.isBlank()) lastGrokError = "blank content in response"
                text.ifBlank { null }
            }
        } catch (e: Exception) {
            lastGrokError = "${e.javaClass.simpleName}: ${e.message}"
            null
        }
    }

    /**
     * Tries each configured Gemini key in order until one succeeds. Moves to
     * the next key specifically on quota/rate-limit errors (429) or auth
     * failures (401/403) — those mean that key is exhausted or invalid, not
     * that Gemini itself is down, so retrying with a different key is worth
     * it. Any other failure (network error, malformed response) stops the
     * rotation immediately since a different key wouldn't fix it.
     */
    private fun callGeminiApi(prompt: String, isDoctorMode: Boolean): String? {
        if (geminiApiKeys.isEmpty()) {
            lastGeminiError = "no keys configured"
            return null
        }

        for ((index, key) in geminiApiKeys.withIndex()) {
            val result = callGeminiWithKey(prompt, isDoctorMode, key)
            if (result != null) return result

            val isQuotaOrAuthError = lastGeminiError.startsWith("HTTP 429") ||
                lastGeminiError.startsWith("HTTP 401") ||
                lastGeminiError.startsWith("HTTP 403")

            if (!isQuotaOrAuthError) {
                // Network error, bad response, etc — switching keys won't help.
                return null
            }
            // Otherwise this key is exhausted/invalid — loop tries the next one.
            if (index == geminiApiKeys.lastIndex) {
                lastGeminiError = "all ${geminiApiKeys.size} keys exhausted — last error: $lastGeminiError"
            }
        }
        return null
    }

    /** Returns the answer text on success, or null on any failure so the caller can fall back. */
    private fun callGeminiWithKey(prompt: String, isDoctorMode: Boolean, geminiApiKey: String): String? {
        if (geminiApiKey.isBlank()) {
            lastGeminiError = "key missing/blank"
            return null
        }

        val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent"

        val requestBody = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply { put("text", prompt) })
                    })
                })
            })
            put("generationConfig", JSONObject().apply {
                put("temperature", if (isDoctorMode) 0.3 else 0.7)
                // Raised from 4096 — PhD-level teaching answers (full
                // derivations, multi-approach math solutions, in-depth
                // physics/science explanations) genuinely need more room
                // than code answers alone did. Doctor Mode responses stay
                // shorter/clinical by nature so this doesn't bloat those.
                put("maxOutputTokens", 8192)
            })
        }.toString()

        val request = Request.Builder()
            .url(url)
            .addHeader("X-goog-api-key", geminiApiKey)
            .post(requestBody.toRequestBody("application/json".toMediaType()))
            .build()

        return try {
            client.newCall(request).execute().use { response ->
                val bodyString = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    lastGeminiError = "HTTP ${response.code}: ${bodyString.take(200)}"
                    return null
                }

                val json = JSONObject(bodyString)
                val candidates = json.optJSONArray("candidates")
                if (candidates == null || candidates.length() == 0) {
                    lastGeminiError = "empty candidates: ${bodyString.take(200)}"
                    return null
                }

                val candidate = candidates.getJSONObject(0)
                val parts = candidate.getJSONObject("content").getJSONArray("parts")

                // Gemini can split a reply across multiple parts (this
                // happens more often on longer answers) — previously only
                // parts.getJSONObject(0) was read, silently dropping every
                // part after the first and cutting answers short. Concatenate
                // all text parts instead.
                val fullText = buildString {
                    for (i in 0 until parts.length()) {
                        val part = parts.getJSONObject(i)
                        if (part.has("text")) append(part.getString("text"))
                    }
                }.trim()

                if (fullText.isBlank()) {
                    lastGeminiError = "blank text in response"
                    return null
                }

                // If Gemini stopped because it hit the token limit rather
                // than finishing naturally, the answer is genuinely
                // incomplete — not just a parsing bug.
                val finishReason = candidate.optString("finishReason", "")
                if (finishReason == "MAX_TOKENS") {
                    fullText + "\n\n(jaani, jawab lamba ho gaya tha isliye thoda kaat diya — \"aur bata do\" bol ke pucho, baaki bata degi.)"
                } else {
                    fullText
                }
            }
        } catch (e: Exception) {
            lastGeminiError = "${e.javaClass.simpleName}: ${e.message}"
            null
        }
    }

    /**
     * Used whenever Gemini can't be reached (bad key, quota, no internet,
     * server error, etc). Instead of just showing an error, we fall back
     * to whatever we found locally in the PDFs via [RagSearchEngine] — no
     * network needed for this part at all. If nothing relevant was found
     * locally either, we say so plainly instead of pretending to answer.
     */
    private fun offlineFallback(
        question: String,
        relevantChunks: List<RagSearchEngine.RelevantChunk>,
        reason: String
    ): String {
        if (relevantChunks.isEmpty()) {
            return "Abhi AI se connect nahi ho paa rahi ($reason), aur is sawaal se " +
                "milta-julta kuch tumhare PDF notes mein bhi nahi mila. Internet check karo " +
                "ya thodi der baad try karo — tab tak main sirf notes mein se dhoondh sakti hoon."
        }

        val best = relevantChunks.first()
        val extra = if (relevantChunks.size > 1) {
            "\n\n(${relevantChunks.size - 1} aur jagah bhi isse milta-julta content mila hai " +
                "notes mein, agar chahiye to alag se pucho.)"
        } else ""

        return "Abhi AI se connect nahi ho paa rahi ($reason), lekin tumhare notes " +
            "\"${best.pdfName}\" (page ${best.pageNumber}) mein yeh mila:\n\n" +
            "${best.text.trim()}$extra"
    }

    private fun buildStudyPrompt(
        question: String,
        relevantChunks: List<RagSearchEngine.RelevantChunk>,
        memoryBlock: String = "",
        feedbackBlock: String = ""
    ): String {
        val historyBlock = studyHistory.asPromptBlock()
        val personalizationBlock = listOf(memoryBlock, feedbackBlock).filter { it.isNotBlank() }.joinToString("\n\n")

        if (relevantChunks.isEmpty()) {
            return """
                $basePersonality

                $varietyInstruction

                $reasoningInstruction

                $codingInstruction

                $advancedTeachingInstruction

                $medicalTeachingInstruction

                $personalizationBlock

                $historyBlock
                Is question ke liye Kavita ke PDF notes mein kuch relevant nahi mila,
                isliye apne general knowledge se answer do. Clearly accurate raho.

                Question: $question
            """.trimIndent()
        }

        val contextBlock = relevantChunks.joinToString("\n\n") { chunk ->
            "[From ${chunk.pdfName}, page ${chunk.pageNumber}]\n${chunk.text}"
        }

        return """
            $basePersonality

            $varietyInstruction

            $reasoningInstruction

            $codingInstruction

            $advancedTeachingInstruction

            $medicalTeachingInstruction

            $personalizationBlock

            $historyBlock
            Neeche Kavita ke apne study notes se relevant content diya gaya hai.
            Answer dete waqt isi content ko priority do taaki uske exam syllabus
            ke hisaab se accurate rahe. Agar notes mein poora answer nahi hai,
            to apne general knowledge se bhi thoda add kar sakti ho, lekin
            notes ke content ko contradict mat karna.

            --- NOTES CONTEXT ---
            $contextBlock
            --- END CONTEXT ---

            Question: $question
        """.trimIndent()
    }

    private fun buildDoctorPrompt(
        caseDescription: String,
        relevantChunks: List<RagSearchEngine.RelevantChunk>
    ): String {
        val historyBlock = doctorHistory.asPromptBlock()

        if (relevantChunks.isEmpty()) {
            return """
                $doctorModePersonality

                $reasoningInstruction

                $medicalTeachingInstruction

                $historyBlock
                Is case ke liye uploaded guidelines/textbook mein kuch specific
                relevant nahi mila, isliye general clinical knowledge se answer do.

                Case: $caseDescription
            """.trimIndent()
        }

        val contextBlock = relevantChunks.joinToString("\n\n") { chunk ->
            "[From ${chunk.pdfName}, page ${chunk.pageNumber}]\n${chunk.text}"
        }

        return """
            $doctorModePersonality

            $reasoningInstruction

            $medicalTeachingInstruction

            $historyBlock
            Neeche uploaded medical guidelines/textbook se relevant content diya
            gaya hai. Isko primary reference maano, lekin agar incomplete lage to
            apne general clinical knowledge se bhi add karo.

            --- REFERENCE CONTEXT ---
            $contextBlock
            --- END CONTEXT ---

            Case: $caseDescription
        """.trimIndent()
    }
}
