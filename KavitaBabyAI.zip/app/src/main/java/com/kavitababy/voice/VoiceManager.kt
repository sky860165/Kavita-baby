// VoiceManager.kt
package com.kavitababy.voice

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.util.Locale

class VoiceManager(private val context: Context) {

    /** User-facing voice gender choice. Persisted so it survives app restarts. */
    enum class VoiceGender { FEMALE, MALE }

    private var textToSpeech: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null

    private var ttsReady = false

    private val prefs = context.getSharedPreferences("kavita_voice_prefs", Context.MODE_PRIVATE)

    private var currentGender: VoiceGender = VoiceGender.valueOf(
        prefs.getString("voice_gender", VoiceGender.FEMALE.name) ?: VoiceGender.FEMALE.name
    )

    fun getCurrentGender(): VoiceGender = currentGender

    /**
     * Switches the TTS voice to a male or female Hindi voice and remembers
     * the choice for next app launch. If no voice of the requested gender
     * is installed on this device, falls back to selectBestHindiVoice()
     * (whatever the device has) rather than silently failing.
     */
    fun setVoiceGender(gender: VoiceGender) {
        currentGender = gender
        prefs.edit().putString("voice_gender", gender.name).apply()
        if (ttsReady) {
            selectBestHindiVoice()
        }
    }

    // Whether the current listening pass already tried falling back from
    // the default recognizer to Google's explicitly. Reset at the start
    // of every fresh startListening() call.
    private var hasFallenBackToGoogle = false

    // Whether this pass already retried with hi-IN forced explicitly, after
    // a first attempt with no language extra (device default) came back
    // with ERROR_NO_MATCH / empty result. Some devices default to an
    // en-US-only recognition profile that mishears Hindi/Hinglish speech
    // as silence rather than transcribing it — forcing hi-IN as a second
    // attempt catches those cases instead of leaving the user stuck
    // repeating themselves into a recognizer that will never understand.
    private var hasRetriedWithHindiLocale = false

    init {
        textToSpeech = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                textToSpeech?.language = Locale("hi", "IN")
                selectBestHindiVoice()
                textToSpeech?.setSpeechRate(0.92f)
                // Slightly below 1.0 default — many Hindi TTS voices sound
                // less robotic/mispronounced at a marginally lower pitch;
                // this is a small, safe tweak, not a fix for a genuinely
                // low-quality installed voice (that needs a better voice
                // pack from Settings, which no app can force-install).
                textToSpeech?.setPitch(0.97f)
                ttsReady = true
            }
        }
    }

    /**
     * Some devices ship multiple Hindi voice variants (e.g. network-based
     * "hi-in-x-hia-network" vs an older bundled offline voice) — the
     * network ones are generally far more natural/correctly pronounced.
     * If more than one Hindi voice is available on this device, this picks
     * the highest-quality one instead of leaving it to whatever default
     * Android picked. If only one exists, this is a harmless no-op — it
     * cannot conjure a better voice than what's actually installed on the
     * device (that requires the user to install one from TTS Settings).
     */
    private fun selectBestHindiVoice() {
        try {
            val voices = textToSpeech?.voices ?: return
            val hindiVoices = voices.filter { it.locale.language == "hi" }
            if (hindiVoices.isEmpty()) return

            val genderMatched = hindiVoices.filter { guessGender(it.name) == currentGender }
            // If nothing matches the requested gender on this device (many
            // devices only ship one Hindi voice, or an OEM TTS with no
            // gender-identifiable names), fall back to the best voice
            // available overall rather than leaving TTS unconfigured.
            val best = pickBestVoice(genderMatched) ?: pickBestVoice(hindiVoices)

            if (best != null) {
                textToSpeech?.voice = best
            }
        } catch (e: Exception) {
            // If voice querying/selection fails on some OEM TTS
            // implementation, just fall back to whatever default the
            // language-set call above already picked — never crash speech.
        }
    }

    /**
     * Android's Voice objects don't expose a real gender field, but
     * Google's TTS engine (and most others) encode it in the voice name,
     * e.g. "hi-in-x-hia-network" vs "hi-in-x-hid-network", or names
     * containing "#male"/"#female". This matches on those common naming
     * patterns. Best-effort only — an OEM TTS with opaque voice names will
     * return null here and callers fall back to picking any Hindi voice.
     */
    private fun guessGender(voiceName: String): VoiceGender? {
        val n = voiceName.lowercase()
        return when {
            n.contains("female") -> VoiceGender.FEMALE
            n.contains("male") -> VoiceGender.MALE
            // Google's network Hindi voices follow hi-in-x-hi{c}-... where
            // c cycles through a/b/c/d — on common builds the 'a'/'c'
            // variants are female, 'b'/'d' are male. Not guaranteed on
            // every OEM; that's fine since this is only a hint.
            Regex("hi-in-x-hi[ac]").containsMatchIn(n) -> VoiceGender.FEMALE
            Regex("hi-in-x-hi[bd]").containsMatchIn(n) -> VoiceGender.MALE
            else -> null
        }
    }

    private fun pickBestVoice(pool: List<android.speech.tts.Voice>): android.speech.tts.Voice? {
        if (pool.isEmpty()) return null
        // Prefer: not a "novelty" voice, higher declared quality, and
        // network voices (usually Google's better cloud voices) over
        // bundled offline ones when quality ties.
        return pool
            .filterNot { it.isNetworkConnectionRequired && !isNetworkAvailable() }
            .maxWithOrNull(
                compareBy(
                    { it.quality },
                    { if (it.isNetworkConnectionRequired) 1 else 0 }
                )
            ) ?: pool.maxByOrNull { it.quality }
    }

    /** Lists Hindi voices installed on this device, tagged with our best-guess gender — useful for a picker UI or diagnostics. */
    data class AvailableVoice(val name: String, val gender: VoiceGender?, val quality: Int)

    fun listAvailableHindiVoices(): List<AvailableVoice> {
        return try {
            val voices = textToSpeech?.voices ?: return emptyList()
            voices.filter { it.locale.language == "hi" }
                .map { AvailableVoice(it.name, guessGender(it.name), it.quality) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun isNetworkAvailable(): Boolean {
        return try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
            val network = cm.activeNetwork ?: return false
            val capabilities = cm.getNetworkCapabilities(network) ?: return false
            capabilities.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } catch (e: Exception) {
            false
        }
    }

    /** Speaks [text]. Calls [onDone] when speech finishes or fails, so callers can reset UI state. */
    fun speak(text: String, onDone: (() -> Unit)? = null) {
        if (!ttsReady) {
            onDone?.invoke()
            return
        }

        if (onDone != null) {
            textToSpeech?.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {
                    onDone()
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    onDone()
                }
            })
        }

        val cleanText = sanitizeForSpeech(text)
        textToSpeech?.speak(cleanText, TextToSpeech.QUEUE_FLUSH, null, "kavita_speak")
    }

    /**
     * Strips markdown/formatting symbols before handing text to TTS.
     *
     * The AI's replies can contain markdown (**bold**, _italic_, # headings,
     * `code`, bullet dashes, etc). TextToSpeech doesn't understand markdown —
     * it reads the literal symbols out loud (e.g. "*" gets spoken as
     * "asterisk"/"tarakan" on some voices), which sounds broken in a voice
     * conversation. This removes those symbols so only real words get
     * spoken. It only affects what's passed to speak() — the on-screen chat
     * bubble still gets the original raw text for rendering.
     */
    private fun sanitizeForSpeech(raw: String): String {
        var s = raw

        s = s.replace(Regex("```[a-zA-Z]*\\n?"), "")
        s = s.replace("```", "")
        s = s.replace(Regex("[*_`~]+"), "")
        s = s.replace(Regex("(?m)^#{1,6}\\s*"), "")
        s = s.replace(Regex("(?m)^\\s*[-•]\\s+"), "")
        s = s.replace(Regex("\\[([^\\]]+)\\]\\([^)]+\\)"), "$1")
        s = s.replace(Regex("[\\p{So}\\p{Cn}]"), "")
        s = s.replace(Regex("\\n{2,}"), ". ")
        s = s.replace(Regex("[ \\t]{2,}"), " ")

        return s.trim()
    }

    fun stopSpeaking() {
        textToSpeech?.stop()
    }

    /**
     * Starts listening for speech, driven directly from whatever Activity
     * context this VoiceManager was created with (e.g. ChatScreen's
     * MainActivity) — no separate window is opened, so it never steals
     * touch focus from the rest of the screen.
     *
     * [onResult] is called with the recognized text, or an empty string
     * if nothing was understood — check for blank rather than assuming a
     * result is always present.
     * [onError] is called if recognition fails outright after all retries
     * are exhausted, with the SpeechRecognizer error code.
     */
    fun startListening(onResult: (String) -> Unit, onError: ((Int) -> Unit)? = null) {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onError?.invoke(SpeechRecognizer.ERROR_CLIENT)
            return
        }

        hasFallenBackToGoogle = false
        hasRetriedWithHindiLocale = false

        // SpeechRecognizer must be created and driven from the main thread —
        // when this is called from a background Service, that isn't always
        // guaranteed, so we force it onto the main looper explicitly. Skipping
        // this is a common cause of recognition silently failing every time
        // when triggered from a floating-widget service instead of an Activity.
        android.os.Handler(context.mainLooper).post {
            startListeningOnMainThread(onResult, onError, useGoogleExplicitly = false)
        }
    }

    private fun startListeningOnMainThread(
        onResult: (String) -> Unit,
        onError: ((Int) -> Unit)?,
        useGoogleExplicitly: Boolean,
        forceHindiLocale: Boolean = false
    ) {
        // Avoid leaking a previous recognizer instance if startListening
        // is called again before the last one was cleaned up.
        speechRecognizer?.destroy()

        speechRecognizer = if (useGoogleExplicitly) {
            val googleRecognizer = ComponentName(
                "com.google.android.googlequicksearchbox",
                "com.google.android.voicesearch.serviceapi.GoogleRecognitionService"
            )
            SpeechRecognizer.createSpeechRecognizer(context, googleRecognizer)
        } else {
            SpeechRecognizer.createSpeechRecognizer(context)
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            // On the FIRST attempt we deliberately DON'T force "hi-IN". If
            // the device's Hindi speech-recognition pack isn't installed/
            // downloaded, forcing this language makes the recognizer reject
            // the request instantly (no capture attempt at all) instead of
            // falling back gracefully. Leaving EXTRA_LANGUAGE unset makes
            // the recognizer use the device's current default recognition
            // language instead, which works fine on most devices.
            //
            // But some devices default to an en-US-only recognition profile
            // that mishears Hindi/Hinglish as silence (ERROR_NO_MATCH/blank
            // result) rather than rejecting the request outright. If that
            // happens once, we retry the same utterance with hi-IN forced —
            // see onError/onResults below — which catches that case without
            // breaking devices that need the language extra left unset.
            if (forceHindiLocale) {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            }
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            // Deliberately NOT setting EXTRA_CALLING_PACKAGE — the system
            // fills this from the real caller UID; setting it ourselves
            // has triggered rejects on some MIUI builds.
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            // Deliberately NOT setting the custom silence-length/minimum-
            // length extras (EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS
            // etc). These aren't reliably honored by every recognizer
            // implementation, and on this device they caused onResults to
            // fire with an empty match even for a clearly spoken short
            // word ("hello") — while Google Assistant's own mic, which
            // doesn't set these extras, worked fine on the same device.
            // Leaving them unset lets the recognizer use its own default
            // timing, matching what Assistant/keyboard mic already use
            // successfully here.
        }

        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}

            override fun onError(error: Int) {
                // MIUI/Xiaomi devices sometimes reject the device-default
                // recognizer outright (ERROR_CLIENT) even though the same
                // device's Google app works fine — because it explicitly
                // targets Google's recognition service rather than
                // whatever the OEM resolved as default. Try that once
                // before surfacing a real error, so this self-heals
                // without ever opening a second window.
                if (error == SpeechRecognizer.ERROR_CLIENT && !useGoogleExplicitly && !hasFallenBackToGoogle) {
                    hasFallenBackToGoogle = true
                    android.os.Handler(context.mainLooper).post {
                        startListeningOnMainThread(onResult, onError, useGoogleExplicitly = true, forceHindiLocale = forceHindiLocale)
                    }
                    return
                }
                // ERROR_NO_MATCH means the recognizer heard audio but
                // couldn't transcribe it against its current language
                // profile — on some devices that's an en-US-only default
                // that simply mishears Hindi/Hinglish. Retry once with
                // hi-IN forced before surfacing this as a real error.
                if (error == SpeechRecognizer.ERROR_NO_MATCH && !forceHindiLocale && !hasRetriedWithHindiLocale) {
                    hasRetriedWithHindiLocale = true
                    android.os.Handler(context.mainLooper).post {
                        startListeningOnMainThread(onResult, onError, useGoogleExplicitly = useGoogleExplicitly, forceHindiLocale = true)
                    }
                    return
                }
                // Covers cases like ERROR_SPEECH_TIMEOUT, ERROR_NETWORK, etc.
                // Without this, the caller's UI would stay stuck in a "listening" state forever.
                onError?.invoke(error)
            }

            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = matches?.firstOrNull().orEmpty()
                // A "successful" result with no actual text is functionally
                // the same failure as ERROR_NO_MATCH — the device-default
                // language profile just didn't recognize anything. Retry
                // once with hi-IN forced before reporting blank to the caller.
                if (text.isBlank() && !forceHindiLocale && !hasRetriedWithHindiLocale) {
                    hasRetriedWithHindiLocale = true
                    android.os.Handler(context.mainLooper).post {
                        startListeningOnMainThread(onResult, onError, useGoogleExplicitly = useGoogleExplicitly, forceHindiLocale = true)
                    }
                    return
                }
                onResult(text)
            }

            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        speechRecognizer?.startListening(intent)
    }

    fun stopListening() {
        android.os.Handler(context.mainLooper).post {
            speechRecognizer?.stopListening()
        }
    }

    fun destroy() {
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        android.os.Handler(context.mainLooper).post {
            speechRecognizer?.destroy()
            speechRecognizer = null
        }
    }
}
