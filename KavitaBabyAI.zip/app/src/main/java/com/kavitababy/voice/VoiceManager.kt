// VoiceManager.kt
package com.kavitababy.voice

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.util.Locale

class VoiceManager(private val context: Context) {

    private var textToSpeech: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null

    private var ttsReady = false

    // Whether the current listening pass already tried falling back from
    // the default recognizer to Google's explicitly. Reset at the start
    // of every fresh startListening() call.
    private var hasFallenBackToGoogle = false

    // Whether this pass already retried with hi-IN forced explicitly, after
    // a first attempt with no language extra (device default) came back
    // with ERROR_NO_MATCH / empty result. Some devices default to an
    // en-US-only recognition profile that mishears Hindi/Hinglish speech
    // as silence rather than transcribing it — forcing hi-IN as a second
    // attempt catches those cases instead of leaving the user stuck
    // repeating themselves into a recognizer that will never understand.
    private var hasRetriedWithHindiLocale = false

    init {
        textToSpeech = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                textToSpeech?.language = Locale("hi", "IN")
                textToSpeech?.setSpeechRate(0.95f)
                ttsReady = true
            }
        }
    }

    /** Speaks [text]. Calls [onDone] when speech finishes or fails, so callers can reset UI state. */
    fun speak(text: String, onDone: (() -> Unit)? = null) {
        if (!ttsReady) {
            onDone?.invoke()
            return
        }

        if (onDone != null) {
            textToSpeech?.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {
                    onDone()
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    onDone()
                }
            })
        }

        val cleanText = sanitizeForSpeech(text)
        textToSpeech?.speak(cleanText, TextToSpeech.QUEUE_FLUSH, null, "kavita_speak")
    }

    /**
     * Strips markdown/formatting symbols before handing text to TTS.
     *
     * The AI's replies can contain markdown (**bold**, _italic_, # headings,
     * `code`, bullet dashes, etc). TextToSpeech doesn't understand markdown —
     * it reads the literal symbols out loud (e.g. "*" gets spoken as
     * "asterisk"/"tarakan" on some voices), which sounds broken in a voice
     * conversation. This removes those symbols so only real words get
     * spoken. It only affects what's passed to speak() — the on-screen chat
     * bubble still gets the original raw text for rendering.
     */
    private fun sanitizeForSpeech(raw: String): String {
        var s = raw

        s = s.replace(Regex("```[a-zA-Z]*\\n?"), "")
        s = s.replace("```", "")
        s = s.replace(Regex("[*_`~]+"), "")
        s = s.replace(Regex("(?m)^#{1,6}\\s*"), "")
        s = s.replace(Regex("(?m)^\\s*[-•]\\s+"), "")
        s = s.replace(Regex("\\[([^\\]]+)\\]\\([^)]+\\)"), "$1")
        s = s.replace(Regex("[\\p{So}\\p{Cn}]"), "")
        s = s.replace(Regex("\\n{2,}"), ". ")
        s = s.replace(Regex("[ \\t]{2,}"), " ")

        return s.trim()
    }

    fun stopSpeaking() {
        textToSpeech?.stop()
    }

    /**
     * Starts listening for speech, driven directly from whatever Activity
     * context this VoiceManager was created with (e.g. ChatScreen's
     * MainActivity) — no separate window is opened, so it never steals
     * touch focus from the rest of the screen.
     *
     * [onResult] is called with the recognized text, or an empty string
     * if nothing was understood — check for blank rather than assuming a
     * result is always present.
     * [onError] is called if recognition fails outright after all retries
     * are exhausted, with the SpeechRecognizer error code.
     */
    fun startListening(onResult: (String) -> Unit, onError: ((Int) -> Unit)? = null) {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onError?.invoke(SpeechRecognizer.ERROR_CLIENT)
            return
        }

        hasFallenBackToGoogle = false
        hasRetriedWithHindiLocale = false

        // SpeechRecognizer must be created and driven from the main thread —
        // when this is called from a background Service, that isn't always
        // guaranteed, so we force it onto the main looper explicitly. Skipping
        // this is a common cause of recognition silently failing every time
        // when triggered from a floating-widget service instead of an Activity.
        android.os.Handler(context.mainLooper).post {
            startListeningOnMainThread(onResult, onError, useGoogleExplicitly = false)
        }
    }

    private fun startListeningOnMainThread(
        onResult: (String) -> Unit,
        onError: ((Int) -> Unit)?,
        useGoogleExplicitly: Boolean,
        forceHindiLocale: Boolean = false
    ) {
        // Avoid leaking a previous recognizer instance if startListening
        // is called again before the last one was cleaned up.
        speechRecognizer?.destroy()

        speechRecognizer = if (useGoogleExplicitly) {
            val googleRecognizer = ComponentName(
                "com.google.android.googlequicksearchbox",
                "com.google.android.voicesearch.serviceapi.GoogleRecognitionService"
            )
            SpeechRecognizer.createSpeechRecognizer(context, googleRecognizer)
        } else {
            SpeechRecognizer.createSpeechRecognizer(context)
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            // On the FIRST attempt we deliberately DON'T force "hi-IN". If
            // the device's Hindi speech-recognition pack isn't installed/
            // downloaded, forcing this language makes the recognizer reject
            // the request instantly (no capture attempt at all) instead of
            // falling back gracefully. Leaving EXTRA_LANGUAGE unset makes
            // the recognizer use the device's current default recognition
            // language instead, which works fine on most devices.
            //
            // But some devices default to an en-US-only recognition profile
            // that mishears Hindi/Hinglish as silence (ERROR_NO_MATCH/blank
            // result) rather than rejecting the request outright. If that
            // happens once, we retry the same utterance with hi-IN forced —
            // see onError/onResults below — which catches that case without
            // breaking devices that need the language extra left unset.
            if (forceHindiLocale) {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            }
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            // Deliberately NOT setting EXTRA_CALLING_PACKAGE — the system
            // fills this from the real caller UID; setting it ourselves
            // has triggered rejects on some MIUI builds.
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            // Deliberately NOT setting the custom silence-length/minimum-
            // length extras (EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS
            // etc). These aren't reliably honored by every recognizer
            // implementation, and on this device they caused onResults to
            // fire with an empty match even for a clearly spoken short
            // word ("hello") — while Google Assistant's own mic, which
            // doesn't set these extras, worked fine on the same device.
            // Leaving them unset lets the recognizer use its own default
            // timing, matching what Assistant/keyboard mic already use
            // successfully here.
        }

        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}

            override fun onError(error: Int) {
                // MIUI/Xiaomi devices sometimes reject the device-default
                // recognizer outright (ERROR_CLIENT) even though the same
                // device's Google app works fine — because it explicitly
                // targets Google's recognition service rather than
                // whatever the OEM resolved as default. Try that once
                // before surfacing a real error, so this self-heals
                // without ever opening a second window.
                if (error == SpeechRecognizer.ERROR_CLIENT && !useGoogleExplicitly && !hasFallenBackToGoogle) {
                    hasFallenBackToGoogle = true
                    android.os.Handler(context.mainLooper).post {
                        startListeningOnMainThread(onResult, onError, useGoogleExplicitly = true, forceHindiLocale = forceHindiLocale)
                    }
                    return
                }
                // ERROR_NO_MATCH means the recognizer heard audio but
                // couldn't transcribe it against its current language
                // profile — on some devices that's an en-US-only default
                // that simply mishears Hindi/Hinglish. Retry once with
                // hi-IN forced before surfacing this as a real error.
                if (error == SpeechRecognizer.ERROR_NO_MATCH && !forceHindiLocale && !hasRetriedWithHindiLocale) {
                    hasRetriedWithHindiLocale = true
                    android.os.Handler(context.mainLooper).post {
                        startListeningOnMainThread(onResult, onError, useGoogleExplicitly = useGoogleExplicitly, forceHindiLocale = true)
                    }
                    return
                }
                // Covers cases like ERROR_SPEECH_TIMEOUT, ERROR_NETWORK, etc.
                // Without this, the caller's UI would stay stuck in a "listening" state forever.
                onError?.invoke(error)
            }

            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = matches?.firstOrNull().orEmpty()
                // A "successful" result with no actual text is functionally
                // the same failure as ERROR_NO_MATCH — the device-default
                // language profile just didn't recognize anything. Retry
                // once with hi-IN forced before reporting blank to the caller.
                if (text.isBlank() && !forceHindiLocale && !hasRetriedWithHindiLocale) {
                    hasRetriedWithHindiLocale = true
                    android.os.Handler(context.mainLooper).post {
                        startListeningOnMainThread(onResult, onError, useGoogleExplicitly = useGoogleExplicitly, forceHindiLocale = true)
                    }
                    return
                }
                onResult(text)
            }

            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        speechRecognizer?.startListening(intent)
    }

    fun stopListening() {
        android.os.Handler(context.mainLooper).post {
            speechRecognizer?.stopListening()
        }
    }

    fun destroy() {
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        android.os.Handler(context.mainLooper).post {
            speechRecognizer?.destroy()
            speechRecognizer = null
        }
    }
}
