// ChatScreen.kt
package com.kavitababy.ui

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kavitababy.R
import com.kavitababy.ai.AIRepository
import com.kavitababy.data.CaseNote
import com.kavitababy.data.ChatMessageEntity
import com.kavitababy.data.FollowUpReminder
import com.kavitababy.data.KavitaDatabase
import com.kavitababy.data.LabMetricPreset
import com.kavitababy.data.LabValue
import com.kavitababy.data.PatientCase
import com.kavitababy.data.PatientCrypto
import com.kavitababy.data.PdfScannerService
import com.kavitababy.data.RagSearchEngine
import com.kavitababy.data.ReminderScheduler
import com.kavitababy.data.VitalsCalculator
import com.kavitababy.voice.VoiceManager
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Locale

private enum class AppMode { STUDY, DOCTOR, ENGINEER }

private enum class VitalsCalcTab(val label: String) {
    BMI("BMI"),
    GFR("Creatinine Clearance"),
    DOSAGE("Dosage/kg"),
    APGAR("Apgar")
}

/**
 * Best-effort check for whether a picked file is an image, used to decide
 * whether to stage it (thumbnail + caption entry before sending) versus
 * the old immediate-send behavior kept for PDFs/video/audio/zip.
 * Extension check first since it's free; content resolver mime type as a
 * fallback for extension-less Uris some file pickers return.
 */
private fun isLikelyImage(context: Context, name: String, uri: Uri): Boolean {
    val lower = name.lowercase()
    val imageExtensions = listOf(".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp", ".heic", ".heif")
    if (imageExtensions.any { lower.endsWith(it) }) return true
    return try {
        context.contentResolver.getType(uri)?.startsWith("image/") == true
    } catch (e: Exception) {
        false
    }
}

@Composable
fun ChatScreen(voiceManager: VoiceManager, pdfScanTrigger: Int = 0, screenshotScanTrigger: Int = 0) {
    val context = LocalContext.current
    var mode by remember { mutableStateOf(AppMode.STUDY) }
    val scope = rememberCoroutineScope()
    var showSettings by remember { mutableStateOf(false) }
    // Study Mode and Doctor Mode each keep their own chat history — they used
    // to share one `messages` list, which made switching tabs show the other
    // mode's conversation mixed in with this one. Kept as two separate
    // remembered lists so switching tabs is a pure UI swap, not a data merge.
    var studyMessages by remember { mutableStateOf(listOf<Message>()) }
    var doctorMessages by remember { mutableStateOf(listOf<Message>()) }
    var engineerMessages by remember { mutableStateOf(listOf<Message>()) }
    val chatMessageDao = remember { KavitaDatabase.getInstance(context.applicationContext).chatMessageDao() }
    // Restores chat history saved from a previous session — without this,
    // Android killing the app in the background (or the user just closing
    // it) meant every reopen started from a totally empty chat, since
    // studyMessages/doctorMessages above are only in-memory state.
    LaunchedEffect(Unit) {
        val savedStudy = chatMessageDao.getAllForMode("STUDY").map {
            Message(text = it.text, isUser = it.isUser, id = it.id, question = it.question, isHistorical = it.isHistorical)
        }
        val savedDoctor = chatMessageDao.getAllForMode("DOCTOR").map {
            Message(text = it.text, isUser = it.isUser, id = it.id, question = it.question, isHistorical = it.isHistorical)
        }
        val savedEngineer = chatMessageDao.getAllForMode("ENGINEER").map {
            Message(text = it.text, isUser = it.isUser, id = it.id, question = it.question, isHistorical = it.isHistorical)
        }
        if (savedStudy.isNotEmpty()) studyMessages = savedStudy
        if (savedDoctor.isNotEmpty()) doctorMessages = savedDoctor
        if (savedEngineer.isNotEmpty()) engineerMessages = savedEngineer
    }
    // `messages` is a plain val — recomputed each recomposition, so any
    // closure that captures it (a scan/export coroutine that keeps running
    // across a suspend/await gap) is holding an OLD, frozen snapshot from
    // whenever that closure was created. If new messages arrive *during*
    // that gap (e.g. a 2-minute PDF scan), the coroutine still only knows
    // about the old list — so when it finally calls updateMessages { it
    // + result }, it overwrites the live chat with (stale list + result),
    // silently erasing everything the user sent in between. This is exactly
    // the "chat disappears when the scan message shows up" bug.
    //
    // Fix: updateMessages takes a transform now, applied to a freshly-read
    // current list *at the moment it actually runs* (studyMessages/
    // doctorMessages are Compose state vars — reading them always gives the
    // live value, unlike the frozen `messages` val above). Every call site
    // uses `updateMessages { it + Message(...) }` instead of
    // `updateMessages { it + Message(...) }` so nothing gets dropped no
    // matter how long the coroutine was suspended.
    val messages: List<Message> = when (mode) {
        AppMode.STUDY -> studyMessages
        AppMode.DOCTOR -> doctorMessages
        AppMode.ENGINEER -> engineerMessages
    }
    fun updateMessages(transform: (List<Message>) -> List<Message>) {
        val newList = when (mode) {
            AppMode.STUDY -> transform(studyMessages)
            AppMode.DOCTOR -> transform(doctorMessages)
            AppMode.ENGINEER -> transform(engineerMessages)
        }
        when (mode) {
            AppMode.STUDY -> studyMessages = newList
            AppMode.DOCTOR -> doctorMessages = newList
            AppMode.ENGINEER -> engineerMessages = newList
        }
        // Persist in the background so history survives the app being
        // killed — replaces this mode's whole saved history each time,
        // which keeps it trivially in sync with what's on screen without
        // needing to track which single message is new at every call site.
        val modeTag = mode.name
        val snapshot = newList
        scope.launch {
            try {
                val entities = snapshot.mapIndexed { index, m ->
                    ChatMessageEntity(
                        id = m.id,
                        mode = modeTag,
                        sortOrder = index.toLong(),
                        text = m.text,
                        isUser = m.isUser,
                        question = m.question,
                        isHistorical = m.isHistorical
                    )
                }
                chatMessageDao.replaceForMode(modeTag, entities)
            } catch (e: Exception) {
                // Chat still works from in-memory state even if a save
                // attempt fails (e.g. a transient DB hiccup) — just skip
                // this particular persist, next update will try again.
            }
        }
    }
    // Full-screen Settings takes over the whole composable when open — an
    // early return, so none of the chat UI below (input row, dialogs,
    // etc.) gets built while it's showing. All the state it needs
    // (studyMessages/doctorMessages/chatMessageDao/mode) is already
    // declared above this point.
    if (showSettings) {
        SettingsScreen(
            onDismiss = { showSettings = false },
            onOpenChatMode = { modeTag -> mode = AppMode.valueOf(modeTag) },
            studyMessageCount = studyMessages.size,
            doctorMessageCount = doctorMessages.size,
            engineerMessageCount = engineerMessages.size,
            onDeleteChatHistory = { modeTag ->
                when (modeTag) {
                    "STUDY" -> studyMessages = emptyList()
                    "DOCTOR" -> doctorMessages = emptyList()
                    else -> engineerMessages = emptyList()
                }
                scope.launch {
                    try {
                        chatMessageDao.deleteAllForMode(modeTag)
                    } catch (e: Exception) {
                        // in-memory list is already cleared regardless
                    }
                }
            },
            onFullAccountDeleted = {
                studyMessages = emptyList()
                doctorMessages = emptyList()
                engineerMessages = emptyList()
                showSettings = false
            }
        )
        return
    }

    var inputText by remember { mutableStateOf("") }
    var isListening by remember { mutableStateOf(false) }
    // Male/Female voice picker dialog — tapping the voice-gender button
    // opens this instead of switching immediately, so the doctor/student
    // can see which one is currently selected before choosing.
    var showVoiceGenderDialog by remember { mutableStateOf(false) }
    var showEngineerCalculator by remember { mutableStateOf(false) }
    var showUnitConverter by remember { mutableStateOf(false) }
    var showScienceCalculator by remember { mutableStateOf(false) }
    var currentVoiceGender by remember { mutableStateOf(voiceManager.getCurrentGender()) }
    var isThinking by remember { mutableStateOf(false) }
    var isIndexingPdf by remember { mutableStateOf(false) }
    // Separate from isIndexingPdf on purpose: isIndexingPdf is for the
    // manual 📎-picked single PDF (fast, finite). This one is for the
    // automatic whole-device background scan on app start, which can
    // legitimately take minutes on a phone with lots of files/apps (full
    // filesystem walk + OCR of any scanned-image pages it finds). That
    // background scan used to share isIndexingPdf, which meant the 📎
    // attach button stayed disabled — looking completely dead — for as
    // long as the background scan ran, sometimes several minutes, even
    // though the user never asked for that scan and just wanted to pick a
    // file themselves. The header status text still shows this so the
    // user knows something's happening, but it no longer blocks the
    // attach button.
    var isBackgroundPdfScanning by remember { mutableStateOf(false) }
    // Same idea, for the separate "📚 Sab Files" (read everything: pdf +
    // txt + docx) manual scan button — kept independent of
    // isBackgroundPdfScanning so the two buttons don't disable each other.
    var isBackgroundAllFilesScanning by remember { mutableStateOf(false) }
    var voiceErrorMessage by remember { mutableStateOf<String?>(null) }
    val aiRepository = remember { AIRepository(context.applicationContext) }
    val ragEngine = remember { RagSearchEngine(context.applicationContext) }
    val pdfScanner = remember { PdfScannerService(context.applicationContext) }
    val mediaScanner = remember { com.kavitababy.data.MediaScannerService(context.applicationContext) }
    val learningEngine = remember { com.kavitababy.data.LearningEngine(context.applicationContext) }
    val doctorLearningEngine = remember { com.kavitababy.data.DoctorLearningEngine(context.applicationContext) }
    val exportService = remember { com.kavitababy.data.ExportService(context.applicationContext) }
    val backupService = remember { com.kavitababy.data.BackupService(context.applicationContext) }
    var isProcessingMedia by remember { mutableStateOf(false) }

    // Staged image attachment — set when the user picks an image via 📎
    // but hasn't hit Send yet. This is what lets them see a real preview
    // and type a caption alongside it (like every other chat app), instead
    // of the old behavior where picking an image sent it immediately with
    // no chance to add text and no visible thumbnail.
    data class PendingImage(val uri: Uri, val name: String, val base64Data: String, val mimeType: String)
    var pendingImage by remember { mutableStateOf<PendingImage?>(null) }
    var isLoadingPendingImage by remember { mutableStateOf(false) }

    // Case Workup: lets Doctor Mode collect MULTIPLE findings (typed notes +
    // every uploaded report/scan's individual reading) for the SAME case,
    // then combine all of them into one ranked differential in a single
    // step — instead of the doctor mentally cross-referencing several
    // separate per-file answers herself. Purely in-memory/session state,
    // same as doctorHistory in AIRepository — not persisted as its own
    // table, only the final combined result gets saved via saveCaseNote
    // (same as any other Doctor Mode answer already is).
    var caseWorkupActive by remember { mutableStateOf(false) }
    var caseFindings by remember { mutableStateOf(listOf<AIRepository.CaseFinding>()) }
    var isCombiningCase by remember { mutableStateOf(false) }
    // Set once the doctor confirms a diagnosis for the active workup, so the
    // "get treatment reference" action has something to act on.
    var confirmedDiagnosisContext by remember { mutableStateOf("") }
    // Which medical system to show treatment reference for — doctor picks
    // before confirming a diagnosis.
    var treatmentSystem by remember { mutableStateOf(AIRepository.TreatmentSystem.BOTH) }

    // Doctor Mode patient list — a simple, on-device, encrypted-name record
    // per patient. Every Case Workup can now be tied to a patient so past
    // cases are organized by who they belong to, instead of being one flat
    // unlabeled list. currentPatient is whichever patient the doctor is
    // actively working with right now (null = no patient context, old
    // ad-hoc behavior).
    data class ActivePatient(
        val id: Long,
        val displayName: String,
        val age: String,
        val gender: String,
        val currentDiagnosis: String = "",
        val currentSuggestion: String = "",
        val currentMedicines: String = "",
        val knownAllergies: String = ""
    )
    var currentPatient by remember { mutableStateOf<ActivePatient?>(null) }
    var showPatientList by remember { mutableStateOf(false) }
    var showUpcomingFollowUps by remember { mutableStateOf(false) }
    var showNewPatientDialog by remember { mutableStateOf(false) }
    var showFollowUpDialog by remember { mutableStateOf(false) }
    var showMedicineCheckDialog by remember { mutableStateOf(false) }
    var showSoapNoteDialog by remember { mutableStateOf(false) }
    var showSymptomCheckerDialog by remember { mutableStateOf(false) }
    var patientListRefreshTrigger by remember { mutableStateOf(0) }
    // Lets the doctor manually edit the patient's clinical summary fields
    // directly, as an alternative to (or override of) the automatic fill
    // that happens after a case combine / diagnosis confirm / treatment ref.
    var showEditPatientFileDialog by remember { mutableStateOf(false) }
    var showLabTrendsDialog by remember { mutableStateOf(false) }
    var showVitalsCalcDialog by remember { mutableStateOf(false) }
    var showReferralLetterDialog by remember { mutableStateOf(false) }
    // "Learn from URL" — doctor explicitly gives one webpage; the app
    // fetches just that page and saves it into the local knowledge base
    // for offline use later. Not a background/autonomous crawl.
    var showLearnUrlDialog by remember { mutableStateOf(false) }
    var isLearningUrl by remember { mutableStateOf(false) }
    // Drug interaction check result — shown in its own dialog rather than
    // dumped into chat, since it's a lookup the doctor triggers on demand
    // and re-runs often (each time medicines change), not a running
    // conversation thread.
    var interactionCheckResult by remember { mutableStateOf<String?>(null) }
    var isCheckingInteractions by remember { mutableStateOf(false) }

    // Doctor Mode's warning banner + patient bar + Case Workup panel used to
    // always be expanded, permanently eating vertical space above the chat
    // no matter how deep the conversation was. Now collapsed by default once
    // there's an active case with messages, and expandable on tap via a
    // single compact summary row — the doctor can still reach every action
    // (Patient List, Learn URL, Case Workup, Combine, Confirm dx) by
    // expanding it, but it no longer permanently shrinks the chat area.
    var doctorPanelExpanded by remember { mutableStateOf(true) }

    // Writes the patient's clinical summary (diagnosis/suggestion/medicines/
    // allergies) to their file and refreshes currentPatient so the UI
    // reflects it immediately — used by BOTH the automatic path (after case
    // combine, diagnosis confirm, treatment reference) and the manual edit
    // dialog, so there is exactly one place that actually performs this
    // write. Passing null for a field leaves that field unchanged; pass ""
    // to explicitly clear it.
    fun updatePatientClinicalSummary(
        patientId: Long,
        diagnosis: String? = null,
        suggestion: String? = null,
        medicines: String? = null,
        allergies: String? = null
    ) {
        scope.launch(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val dao = KavitaDatabase.getInstance(context.applicationContext).patientCaseDao()
                val existing = dao.getById(patientId) ?: return@launch
                dao.updateClinicalSummary(
                    patientId = patientId,
                    diagnosis = diagnosis ?: existing.currentDiagnosis,
                    suggestion = suggestion ?: existing.currentSuggestion,
                    medicines = medicines ?: existing.currentMedicines,
                    allergies = allergies ?: existing.knownAllergies
                )
                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                    if (currentPatient?.id == patientId) {
                        currentPatient = currentPatient?.copy(
                            currentDiagnosis = diagnosis ?: currentPatient?.currentDiagnosis.orEmpty(),
                            currentSuggestion = suggestion ?: currentPatient?.currentSuggestion.orEmpty(),
                            currentMedicines = medicines ?: currentPatient?.currentMedicines.orEmpty(),
                            knownAllergies = allergies ?: currentPatient?.knownAllergies.orEmpty()
                        )
                    }
                }
            } catch (e: Exception) {
                // File write failing shouldn't disrupt the chat — the doctor
                // can retry via the manual edit dialog if this silently fails.
            }
        }
    }

    // Storage Access Framework picker — the system's own file browser.
    // Because the user explicitly chooses the file themselves through this
    // picker, Android grants read access to that one file automatically,
    // with no READ_EXTERNAL_STORAGE/READ_MEDIA_* runtime permission needed
    // at all.
    //
    // Mime type "*/*" (instead of the old "application/pdf" only) so the
    // same 📎 button now lets the user pick PDF, image, video, audio, or
    // zip — MediaScannerService/PdfScannerService figure out what it is by
    // extension and route it to the right handler below.
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val uri: Uri? = result.data?.data
        if (uri == null) return@rememberLauncherForActivityResult

        // Query the display name off the Main thread — some MIUI content
        // providers (Gallery/Files app) are slow to answer this cursor
        // query, and running it directly in the launcher callback (Main
        // thread) is exactly what was freezing the button / triggering the
        // ANR popup. Everything now happens inside scope.launch on IO.
        scope.launch {
            val name = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    val idx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                    if (cursor.moveToFirst() && idx >= 0) cursor.getString(idx) else null
                } ?: uri.lastPathSegment.orEmpty()
            }

            if (name.endsWith(".pdf", ignoreCase = true)) {
                isIndexingPdf = true
                // try/finally so isIndexingPdf is guaranteed to reset even
                // if indexPickedPdf throws something unexpected — without
                // this, a single failure here would leave the flag stuck
                // `true` forever, permanently disabling the attach button
                // (it stays visible but every tap silently does nothing)
                // until the app is force-restarted.
                val result = try {
                    pdfScanner.indexPickedPdf(uri)
                } catch (e: Exception) {
                    PdfScannerService.PickResult.Failure(e.message ?: "PDF padhte waqt kuch galat ho gaya")
                } finally {
                    isIndexingPdf = false
                }
                val confirmationText = when (result) {
                    is PdfScannerService.PickResult.Success ->
                        "\"${result.pdfName}\" padh liya maine, ${result.chunksCreated} sections mil gaye — ab isse related kuch bhi pucho, jaani!"
                    is PdfScannerService.PickResult.Failure ->
                        "Is PDF ko padhne mein dikkat aa gayi: ${result.reason}"
                }
                updateMessages { it + Message(confirmationText, isUser = false) }
            } else if (isLikelyImage(context, name, uri)) {
                // Stage it instead of sending immediately — loads the
                // image data now (so the preview + eventual AI call don't
                // need to re-read the content:// Uri later), but doesn't
                // add a chat message or call the AI until the user hits
                // Send. This is what lets them see a real thumbnail and
                // type a caption first, like any other chat app.
                isLoadingPendingImage = true
                try {
                    val loadResult = mediaScanner.loadPicked(uri)
                    if (loadResult is com.kavitababy.data.MediaScannerService.LoadResult.Success &&
                        loadResult.files.size == 1 &&
                        loadResult.files.first().kind == com.kavitababy.data.MediaScannerService.Kind.IMAGE
                    ) {
                        val file = loadResult.files.first()
                        pendingImage = PendingImage(uri, name, file.base64Data, file.mimeType)
                    } else {
                        // Zip-of-images or a load failure — fall back to
                        // the old immediate-send behavior rather than
                        // silently dropping it.
                        val fallbackText = when (loadResult) {
                            is com.kavitababy.data.MediaScannerService.LoadResult.Failure -> loadResult.reason
                            is com.kavitababy.data.MediaScannerService.LoadResult.Success ->
                                "\"$name\" mein ${loadResult.files.size} files mili, sabko padh rahi hoon...\n\n" +
                                    aiRepository.getZipContentsResponse(loadResult.files)
                        }
                        updateMessages { it + Message("📎 $name bheja", isUser = true) }
                        updateMessages { it + Message(fallbackText, isUser = false) }
                    }
                } catch (e: Exception) {
                    updateMessages { it + Message("File load karte waqt kuch galat ho gaya, dobara try karo.", isUser = false) }
                } finally {
                    isLoadingPendingImage = false
                }
            } else {
                // Image, video, audio, or zip — everything else goes through
                // MediaScannerService + Gemini's multimodal understanding.
                updateMessages { it + Message("📎 $name bheja", isUser = true) }
                isProcessingMedia = true

                // Everything below runs inside try/finally so
                // isProcessingMedia is guaranteed to reset even if
                // getMediaResponse/getDoctorImageResponse/
                // getZipContentsResponse throw something unexpected —
                // without this, a single failure here left the flag stuck
                // `true` forever, permanently disabling the attach button
                // (visible but every tap silently doing nothing) until the
                // app was force-restarted. mediaScanner.loadPicked was
                // already try/caught below; the AI-response calls weren't.
                try {
                    val loadResult = try {
                        mediaScanner.loadPicked(uri)
                    } catch (e: Exception) {
                        com.kavitababy.data.MediaScannerService.LoadResult.Failure(
                            e.message ?: "File load karte waqt kuch galat ho gaya"
                        )
                    }

                    val responseText = when (loadResult) {
                        is com.kavitababy.data.MediaScannerService.LoadResult.Failure ->
                            loadResult.reason
                        is com.kavitababy.data.MediaScannerService.LoadResult.Success -> {
                            val pdfSummary = if (loadResult.indexedPdfs.isNotEmpty()) {
                                loadResult.indexedPdfs.joinToString("\n") { result ->
                                    when (result) {
                                        is PdfScannerService.PickResult.Success ->
                                            "📄 \"${result.pdfName}\" padh liya (${result.chunksCreated} sections) — ab isse related pucho!"
                                        is PdfScannerService.PickResult.Failure ->
                                            "📄 \"${result.reason}\""
                                    }
                                }
                            } else null

                            when {
                                loadResult.files.isEmpty() && pdfSummary != null ->
                                    // Zip had only PDF(s), no image/video/audio.
                                    pdfSummary
                                loadResult.files.size == 1 -> {
                                    val file = loadResult.files.first()
                                    // Doctor Mode + image (X-ray/CT/MRI/ECG/EEG/blood
                                    // report etc) goes through the medical-specific
                                    // reading path instead of the casual Study Mode
                                    // description — same image kind, different depth
                                    // and mandatory clinical disclaimer.
                                    val mediaAnswer = if (mode == AppMode.DOCTOR && file.kind == com.kavitababy.data.MediaScannerService.Kind.IMAGE) {
                                        aiRepository.getDoctorImageResponse(
                                            fileName = file.displayName,
                                            mimeType = file.mimeType,
                                            base64Data = file.base64Data
                                        )
                                    } else if (mode == AppMode.ENGINEER && file.kind == com.kavitababy.data.MediaScannerService.Kind.IMAGE) {
                                        aiRepository.getEngineerImageResponse(
                                            fileName = file.displayName,
                                            mimeType = file.mimeType,
                                            base64Data = file.base64Data
                                        )
                                    } else {
                                        aiRepository.getMediaResponse(
                                            fileName = file.displayName,
                                            mimeType = file.mimeType,
                                            base64Data = file.base64Data,
                                            kind = file.kind
                                        )
                                    }
                                    if (pdfSummary != null) "$pdfSummary\n\n$mediaAnswer" else mediaAnswer
                                }
                                else -> {
                                    // Multiple media files came out of a zip.
                                    val mediaAnswer = "\"$name\" mein ${loadResult.files.size} files mili, sabko padh rahi hoon...\n\n" +
                                        aiRepository.getZipContentsResponse(loadResult.files)
                                    if (pdfSummary != null) "$pdfSummary\n\n$mediaAnswer" else mediaAnswer
                                }
                            }
                        }
                    }

                    updateMessages { it + Message(responseText, isUser = false) }
                    if (mode == AppMode.DOCTOR && loadResult is com.kavitababy.data.MediaScannerService.LoadResult.Success) {
                        val file = loadResult.files.firstOrNull()
                        if (file != null) {
                            saveCaseNote(context, scope, "Medical image: ${file.displayName}", responseText, currentPatient?.id)
                            // If a Case Workup is active, this report's reading
                            // becomes one more finding to be correlated together
                            // with everything else in the case later.
                            if (caseWorkupActive) {
                                caseFindings = caseFindings + AIRepository.CaseFinding(
                                    label = file.displayName,
                                    content = responseText
                                )
                            }
                        }
                    }
                    if (mode == AppMode.STUDY && loadResult is com.kavitababy.data.MediaScannerService.LoadResult.Success) {
                        voiceManager.speak(responseText)
                    }
                } catch (e: Exception) {
                    updateMessages { it + Message(
                        "File samajhne mein dikkat aa gayi, dobara try karo.",
                        isUser = false
                    ) }
                } finally {
                    isProcessingMedia = false
                }
            }
        }
    }

    // Runs on first composition AND again whenever pdfScanTrigger changes
    // (bumped by MainActivity once storage access actually becomes
    // available — either already granted at launch, or granted just now
    // after the user returns from the All Files Access settings screen).
    // Scans the whole device for PDFs (filesystem walk if All Files Access
    // is granted, MediaStore query otherwise) and posts a confirmation into
    // the chat so the user can actually see it happened, instead of it
    // silently running with no feedback.
    // Shared by both the automatic startup scan (LaunchedEffect below) and
    // the manual "🔄 Rescan PDFs" button in the Study Mode header. Pulled
    // out into its own function so a failed auto-scan (timeout, permission
    // hiccup on MIUI, transient filesystem error) isn't a dead end — the
    // doctor/student can just tap the button to try again instead of
    // restarting the whole app.
    //
    // [forceRescan] re-reads and re-chunks every PDF found, even ones
    // already indexed — this is what "rescan" means to the button (in case
    // a previously-failed/partial index needs a clean redo), whereas the
    // automatic startup scan only wants to pick up genuinely new files.
    // [silent] = true for the automatic startup pass: it only speaks up in
    // chat when something actually changed (new PDFs indexed) or something
    // failed — not on every single app reopen just to say "sab pehle se
    // padhe hue hain", which would otherwise clutter history with a
    // near-identical message every time the app restarts.
    suspend fun runPdfScan(forceRescan: Boolean, silent: Boolean = false) {
        isBackgroundPdfScanning = true
        var errorDetail: String? = null
        val result = try {
            // Capped at 2 minutes — a full filesystem walk plus OCR on
            // every scanned-image PDF can genuinely take a long time on a
            // phone with lots of storage/apps, but it should never be able
            // to hang indefinitely. Timing out here just means this
            // particular scan pass gives up early; it does NOT block manual
            // PDF picking either way, since that's tracked separately via
            // isIndexingPdf.
            // Silent startup pass stays capped at 2 minutes (it runs on every
            // app open, shouldn't hang the launch experience). The manual
            // "🔄 Rescan PDFs" tap is an explicit, patient user action, and
            // OCR on scanned-image PDFs genuinely needs more time on a
            // phone with several such files — so it gets 5 minutes instead
            // of silently timing out on exactly the files that most need
            // OCR to begin with.
            val scanTimeoutMs = if (silent) 120_000L else 300_000L
            val timeoutMsg = if (silent) "2 minute" else "5 minute"
            // Internal budget is set below the hard outer timeout above, so
            // scanAllPdfs gets a chance to stop itself gracefully (and
            // return a real, partial ScanResult with timedOut=true) instead
            // of being killed mid-file by withTimeoutOrNull, which would
            // otherwise throw away the whole result even after most PDFs
            // in a big (e.g. 2GB) storage were already indexed and
            // committed to Room.
            val internalBudgetMs = scanTimeoutMs - 15_000L
            kotlinx.coroutines.withTimeoutOrNull(scanTimeoutMs) {
                pdfScanner.scanAllPdfs(forceRescan = forceRescan, timeBudgetMs = internalBudgetMs)
            } ?: run { errorDetail = "$timeoutMsg mein scan poora nahi hua (timeout)"; null }
        } catch (e: Exception) {
            errorDetail = e.message?.take(120) ?: e::class.simpleName
            null
        }
        isBackgroundPdfScanning = false

        if (silent && result != null && result.pdfsIndexed == 0 && result.failedFiles.isEmpty() && !result.timedOut) {
            return
        }

        val statusText = when {
            result == null ->
                "Phone ke PDFs scan karne mein dikkat aa gayi${if (errorDetail != null) " ($errorDetail)" else ""} — 📎 button se manually bhi PDF de sakte ho."
            result.timedOut && result.pdfsIndexed > 0 -> {
                val percent = if (result.pdfsFound > 0) (result.totalIndexedOverall * 100 / result.pdfsFound) else 0
                "Maine abhi ${result.pdfsIndexed} PDF padh liye. Overall ${result.totalIndexedOverall}/${result.pdfsFound} PDFs ho chuki hain ($percent%), ${result.pdfsRemaining} baaki hain — jo padh liya wo turant use kar sakte ho. 🔄 'Rescan PDFs' dabao ya app dobara kholo, wahi se aage padhegi."
            }
            result.timedOut ->
                "Scan shuru kiya tha lekin time kam pad gaya, is baar ek bhi PDF poora nahi padha paayi — 🔄 'Rescan PDFs' dabao, dobara try karegi."
            result.pdfsIndexed > 0 ->
                "Maine tumhare phone mein ${result.pdfsFound} PDF dhoondhe, unme se ${result.pdfsIndexed} ${if (forceRescan) "dobara" else "naye"} padh liye — ab in sabse related kuch bhi pucho, jaani!"
            result.pdfsFound > 0 ->
                "Tumhare phone ke saare ${result.pdfsFound} PDFs pehle se hi padhe hue hain, kuch naya nahi mila is baar."
            else ->
                "Mujhe abhi phone mein koi PDF nahi mila. Agar kahin folder mein hai jo main dekh nahi paa rahi, 📎 button se seedha de do."
        }
        // Surface *which* files failed and why — this is what actually
        // lets a repeatedly-failing PDF get diagnosed (password-protected,
        // corrupt, genuinely blank) instead of just silently vanishing.
        val failureNote = if (result != null && result.failedFiles.isNotEmpty()) {
            "\n\n⚠️ Ye nahi padh payi:\n" + result.failedFiles.take(5).joinToString("\n") { (name, reason) -> "• $name — $reason" } +
                if (result.failedFiles.size > 5) "\n...aur ${result.failedFiles.size - 5} aur" else ""
        } else ""
        updateMessages { it + Message(statusText + failureNote, isUser = false) }
    }

    // Full-device "read everything" scan — PDFs plus .txt/.md/.docx in one
    // pass, triggered only by the manual "📚 Sab Files" button (never
    // automatically on startup, unlike the PDF-only scan above, since this
    // one walks more of the filesystem and is meant to be an explicit,
    // on-demand "go read all my notes" action).
    suspend fun runAllFilesScan(forceRescan: Boolean) {
        isBackgroundAllFilesScanning = true
        var errorDetail: String? = null
        val result = try {
            kotlinx.coroutines.withTimeoutOrNull(180_000) {
                pdfScanner.scanAllFiles(forceRescan = forceRescan)
            } ?: run { errorDetail = "3 minute mein scan poora nahi hua (timeout)"; null }
        } catch (e: Exception) {
            errorDetail = e.message?.take(120) ?: e::class.simpleName
            null
        }
        isBackgroundAllFilesScanning = false

        val statusText = when {
            result == null ->
                "Phone ki files scan karne mein dikkat aa gayi${if (errorDetail != null) " ($errorDetail)" else ""} — 📎 button se manually bhi file de sakte ho."
            result.pdfsIndexed > 0 ->
                "Maine tumhare phone mein ${result.pdfsFound} files (PDF/txt/docx) dhoondhi, unme se ${result.pdfsIndexed} ${if (forceRescan) "dobara" else "nayi"} padh li — ab in sabse related kuch bhi pucho, jaani!"
            result.pdfsFound > 0 ->
                "Tumhare phone ki saari ${result.pdfsFound} files pehle se hi padhi hui hain, kuch naya nahi mila is baar."
            else ->
                "Mujhe abhi phone mein koi PDF/txt/docx file nahi mili."
        }
        val failureNote = if (result != null && result.failedFiles.isNotEmpty()) {
            "\n\n⚠️ Ye nahi padh payi:\n" + result.failedFiles.take(5).joinToString("\n") { (name, reason) -> "• $name — $reason" } +
                if (result.failedFiles.size > 5) "\n...aur ${result.failedFiles.size - 5} aur" else ""
        } else ""
        updateMessages { it + Message(statusText + failureNote, isUser = false) }
    }

    LaunchedEffect(pdfScanTrigger) {
        if (pdfScanTrigger == 0) return@LaunchedEffect
        // Startup pass only wants genuinely new files, not a full redo.
        runPdfScan(forceRescan = false, silent = true)
    }

    // One-time check for a crash on the previous run. Kept short and
    // non-alarming in chat — the full stack trace stays in the log file
    // (exportable via the Backup pill's crash-log option) rather than
    // being dumped into the conversation itself.
    LaunchedEffect(Unit) {
        val crashLog = com.kavitababy.data.CrashHandler.consumeLastCrashIfAny(context.applicationContext)
        if (crashLog != null) {
            val firstLine = crashLog.lineSequence().drop(8).firstOrNull()?.take(100) ?: "reason samajh nahi aayi"
            updateMessages { it + Message(
                "⚠️ Pichli baar app achanak band ho gayi thi ($firstLine). Agar dobara ho, 💾 Backup button se export karke bhej dena — crash log usme bhi included rahega, dekh lungi kya hua.",
                isUser = false
            ) }
        }
    }

    // Fires exactly once, only when MainActivity bumps screenshotScanTrigger
    // after the user explicitly tapped "Haan, padho" on the one-time
    // consent dialog. This is not a recurring/background scan — it runs
    // this single pass and then does nothing further unless the user picks
    // an image manually via the 📎 button afterwards.
    LaunchedEffect(screenshotScanTrigger) {
        if (screenshotScanTrigger == 0) return@LaunchedEffect
        isProcessingMedia = true
        updateMessages { it + Message(
            "Thik hai jaani, tumhare Screenshots folder ki recent images padh rahi hoon, ek second...",
            isUser = false
        ) }

        var found = 0
        val results = mutableListOf<Pair<String, String>>()
        try {
            found = mediaScanner.scanScreenshotsFolder { fileName, mimeType, base64Data ->
                val summary = aiRepository.getMediaResponse(
                    fileName = fileName,
                    mimeType = mimeType,
                    base64Data = base64Data,
                    kind = com.kavitababy.data.MediaScannerService.Kind.IMAGE
                )
                results.add(fileName to summary)
            }
        } catch (e: Exception) {
            // Scan failing shouldn't crash the chat — just report nothing found below.
        }

        isProcessingMedia = false
        val summaryText = if (results.isEmpty()) {
            "Mujhe Screenshots folder mein koi padhne layak image nahi mili."
        } else {
            "Maine $found screenshots padhe. Kuch important cheez chahiye inme se to bata do, " +
                "ya seedha pucho kisi specific screenshot ke baare mein."
        }
        updateMessages { it + Message(summaryText, isUser = false) }
    }

    // Combines every finding gathered so far in the active Case Workup into
    // one ranked differential. Posted into the chat like any other answer,
    // and also saved as a case note so it's retrievable later.
    fun combineCaseFindings() {
        if (caseFindings.isEmpty()) return
        isCombiningCase = true
        updateMessages { it + Message("🔗 Sab findings combine karke analyze kar rahi hoon (verification pass ke saath)...", isUser = true) }
        scope.launch {
            val relevantChunks = try {
                // One search PER finding (not one search over everything
                // joined together) — so a book chunk that's highly
                // relevant to just one finding's specific wording can
                // still surface, instead of needing to also match the
                // other unrelated findings to rank highly.
                ragEngine.findRelevantChunksMulti(
                    ragEngine.queriesFromFindings(caseFindings.map { it.content }),
                    maxChunks = 6
                )
            } catch (e: Exception) {
                emptyList()
            }
            val result = try {
                aiRepository.getCombinedCaseAnalysis(caseFindings, relevantChunks)
            } catch (e: Exception) {
                "Sorry, case combine karte waqt dikkat aa gayi. Dobara try karo."
            }
            isCombiningCase = false
            updateMessages { it + Message(result, isUser = false) }
            saveCaseNote(
                context, scope,
                "Combined case (${caseFindings.size} findings)",
                result,
                currentPatient?.id
            )
            // Auto-fill the patient file's "current suggestion" with this
            // combined differential — the doctor hasn't confirmed a
            // diagnosis yet at this point, so currentDiagnosis is left
            // untouched (only currentSuggestion is written here).
            currentPatient?.let { patient ->
                updatePatientClinicalSummary(patient.id, suggestion = result)
            }
            // Explicit confirmation so the doctor sees this actually landed
            // in the patient's file, instead of just trusting it happened
            // silently in the background.
            updateMessages { it + Message(
                currentPatient?.let { "💾 Saved to ${it.displayName}'s file." }
                    ?: "💾 Saved (no patient linked — select a patient from Patient List to attach future cases to their file).",
                isUser = false
            ) }
            confirmedDiagnosisContext = caseFindings.joinToString("\n") { "${it.label}: ${it.content.take(200)}" }
        }
    }

    // Once the doctor types/confirms a diagnosis, fetches a standard
    // treatment/medicine REFERENCE for it — gated entirely on this explicit
    // confirmation, never auto-suggested off the AI's own ranked list.
    fun getTreatmentForConfirmedDiagnosis(diagnosis: String) {
        if (diagnosis.isBlank()) return
        updateMessages { it + Message("✅ Diagnosis confirm: $diagnosis", isUser = true) }
        isThinking = true

        // Same stale-snapshot trap as in send(): `messages` above is a
        // one-time val from THIS recomposition. Everything below runs
        // later inside the coroutine, and this function fires off several
        // updateMessages() calls in sequence (result, interaction check,
        // file-saved confirmation) — reusing the stale `messages` each
        // time means every call overwrites the previous one instead of
        // appending, so only the last message ever survives. Capturing
        // the mode now and always reading/writing the LIVE per-mode list
        // fixes that.
        val sendMode = mode
        fun liveMessages(): List<Message> = if (sendMode == AppMode.STUDY) studyMessages else doctorMessages
        fun setLiveMessages(newList: List<Message>) {
            if (sendMode == AppMode.STUDY) studyMessages = newList else doctorMessages = newList
        }

        scope.launch {
            val relevantChunks = try {
                // Search using BOTH the diagnosis name AND the case
                // context separately — a treatment/dosage chunk in the
                // book might be indexed under wording that matches the
                // clinical context (symptoms/history) even if it doesn't
                // literally contain the diagnosis name itself.
                val queries = listOf(diagnosis) +
                    (if (confirmedDiagnosisContext.isNotBlank()) listOf(confirmedDiagnosisContext.take(300)) else emptyList())
                ragEngine.findRelevantChunksMulti(queries, maxChunks = 6)
            } catch (e: Exception) {
                emptyList()
            }
            val result = try {
                aiRepository.getTreatmentReference(diagnosis, confirmedDiagnosisContext, relevantChunks, treatmentSystem)
            } catch (e: Exception) {
                "Sorry, treatment reference laate waqt dikkat aa gayi. Dobara try karo."
            }
            isThinking = false
            setLiveMessages(liveMessages() + Message(result, isUser = false))
            saveCaseNote(context, scope, "Confirmed diagnosis: $diagnosis", result, currentPatient?.id)
            // If the patient already has medicines on file, check the new
            // suggestion against them BEFORE overwriting — this way the
            // interaction warning (if any) is visible while the doctor
            // still has the old list to compare against, not after it's
            // already been replaced.
            currentPatient?.let { patient ->
                if (patient.currentMedicines.isNotBlank()) {
                    setLiveMessages(liveMessages() + Message(
                        "💊 Existing medicines ke saath cross-check kar rahi hoon...",
                        isUser = false
                    ))
                    val interactionResult = try {
                        aiRepository.checkDrugInteractions(
                            existingMedicines = patient.currentMedicines,
                            newMedicines = result,
                            knownAllergies = patient.knownAllergies,
                            relevantChunks = relevantChunks
                        )
                    } catch (e: Exception) {
                        "Sorry, interaction check karte waqt dikkat aa gayi — manually verify karo."
                    }
                    setLiveMessages(liveMessages() + Message(interactionResult, isUser = false))
                }
                updatePatientClinicalSummary(
                    patient.id,
                    diagnosis = diagnosis,
                    medicines = result
                )
                setLiveMessages(liveMessages() + Message(
                    "💾 ${patient.displayName}'s file updated — diagnosis aur medicine/dose reference save ho gaya.",
                    isUser = false
                ))
            }
        }
    }

    fun send(text: String) {
        if (text.isBlank()) return
        updateMessages { it + Message(text, isUser = true) }
        isThinking = true

        // `messages` above is a one-time snapshot from this recomposition.
        // Everything inside scope.launch below runs later/asynchronously, so
        // capturing the mode now and always reading the LIVE per-mode list
        // (instead of the stale `messages` val) is what keeps every message
        // added after this point — including the user bubble we just added —
        // from being silently dropped when the next update overwrites the list.
        val sendMode = mode
        fun liveMessages(): List<Message> = when (sendMode) {
            AppMode.STUDY -> studyMessages
            AppMode.DOCTOR -> doctorMessages
            AppMode.ENGINEER -> engineerMessages
        }
        fun setLiveMessages(newList: List<Message>) {
            when (sendMode) {
                AppMode.STUDY -> studyMessages = newList
                AppMode.DOCTOR -> doctorMessages = newList
                AppMode.ENGINEER -> engineerMessages = newList
            }
        }

        scope.launch {
            // Explicit memory commands ("yaad rakhna ki...", "sab bhool ja")
            // short-circuit straight to a confirmation — no need to hit
            // Gemini at all for these, and they should always work even if
            // the AI is unreachable.
            val memoryCommandReply = try {
                learningEngine.maybeHandleExplicitMemoryCommand(text)
            } catch (e: Exception) {
                null
            }
            if (memoryCommandReply != null) {
                setLiveMessages(liveMessages() + Message(memoryCommandReply, isUser = false, question = text))
                isThinking = false
                if (sendMode == AppMode.STUDY) voiceManager.speak(memoryCommandReply)
                return@launch
            }

            // Passive extraction from ordinary messages (name, exam date,
            // weak subject mentioned in passing) — best-effort, never blocks
            // the main reply if it fails or finds nothing.
            try { learningEngine.autoExtractFromMessage(text) } catch (e: Exception) { }

            val relevantChunks = try {
                ragEngine.findRelevantChunks(text)
            } catch (e: Exception) {
                emptyList()
            }

            var wasStreamed = false
            val response = try {
                if (sendMode == AppMode.DOCTOR) {
                    aiRepository.getDoctorResponse(text, relevantChunks)
                } else if (sendMode == AppMode.ENGINEER) {
                    aiRepository.getEngineerResponse(text, relevantChunks)
                } else {
                    val memoryBlock = try { learningEngine.memoryContextBlock() } catch (e: Exception) { "" }
                    val feedbackBlock = try { learningEngine.feedbackContextBlock() } catch (e: Exception) { "" }

                    // Insert an empty placeholder bubble first, then grow its
                    // text in place as chunks stream in — same Message id
                    // throughout so this reads as "the answer typing itself
                    // out" rather than a new bubble appearing per chunk.
                    val streamingId = java.util.UUID.randomUUID().toString()
                    setLiveMessages(liveMessages() + Message("", isUser = false, id = streamingId, question = text))
                    isThinking = false
                    wasStreamed = true

                    // Streaming mode captured at closure-creation time so
                    // onChunk below always patches the correct per-mode list
                    // even if the doctor somehow switches tabs mid-stream.
                    val streamingMode = sendMode

                    val streamedAnswer = aiRepository.streamResponse(
                        question = text,
                        relevantChunks = relevantChunks,
                        memoryBlock = memoryBlock,
                        feedbackBlock = feedbackBlock
                    ) { chunk ->
                        withContext(kotlinx.coroutines.Dispatchers.Main) {
                            // Read/write the live per-mode state directly
                            // (not the outer `messages` val, which is a
                            // one-time snapshot from when send() started —
                            // using it here would silently drop every
                            // chunk but the first since each update would
                            // overwrite from the same stale base list).
                            if (streamingMode == AppMode.STUDY) {
                                studyMessages = studyMessages.map { m ->
                                    if (m.id == streamingId) m.copy(text = m.text + chunk) else m
                                }
                            } else {
                                doctorMessages = doctorMessages.map { m ->
                                    if (m.id == streamingId) m.copy(text = m.text + chunk) else m
                                }
                            }
                        }
                    }

                    // Reconcile the final bubble with the authoritative full
                    // answer (covers the offline-fallback path inside
                    // streamResponse, where onChunk fires once with the
                    // complete text rather than incrementally).
                    if (streamingMode == AppMode.STUDY) {
                        studyMessages = studyMessages.map { m -> if (m.id == streamingId) m.copy(text = streamedAnswer) else m }
                    } else {
                        doctorMessages = doctorMessages.map { m -> if (m.id == streamingId) m.copy(text = streamedAnswer) else m }
                    }
                    streamedAnswer
                }
            } catch (e: Exception) {
                "Sorry jaani, thoda dikkat aa gayi. Dobara try karo."
            }

            if (!wasStreamed) {
                setLiveMessages(liveMessages() + Message(response, isUser = false, question = text))
            }
            isThinking = false

            if (sendMode == AppMode.DOCTOR) {
                saveCaseNote(context, scope, text, response, currentPatient?.id)
                if (caseWorkupActive) {
                    caseFindings = caseFindings + AIRepository.CaseFinding(
                        label = "Doctor's note",
                        content = text
                    )
                }
            }

            // Doctor Mode answers are long/clinical — reading them aloud
            // isn't useful the way it is for the casual Study Mode chat.
            if (sendMode == AppMode.STUDY) {
                voiceManager.speak(response)

                // Topic-repeat nudge only makes sense in Study Mode (it's
                // meant for exam revision, not clinical cases). Posted as a
                // separate follow-up message so it doesn't get lost inside
                // the main answer text.
                val nudge = try { learningEngine.trackAndMaybeNudge(text) } catch (e: Exception) { null }
                if (nudge != null) {
                    setLiveMessages(liveMessages() + Message(nudge, isUser = false))
                }
            }
        }
    }

    // Sends a staged image (from the 📎 → pick image flow) together with
    // whatever caption the user typed, then runs it through the same AI
    // reading path the old immediate-send flow used — just with the
    // caption passed through as extra instruction/context instead of
    // being unused.
    fun sendPendingImage(caption: String) {
        val pending = pendingImage ?: return
        pendingImage = null

        updateMessages { it + Message(
            text = caption,
            isUser = true,
            attachmentBase64 = pending.base64Data,
            attachmentMimeType = pending.mimeType
        ) }
        isProcessingMedia = true

        val sendMode = mode
        scope.launch {
            try {
                val responseText = if (sendMode == AppMode.DOCTOR) {
                    aiRepository.getDoctorImageResponse(
                        fileName = pending.name,
                        mimeType = pending.mimeType,
                        base64Data = pending.base64Data,
                        caseContext = caption
                    )
                } else if (sendMode == AppMode.ENGINEER) {
                    aiRepository.getEngineerImageResponse(
                        fileName = pending.name,
                        mimeType = pending.mimeType,
                        base64Data = pending.base64Data,
                        questionContext = caption
                    )
                } else {
                    aiRepository.getMediaResponse(
                        fileName = pending.name,
                        mimeType = pending.mimeType,
                        base64Data = pending.base64Data,
                        kind = com.kavitababy.data.MediaScannerService.Kind.IMAGE,
                        instruction = caption
                    )
                }

                updateMessages { it + Message(responseText, isUser = false) }

                if (sendMode == AppMode.DOCTOR) {
                    saveCaseNote(context, scope, "Medical image: ${pending.name}", responseText, currentPatient?.id)
                    if (caseWorkupActive) {
                        caseFindings = caseFindings + AIRepository.CaseFinding(
                            label = pending.name,
                            content = responseText
                        )
                    }
                }
                if (sendMode == AppMode.STUDY) {
                    voiceManager.speak(responseText)
                }
            } catch (e: Exception) {
                updateMessages { it + Message("Image samajhne mein dikkat aa gayi, dobara try karo.", isUser = false) }
            } finally {
                isProcessingMedia = false
            }
        }
    }

    // Fires the Android share sheet for whatever Uri was last exported —
    // a plain Intent.ACTION_SEND rather than a registered launcher, since
    // this doesn't need a result back (the doctor picks WhatsApp/Email/
    // whatever and this app's job is done once the chooser opens).
    fun shareExportedFile(uri: Uri, mimeType: String = "text/plain") {
        try {
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(shareIntent, "Export share karo"))
        } catch (e: Exception) {
            // No app available to handle the share sheet, or some other
            // one-off failure — nothing to recover into, just no-op
            // rather than crash the chat screen over an export share.
        }
    }

    var isExporting by remember { mutableStateOf(false) }
    var isBackingUp by remember { mutableStateOf(false) }
    var isRestoring by remember { mutableStateOf(false) }

    fun backupAllData() {
        if (isBackingUp) return
        isBackingUp = true
        scope.launch {
            val uri = try {
                backupService.exportBackup()
            } catch (e: Exception) {
                null
            }
            isBackingUp = false
            if (uri != null) {
                shareExportedFile(uri, mimeType = "application/zip")
            } else {
                updateMessages { it + Message("Backup banane mein dikkat aa gayi, dobara try karo.", isUser = false) }
            }
        }
    }

    val restoreBackupLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri == null || isRestoring) return@rememberLauncherForActivityResult
        isRestoring = true
        scope.launch {
            val success = try {
                backupService.importBackup(uri)
            } catch (e: Exception) {
                false
            }
            isRestoring = false
            updateMessages { it + Message(
                if (success)
                    "✅ Backup restore ho gaya! Ab app ko poori tarah band karke (recent apps se swipe karke) dobara kholo taaki restored data load ho jaaye."
                else
                    "Backup restore nahi ho paaya — check karo ki ye wahi zip file hai jo 💾 Backup se banayi thi.",
                isUser = false
            ) }
        }
    }

    fun exportCurrentChat() {
        if (messages.isEmpty() || isExporting) return
        isExporting = true
        scope.launch {
            val exportMessages = messages.map {
                com.kavitababy.data.ExportService.ChatMessageForExport(it.text, it.isUser)
            }
            val uri = try {
                exportService.exportChatTranscript(
                    messages = exportMessages,
                    modeLabel = when (mode) {
                        AppMode.DOCTOR -> "Doctor Mode"
                        AppMode.ENGINEER -> "Engineer Mode"
                        AppMode.STUDY -> "Study Mode"
                    },
                    patientName = currentPatient?.displayName
                )
            } catch (e: Exception) {
                null
            }
            isExporting = false
            if (uri != null) {
                shareExportedFile(uri)
            } else {
                updateMessages { it + Message("Export banane mein dikkat aa gayi, dobara try karo.", isUser = false) }
            }
        }
    }

    fun exportActivePatientHistory() {
        val patient = currentPatient ?: return
        if (isExporting) return
        isExporting = true
        scope.launch {
            val uri = try {
                val db = KavitaDatabase.getInstance(context.applicationContext)
                val notes = db.caseNoteDao().getForPatient(patient.id)
                val patientCase = db.patientCaseDao().getById(patient.id)
                if (patientCase != null) {
                    exportService.exportPatientHistory(patientCase, patient.displayName, notes)
                } else null
            } catch (e: Exception) {
                null
            }
            isExporting = false
            if (uri != null) {
                shareExportedFile(uri)
            } else {
                updateMessages { it + Message("Patient history export nahi ho payi, dobara try karo.", isUser = false) }
            }
        }
    }

    fun exportActivePatientPrescription() {
        val patient = currentPatient ?: return
        if (isExporting) return
        isExporting = true
        scope.launch {
            val uri = try {
                val db = KavitaDatabase.getInstance(context.applicationContext)
                val patientCase = db.patientCaseDao().getById(patient.id)
                if (patientCase != null) {
                    exportService.exportPrescription(patientCase, patient.displayName)
                } else null
            } catch (e: Exception) {
                null
            }
            isExporting = false
            if (uri != null) {
                shareExportedFile(uri)
            } else {
                updateMessages {
                    it + Message(
                        "Prescription banane ke liye pehle patient ki file mein medicines add karo.",
                        isUser = false
                    )
                 }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF1A1A2E))
    ) {
        // Header with Kavita's face — compact single row in Doctor Mode
        // (face + subtitle removed) since that screen already has several
        // stacked panels below competing for vertical space; Study Mode
        // keeps the original full-size friendly header.
        if (mode == AppMode.DOCTOR) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF16213E))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Tap Kavita's photo or name to open Profile & Settings —
                // scoped to just the photo+name (weight(1f) Column below),
                // not the mode chips or Voice Changer chip further right,
                // so it doesn't steal taps meant for those.
                Image(
                    painter = painterResource(id = R.drawable.kavita_face),
                    contentDescription = "Kavita Baby",
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .clickable(
                            indication = null,
                            interactionSource = remember { MutableInteractionSource() },
                            onClick = { showSettings = true }
                        )
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clickable(
                            indication = null,
                            interactionSource = remember { MutableInteractionSource() },
                            onClick = { showSettings = true }
                        )
                ) {
                    Text(
                        text = "Kavita Baby — Doctor Mode 🩺",
                        color = Color.White,
                        fontSize = 15.sp
                    )
                    Text(
                        text = when {
                            isListening -> "Sunn rahi hoon... 👂"
                            voiceErrorMessage != null -> voiceErrorMessage!!
                            isThinking -> "Soch rahi hoon... 🤔"
                            isIndexingPdf || isBackgroundPdfScanning -> "PDF padh rahi hoon... 📄"
                            isBackgroundAllFilesScanning -> "Sab files padh rahi hoon... 📚"
                            isProcessingMedia -> "File samajh rahi hoon... 🔍"
                            else -> "Case describe karo (naam mat likho)... 📋"
                        },
                        color = if (voiceErrorMessage != null) Color.Red else Color(0xFFFF6B9D),
                        fontSize = 11.sp
                    )
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(Color(0xFF0F1729))
                            .padding(3.dp)
                    ) {
                        ModeChip(label = "Study", selected = false, onClick = { mode = AppMode.STUDY })
                        ModeChip(label = "Doctor", selected = true, onClick = { })
                        ModeChip(label = "Engineer", selected = false, onClick = { mode = AppMode.ENGINEER })
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    // Voice Changer — opens the male/female TTS voice
                    // picker. Kept up here with the mode chips (header
                    // area has room), not in the bottom input row, which
                    // stays reserved for attach + mic like before.
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0xFF0F1729))
                            .clickable(
                                indication = null,
                                interactionSource = remember { MutableInteractionSource() },
                                onClick = { showVoiceGenderDialog = true }
                            )
                            .padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (currentVoiceGender == VoiceManager.VoiceGender.FEMALE) "👩" else "👨",
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Voice Changer",
                            color = Color(0xFFAAAAAA),
                            fontSize = 10.sp
                        )
                    }
                }
            }
        } else if (mode == AppMode.ENGINEER) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF16213E))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Image(
                    painter = painterResource(id = R.drawable.kavita_face),
                    contentDescription = "Kavita Baby",
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .clickable(
                            indication = null,
                            interactionSource = remember { MutableInteractionSource() },
                            onClick = { showSettings = true }
                        )
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clickable(
                            indication = null,
                            interactionSource = remember { MutableInteractionSource() },
                            onClick = { showSettings = true }
                        )
                ) {
                    Text(
                        text = "Kavita Baby — Engineer Mode ⚙️",
                        color = Color.White,
                        fontSize = 15.sp
                    )
                    Text(
                        text = when {
                            isListening -> "Sunn rahi hoon... 👂"
                            voiceErrorMessage != null -> voiceErrorMessage!!
                            isThinking -> "Soch rahi hoon... 🤔"
                            isIndexingPdf || isBackgroundPdfScanning -> "PDF padh rahi hoon... 📄"
                            isBackgroundAllFilesScanning -> "Sab files padh rahi hoon... 📚"
                            isProcessingMedia -> "File samajh rahi hoon... 🔍"
                            else -> "Engineering sawaal pucho (Mechanical/Electrical/Civil/etc)... 🛠️"
                        },
                        color = if (voiceErrorMessage != null) Color.Red else Color(0xFFFF6B9D),
                        fontSize = 11.sp
                    )
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(Color(0xFF0F1729))
                            .padding(3.dp)
                    ) {
                        ModeChip(label = "Study", selected = false, onClick = { mode = AppMode.STUDY })
                        ModeChip(label = "Doctor", selected = false, onClick = { mode = AppMode.DOCTOR })
                        ModeChip(label = "Engineer", selected = true, onClick = { })
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0xFF0F1729))
                            .clickable(
                                indication = null,
                                interactionSource = remember { MutableInteractionSource() },
                                onClick = { showEngineerCalculator = true }
                            )
                            .padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "🧮", fontSize = 13.sp)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Calculator",
                            color = Color(0xFFAAAAAA),
                            fontSize = 10.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0xFF0F1729))
                            .clickable(
                                indication = null,
                                interactionSource = remember { MutableInteractionSource() },
                                onClick = { showUnitConverter = true }
                            )
                            .padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "📐", fontSize = 13.sp)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Units",
                            color = Color(0xFFAAAAAA),
                            fontSize = 10.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0xFF0F1729))
                            .clickable(
                                indication = null,
                                interactionSource = remember { MutableInteractionSource() },
                                onClick = { showScienceCalculator = true }
                            )
                            .padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "🔬", fontSize = 13.sp)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Science",
                            color = Color(0xFFAAAAAA),
                            fontSize = 10.sp
                        )
                    }
                }
            }
        } else {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF16213E))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.kavita_face),
                        contentDescription = "Kavita Baby",
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .clickable(
                                indication = null,
                                interactionSource = remember { MutableInteractionSource() },
                                onClick = { showSettings = true }
                            )
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clickable(
                                indication = null,
                                interactionSource = remember { MutableInteractionSource() },
                                onClick = { showSettings = true }
                            )
                    ) {
                        Text(
                            text = "Kavita Baby 💕",
                            color = Color.White,
                            fontSize = 15.sp
                        )
                        Text(
                            text = when {
                                isListening -> "Sunn rahi hoon... 👂"
                                voiceErrorMessage != null -> voiceErrorMessage!!
                                isThinking -> "Soch rahi hoon... 🤔"
                                isIndexingPdf || isBackgroundPdfScanning -> "PDF padh rahi hoon... 📄"
                                isBackgroundAllFilesScanning -> "Sab files padh rahi hoon... 📚"
                                isProcessingMedia -> "File samajh rahi hoon... 🔍"
                                else -> "Bolo jaani... 💬"
                            },
                            color = if (voiceErrorMessage != null) Color.Red else Color(0xFFFF6B9D),
                            fontSize = 11.sp
                        )
                    }
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(Color(0xFF0F1729))
                            .padding(3.dp)
                    ) {
                        ModeChip(label = "Study", selected = true, onClick = { })
                        ModeChip(label = "Doctor", selected = false, onClick = { mode = AppMode.DOCTOR })
                        ModeChip(label = "Engineer", selected = false, onClick = { mode = AppMode.ENGINEER })
                    }
                }

                // Button pill row — horizontally scrollable so all 5
                // pills (Voice Changer, Rescan PDFs, Sab Files, Export,
                // Case Practice) fit on one compact line instead of
                // getting clipped off-screen or forcing a taller header.
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Voice Changer — opens the male/female TTS voice
                    // picker.
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0xFF0F1729))
                            .clickable(
                                indication = null,
                                interactionSource = remember { MutableInteractionSource() },
                                onClick = { showVoiceGenderDialog = true }
                            )
                            .padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (currentVoiceGender == VoiceManager.VoiceGender.FEMALE) "👩" else "👨",
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Voice Changer",
                            color = Color(0xFFAAAAAA),
                            fontSize = 10.sp
                        )
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    // Manual PDF rescan — for when the automatic startup
                    // scan fails (timeout on a big/slow MIUI filesystem
                    // walk, transient error) or the doctor/student just
                    // added new PDFs and doesn't want to wait for the next
                    // app restart. forceRescan = true so it also re-reads
                    // PDFs that failed partway through last time, not just
                    // brand-new files. Disabled mid-scan so a tap doesn't
                    // queue up a second overlapping scan.
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0xFF0F1729))
                            .clickable(
                                enabled = !isBackgroundPdfScanning,
                                indication = null,
                                interactionSource = remember { MutableInteractionSource() },
                                onClick = { scope.launch { runPdfScan(forceRescan = true) } }
                            )
                            .padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = if (isBackgroundPdfScanning) "⏳" else "🔄", fontSize = 13.sp)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "Rescan PDFs", color = Color(0xFFAAAAAA), fontSize = 10.sp)
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    // "Sab Files Padho" — reads everything the phone has
                    // that actually contains extractable text (PDF +
                    // txt/md + docx) in one full-device pass, not just
                    // PDFs. Separate from the PDF-only button above so
                    // tapping one doesn't disable the other.
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0xFF0F1729))
                            .clickable(
                                enabled = !isBackgroundAllFilesScanning,
                                indication = null,
                                interactionSource = remember { MutableInteractionSource() },
                                onClick = { scope.launch { runAllFilesScan(forceRescan = true) } }
                            )
                            .padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = if (isBackgroundAllFilesScanning) "⏳" else "📚", fontSize = 13.sp)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "Sab Files", color = Color(0xFFAAAAAA), fontSize = 10.sp)
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    // Full-data backup (Room DB + any crash logs) as a
                    // shareable zip — the "don't lose everything" safety
                    // net. Always available, unlike Export above which
                    // needs an active chat.
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0xFF0F1729))
                            .clickable(
                                enabled = !isBackingUp,
                                indication = null,
                                interactionSource = remember { MutableInteractionSource() },
                                onClick = { backupAllData() }
                            )
                            .padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = if (isBackingUp) "⏳" else "💾", fontSize = 13.sp)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "Backup", color = Color(0xFFAAAAAA), fontSize = 10.sp)
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    // Restores a previously exported backup zip. Opens the
                    // system file picker via GetContent — the same
                    // no-broad-permission-needed pattern as the 📎 attach
                    // button, since the user explicitly picks the file.
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0xFF0F1729))
                            .clickable(
                                enabled = !isRestoring,
                                indication = null,
                                interactionSource = remember { MutableInteractionSource() },
                                onClick = { restoreBackupLauncher.launch("*/*") }
                            )
                            .padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = if (isRestoring) "⏳" else "📥", fontSize = 13.sp)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "Restore", color = Color(0xFFAAAAAA), fontSize = 10.sp)
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    // Export this chat as a text file, shareable via
                    // WhatsApp/Email/etc — only meaningful once there's
                    // actually a conversation to export.
                    if (messages.isNotEmpty()) {
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color(0xFF0F1729))
                                .clickable(
                                    indication = null,
                                    interactionSource = remember { MutableInteractionSource() },
                                    onClick = { exportCurrentChat() }
                                )
                                .padding(horizontal = 10.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = if (isExporting) "⏳" else "📤", fontSize = 13.sp)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "Export", color = Color(0xFFAAAAAA), fontSize = 10.sp)
                        }

                        Spacer(modifier = Modifier.width(6.dp))
                    }

                    // Case Practice — opens the symptom-checker case
                    // simulation dialog (AI plays a patient with a hidden
                    // diagnosis, student asks questions then submits
                    // their own diagnosis for feedback).
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0xFF0F1729))
                            .clickable(
                                indication = null,
                                interactionSource = remember { MutableInteractionSource() },
                                onClick = { showSymptomCheckerDialog = true }
                            )
                            .padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "🩺", fontSize = 13.sp)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "Case Practice", color = Color(0xFFAAAAAA), fontSize = 10.sp)
                    }
                }
            }
        }

        if (mode == AppMode.DOCTOR) {
            // Compact summary row — always visible, one line, tap to
            // expand/collapse everything below (warning banner, patient
            // bar, Case Workup panel). This is what reclaims the vertical
            // space that used to be permanently occupied by those panels.
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF241833))
                    .clickable(
                        indication = null,
                        interactionSource = remember { MutableInteractionSource() },
                        onClick = { doctorPanelExpanded = !doctorPanelExpanded }
                    )
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = currentPatient?.let { "🧑‍⚕️ ${it.displayName}" } ?: "🧑‍⚕️ Patient nahi select",
                    color = Color.White,
                    fontSize = 12.sp,
                    modifier = Modifier.weight(1f)
                )
                if (caseWorkupActive) {
                    Text(
                        text = "📋 ${caseFindings.size} finding${if (caseFindings.size == 1) "" else "s"}",
                        color = Color(0xFFFF6B9D),
                        fontSize = 12.sp,
                        modifier = Modifier.padding(end = 8.dp)
                    )
                }
                // Export — patient's full case history if one is active,
                // otherwise just this session's chat transcript. Nested
                // clickable inside the row's own clickable (which toggles
                // Details) — Compose gives touch priority to the more
                // specific inner target, so tapping this doesn't also
                // toggle the panel.
                Text(
                    text = if (isExporting) "⏳" else "📤",
                    fontSize = 14.sp,
                    modifier = Modifier
                        .padding(end = 10.dp)
                        .clickable(
                            indication = null,
                            interactionSource = remember { MutableInteractionSource() },
                            onClick = {
                                if (currentPatient != null) exportActivePatientHistory() else exportCurrentChat()
                            }
                        )
                )
                // Rx — separate from the full-history export above, this
                // pulls just the current diagnosis + medicines into a
                // clean printable prescription slip. Only shown once a
                // patient is selected and has at least something in the
                // medicines field (checked at export time; a tap with
                // nothing there just gets a friendly nudge instead of a
                // silent no-op) — Case Workup/history export doesn't need
                // this same guard since an empty history is still valid.
                if (currentPatient != null) {
                    Text(
                        text = if (isExporting) "⏳" else "💊",
                        fontSize = 14.sp,
                        modifier = Modifier
                            .padding(end = 10.dp)
                            .clickable(
                                indication = null,
                                interactionSource = remember { MutableInteractionSource() },
                                onClick = { exportActivePatientPrescription() }
                            )
                    )
                }
                Text(
                    text = if (doctorPanelExpanded) "▲ Hide" else "▼ Details",
                    color = Color(0xFF4A90E2),
                    fontSize = 12.sp
                )
            }

            if (doctorPanelExpanded) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF2A1A1A))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "⚠️ Patient naam sirf Patient List ke through add karo (encrypted save hota hai) " +
                            "— chat mein direct naam mat likho. Final decision aapka clinical judgement hai.",
                        color = Color(0xFFFFB4A2),
                        fontSize = 11.sp
                    )
                }

                // Patient bar — shows the active patient (if any) and a button
                // to open the patient list / switch patient / start fresh.
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF241833))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = currentPatient?.let { "🧑‍⚕️ ${it.displayName} (${it.age}, ${it.gender})" }
                            ?: "🧑‍⚕️ Koi patient select nahi hai",
                        color = Color.White,
                        fontSize = 13.sp,
                        modifier = Modifier.weight(1f)
                    )
                    if (currentPatient != null) {
                        TextButton(onClick = { showEditPatientFileDialog = true }) {
                            Text("Edit File", color = Color(0xFFFFD166), fontSize = 13.sp)
                        }
                    }
                    TextButton(onClick = { showLearnUrlDialog = true }) {
                        Text("🌐 Learn URL", color = Color(0xFF4A90E2), fontSize = 13.sp)
                    }
                    TextButton(onClick = {
                        patientListRefreshTrigger++
                        showPatientList = true
                    }) {
                        Text("Patient List", color = Color(0xFFFF6B9D), fontSize = 13.sp)
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF241833))
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 12.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (currentPatient != null) {
                        TextButton(onClick = { showFollowUpDialog = true }) {
                            Text("⏰ Follow-up set karo", color = Color(0xFF6BCB77), fontSize = 13.sp)
                        }
                    }
                    TextButton(onClick = { showUpcomingFollowUps = true }) {
                        Text("📋 Upcoming Follow-ups", color = Color(0xFF6BCB77), fontSize = 13.sp)
                    }
                    TextButton(onClick = { showSymptomCheckerDialog = true }) {
                        Text("🩺 Symptom Checker", color = Color(0xFF6BCB77), fontSize = 13.sp)
                    }
                    TextButton(onClick = { showMedicineCheckDialog = true }) {
                        Text("💊 Medicine Check", color = Color(0xFF6BCB77), fontSize = 13.sp)
                    }
                    TextButton(onClick = { showSoapNoteDialog = true }) {
                        Text("📝 SOAP Note", color = Color(0xFF6BCB77), fontSize = 13.sp)
                    }
                    if (currentPatient != null) {
                        TextButton(onClick = { showLabTrendsDialog = true }) {
                            Text("📈 Lab Trends", color = Color(0xFF6BCB77), fontSize = 13.sp)
                        }
                    }
                    TextButton(onClick = { showVitalsCalcDialog = true }) {
                        Text("🧮 Vitals Calc", color = Color(0xFF6BCB77), fontSize = 13.sp)
                    }
                    TextButton(onClick = { showReferralLetterDialog = true }) {
                        Text("📨 Referral Letter", color = Color(0xFF6BCB77), fontSize = 13.sp)
                    }
                }

                // Case Workup panel — lets multiple reports/notes for ONE case be
                // gathered, then combined into a single ranked differential, then
                // (once the doctor confirms a diagnosis) a treatment reference.
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF1E1430))
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = if (caseWorkupActive)
                                "📋 Case Workup: ${caseFindings.size} finding${if (caseFindings.size == 1) "" else "s"} collected"
                            else "📋 Case Workup",
                            color = Color.White,
                            fontSize = 13.sp,
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(onClick = {
                            if (caseWorkupActive) {
                                // Ending a workup clears it — starting a new one
                                // later begins a fresh, empty findings list.
                                caseWorkupActive = false
                                caseFindings = emptyList()
                                confirmedDiagnosisContext = ""
                                currentPatient = null
                            } else {
                                caseWorkupActive = true
                                val patientNote = if (currentPatient == null) {
                                    " (Abhi koi patient select nahi hai — Patient List se select ya naya patient banao " +
                                        "taaki ye case unke record mein bhi save ho.)"
                                } else ""
                                updateMessages { it + Message(
                                    "Case Workup shuru — ab jo bhi reports/scans upload karogi ya notes " +
                                        "type karogi, sab is ek case mein collect hongi. Jab sab de diya ho, " +
                                        "\"Combine\" dabao ek combined ranked differential ke liye.$patientNote",
                                    isUser = false
                                ) }
                            }
                        }) {
                            Text(
                                text = if (caseWorkupActive) "End" else "Start",
                                color = Color(0xFFFF6B9D),
                                fontSize = 13.sp
                            )
                        }
                    }

                    if (caseWorkupActive) {
                        // Treatment-system choice — applies to the "Confirm dx +
                        // treatment" action below.
                        Row(
                            modifier = Modifier.padding(top = 4.dp, bottom = 2.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text("Reference:", color = Color(0xFF888888), fontSize = 10.sp, modifier = Modifier.padding(top = 3.dp))
                            ModeChip(
                                label = "Modern",
                                selected = treatmentSystem == AIRepository.TreatmentSystem.MODERN_ONLY,
                                onClick = { treatmentSystem = AIRepository.TreatmentSystem.MODERN_ONLY }
                            )
                            ModeChip(
                                label = "Ayurveda",
                                selected = treatmentSystem == AIRepository.TreatmentSystem.AYURVEDA_ONLY,
                                onClick = { treatmentSystem = AIRepository.TreatmentSystem.AYURVEDA_ONLY }
                            )
                            ModeChip(
                                label = "Both",
                                selected = treatmentSystem == AIRepository.TreatmentSystem.BOTH,
                                onClick = { treatmentSystem = AIRepository.TreatmentSystem.BOTH }
                            )
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { combineCaseFindings() },
                                enabled = caseFindings.isNotEmpty() && !isCombiningCase,
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4A90E2)),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = if (isCombiningCase) "Combining..." else "Combine (${caseFindings.size})",
                                    fontSize = 12.sp
                                )
                            }
                            Button(
                                onClick = {
                                    val d = inputText
                                    if (d.isNotBlank()) {
                                        inputText = ""
                                        getTreatmentForConfirmedDiagnosis(d)
                                    }
                                },
                                enabled = inputText.isNotBlank(),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Confirm dx + treatment", fontSize = 11.sp)
                            }
                        }
                        Text(
                            text = "Confirm ke liye: text box mein diagnosis type karo, phir upar wala button dabao.",
                            color = Color(0xFF888888),
                            fontSize = 10.sp
                        )
                    }
                }
            }
        }

        // Chat Messages — wrapped in a Box so the fast-scroll buttons can
        // float on top of the list without pushing it up/down.
        val chatListState = rememberLazyListState()
        Box(modifier = Modifier.weight(1f)) {
            LazyColumn(
                state = chatListState,
                modifier = Modifier.fillMaxSize(),
                reverseLayout = true
            ) {
                items(messages.reversed(), key = { it.id }) { message ->
                    MessageBubble(
                        message = message,
                        onFeedback = { liked, reason ->
                            scope.launch {
                                learningEngine.recordFeedback(
                                    question = message.question,
                                    answer = message.text,
                                    liked = liked,
                                    reason = reason
                                )
                            }
                        }
                    )
                }
            }

            // Fast scroll buttons — only worth showing once there's
            // actually enough chat to make manual scrolling tedious.
            // reverseLayout=true means list index 0 is the newest message
            // (bottom of screen) and the last index is the oldest (top).
            if (messages.size > 8) {
                Column(
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .padding(end = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    FastScrollButton(label = "⬆") {
                        scope.launch { chatListState.animateScrollToItem(messages.size - 1) }
                    }
                    FastScrollButton(label = "⬇") {
                        scope.launch { chatListState.animateScrollToItem(0) }
                    }
                }
            }
        }

        // Staged image preview — shown between the last message and the
        // input row while an image is picked but not yet sent. Tapping ✕
        // discards it without sending; typing in the input box below now
        // becomes the caption instead of being unusable/ignored.
        if (isLoadingPendingImage) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = Color(0xFFFF6B9D))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Image load ho rahi hai...", color = Color(0xFFAAAAAA), fontSize = 12.sp)
            }
        }
        pendingImage?.let { pending ->
            val previewBitmap = remember(pending.base64Data) {
                try {
                    val bytes = android.util.Base64.decode(pending.base64Data, android.util.Base64.DEFAULT)
                    android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap()
                } catch (e: Exception) {
                    null
                }
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 4.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF0F1729))
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (previewBitmap != null) {
                    Image(
                        bitmap = previewBitmap,
                        contentDescription = "Attached image preview",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(56.dp)
                            .clip(RoundedCornerShape(8.dp))
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF222222)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("📎", fontSize = 20.sp)
                    }
                }
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = pending.name,
                    color = Color.White,
                    fontSize = 13.sp,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = { pendingImage = null }) {
                    Text("✕", color = Color(0xFFAAAAAA), fontSize = 16.sp)
                }
            }
        }

        // Input Area
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // PDF Upload Button — opens the system file picker scoped to
            // PDFs. Placed first so it reads left-to-right as "attach, talk,
            // type, send", matching how chat apps usually order these.
            IconButton(
                onClick = {
                    // Wrapped in Intent.createChooser and launched via a raw
                    // StartActivityForResult contract instead of plain
                    // ActivityResultContracts.GetContent(). On some OEM ROMs
                    // (MIUI especially) GET_CONTENT with a wildcard mime
                    // resolves to zero activities if the device's default
                    // Files/Documents app isn't registered as a GET_CONTENT
                    // handler — GetContent() then just silently does nothing
                    // on tap (no crash, no picker). createChooser forces
                    // Android to show every matching app (or the picker) and
                    // ACTION_OPEN_DOCUMENT is honoured by more OEM file
                    // managers than GET_CONTENT is. If literally nothing on
                    // the device can handle it, the user now sees why
                    // instead of the button appearing dead.
                    val openDocIntent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                        putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("*/*"))
                    }
                    try {
                        filePickerLauncher.launch(Intent.createChooser(openDocIntent, "File chuno"))
                    } catch (e: ActivityNotFoundException) {
                        val getContentIntent = Intent(Intent.ACTION_GET_CONTENT).apply {
                            addCategory(Intent.CATEGORY_OPENABLE)
                            type = "*/*"
                        }
                        try {
                            filePickerLauncher.launch(Intent.createChooser(getContentIntent, "File chuno"))
                        } catch (e2: ActivityNotFoundException) {
                            updateMessages { it + Message(
                                "Is phone par koi file picker app nahi mila (Files/Documents app disabled ho sakta hai). Settings > Apps mein check karo.",
                                isUser = false
                            ) }
                        }
                    }
                },
                enabled = !isIndexingPdf && !isProcessingMedia && !isLoadingPendingImage && pendingImage == null
            ) {
                Icon(
                    painter = painterResource(id = R.drawable.ic_attach),
                    contentDescription = "File upload karo (PDF/image/video/audio/zip)",
                    tint = if (isIndexingPdf || isProcessingMedia) Color(0xFF666666) else Color(0xFFFF6B9D)
                )
            }

            // Voice Button
            IconButton(
                onClick = {
                    isListening = true
                    voiceErrorMessage = null
                    // Driven directly from this Activity's own context —
                    // no separate window is opened, so the rest of the
                    // screen (buttons, text field) stays touchable while
                    // listening. VoiceManager internally retries once via
                    // Google's recognizer explicitly if the device default
                    // rejects the request (common on some MIUI builds).
                    voiceManager.startListening(
                        onResult = { text ->
                            isListening = false
                            if (text.isNotBlank()) {
                                send(text)
                            } else {
                                // Recognizer returned success but with no
                                // usable text — surface this instead of
                                // silently doing nothing, since otherwise
                                // it looks identical to the mic not working.
                                voiceErrorMessage = "Kuch samajh nahi aaya, dobara bolo 🎙️"
                                scope.launch {
                                    kotlinx.coroutines.delay(2500)
                                    if (voiceErrorMessage != null) voiceErrorMessage = null
                                }
                            }
                        },
                        onError = { errorCode ->
                            isListening = false
                            val friendly = when (errorCode) {
                                android.speech.SpeechRecognizer.ERROR_NO_MATCH,
                                android.speech.SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                                    "Kuch samajh nahi aaya, dobara bolo"
                                android.speech.SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                                    "Mic permission chahiye"
                                android.speech.SpeechRecognizer.ERROR_NETWORK,
                                android.speech.SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                                    "Network problem, dobara try karo"
                                else -> "Mic error"
                            }
                            // Error code shown alongside the message so any
                            // future issue is diagnosable straight from a
                            // screenshot instead of guessing the cause again.
                            voiceErrorMessage = "$friendly (code $errorCode) 🎙️"
                            scope.launch {
                                kotlinx.coroutines.delay(4000)
                                if (voiceErrorMessage != null) voiceErrorMessage = null
                            }
                        }
                    )
                }
            ) {
                Icon(
                    painter = painterResource(id = R.drawable.ic_mic),
                    contentDescription = "Voice",
                    tint = if (isListening) Color.Red else Color(0xFFFF6B9D)
                )
            }

            // Text Input
            OutlinedTextField(
                value = inputText,
                onValueChange = { inputText = it },
                modifier = Modifier.weight(1f),
                placeholder = {
                    Text(
                        when {
                            pendingImage != null -> "Caption likho (optional)..."
                            mode == AppMode.DOCTOR -> "Age/gender, symptoms, history..."
                            mode == AppMode.ENGINEER -> "Engineering sawaal ya problem describe karo..."
                            else -> "Kuch bolo... 💬"
                        }
                    )
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                )
            )

            // Send Button
            IconButton(
                onClick = {
                    val text = inputText
                    inputText = ""
                    if (pendingImage != null) {
                        sendPendingImage(text)
                    } else {
                        send(text)
                    }
                }
            ) {
                Icon(
                    painter = painterResource(id = R.drawable.ic_send),
                    contentDescription = "Send",
                    tint = Color(0xFFFF6B9D)
                )
            }
        }
    }

    // Patient List dialog — shows every saved patient (names decrypted only
    // for on-screen display, never re-encrypted-and-logged anywhere), lets
    // the doctor pick one to make active, or start a new patient.
    if (showPatientList) {
        var patients by remember { mutableStateOf(listOf<PatientListEntry>()) }
        var isLoadingPatients by remember { mutableStateOf(true) }
        var expandedPatientId by remember { mutableStateOf<Long?>(null) }
        var expandedPatientHistory by remember { mutableStateOf(listOf<CaseNote>()) }
        // Holds the patient pending delete confirmation — delete only
        // actually happens after the doctor confirms in a second dialog,
        // never on a single tap.
        var patientPendingDelete by remember { mutableStateOf<PatientListEntry?>(null) }

        LaunchedEffect(patientListRefreshTrigger) {
            isLoadingPatients = true
            patients = loadPatientList(context)
            isLoadingPatients = false
        }

        AlertDialog(
            onDismissRequest = { showPatientList = false },
            title = { Text("Patient List", color = Color.White) },
            containerColor = Color(0xFF1A1A2E),
            text = {
                Column(modifier = Modifier.heightIn(max = 420.dp)) {
                    if (isLoadingPatients) {
                        Text("Loading...", color = Color(0xFFAAAAAA), fontSize = 13.sp)
                    } else if (patients.isEmpty()) {
                        Text("Abhi koi patient nahi hai — neeche se naya banao.", color = Color(0xFFAAAAAA), fontSize = 13.sp)
                    } else {
                        LazyColumn(modifier = Modifier.heightIn(max = 320.dp)) {
                            items(patients, key = { it.id }) { patient ->
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable(
                                            indication = null,
                                            interactionSource = remember { MutableInteractionSource() },
                                            onClick = {
                                                currentPatient = ActivePatient(
                                                    id = patient.id,
                                                    displayName = patient.name,
                                                    age = patient.age,
                                                    gender = patient.gender,
                                                    currentDiagnosis = patient.currentDiagnosis,
                                                    currentSuggestion = patient.currentSuggestion,
                                                    currentMedicines = patient.currentMedicines,
                                                    knownAllergies = patient.knownAllergies
                                                )
                                                showPatientList = false
                                                // Switching patients ends any in-progress workup for
                                                // the previous patient — otherwise leftover findings
                                                // could get combined and saved under the wrong file.
                                                caseWorkupActive = false
                                                caseFindings = emptyList()
                                                confirmedDiagnosisContext = ""
                                                // "Open" this patient's file: load their saved case
                                                // history into the chat as faded, read-only bubbles,
                                                // so the doctor sees continuity instead of an empty
                                                // chat with just a name in the header bar.
                                                scope.launch {
                                                    val history = try {
                                                        KavitaDatabase.getInstance(context.applicationContext)
                                                            .caseNoteDao().getForPatient(patient.id)
                                                    } catch (e: Exception) {
                                                        emptyList()
                                                    }
                                                    val historyMessages = history.flatMap { note ->
                                                        listOf(
                                                            Message(note.symptoms, isUser = true, isHistorical = true),
                                                            Message(note.aiSuggestion, isUser = false, isHistorical = true)
                                                        )
                                                    }
                                                    val summaryLines = buildList {
                                                        if (patient.currentDiagnosis.isNotBlank()) add("🩺 Current diagnosis: ${patient.currentDiagnosis}")
                                                        if (patient.currentMedicines.isNotBlank()) add("💊 Current medicines/dose is saved in file — 'Edit File' se dekho ya update karo.")
                                                        if (patient.knownAllergies.isNotBlank()) add("⚠️ Known allergies: ${patient.knownAllergies}")
                                                    }
                                                    val openLine = if (history.isEmpty())
                                                        "📂 ${patient.name} ki file khul gayi — abhi koi purana case nahi hai. Naya case workup shuru karo."
                                                    else
                                                        "📂 ${patient.name} ki file khul gayi — ${history.size} purana case dikh raha hai upar."
                                                    doctorMessages = historyMessages + Message(
                                                        (listOf(openLine) + summaryLines).joinToString("\n"),
                                                        isUser = false
                                                    )
                                                }
                                            }
                                        )
                                        .padding(vertical = 8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(patient.name, color = Color.White, fontSize = 14.sp)
                                            Text(
                                                "${patient.age.ifBlank { "?" }} yrs, ${patient.gender.ifBlank { "?" }}",
                                                color = Color(0xFF888888),
                                                fontSize = 11.sp
                                            )
                                            if (patient.currentDiagnosis.isNotBlank()) {
                                                Text(
                                                    "🩺 ${patient.currentDiagnosis}",
                                                    color = Color(0xFFFFD166),
                                                    fontSize = 11.sp
                                                )
                                            }
                                        }
                                        TextButton(onClick = {
                                            scope.launch {
                                                if (expandedPatientId == patient.id) {
                                                    expandedPatientId = null
                                                } else {
                                                    expandedPatientId = patient.id
                                                    expandedPatientHistory = try {
                                                        KavitaDatabase.getInstance(context.applicationContext)
                                                            .caseNoteDao().getForPatient(patient.id)
                                                    } catch (e: Exception) {
                                                        emptyList()
                                                    }
                                                }
                                            }
                                        }) {
                                            Text(
                                                if (expandedPatientId == patient.id) "Hide history" else "History",
                                                color = Color(0xFFFF6B9D),
                                                fontSize = 11.sp
                                            )
                                        }
                                        TextButton(onClick = { patientPendingDelete = patient }) {
                                            Text("🗑️", fontSize = 14.sp)
                                        }
                                    }

                                    if (expandedPatientId == patient.id) {
                                        if (expandedPatientHistory.isEmpty()) {
                                            Text(
                                                "Is patient ke liye abhi koi saved case nahi hai.",
                                                color = Color(0xFF888888),
                                                fontSize = 11.sp,
                                                modifier = Modifier.padding(start = 8.dp, top = 4.dp)
                                            )
                                        } else {
                                            Column(modifier = Modifier.padding(start = 8.dp, top = 4.dp)) {
                                                expandedPatientHistory.forEach { note ->
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Text(
                                                            "• ${note.caseLabel}",
                                                            color = Color(0xFFCCCCCC),
                                                            fontSize = 11.sp,
                                                            modifier = Modifier.weight(1f)
                                                        )
                                                        Text(
                                                            "🗑️",
                                                            fontSize = 11.sp,
                                                            modifier = Modifier
                                                                .padding(start = 6.dp)
                                                                .clickable(
                                                                    indication = null,
                                                                    interactionSource = remember { MutableInteractionSource() },
                                                                    onClick = {
                                                                        deleteCaseNote(context, scope, note) {
                                                                            expandedPatientHistory = expandedPatientHistory.filter { it.id != note.id }
                                                                            // If this patient's file is currently
                                                                            // open in the chat, also drop the
                                                                            // matching historical bubble pair so
                                                                            // the deleted note doesn't linger on
                                                                            // screen until the file is reopened.
                                                                            if (currentPatient?.id == patient.id) {
                                                                                doctorMessages = doctorMessages.filterNot {
                                                                                    it.isHistorical && (it.text == note.symptoms || it.text == note.aiSuggestion)
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                )
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    Divider(color = Color(0xFF333333), modifier = Modifier.padding(top = 8.dp))
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    showPatientList = false
                    showNewPatientDialog = true
                }) {
                    Text("+ New Patient", color = Color(0xFFFF6B9D))
                }
            },
            dismissButton = {
                TextButton(onClick = { showPatientList = false }) {
                    Text("Close", color = Color(0xFFAAAAAA))
                }
            }
        )

        // Delete confirmation — separate dialog so a single accidental tap
        // on 🗑️ can never delete a patient; the doctor must explicitly
        // confirm here. Deleting removes the patient AND their entire case
        // history (irreversible).
        patientPendingDelete?.let { toDelete ->
            AlertDialog(
                onDismissRequest = { patientPendingDelete = null },
                title = { Text("Patient delete karein?", color = Color.White) },
                containerColor = Color(0xFF1A1A2E),
                text = {
                    Text(
                        "${toDelete.name} (${toDelete.age.ifBlank { "?" }}, ${toDelete.gender.ifBlank { "?" }}) " +
                            "aur unka poora case history permanently delete ho jaayega. Ye undo nahi ho sakta.",
                        color = Color(0xFFCCCCCC),
                        fontSize = 13.sp
                    )
                },
                confirmButton = {
                    TextButton(onClick = {
                        val idToDelete = toDelete.id
                        val wasActivePatient = currentPatient?.id == idToDelete
                        deletePatient(context, scope, idToDelete) {
                            patients = patients.filterNot { it.id == idToDelete }
                            if (wasActivePatient) {
                                currentPatient = null
                                // Clear the doctor chat too — it was showing this
                                // patient's now-deleted file/history, so leaving
                                // it on screen would be stale, deleted data.
                                doctorMessages = listOf(
                                    Message("🗑️ ${toDelete.name}'s file deleted. Chat cleared.", isUser = false)
                                )
                            }
                            if (expandedPatientId == idToDelete) expandedPatientId = null
                            patientPendingDelete = null
                        }
                    }) {
                        Text("Delete", color = Color(0xFFFF6B6B))
                    }
                },
                dismissButton = {
                    TextButton(onClick = { patientPendingDelete = null }) {
                        Text("Cancel", color = Color(0xFFAAAAAA))
                    }
                }
            )
        }
    }

    // New Patient dialog — the ONLY place a name is ever typed/collected.
    // Encrypted via PatientCrypto before it's written to Room; never sent to
    // any network call from here.
    if (showNewPatientDialog) {
        var nameInput by remember { mutableStateOf("") }
        var ageInput by remember { mutableStateOf("") }
        var genderInput by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showNewPatientDialog = false },
            title = { Text("New Patient", color = Color.White) },
            containerColor = Color(0xFF1A1A2E),
            text = {
                Column {
                    OutlinedTextField(
                        value = nameInput,
                        onValueChange = { nameInput = it },
                        label = { Text("Naam") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = ageInput,
                        onValueChange = { ageInput = it },
                        label = { Text("Age") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = genderInput,
                        onValueChange = { genderInput = it },
                        label = { Text("Gender") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                    )
                    Text(
                        "Naam encrypted save hoga (Android Keystore), sirf is phone par — kahin bhi network par nahi jaata.",
                        color = Color(0xFF888888),
                        fontSize = 10.sp,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (nameInput.isNotBlank()) {
                            createPatient(context, scope, nameInput, ageInput, genderInput) { newId ->
                                currentPatient = ActivePatient(
                                    id = newId,
                                    displayName = nameInput.trim(),
                                    age = ageInput.trim(),
                                    gender = genderInput.trim()
                                )
                                showNewPatientDialog = false
                                caseWorkupActive = true
                                caseFindings = emptyList()
                                confirmedDiagnosisContext = ""
                                updateMessages { it + Message(
                                    "Naya patient add kiya: ${nameInput.trim()}. Case Workup shuru ho gaya hai " +
                                        "iske liye — reports/notes bhejo.",
                                    isUser = false
                                ) }
                            }
                        }
                    },
                    enabled = nameInput.isNotBlank()
                ) {
                    Text("Save", color = Color(0xFFFF6B9D))
                }
            },
            dismissButton = {
                TextButton(onClick = { showNewPatientDialog = false }) {
                    Text("Cancel", color = Color(0xFFAAAAAA))
                }
            }
        )
    }

    // Follow-up reminder dialog — quick-pick day chips (most common cases:
    // "3 din baad", "1 week baad") plus a free-text note. Fires an actual
    // OS notification at 10 AM on the chosen day via AlarmManager
    // (ReminderScheduler) — picking a fixed hour rather than asking the
    // doctor to also pick a time keeps this to one tap for the common
    // case, since "which day" matters far more than "which hour" for a
    // patient check-in reminder.
    if (showFollowUpDialog && currentPatient != null) {
        var reminderNote by remember { mutableStateOf("") }
        var selectedDaysAhead by remember { mutableStateOf(3) }
        val patient = currentPatient!!

        AlertDialog(
            onDismissRequest = { showFollowUpDialog = false },
            title = { Text("Follow-up Reminder", color = Color.White) },
            containerColor = Color(0xFF1A1A2E),
            text = {
                Column {
                    Text(
                        "Patient: ${patient.displayName}",
                        color = Color(0xFFAAAAAA),
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("Kab yaad dilau?", color = Color.White, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(1 to "1 din", 3 to "3 din", 7 to "1 week").forEach { (days, label) ->
                            val isSelected = selectedDaysAhead == days
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (isSelected) Color(0xFF6BCB77) else Color(0xFF0F1729))
                                    .clickable(
                                        indication = null,
                                        interactionSource = remember { MutableInteractionSource() },
                                        onClick = { selectedDaysAhead = days }
                                    )
                                    .padding(horizontal = 12.dp, vertical = 8.dp)
                            ) {
                                Text(
                                    text = label,
                                    color = if (isSelected) Color.Black else Color(0xFFAAAAAA),
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = reminderNote,
                        onValueChange = { reminderNote = it },
                        label = { Text("Note (optional)") },
                        placeholder = { Text("e.g. BP dobara check karo") },
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                    )
                    Text(
                        "Reminder subah 10 baje notification ke through aayega, is din.",
                        color = Color(0xFF888888),
                        fontSize = 10.sp,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val calendar = java.util.Calendar.getInstance().apply {
                        add(java.util.Calendar.DAY_OF_YEAR, selectedDaysAhead)
                        set(java.util.Calendar.HOUR_OF_DAY, 10)
                        set(java.util.Calendar.MINUTE, 0)
                        set(java.util.Calendar.SECOND, 0)
                        set(java.util.Calendar.MILLISECOND, 0)
                    }
                    createFollowUpReminder(
                        context = context,
                        scope = scope,
                        patientId = patient.id,
                        patientDisplayName = patient.displayName,
                        note = reminderNote,
                        triggerAtMillis = calendar.timeInMillis
                    ) {
                        showFollowUpDialog = false
                        updateMessages { it + Message(
                            "⏰ Follow-up reminder set ho gaya — ${patient.displayName} ke liye, " +
                                "$selectedDaysAhead din baad subah 10 baje.",
                            isUser = false
                        ) }
                    }
                }) {
                    Text("Set Reminder", color = Color(0xFF6BCB77))
                }
            },
            dismissButton = {
                TextButton(onClick = { showFollowUpDialog = false }) {
                    Text("Cancel", color = Color(0xFFAAAAAA))
                }
            }
        )
    }

    // Upcoming Follow-ups viewer — lists every not-yet-fired, not-cancelled
    // reminder across ALL patients (not just the currently active one),
    // soonest first, with an inline cancel action per row. Loaded fresh
    // every time the dialog opens via followUpListRefreshTrigger, same
    // reload-on-open pattern already used by the Patient List dialog
    // elsewhere in this screen.
    if (showUpcomingFollowUps) {
        var upcomingReminders by remember { mutableStateOf<List<FollowUpReminder>?>(null) }
        var followUpListRefreshTrigger by remember { mutableStateOf(0) }

        LaunchedEffect(followUpListRefreshTrigger) {
            upcomingReminders = try {
                KavitaDatabase.getInstance(context.applicationContext).followUpReminderDao().getUpcoming()
            } catch (e: Exception) {
                emptyList()
            }
        }

        val dateFormat = remember { java.text.SimpleDateFormat("dd MMM, hh:mm a", java.util.Locale.ENGLISH) }

        AlertDialog(
            onDismissRequest = { showUpcomingFollowUps = false },
            title = { Text("Upcoming Follow-ups", color = Color.White) },
            containerColor = Color(0xFF1A1A2E),
            text = {
                val reminders = upcomingReminders
                when {
                    reminders == null -> Text("Loading...", color = Color(0xFF888888), fontSize = 13.sp)
                    reminders.isEmpty() -> Text(
                        "Koi upcoming follow-up nahi hai abhi. Patient ke \"⏰ Follow-up set karo\" se naya set karo.",
                        color = Color(0xFF888888),
                        fontSize = 13.sp
                    )
                    else -> Column(
                        modifier = Modifier.heightIn(max = 400.dp)
                    ) {
                        // AlertDialog's text slot doesn't scroll on its own
                        // once content is tall — a real LazyColumn here
                        // keeps a long reminder list usable instead of
                        // clipping past the dialog's bottom edge.
                        LazyColumn {
                            items(reminders, key = { it.id }) { reminder ->
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 6.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = if (reminder.patientDisplayName.isNotBlank())
                                                    "🧑‍⚕️ ${reminder.patientDisplayName}"
                                                else "📌 General reminder",
                                                color = Color.White,
                                                fontSize = 13.sp
                                            )
                                            Text(
                                                text = dateFormat.format(java.util.Date(reminder.triggerAtMillis)),
                                                color = Color(0xFF6BCB77),
                                                fontSize = 11.sp
                                            )
                                            if (reminder.note.isNotBlank()) {
                                                Text(
                                                    text = reminder.note,
                                                    color = Color(0xFFAAAAAA),
                                                    fontSize = 11.sp
                                                )
                                            }
                                        }
                                        Text(
                                            text = "✕",
                                            color = Color(0xFFFF6B6B),
                                            fontSize = 14.sp,
                                            modifier = Modifier
                                                .padding(start = 8.dp)
                                                .clickable(
                                                    indication = null,
                                                    interactionSource = remember { MutableInteractionSource() },
                                                    onClick = {
                                                        cancelFollowUpReminder(context, scope, reminder) {
                                                            followUpListRefreshTrigger++
                                                        }
                                                    }
                                                )
                                        )
                                    }
                                    HorizontalDivider(color = Color(0xFF2A2A3E), modifier = Modifier.padding(top = 6.dp))
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showUpcomingFollowUps = false }) {
                    Text("Band karo", color = Color(0xFF4A90E2))
                }
            }
        )
    }

    // Medicine Check dialog — one input box, comma-separated medicine
    // names. A single name does a full clinical reference lookup; two or
    // more names runs a cross-drug interaction check instead. Both paths
    // pull real FDA label data via DrugInfoService first, then Gemini
    // synthesizes it — same "real data grounds the AI" pattern as RAG
    // over uploaded PDFs elsewhere in this app.
    if (showMedicineCheckDialog) {
        var medicineInput by remember { mutableStateOf("") }
        var isChecking by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { if (!isChecking) showMedicineCheckDialog = false },
            title = { Text("💊 Medicine Check", color = Color.White) },
            containerColor = Color(0xFF1A1A2E),
            text = {
                Column {
                    Text(
                        "Ek medicine ka naam do (full info ke liye) ya 2+ names " +
                            "comma se separate karke do (interaction check ke liye).",
                        color = Color(0xFFAAAAAA),
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = medicineInput,
                        onValueChange = { medicineInput = it },
                        label = { Text("Medicine name(s)") },
                        placeholder = { Text("e.g. Paracetamol, Ibuprofen") },
                        enabled = !isChecking,
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(
                        "Note: FDA (US) database use hoti hai — Indian brand names " +
                            "(jaise Crocin) ke bajaye generic naam (Paracetamol) se " +
                            "search zyada reliable rahega.",
                        color = Color(0xFF888888),
                        fontSize = 10.sp,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                    if (isChecking) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("Check kar rahi hoon...", color = Color(0xFF6BCB77), fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                TextButton(
                    enabled = !isChecking && medicineInput.isNotBlank(),
                    onClick = {
                        val names = medicineInput.split(",").map { it.trim() }.filter { it.isNotBlank() }
                        if (names.isEmpty()) return@TextButton
                        isChecking = true
                        scope.launch {
                            val result = try {
                                if (names.size == 1) {
                                    aiRepository.getMedicineInfo(names.first())
                                } else {
                                    aiRepository.getDrugInteractionAnalysis(names)
                                }
                            } catch (e: Exception) {
                                "Medicine check karne mein dikkat aa gayi, dobara try karo."
                            }
                            isChecking = false
                            showMedicineCheckDialog = false
                            medicineInput = ""
                            val questionLabel = if (names.size == 1) {
                                "💊 Medicine info: ${names.first()}"
                            } else {
                                "💊 Interaction check: ${names.joinToString(", ")}"
                            }
                            updateMessages { it + Message(questionLabel, isUser = true) + Message(result, isUser = false) }
                            if (currentPatient != null) {
                                saveCaseNote(context, scope, questionLabel, result, currentPatient?.id)
                            }
                        }
                    }
                ) {
                    Text("Check karo", color = Color(0xFF6BCB77))
                }
            },
            dismissButton = {
                TextButton(
                    enabled = !isChecking,
                    onClick = { showMedicineCheckDialog = false; medicineInput = "" }
                ) {
                    Text("Cancel", color = Color(0xFFAAAAAA))
                }
            }
        )
    }

    // Advanced Symptom Checker — a distinct, structured flow from the
    // free-text Case Workup: quick-pick common symptoms + chief complaint
    // -> AI asks 4-6 targeted adaptive follow-up questions (like a real
    // symptom checker, not generic ones) -> full analysis with an
    // explicit TRIAGE URGENCY level up front (🔴/🟠/🟡/🟢), ranked
    // differential, red flags, and next steps. Two-step wizard inside one
    // dialog (step state resets whenever the dialog is reopened).
    if (showSymptomCheckerDialog) {
        val commonSymptoms = listOf(
            "Fever", "Cough", "Chest pain", "Shortness of breath", "Headache",
            "Abdominal pain", "Vomiting", "Diarrhea", "Dizziness", "Fatigue",
            "Joint pain", "Rash", "Sore throat", "Back pain", "Palpitations"
        )
        var step by remember { mutableStateOf(1) }
        var chiefComplaint by remember { mutableStateOf("") }
        val pickedSymptoms = remember { mutableStateListOf<String>() }
        var durationSeverity by remember { mutableStateOf("") }
        var followUpQuestions by remember { mutableStateOf("") }
        var followUpAnswers by remember { mutableStateOf("") }
        var isLoading by remember { mutableStateOf(false) }

        fun resetAndClose() {
            showSymptomCheckerDialog = false
            step = 1
            chiefComplaint = ""
            pickedSymptoms.clear()
            durationSeverity = ""
            followUpQuestions = ""
            followUpAnswers = ""
        }

        fun patientContextString(): String {
            val p = currentPatient
            return if (p == null) "" else buildString {
                append("${p.age} yrs, ${p.gender}")
                if (p.knownAllergies.isNotBlank()) append("; Known allergies: ${p.knownAllergies}")
                if (p.currentMedicines.isNotBlank()) append("; Current medicines: ${p.currentMedicines}")
                if (p.currentDiagnosis.isNotBlank()) append("; Existing diagnosis: ${p.currentDiagnosis}")
            }
        }

        AlertDialog(
            onDismissRequest = { if (!isLoading) resetAndClose() },
            title = { Text("🩺 Symptom Checker (Step $step/2)", color = Color.White) },
            containerColor = Color(0xFF1A1A2E),
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    if (step == 1) {
                        OutlinedTextField(
                            value = chiefComplaint,
                            onValueChange = { chiefComplaint = it },
                            label = { Text("Chief complaint") },
                            placeholder = { Text("e.g. 3 din se tez bukhar aur badan dard") },
                            enabled = !isLoading,
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("Quick-pick associated symptoms:", color = Color(0xFFAAAAAA), fontSize = 11.sp)
                        Column {
                            commonSymptoms.chunked(3).forEach { rowSymptoms ->
                                Row(modifier = Modifier.padding(top = 4.dp)) {
                                    rowSymptoms.forEach { symptom ->
                                        val isSelected = pickedSymptoms.contains(symptom)
                                        Row(
                                            modifier = Modifier
                                                .padding(end = 6.dp)
                                                .clip(RoundedCornerShape(14.dp))
                                                .background(if (isSelected) Color(0xFF6BCB77) else Color(0xFF0F1729))
                                                .clickable(
                                                    indication = null,
                                                    interactionSource = remember { MutableInteractionSource() },
                                                    onClick = {
                                                        if (isSelected) pickedSymptoms.remove(symptom) else pickedSymptoms.add(symptom)
                                                    }
                                                )
                                                .padding(horizontal = 10.dp, vertical = 6.dp)
                                        ) {
                                            Text(symptom, color = Color.White, fontSize = 11.sp)
                                        }
                                    }
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedTextField(
                            value = durationSeverity,
                            onValueChange = { durationSeverity = it },
                            label = { Text("Duration / severity") },
                            placeholder = { Text("e.g. 3 days, mild-moderate, worsening at night") },
                            enabled = !isLoading,
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                            modifier = Modifier.fillMaxWidth()
                        )
                        if (currentPatient != null) {
                            Text(
                                "Patient context auto-included: ${patientContextString()}",
                                color = Color(0xFF888888),
                                fontSize = 10.sp,
                                modifier = Modifier.padding(top = 6.dp)
                            )
                        }
                        if (isLoading) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Text("Targeted follow-up questions ban rahi hain...", color = Color(0xFF6BCB77), fontSize = 12.sp)
                        }
                    } else {
                        Text("Follow-up questions:", color = Color(0xFFAAAAAA), fontSize = 11.sp)
                        Text(
                            followUpQuestions,
                            color = Color.White,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(top = 4.dp, bottom = 10.dp)
                        )
                        OutlinedTextField(
                            value = followUpAnswers,
                            onValueChange = { followUpAnswers = it },
                            label = { Text("Answers (sab ek saath likh do)") },
                            enabled = !isLoading,
                            minLines = 4,
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                            modifier = Modifier.fillMaxWidth()
                        )
                        if (isLoading) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Text("Full analysis + triage ban rahi hai...", color = Color(0xFF6BCB77), fontSize = 12.sp)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    enabled = !isLoading && (if (step == 1) chiefComplaint.isNotBlank() else true),
                    onClick = {
                        if (step == 1) {
                            isLoading = true
                            scope.launch {
                                val questions = try {
                                    aiRepository.getSymptomCheckerQuestions(
                                        chiefComplaint = chiefComplaint,
                                        quickSymptoms = pickedSymptoms.toList(),
                                        durationSeverity = durationSeverity,
                                        patientContext = patientContextString()
                                    )
                                } catch (e: Exception) {
                                    "1. Symptoms kab shuru hue?\n2. Kuch aur associated symptoms?\n3. Pehle kabhi aisa hua hai?"
                                }
                                followUpQuestions = questions
                                isLoading = false
                                step = 2
                            }
                        } else {
                            isLoading = true
                            scope.launch {
                                val relevantChunks = try {
                                    ragEngine.findRelevantChunks("$chiefComplaint ${pickedSymptoms.joinToString(" ")}")
                                } catch (e: Exception) {
                                    emptyList()
                                }
                                val result = try {
                                    aiRepository.getSymptomCheckerAnalysis(
                                        chiefComplaint = chiefComplaint,
                                        quickSymptoms = pickedSymptoms.toList(),
                                        durationSeverity = durationSeverity,
                                        followUpQA = "$followUpQuestions\n\nDoctor's answers: $followUpAnswers",
                                        patientContext = patientContextString(),
                                        relevantChunks = relevantChunks
                                    )
                                } catch (e: Exception) {
                                    "Symptom checker analysis mein dikkat aa gayi, dobara try karo."
                                }
                                isLoading = false
                                val questionLabel = "🩺 Symptom Checker: $chiefComplaint"
                                updateMessages { it + Message(questionLabel, isUser = true) + Message(result, isUser = false) }
                                if (currentPatient != null) {
                                    saveCaseNote(context, scope, questionLabel, result, currentPatient?.id)
                                }
                                // If a Case Workup is active, this becomes one
                                // more correlated finding, same as an uploaded
                                // report reading would.
                                if (caseWorkupActive) {
                                    caseFindings = caseFindings + AIRepository.CaseFinding(
                                        label = "Symptom Checker: $chiefComplaint",
                                        content = result
                                    )
                                }
                                resetAndClose()
                            }
                        }
                    }
                ) {
                    Text(if (step == 1) "Next: Follow-up questions" else "Analyze", color = Color(0xFF6BCB77))
                }
            },
            dismissButton = {
                TextButton(enabled = !isLoading, onClick = { resetAndClose() }) {
                    Text("Cancel", color = Color(0xFFAAAAAA))
                }
            }
        )
    }

    // Voice-to-SOAP Note dialog — doctor either types or dictates (mic
    // button inside the dialog, reusing the same voiceManager.startListening
    // already used for the main chat mic) their encounter notes in
    // whatever order they naturally speak them, and Gemini organizes it
    // into a standard Subjective/Objective/Assessment/Plan note. Multiple
    // mic taps append to the text field rather than replacing it, so the
    // doctor can dictate in several short bursts (e.g. pause to think,
    // then continue) instead of one unbroken take.
    if (showSoapNoteDialog) {
        var soapInput by remember { mutableStateOf("") }
        var isGeneratingSoap by remember { mutableStateOf(false) }
        var isListeningForSoap by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { if (!isGeneratingSoap && !isListeningForSoap) showSoapNoteDialog = false },
            title = { Text("📝 Voice-to-SOAP Note", color = Color.White) },
            containerColor = Color(0xFF1A1A2E),
            text = {
                Column {
                    Text(
                        "Encounter ke baare mein bolo ya likho (jis order mein " +
                            "yaad aaye, kuch structure follow karna zaroori nahi) " +
                            "— main isse Subjective/Objective/Assessment/Plan mein " +
                            "organize kar dungi.",
                        color = Color(0xFFAAAAAA),
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = soapInput,
                        onValueChange = { soapInput = it },
                        label = { Text("Encounter notes") },
                        placeholder = { Text("e.g. patient 3 din se fever, BP 120/80, malaria rule out karne ko bola, paracetamol start kiya...") },
                        enabled = !isGeneratingSoap,
                        minLines = 4,
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    TextButton(
                        enabled = !isGeneratingSoap,
                        onClick = {
                            isListeningForSoap = true
                            voiceManager.startListening(
                                onResult = { text ->
                                    isListeningForSoap = false
                                    if (text.isNotBlank()) {
                                        soapInput = if (soapInput.isBlank()) text else "$soapInput $text"
                                    }
                                },
                                onError = { isListeningForSoap = false }
                            )
                        }
                    ) {
                        Text(
                            if (isListeningForSoap) "🎙️ Sunn rahi hoon..." else "🎙️ Bolke add karo",
                            color = if (isListeningForSoap) Color(0xFFFF6B9D) else Color(0xFF4A90E2)
                        )
                    }
                    if (isGeneratingSoap) {
                        Text("SOAP note bana rahi hoon...", color = Color(0xFF6BCB77), fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                TextButton(
                    enabled = !isGeneratingSoap && !isListeningForSoap && soapInput.isNotBlank(),
                    onClick = {
                        isGeneratingSoap = true
                        scope.launch {
                            val result = try {
                                aiRepository.getSoapNote(soapInput)
                            } catch (e: Exception) {
                                "SOAP note banane mein dikkat aa gayi, dobara try karo."
                            }
                            isGeneratingSoap = false
                            showSoapNoteDialog = false
                            val notesUsed = soapInput
                            soapInput = ""
                            updateMessages {
                                it + Message("📝 SOAP Note", isUser = true) +
                                    Message(result, isUser = false)
                             }
                            if (currentPatient != null) {
                                saveCaseNote(context, scope, "📝 SOAP Note: $notesUsed", result, currentPatient?.id)
                            }
                        }
                    }
                ) {
                    Text("Banao", color = Color(0xFF6BCB77))
                }
            },
            dismissButton = {
                TextButton(
                    enabled = !isGeneratingSoap,
                    onClick = { showSoapNoteDialog = false; soapInput = "" }
                ) {
                    Text("Cancel", color = Color(0xFFAAAAAA))
                }
            }
        )
    }

    // Lab Trends dialog — lets the doctor log a lab/vitals reading (BP,
    // blood sugar, Hb, whatever) for the active patient, then see it
    // charted over time to answer "improve ho raha hai ya nahi" at a
    // glance instead of scrolling back through old case notes to compare
    // numbers mentally. Two states within the same dialog: metric list
    // (default) and a selected metric's chart+history (drill-in) — kept as
    // one dialog rather than a separate screen since it's a quick, focused
    // in-and-out action during a consult.
    if (showLabTrendsDialog && currentPatient != null) {
        val patientId = currentPatient!!.id
        var readings by remember { mutableStateOf(listOf<LabValue>()) }
        var metricNames by remember { mutableStateOf(listOf<String>()) }
        var presets by remember { mutableStateOf(listOf<LabMetricPreset>()) }
        var isLoadingLabData by remember { mutableStateOf(true) }
        var selectedMetric by remember { mutableStateOf<String?>(null) }
        var labRefreshTrigger by remember { mutableStateOf(0) }

        var selectedPreset by remember { mutableStateOf<LabMetricPreset?>(null) }
        var newValue by remember { mutableStateOf("") }
        var newUnit by remember { mutableStateOf("") }
        var isSavingReading by remember { mutableStateOf(false) }
        // Inline "+ Naya Matrix" mini-form — kept as a toggle rather than a
        // nested AlertDialog (stacking dialogs on top of this one gets
        // visually messy on a small phone screen).
        var showAddPresetForm by remember { mutableStateOf(false) }
        var newPresetName by remember { mutableStateOf("") }
        var newPresetUnit by remember { mutableStateOf("") }
        var addPresetError by remember { mutableStateOf<String?>(null) }
        val labDateFormat = remember { SimpleDateFormat("dd MMM, hh:mm a", Locale.ENGLISH) }

        LaunchedEffect(labRefreshTrigger) {
            isLoadingLabData = true
            val dao = KavitaDatabase.getInstance(context.applicationContext).labValueDao()
            val presetDao = KavitaDatabase.getInstance(context.applicationContext).labMetricPresetDao()
            readings = withContext(kotlinx.coroutines.Dispatchers.IO) { dao.getAllForPatient(patientId) }
            metricNames = withContext(kotlinx.coroutines.Dispatchers.IO) { dao.getDistinctMetricNames(patientId) }
            presets = withContext(kotlinx.coroutines.Dispatchers.IO) { presetDao.getAll() }
            isLoadingLabData = false
        }

        AlertDialog(
            onDismissRequest = { showLabTrendsDialog = false; selectedMetric = null },
            title = {
                Text(
                    if (selectedMetric == null) "📈 Lab Trends — ${currentPatient?.displayName}"
                    else "📈 ${selectedMetric}",
                    color = Color.White,
                    fontSize = 16.sp
                )
            },
            containerColor = Color(0xFF1A1A2E),
            text = {
                Column(modifier = Modifier.heightIn(max = 460.dp)) {
                    if (isLoadingLabData) {
                        Text("Loading...", color = Color(0xFFAAAAAA), fontSize = 13.sp)
                    } else if (selectedMetric != null) {
                        val series = readings
                            .filter { it.metricName == selectedMetric }
                            .sortedBy { it.recordedAt }
                        val numericCount = series.count { it.value.trim().toDoubleOrNull() != null }

                        TextButton(onClick = { selectedMetric = null }) {
                            Text("← Sab metrics", color = Color(0xFF4A90E2), fontSize = 12.sp)
                        }

                        if (numericCount < 2) {
                            Text(
                                "Trend chart dikhane ke liye kam se kam 2 numeric readings chahiye — " +
                                    "abhi sirf $numericCount hai. Non-numeric readings (jaise \"Trace\", \"Negative\") " +
                                    "neeche history mein dikhengi, bas chart mein plot nahi hongi.",
                                color = Color(0xFFAAAAAA),
                                fontSize = 12.sp,
                                modifier = Modifier.padding(vertical = 8.dp)
                            )
                        } else {
                            LabTrendChart(
                                series = series,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(160.dp)
                                    .padding(vertical = 8.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        LazyColumn(modifier = Modifier.heightIn(max = 220.dp)) {
                            items(series.reversed(), key = { it.id }) { reading ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        labDateFormat.format(java.util.Date(reading.recordedAt)),
                                        color = Color(0xFFAAAAAA),
                                        fontSize = 11.sp
                                    )
                                    Text(
                                        "${reading.value} ${reading.unit}".trim(),
                                        color = Color.White,
                                        fontSize = 13.sp
                                    )
                                }
                            }
                        }
                    } else {
                        // Add-reading form — always visible at the top of
                        // the metric-list screen so a new reading can be
                        // logged in one step without drilling anywhere.
                        // Metric is picked from saved presets (name+unit
                        // already known) instead of retyped every time —
                        // "+ Naya Matrix" below lets a new one be created
                        // on the spot, and custom ones can be deleted with
                        // the ✕ next to them.
                        Text("Matrix", color = Color(0xFFAAAAAA), fontSize = 12.sp)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState())
                                .padding(top = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            presets.forEach { preset ->
                                val isSelected = selectedPreset?.id == preset.id
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .padding(end = 4.dp)
                                        .background(
                                            if (isSelected) Color(0xFF4A90E2) else Color(0xFF22223A),
                                            RoundedCornerShape(8.dp)
                                        )
                                ) {
                                    TextButton(onClick = {
                                        selectedPreset = preset
                                        newUnit = preset.unit
                                    }) {
                                        Text(
                                            preset.name,
                                            color = if (isSelected) Color.White else Color(0xFFDDDDDD),
                                            fontSize = 12.sp
                                        )
                                    }
                                    if (!preset.isBuiltIn) {
                                        Text(
                                            "✕",
                                            color = Color(0xFFFF6B6B),
                                            fontSize = 13.sp,
                                            modifier = Modifier
                                                .clickable {
                                                    scope.launch {
                                                        val presetDao = KavitaDatabase.getInstance(context.applicationContext).labMetricPresetDao()
                                                        withContext(kotlinx.coroutines.Dispatchers.IO) { presetDao.delete(preset) }
                                                        if (selectedPreset?.id == preset.id) {
                                                            selectedPreset = null
                                                            newUnit = ""
                                                        }
                                                        labRefreshTrigger++
                                                    }
                                                }
                                                .padding(end = 8.dp)
                                        )
                                    }
                                }
                            }
                            TextButton(onClick = { showAddPresetForm = !showAddPresetForm }) {
                                Text("+ Naya Matrix", color = Color(0xFF6BCB77), fontSize = 12.sp)
                            }
                        }

                        if (showAddPresetForm) {
                            Row(modifier = Modifier.padding(top = 6.dp)) {
                                OutlinedTextField(
                                    value = newPresetName,
                                    onValueChange = { newPresetName = it; addPresetError = null },
                                    label = { Text("Naya matrix naam") },
                                    placeholder = { Text("e.g. Vitamin D") },
                                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                                    modifier = Modifier.weight(1f)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                OutlinedTextField(
                                    value = newPresetUnit,
                                    onValueChange = { newPresetUnit = it },
                                    label = { Text("Unit") },
                                    placeholder = { Text("ng/mL") },
                                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            if (addPresetError != null) {
                                Text(addPresetError!!, color = Color(0xFFFF6B6B), fontSize = 11.sp)
                            }
                            TextButton(
                                enabled = newPresetName.isNotBlank(),
                                onClick = {
                                    val name = newPresetName.trim()
                                    scope.launch {
                                        val presetDao = KavitaDatabase.getInstance(context.applicationContext).labMetricPresetDao()
                                        val alreadyExists = withContext(kotlinx.coroutines.Dispatchers.IO) { presetDao.countByName(name) } > 0
                                        if (alreadyExists) {
                                            addPresetError = "\"$name\" naam se pehle se ek matrix hai."
                                            return@launch
                                        }
                                        val created = LabMetricPreset(name = name, unit = newPresetUnit.trim(), isBuiltIn = false)
                                        withContext(kotlinx.coroutines.Dispatchers.IO) { presetDao.insert(created) }
                                        newPresetName = ""
                                        newPresetUnit = ""
                                        showAddPresetForm = false
                                        labRefreshTrigger++
                                    }
                                }
                            ) {
                                Text("Matrix save karo", color = Color(0xFF6BCB77))
                            }
                        }

                        Row(modifier = Modifier.padding(top = 6.dp)) {
                            OutlinedTextField(
                                value = newValue,
                                onValueChange = { newValue = it },
                                label = { Text("Value") },
                                placeholder = { Text("koi bhi value ya text") },
                                enabled = !isSavingReading,
                                // Full keyboard, no numeric restriction — some
                                // readings are text ("Trace", "1+", "Negative")
                                // or need special characters, not just digits.
                                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            OutlinedTextField(
                                value = newUnit,
                                onValueChange = { newUnit = it },
                                label = { Text("Unit") },
                                placeholder = { Text("mg/dL") },
                                enabled = !isSavingReading,
                                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                                modifier = Modifier.weight(1f)
                            )
                        }
                        TextButton(
                            enabled = !isSavingReading && selectedPreset != null && newValue.isNotBlank(),
                            onClick = {
                                val preset = selectedPreset ?: return@TextButton
                                isSavingReading = true
                                scope.launch {
                                    val dao = KavitaDatabase.getInstance(context.applicationContext).labValueDao()
                                    withContext(kotlinx.coroutines.Dispatchers.IO) {
                                        dao.insert(
                                            LabValue(
                                                patientId = patientId,
                                                metricName = preset.name,
                                                value = newValue.trim(),
                                                unit = newUnit.trim()
                                            )
                                        )
                                    }
                                    newValue = ""
                                    isSavingReading = false
                                    labRefreshTrigger++
                                }
                            },
                            modifier = Modifier.padding(top = 4.dp)
                        ) {
                            Text(
                                if (isSavingReading) "Save ho raha hai..." else "+ Reading add karo",
                                color = Color(0xFF6BCB77)
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider(color = Color(0xFF333333))
                        Spacer(modifier = Modifier.height(6.dp))

                        if (metricNames.isEmpty()) {
                            Text(
                                "Abhi is patient ke liye koi reading nahi hai — upar se ek add karo.",
                                color = Color(0xFFAAAAAA),
                                fontSize = 12.sp
                            )
                        } else {
                            LazyColumn(modifier = Modifier.heightIn(max = 200.dp)) {
                                items(metricNames, key = { it }) { name ->
                                    val count = readings.count { it.metricName == name }
                                    TextButton(
                                        onClick = { selectedMetric = name },
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(name, color = Color.White, fontSize = 13.sp)
                                            Text(
                                                "$count reading${if (count == 1) "" else "s"} →",
                                                color = Color(0xFFAAAAAA),
                                                fontSize = 11.sp
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showLabTrendsDialog = false; selectedMetric = null }) {
                    Text("Band karo", color = Color(0xFFAAAAAA))
                }
            }
        )
    }

    // Vitals Calculator Suite — BMI, estimated creatinine clearance (GFR
    // proxy), weight-based (mg/kg) dosage, and Apgar scoring, all in one
    // dialog with a tab switcher. Deliberately pure-math / no AI call and
    // no patient required — a quick bedside utility that works even with
    // no patient selected, unlike the other Doctor Mode tools above.
    if (showVitalsCalcDialog) {
        var calcTab by remember { mutableStateOf(VitalsCalcTab.BMI) }

        // BMI inputs
        var bmiWeight by remember { mutableStateOf("") }
        var bmiHeight by remember { mutableStateOf("") }

        // Creatinine clearance inputs
        var crclAge by remember { mutableStateOf("") }
        var crclWeight by remember { mutableStateOf("") }
        var crclCreatinine by remember { mutableStateOf("") }
        var crclFemale by remember { mutableStateOf(false) }

        // Dosage inputs
        var doseWeight by remember { mutableStateOf("") }
        var dosePerKg by remember { mutableStateOf("") }
        var doseFrequency by remember { mutableStateOf("") }

        // Apgar inputs — each 0/1/2, default 2 (healthy baseline) so the
        // doctor only has to tap down the ones that are actually reduced.
        var apgarAppearance by remember { mutableStateOf(2) }
        var apgarPulse by remember { mutableStateOf(2) }
        var apgarGrimace by remember { mutableStateOf(2) }
        var apgarActivity by remember { mutableStateOf(2) }
        var apgarRespiration by remember { mutableStateOf(2) }

        AlertDialog(
            onDismissRequest = { showVitalsCalcDialog = false },
            title = { Text("🧮 Vitals Calculator", color = Color.White, fontSize = 16.sp) },
            containerColor = Color(0xFF1A1A2E),
            text = {
                Column(modifier = Modifier.heightIn(max = 460.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        VitalsCalcTab.values().forEach { tab ->
                            TextButton(onClick = { calcTab = tab }) {
                                Text(
                                    tab.label,
                                    color = if (calcTab == tab) Color(0xFF6BCB77) else Color(0xFFAAAAAA),
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))

                    when (calcTab) {
                        VitalsCalcTab.BMI -> {
                            OutlinedTextField(
                                value = bmiWeight,
                                onValueChange = { bmiWeight = it },
                                label = { Text("Weight (kg)") },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedTextField(
                                value = bmiHeight,
                                onValueChange = { bmiHeight = it },
                                label = { Text("Height (cm)") },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            val result = VitalsCalculator.calculateBmi(
                                bmiWeight.trim().toDoubleOrNull() ?: 0.0,
                                bmiHeight.trim().toDoubleOrNull() ?: 0.0
                            )
                            if (result != null) {
                                Text(
                                    "BMI: ${result.bmi} — ${result.category}",
                                    color = Color(0xFF6BCB77),
                                    fontSize = 15.sp
                                )
                            }
                        }
                        VitalsCalcTab.GFR -> {
                            OutlinedTextField(
                                value = crclAge,
                                onValueChange = { crclAge = it },
                                label = { Text("Age (years)") },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedTextField(
                                value = crclWeight,
                                onValueChange = { crclWeight = it },
                                label = { Text("Weight (kg)") },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedTextField(
                                value = crclCreatinine,
                                onValueChange = { crclCreatinine = it },
                                label = { Text("Serum creatinine (mg/dL)") },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(checked = crclFemale, onCheckedChange = { crclFemale = it })
                                Text("Female patient", color = Color.White, fontSize = 13.sp)
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            val result = VitalsCalculator.calculateCreatinineClearance(
                                crclAge.trim().toIntOrNull() ?: 0,
                                crclWeight.trim().toDoubleOrNull() ?: 0.0,
                                crclCreatinine.trim().toDoubleOrNull() ?: 0.0,
                                crclFemale
                            )
                            if (result != null) {
                                Text(
                                    "Est. CrCl: ${result.crClMlMin} mL/min — ${result.interpretation}",
                                    color = Color(0xFF6BCB77),
                                    fontSize = 15.sp
                                )
                                Text(
                                    "Cockcroft-Gault estimate — bedside reference only, not a lab eGFR.",
                                    color = Color(0xFFAAAAAA),
                                    fontSize = 11.sp
                                )
                            }
                        }
                        VitalsCalcTab.DOSAGE -> {
                            OutlinedTextField(
                                value = doseWeight,
                                onValueChange = { doseWeight = it },
                                label = { Text("Weight (kg)") },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedTextField(
                                value = dosePerKg,
                                onValueChange = { dosePerKg = it },
                                label = { Text("Dose (mg per kg)") },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedTextField(
                                value = doseFrequency,
                                onValueChange = { doseFrequency = it },
                                label = { Text("Doses per day") },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            val result = VitalsCalculator.calculateDosage(
                                doseWeight.trim().toDoubleOrNull() ?: 0.0,
                                dosePerKg.trim().toDoubleOrNull() ?: 0.0,
                                doseFrequency.trim().toIntOrNull() ?: 0
                            )
                            if (result != null) {
                                Text(
                                    "Per dose: ${result.perDoseMg} mg  •  Per day: ${result.perDayMg} mg",
                                    color = Color(0xFF6BCB77),
                                    fontSize = 15.sp
                                )
                            }
                        }
                        VitalsCalcTab.APGAR -> {
                            ApgarRow("Appearance/Color", apgarAppearance) { apgarAppearance = it }
                            ApgarRow("Pulse/Heart rate", apgarPulse) { apgarPulse = it }
                            ApgarRow("Grimace/Reflex", apgarGrimace) { apgarGrimace = it }
                            ApgarRow("Activity/Tone", apgarActivity) { apgarActivity = it }
                            ApgarRow("Respiration", apgarRespiration) { apgarRespiration = it }
                            Spacer(modifier = Modifier.height(6.dp))
                            val result = VitalsCalculator.calculateApgar(
                                apgarAppearance, apgarPulse, apgarGrimace, apgarActivity, apgarRespiration
                            )
                            if (result != null) {
                                Text(
                                    "Apgar: ${result.total}/10 — ${result.interpretation}",
                                    color = Color(0xFF6BCB77),
                                    fontSize = 15.sp
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showVitalsCalcDialog = false }) {
                    Text("Band karo", color = Color(0xFFAAAAAA))
                }
            }
        )
    }

    // Referral Letter Generator — doctor gives a case summary + reason
    // for referral (+ optional target specialty), AI turns it into a
    // structured, formal referral letter (getReferralLetter in
    // AIRepository), same focused-prompt approach as Voice-to-SOAP.
    // Generated letter can be shared straight from here via the same
    // ExportService/share-sheet path every other export uses.
    if (showReferralLetterDialog) {
        var referralSummary by remember { mutableStateOf("") }
        var referralReason by remember { mutableStateOf("") }
        var referralSpecialty by remember { mutableStateOf("") }
        var referralResult by remember { mutableStateOf<String?>(null) }
        var isGeneratingReferral by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { if (!isGeneratingReferral) showReferralLetterDialog = false },
            title = { Text("📨 Referral Letter", color = Color.White) },
            containerColor = Color(0xFF1A1A2E),
            text = {
                Column(modifier = Modifier.heightIn(max = 460.dp)) {
                    if (referralResult == null) {
                        OutlinedTextField(
                            value = referralSpecialty,
                            onValueChange = { referralSpecialty = it },
                            label = { Text("Specialist (optional, e.g. Cardiologist)") },
                            enabled = !isGeneratingReferral,
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(
                            value = referralSummary,
                            onValueChange = { referralSummary = it },
                            label = { Text("Case summary") },
                            placeholder = { Text("History, findings, investigations, current treatment...") },
                            enabled = !isGeneratingReferral,
                            minLines = 3,
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(
                            value = referralReason,
                            onValueChange = { referralReason = it },
                            label = { Text("Reason for referral") },
                            placeholder = { Text("e.g. further cardiac evaluation needed") },
                            enabled = !isGeneratingReferral,
                            minLines = 2,
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                            modifier = Modifier.fillMaxWidth()
                        )
                        if (isGeneratingReferral) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Referral letter bana rahi hoon...", color = Color(0xFF6BCB77), fontSize = 12.sp)
                        }
                    } else {
                        Text(
                            referralResult ?: "",
                            color = Color.White,
                            fontSize = 13.sp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .verticalScroll(rememberScrollState())
                        )
                    }
                }
            },
            confirmButton = {
                if (referralResult == null) {
                    TextButton(
                        enabled = !isGeneratingReferral && referralSummary.isNotBlank(),
                        onClick = {
                            isGeneratingReferral = true
                            scope.launch {
                                val result = try {
                                    aiRepository.getReferralLetter(referralSummary, referralReason, referralSpecialty)
                                } catch (e: Exception) {
                                    "Referral letter banane mein dikkat aa gayi, dobara try karo."
                                }
                                isGeneratingReferral = false
                                referralResult = result
                                if (currentPatient != null) {
                                    saveCaseNote(context, scope, "📨 Referral Letter: $referralReason", result, currentPatient?.id)
                                }
                            }
                        }
                    ) {
                        Text("Banao", color = Color(0xFF6BCB77))
                    }
                } else {
                    TextButton(onClick = {
                        scope.launch {
                            val uri = try {
                                exportService.exportReferralLetter(referralResult ?: "", currentPatient?.displayName)
                            } catch (e: Exception) {
                                null
                            }
                            if (uri != null) shareExportedFile(uri)
                        }
                    }) {
                        Text("Share", color = Color(0xFF6BCB77))
                    }
                }
            },
            dismissButton = {
                TextButton(
                    enabled = !isGeneratingReferral,
                    onClick = {
                        showReferralLetterDialog = false
                        referralSummary = ""
                        referralReason = ""
                        referralSpecialty = ""
                        referralResult = null
                    }
                ) {
                    Text(if (referralResult == null) "Cancel" else "Band karo", color = Color(0xFFAAAAAA))
                }
            }
        )
    }

    // Symptom Checker / Case Practice (Study Mode) — AI generates a
    // fictional patient case with a hidden diagnosis; the student asks
    // questions (AI stays in character as the patient), then submits
    // their own diagnosis guess for feedback. Three phases within one
    // dialog: (1) start screen / topic hint, (2) Q&A roleplay, (3) reveal
    // + feedback after the student submits a guess.
    if (showSymptomCheckerDialog) {
        var symptomCase by remember { mutableStateOf<AIRepository.SymptomCase?>(null) }
        var symptomTranscript by remember { mutableStateOf(listOf<Pair<Boolean, String>>()) } // true = student, false = patient
        var topicHintInput by remember { mutableStateOf("") }
        var questionInput by remember { mutableStateOf("") }
        var isLoadingCase by remember { mutableStateOf(false) }
        var isAskingPatient by remember { mutableStateOf(false) }
        var showDiagnosisInput by remember { mutableStateOf(false) }
        var diagnosisInput by remember { mutableStateOf("") }
        var evaluationResult by remember { mutableStateOf<String?>(null) }
        var isEvaluating by remember { mutableStateOf(false) }

        fun transcriptText(): String = symptomTranscript.joinToString("\n") { (isStudent, text) ->
            if (isStudent) "Student poocha: $text" else "Patient bola: $text"
        }

        fun resetCase() {
            symptomCase = null
            symptomTranscript = emptyList()
            questionInput = ""
            showDiagnosisInput = false
            diagnosisInput = ""
            evaluationResult = null
        }

        AlertDialog(
            onDismissRequest = {
                if (!isLoadingCase && !isAskingPatient && !isEvaluating) showSymptomCheckerDialog = false
            },
            title = { Text("🩺 Case Practice", color = Color.White) },
            containerColor = Color(0xFF1A1A2E),
            text = {
                Column(modifier = Modifier.heightIn(max = 460.dp)) {
                    if (symptomCase == null) {
                        // Phase 1 — start screen
                        Text(
                            "Ek fictional patient case milega jisme hidden diagnosis hoga — " +
                                "questions poochh ke khud figure out karo, phir apni diagnosis submit karo.",
                            color = Color(0xFFAAAAAA),
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedTextField(
                            value = topicHintInput,
                            onValueChange = { topicHintInput = it },
                            label = { Text("Topic (optional, e.g. cardiology)") },
                            enabled = !isLoadingCase,
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                            modifier = Modifier.fillMaxWidth()
                        )
                        if (isLoadingCase) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Case bana rahi hoon...", color = Color(0xFF6BCB77), fontSize = 12.sp)
                        }
                    } else if (evaluationResult != null) {
                        // Phase 3 — reveal + feedback
                        Text(
                            evaluationResult ?: "",
                            color = Color.White,
                            fontSize = 13.sp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .verticalScroll(rememberScrollState())
                        )
                    } else {
                        // Phase 2 — Q&A roleplay
                        Text(
                            symptomCase?.openingPresentation ?: "",
                            color = Color(0xFFFFD166),
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        LazyColumn(modifier = Modifier.weight(1f, fill = false).heightIn(max = 220.dp)) {
                            items(symptomTranscript) { (isStudent, text) ->
                                Text(
                                    text = if (isStudent) "🧑‍⚕️ Aap: $text" else "🤒 Patient: $text",
                                    color = if (isStudent) Color(0xFF4A90E2) else Color.White,
                                    fontSize = 13.sp,
                                    modifier = Modifier.padding(vertical = 3.dp)
                                )
                            }
                        }
                        if (!showDiagnosisInput) {
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedTextField(
                                value = questionInput,
                                onValueChange = { questionInput = it },
                                label = { Text("Patient se poocho...") },
                                enabled = !isAskingPatient,
                                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                                modifier = Modifier.fillMaxWidth()
                            )
                            if (isAskingPatient) {
                                Text("Sochh rahi hoon...", color = Color(0xFF6BCB77), fontSize = 11.sp)
                            }
                        } else {
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedTextField(
                                value = diagnosisInput,
                                onValueChange = { diagnosisInput = it },
                                label = { Text("Aapki diagnosis") },
                                enabled = !isEvaluating,
                                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                                modifier = Modifier.fillMaxWidth()
                            )
                            if (isEvaluating) {
                                Text("Check kar rahi hoon...", color = Color(0xFF6BCB77), fontSize = 11.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                when {
                    symptomCase == null -> {
                        TextButton(
                            enabled = !isLoadingCase,
                            onClick = {
                                isLoadingCase = true
                                scope.launch {
                                    val newCase = try {
                                        aiRepository.startSymptomCase(topicHintInput)
                                    } catch (e: Exception) {
                                        AIRepository.SymptomCase("Unknown", "Case generate nahi ho paya, dobara try karo.")
                                    }
                                    isLoadingCase = false
                                    symptomCase = newCase
                                }
                            }
                        ) {
                            Text("Case Shuru Karo", color = Color(0xFF6BCB77))
                        }
                    }
                    evaluationResult != null -> {
                        TextButton(onClick = { resetCase() }) {
                            Text("Naya Case", color = Color(0xFF6BCB77))
                        }
                    }
                    !showDiagnosisInput -> {
                        TextButton(
                            enabled = !isAskingPatient && questionInput.isNotBlank(),
                            onClick = {
                                val question = questionInput.trim()
                                isAskingPatient = true
                                scope.launch {
                                    val theCase = symptomCase
                                    val answer = try {
                                        if (theCase != null) {
                                            aiRepository.getSymptomCaseReply(
                                                theCase.hiddenDiagnosis,
                                                theCase.openingPresentation,
                                                transcriptText(),
                                                question
                                            )
                                        } else "Kuch gadbad ho gaya, dobara try karo."
                                    } catch (e: Exception) {
                                        "Kuch gadbad ho gaya, dobara try karo."
                                    }
                                    symptomTranscript = symptomTranscript + (true to question) + (false to answer)
                                    questionInput = ""
                                    isAskingPatient = false
                                }
                            }
                        ) {
                            Text("Poocho", color = Color(0xFF6BCB77))
                        }
                    }
                    else -> {
                        TextButton(
                            enabled = !isEvaluating && diagnosisInput.isNotBlank(),
                            onClick = {
                                isEvaluating = true
                                scope.launch {
                                    val theCase = symptomCase
                                    val result = try {
                                        if (theCase != null) {
                                            aiRepository.evaluateSymptomCaseDiagnosis(
                                                theCase.hiddenDiagnosis,
                                                theCase.openingPresentation,
                                                transcriptText(),
                                                diagnosisInput.trim()
                                            )
                                        } else "Kuch gadbad ho gaya, dobara try karo."
                                    } catch (e: Exception) {
                                        "Kuch gadbad ho gaya, dobara try karo."
                                    }
                                    isEvaluating = false
                                    evaluationResult = result
                                }
                            }
                        ) {
                            Text("Submit Karo", color = Color(0xFF6BCB77))
                        }
                    }
                }
            },
            dismissButton = {
                if (symptomCase != null && evaluationResult == null) {
                    TextButton(
                        enabled = !isAskingPatient && !isEvaluating,
                        onClick = {
                            if (!showDiagnosisInput) showDiagnosisInput = true
                            else showDiagnosisInput = false
                        }
                    ) {
                        Text(
                            if (!showDiagnosisInput) "Diagnosis Do" else "← Wapas Poochho",
                            color = Color(0xFFFFD166)
                        )
                    }
                } else {
                    TextButton(
                        enabled = !isLoadingCase,
                        onClick = { showSymptomCheckerDialog = false; resetCase() }
                    ) {
                        Text("Band Karo", color = Color(0xFFAAAAAA))
                    }
                }
            }
        )
    }

    // Manual edit — lets the doctor directly set/override the patient
    // file's diagnosis, suggestion, and current medicines/dose, as an
    // alternative to (or correction of) whatever got auto-filled by case
    // combine / diagnosis confirm / treatment reference. Writes through the
    // exact same updatePatientClinicalSummary() function as the automatic
    // path, so there's one source of truth for how this data gets saved.
    if (showEditPatientFileDialog && currentPatient != null) {
        val patient = currentPatient!!
        var diagnosisInput by remember(patient.id) { mutableStateOf(patient.currentDiagnosis) }
        var suggestionInput by remember(patient.id) { mutableStateOf(patient.currentSuggestion) }
        var medicinesInput by remember(patient.id) { mutableStateOf(patient.currentMedicines) }
        var allergiesInput by remember(patient.id) { mutableStateOf(patient.knownAllergies) }

        AlertDialog(
            onDismissRequest = { showEditPatientFileDialog = false },
            title = { Text("${patient.displayName}'s File — Manual Edit", color = Color.White, fontSize = 16.sp) },
            containerColor = Color(0xFF1A1A2E),
            text = {
                Column(modifier = Modifier.heightIn(max = 460.dp)) {
                    OutlinedTextField(
                        value = diagnosisInput,
                        onValueChange = { diagnosisInput = it },
                        label = { Text("Diagnosis") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = suggestionInput,
                        onValueChange = { suggestionInput = it },
                        label = { Text("AI Suggestion / Differential") },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 80.dp),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = medicinesInput,
                        onValueChange = { medicinesInput = it },
                        label = { Text("Current Medicines & Dose") },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 80.dp),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = allergiesInput,
                        onValueChange = { allergiesInput = it },
                        label = { Text("Known Allergies") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    // Checks whatever's currently SAVED on file
                    // (patient.currentMedicines) against whatever's
                    // currently TYPED in the medicines box — so the doctor
                    // can type a new addition, check it before saving, then
                    // decide whether to actually save it.
                    TextButton(
                        onClick = {
                            if (medicinesInput.isBlank()) return@TextButton
                            isCheckingInteractions = true
                            interactionCheckResult = null
                            scope.launch {
                                val relevantChunks = try {
                                    // Search both the existing medicines
                                    // AND the newly typed one separately —
                                    // an interaction/contraindication note
                                    // in the book might be indexed under
                                    // either drug's name.
                                    val queries = listOfNotNull(
                                        medicinesInput.take(300),
                                        patient.currentMedicines.takeIf { it.isNotBlank() }?.take(300)
                                    )
                                    ragEngine.findRelevantChunksMulti(queries, maxChunks = 6)
                                } catch (e: Exception) {
                                    emptyList()
                                }
                                interactionCheckResult = try {
                                    if (patient.currentMedicines.isBlank()) {
                                        "Patient ke file mein abhi koi existing medicine nahi hai " +
                                            "cross-check karne ke liye — ye pehla medicine hoga."
                                    } else {
                                        aiRepository.checkDrugInteractions(
                                            existingMedicines = patient.currentMedicines,
                                            newMedicines = medicinesInput,
                                            knownAllergies = allergiesInput,
                                            relevantChunks = relevantChunks
                                        )
                                    }
                                } catch (e: Exception) {
                                    "Sorry, interaction check karte waqt dikkat aa gayi. Dobara try karo."
                                }
                                isCheckingInteractions = false
                            }
                        },
                        enabled = !isCheckingInteractions
                    ) {
                        Text(
                            if (isCheckingInteractions) "Checking..." else "🔎 Check Interactions",
                            color = Color(0xFFFFD166),
                            fontSize = 13.sp
                        )
                    }
                    Text(
                        "Ye teeno fields automatic bhi update hoti hain (case combine / diagnosis confirm / " +
                            "treatment reference ke baad) — yahan se manually bhi edit ya override kar sakte ho.",
                        color = Color(0xFF888888),
                        fontSize = 10.sp,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    updatePatientClinicalSummary(
                        patient.id,
                        diagnosis = diagnosisInput.trim(),
                        suggestion = suggestionInput.trim(),
                        medicines = medicinesInput.trim(),
                        allergies = allergiesInput.trim()
                    )
                    // This manual save is the explicit "doctor confirmed
                    // this is what she actually did" signal — see
                    // DoctorLearningEngine for why this is the ONLY place
                    // a treatment pattern gets recorded (never off the AI's
                    // own unconfirmed suggestion). Fire-and-forget: a
                    // failure here shouldn't block the file save itself,
                    // which already succeeded above.
                    scope.launch {
                        try {
                            doctorLearningEngine.recordTreatmentPattern(
                                diagnosis = diagnosisInput.trim(),
                                treatmentGiven = medicinesInput.trim()
                            )
                        } catch (e: Exception) { }
                    }
                    showEditPatientFileDialog = false
                    updateMessages { it + Message(
                        "💾 ${patient.displayName}'s file manually update ki gayi.",
                        isUser = false
                    ) }
                }) {
                    Text("Save", color = Color(0xFFFF6B9D))
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditPatientFileDialog = false }) {
                    Text("Cancel", color = Color(0xFFAAAAAA))
                }
            }
        )
    }

    // Interaction check result — separate small dialog so it doesn't get
    // buried inside the (already long) edit file dialog, and stays visible
    // even after the doctor dismisses the edit dialog.
    interactionCheckResult?.let { checkResult ->
        AlertDialog(
            onDismissRequest = { interactionCheckResult = null },
            title = { Text("💊 Interaction Check", color = Color.White, fontSize = 16.sp) },
            containerColor = Color(0xFF1A1A2E),
            text = {
                Column(modifier = Modifier.heightIn(max = 420.dp)) {
                    Text(checkResult, color = Color(0xFFCCCCCC), fontSize = 13.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = { interactionCheckResult = null }) {
                    Text("Close", color = Color(0xFFFF6B9D))
                }
            }
        )
    }

    // "Learn from URL" — the doctor pastes exactly one page's URL (a
    // guideline, circular, reference article) and the app fetches just
    // that page and saves its text locally. This is a manual, one-page-
    // at-a-time action every time — there is no "scan the whole site" or
    // "keep fetching more on its own" behavior here by design.
    if (showLearnUrlDialog) {
        var urlInput by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { if (!isLearningUrl) showLearnUrlDialog = false },
            title = { Text("🌐 Learn From URL", color = Color.White, fontSize = 16.sp) },
            containerColor = Color(0xFF1A1A2E),
            text = {
                Column {
                    Text(
                        "Ek specific page ka URL do (jaise WHO guideline, MoHFW circular) — " +
                            "us page ka text phone mein save ho jaayega, phir internet ke bina bhi " +
                            "usse related sawaalon ka jawab mil sakega.",
                        color = Color(0xFF888888),
                        fontSize = 12.sp,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    OutlinedTextField(
                        value = urlInput,
                        onValueChange = { urlInput = it },
                        label = { Text("https://...") },
                        singleLine = true,
                        enabled = !isLearningUrl,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                    )
                    if (isLearningUrl) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Page fetch kar rahi hoon...", color = Color(0xFF4A90E2), fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                TextButton(
                    enabled = !isLearningUrl && urlInput.isNotBlank(),
                    onClick = {
                        val urlToLearn = urlInput.trim()
                        isLearningUrl = true
                        scope.launch {
                            val result = try {
                                aiRepository.learnFromUrl(urlToLearn)
                            } catch (e: Exception) {
                                AIRepository.UrlLearnResult.Failure("Kuch galat ho gaya — dobara try karo.")
                            }
                            isLearningUrl = false
                            showLearnUrlDialog = false
                            val statusText = when (result) {
                                is AIRepository.UrlLearnResult.Success ->
                                    "🌐 \"${result.title}\" save ho gaya (${result.charsSaved} characters) — " +
                                        "ab isse related sawaal offline mein bhi pucho sakte ho."
                                is AIRepository.UrlLearnResult.Failure ->
                                    "🌐 ${result.reason}"
                            }
                            updateMessages { it + Message(statusText, isUser = false) }
                        }
                    }
                ) {
                    Text("Fetch & Save", color = Color(0xFF4A90E2))
                }
            },
            dismissButton = {
                TextButton(enabled = !isLearningUrl, onClick = { showLearnUrlDialog = false }) {
                    Text("Cancel", color = Color(0xFFAAAAAA))
                }
            }
        )
    }

    // Voice Gender Picker — lets the user switch Kavita's spoken voice
    // between a male and female Hindi TTS voice. The actual device-level
    // voice matching (by name pattern) happens inside VoiceManager; this
    // dialog just presents the two choices and shows which installed
    // voices were found for each, so it's clear if a gender has no voice
    // on this particular device.
    if (showVoiceGenderDialog) {
        val availableVoices = remember { voiceManager.listAvailableHindiVoices() }
        val femaleCount = availableVoices.count { it.gender == VoiceManager.VoiceGender.FEMALE }
        val maleCount = availableVoices.count { it.gender == VoiceManager.VoiceGender.MALE }

        AlertDialog(
            onDismissRequest = { showVoiceGenderDialog = false },
            title = { Text("Kavita ki Awaaz", color = Color.White) },
            containerColor = Color(0xFF1A1A2E),
            text = {
                Column {
                    Text(
                        "Bolne ke liye voice choose karo:",
                        color = Color(0xFFAAAAAA),
                        fontSize = 13.sp,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    listOf(
                        Triple(VoiceManager.VoiceGender.FEMALE, "👩 Female Voice", femaleCount),
                        Triple(VoiceManager.VoiceGender.MALE, "👨 Male Voice", maleCount)
                    ).forEach { (gender, label, count) ->
                        val isSelected = currentVoiceGender == gender
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) Color(0xFF4A90E2).copy(alpha = 0.25f) else Color.Transparent)
                                .clickable(
                                    indication = null,
                                    interactionSource = remember { MutableInteractionSource() },
                                    onClick = {
                                        currentVoiceGender = gender
                                        voiceManager.setVoiceGender(gender)
                                        voiceManager.speak(
                                            if (gender == VoiceManager.VoiceGender.FEMALE)
                                                "Namaste, ab main is awaaz mein bolungi"
                                            else
                                                "Namaste, ab main is awaaz mein bolunga"
                                        )
                                    }
                                )
                                .padding(vertical = 10.dp, horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(label, color = Color.White, fontSize = 15.sp, modifier = Modifier.weight(1f))
                            if (count == 0) {
                                Text("Is device pe nahi mila", color = Color(0xFF888888), fontSize = 11.sp)
                            } else if (isSelected) {
                                Text("✓", color = Color(0xFF4A90E2), fontSize = 16.sp)
                            }
                        }
                    }

                    Text(
                        "Agar phone mein us gender ki voice install nahi hai, toh jo best available hai wahi use hogi.",
                        color = Color(0xFF666666),
                        fontSize = 11.sp,
                        modifier = Modifier.padding(top = 10.dp)
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showVoiceGenderDialog = false }) {
                    Text("Done", color = Color(0xFF4A90E2))
                }
            }
        )
    }

    // Engineer Mode calculator — real local computation (Ohm's Law, Power,
    // Bending Stress, free expression), same pattern as VitalsCalculator
    // used in Doctor Mode. Numbers are computed on-device, not guessed by
    // the AI.
    if (showEngineerCalculator) {
        var formula by remember { mutableStateOf(com.kavitababy.data.EngineeringCalculator.Formula.OHMS_LAW) }
        var fieldValues by remember(formula) {
            mutableStateOf(com.kavitababy.data.EngineeringCalculator.requiredFields(formula).associateWith { "" })
        }
        var calcResult by remember(formula) { mutableStateOf<String?>(null) }
        var calcError by remember(formula) { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = { showEngineerCalculator = false },
            title = { Text("Engineering Calculator", color = Color.White) },
            containerColor = Color(0xFF1A1A2E),
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    Row(modifier = Modifier.horizontalScroll(rememberScrollState())) {
                        com.kavitababy.data.EngineeringCalculator.Formula.values().forEach { f ->
                            val isSelected = f == formula
                            Row(
                                modifier = Modifier
                                    .padding(end = 6.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(if (isSelected) Color(0xFF4A90E2) else Color(0xFF0F1729))
                                    .clickable(
                                        indication = null,
                                        interactionSource = remember { MutableInteractionSource() },
                                        onClick = { formula = f; calcResult = null; calcError = null }
                                    )
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(f.label, color = Color.White, fontSize = 11.sp)
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    com.kavitababy.data.EngineeringCalculator.requiredFields(formula).forEach { field ->
                        OutlinedTextField(
                            value = fieldValues[field] ?: "",
                            onValueChange = { newVal ->
                                fieldValues = fieldValues.toMutableMap().apply { put(field, newVal) }
                            },
                            label = { Text(field, fontSize = 11.sp) },
                            modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )
                    }
                    calcError?.let {
                        Text(it, color = Color(0xFFFF5252), fontSize = 11.sp)
                    }
                    calcResult?.let {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(it, color = Color(0xFF4A90E2), fontSize = 14.sp)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val calcRes = com.kavitababy.data.EngineeringCalculator.calculate(formula, fieldValues)
                    calcRes.onSuccess { calcResult = it; calcError = null }
                    calcRes.onFailure { calcError = it.message; calcResult = null }
                }) {
                    Text("Calculate", color = Color(0xFF4A90E2))
                }
            },
            dismissButton = {
                TextButton(onClick = { showEngineerCalculator = false }) {
                    Text("Close", color = Color(0xFFAAAAAA))
                }
            }
        )
    }

    // Engineer Mode unit converter — exact on-device math (see
    // UnitConverter.kt), independent of any AI call. Covers the
    // SI/Imperial crossovers that come up constantly in real engineering
    // work (datasheets in inches, specs in Nm, supplier drawings in psi).
    if (showUnitConverter) {
        var category by remember { mutableStateOf(com.kavitababy.data.UnitConverter.Category.LENGTH) }
        val units = remember(category) { com.kavitababy.data.UnitConverter.unitsFor(category) }
        var fromUnit by remember(category) { mutableStateOf(units.first()) }
        var toUnit by remember(category) { mutableStateOf(units.getOrElse(1) { units.first() }) }
        var inputValue by remember(category) { mutableStateOf("") }
        var convResult by remember(category) { mutableStateOf<String?>(null) }
        var convError by remember(category) { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = { showUnitConverter = false },
            title = { Text("Unit Converter", color = Color.White) },
            containerColor = Color(0xFF1A1A2E),
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    Row(modifier = Modifier.horizontalScroll(rememberScrollState())) {
                        com.kavitababy.data.UnitConverter.Category.values().forEach { cat ->
                            val isSelected = cat == category
                            Row(
                                modifier = Modifier
                                    .padding(end = 6.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(if (isSelected) Color(0xFF4A90E2) else Color(0xFF0F1729))
                                    .clickable(
                                        indication = null,
                                        interactionSource = remember { MutableInteractionSource() },
                                        onClick = { category = cat; convResult = null; convError = null }
                                    )
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(cat.label, color = Color.White, fontSize = 11.sp)
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = inputValue,
                        onValueChange = { inputValue = it },
                        label = { Text("Value", fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )
                    Text("From:", color = Color(0xFFAAAAAA), fontSize = 10.sp)
                    Row(modifier = Modifier.horizontalScroll(rememberScrollState())) {
                        units.forEach { u ->
                            val isSelected = u == fromUnit
                            Row(
                                modifier = Modifier
                                    .padding(end = 6.dp, top = 4.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(if (isSelected) Color(0xFF4A90E2) else Color(0xFF0F1729))
                                    .clickable(
                                        indication = null,
                                        interactionSource = remember { MutableInteractionSource() },
                                        onClick = { fromUnit = u }
                                    )
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(u, color = Color.White, fontSize = 11.sp)
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("To:", color = Color(0xFFAAAAAA), fontSize = 10.sp)
                    Row(modifier = Modifier.horizontalScroll(rememberScrollState())) {
                        units.forEach { u ->
                            val isSelected = u == toUnit
                            Row(
                                modifier = Modifier
                                    .padding(end = 6.dp, top = 4.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(if (isSelected) Color(0xFF4A90E2) else Color(0xFF0F1729))
                                    .clickable(
                                        indication = null,
                                        interactionSource = remember { MutableInteractionSource() },
                                        onClick = { toUnit = u }
                                    )
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(u, color = Color.White, fontSize = 11.sp)
                            }
                        }
                    }
                    convError?.let {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(it, color = Color(0xFFFF5252), fontSize = 11.sp)
                    }
                    convResult?.let {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(it, color = Color(0xFF4A90E2), fontSize = 14.sp)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val value = inputValue.toDoubleOrNull()
                    if (value == null) {
                        convError = "Enter a valid number"
                        convResult = null
                    } else {
                        val res = com.kavitababy.data.UnitConverter.convert(category, value, fromUnit, toUnit)
                        res.onSuccess { convResult = "$value $fromUnit = $it $toUnit"; convError = null }
                        res.onFailure { convError = it.message; convResult = null }
                    }
                }) {
                    Text("Convert", color = Color(0xFF4A90E2))
                }
            },
            dismissButton = {
                TextButton(onClick = { showUnitConverter = false }) {
                    Text("Close", color = Color(0xFFAAAAAA))
                }
            }
        )
    }

    // Engineer Mode Physics/Chemistry/Maths formula bank — BTech/MTech
    // curriculum-level named formulas (see ScienceCalculator.kt), grouped
    // by category since there are 45+ of them (too many for one flat
    // scroll row like the smaller Engineering Calculator above). Real
    // on-device math, not AI-guessed numbers.
    if (showScienceCalculator) {
        var category by remember { mutableStateOf(com.kavitababy.data.ScienceCalculator.Category.MECHANICS) }
        val formulasInCategory = remember(category) { com.kavitababy.data.ScienceCalculator.formulasFor(category) }
        var formula by remember(category) { mutableStateOf(formulasInCategory.first()) }
        var fieldValues by remember(formula) {
            mutableStateOf(com.kavitababy.data.ScienceCalculator.requiredFields(formula).associateWith { "" })
        }
        var calcResult by remember(formula) { mutableStateOf<String?>(null) }
        var calcError by remember(formula) { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = { showScienceCalculator = false },
            title = { Text("Physics / Chemistry / Maths", color = Color.White) },
            containerColor = Color(0xFF1A1A2E),
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    Text("Category:", color = Color(0xFFAAAAAA), fontSize = 10.sp)
                    Row(modifier = Modifier.horizontalScroll(rememberScrollState()).padding(top = 4.dp)) {
                        com.kavitababy.data.ScienceCalculator.Category.values().forEach { cat ->
                            val isSelected = cat == category
                            Row(
                                modifier = Modifier
                                    .padding(end = 6.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(if (isSelected) Color(0xFF4A90E2) else Color(0xFF0F1729))
                                    .clickable(
                                        indication = null,
                                        interactionSource = remember { MutableInteractionSource() },
                                        onClick = {
                                            category = cat
                                            calcResult = null
                                            calcError = null
                                        }
                                    )
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(cat.label, color = Color.White, fontSize = 11.sp)
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("Formula:", color = Color(0xFFAAAAAA), fontSize = 10.sp)
                    Column(modifier = Modifier.padding(top = 4.dp)) {
                        formulasInCategory.forEach { f ->
                            val isSelected = f == formula
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 4.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (isSelected) Color(0xFF4A90E2) else Color(0xFF0F1729))
                                    .clickable(
                                        indication = null,
                                        interactionSource = remember { MutableInteractionSource() },
                                        onClick = { formula = f; calcResult = null; calcError = null }
                                    )
                                    .padding(horizontal = 10.dp, vertical = 8.dp)
                            ) {
                                Text(f.label, color = Color.White, fontSize = 11.sp)
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    com.kavitababy.data.ScienceCalculator.requiredFields(formula).forEach { field ->
                        OutlinedTextField(
                            value = fieldValues[field] ?: "",
                            onValueChange = { newVal ->
                                fieldValues = fieldValues.toMutableMap().apply { put(field, newVal) }
                            },
                            label = { Text(field, fontSize = 11.sp) },
                            modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )
                    }
                    calcError?.let {
                        Text(it, color = Color(0xFFFF5252), fontSize = 11.sp)
                    }
                    calcResult?.let {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(it, color = Color(0xFF4A90E2), fontSize = 14.sp)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val calcRes = com.kavitababy.data.ScienceCalculator.calculate(formula, fieldValues)
                    calcRes.onSuccess { calcResult = it; calcError = null }
                    calcRes.onFailure { calcError = it.message; calcResult = null }
                }) {
                    Text("Calculate", color = Color(0xFF4A90E2))
                }
            },
            dismissButton = {
                TextButton(onClick = { showScienceCalculator = false }) {
                    Text("Close", color = Color(0xFFAAAAAA))
                }
            }
        )
    }
}

@Composable
private fun ModeChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (selected) Color(0xFFFF6B9D) else Color.Transparent)
            .clickable(
                indication = null,
                interactionSource = remember { MutableInteractionSource() },
                onClick = onClick
            )
            .padding(horizontal = 14.dp, vertical = 6.dp)
    ) {
        Text(
            text = label,
            color = if (selected) Color.White else Color(0xFFAAAAAA),
            fontSize = 13.sp
        )
    }
}

/**
 * Persists a Doctor Mode exchange locally (Room, on-device only). No name or
 * patient identifier is collected — [caseDescription] is whatever free text
 * the doctor typed, which by app convention should already exclude names.
 */
/**
 * True for the standard offline/error fallback texts used across the app
 * (see AIRepository's "Main internet se connect nahi ho pa rahi..." and
 * ChatScreen's own generic exception catch) — anything matching this is
 * a failed exchange, not real clinical content, and should never be
 * saved into a patient's case history.
 */
private fun isFailureResponse(text: String): Boolean {
    val trimmed = text.trim()
    if (trimmed.isBlank()) return true
    return trimmed.startsWith("Main internet se connect nahi ho pa rahi") ||
        trimmed.contains("Sorry jaani, thoda dikkat aa gayi") ||
        trimmed.contains("File load karte waqt kuch galat ho gaya")
}

private fun saveCaseNote(
    context: Context,
    scope: kotlinx.coroutines.CoroutineScope,
    caseDescription: String,
    aiSuggestion: String,
    patientId: Long? = null
) {
    // Skip silently — the failed answer is already visible in the chat
    // either way, it just shouldn't become a permanent, undeletable-until-
    // now entry cluttering the patient's actual medical history.
    if (isFailureResponse(aiSuggestion)) return

    val dao = KavitaDatabase.getInstance(context.applicationContext).caseNoteDao()
    scope.launch(kotlinx.coroutines.Dispatchers.IO) {
        try {
            dao.insert(
                CaseNote(
                    caseLabel = "Case ${System.currentTimeMillis()}",
                    ageGender = "",
                    symptoms = caseDescription,
                    history = "",
                    aiSuggestion = aiSuggestion,
                    patientId = patientId
                )
            )
            // Bump the patient's lastUpdatedAt so the patient list can sort
            // by most-recently-active case.
            if (patientId != null) {
                val patientDao = KavitaDatabase.getInstance(context.applicationContext).patientCaseDao()
                patientDao.getById(patientId)?.let { patient ->
                    patientDao.update(patient.copy(lastUpdatedAt = System.currentTimeMillis()))
                }
            }
        } catch (e: Exception) {
            // Local save failing shouldn't disrupt the chat — the answer is
            // already shown on screen either way.
        }
    }
}

/**
 * Saves a new follow-up reminder to Room AND schedules its AlarmManager
 * alarm in the same step — the two always need to happen together (a row
 * with no alarm never fires; an alarm with no row can't be shown in the
 * "Upcoming Follow-ups" list or cancelled later), so this is the single
 * entry point for creating one rather than leaving callers to remember
 * both steps themselves.
 */
/**
 * Deletes a single case note — the per-entry cleanup that was missing
 * before (only whole-patient deletion existed). Refreshes [onDeleted]'s
 * caller-supplied list after removal so the UI updates immediately.
 */
private fun deleteCaseNote(
    context: Context,
    scope: kotlinx.coroutines.CoroutineScope,
    note: CaseNote,
    onDeleted: () -> Unit
) {
    val dao = KavitaDatabase.getInstance(context.applicationContext).caseNoteDao()
    scope.launch(kotlinx.coroutines.Dispatchers.IO) {
        try {
            dao.delete(note)
            withContext(kotlinx.coroutines.Dispatchers.Main) { onDeleted() }
        } catch (e: Exception) {
            // Leave the list as-is if the delete failed — better than
            // showing a stale "deleted" state that doesn't match the DB.
        }
    }
}

private fun createFollowUpReminder(
    context: Context,
    scope: kotlinx.coroutines.CoroutineScope,
    patientId: Long?,
    patientDisplayName: String,
    note: String,
    triggerAtMillis: Long,
    onCreated: () -> Unit
) {
    val dao = KavitaDatabase.getInstance(context.applicationContext).followUpReminderDao()
    scope.launch(kotlinx.coroutines.Dispatchers.IO) {
        try {
            val reminder = FollowUpReminder(
                patientId = patientId,
                patientDisplayName = patientDisplayName,
                note = note.trim(),
                triggerAtMillis = triggerAtMillis
            )
            val id = dao.insert(reminder)
            ReminderScheduler.schedule(context.applicationContext, reminder.copy(id = id))
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                onCreated()
            }
        } catch (e: Exception) {
            // If this fails, onCreated never fires — the dialog just stays
            // open so the doctor can retry rather than silently losing the
            // reminder with no feedback.
        }
    }
}

/** Cancels a follow-up reminder's alarm and marks it cancelled in Room. */
private fun cancelFollowUpReminder(
    context: Context,
    scope: kotlinx.coroutines.CoroutineScope,
    reminder: FollowUpReminder,
    onCancelled: () -> Unit
) {
    val dao = KavitaDatabase.getInstance(context.applicationContext).followUpReminderDao()
    scope.launch(kotlinx.coroutines.Dispatchers.IO) {
        try {
            ReminderScheduler.cancel(context.applicationContext, reminder)
            dao.markCancelled(reminder.id)
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                onCancelled()
            }
        } catch (e: Exception) {
            // Leave it in the list rather than silently disappearing —
            // doctor can retry the cancel.
        }
    }
}

/**
 * Creates a new patient record — [name] is encrypted via [PatientCrypto]
 * before it ever touches the database. [onCreated] receives the new
 * patient's id along with the plain (decrypted-equivalent, since it's the
 * same string just typed) name/age/gender for immediate in-session use, so
 * the doctor doesn't have to re-fetch and decrypt right after creating it.
 */
private fun createPatient(
    context: Context,
    scope: kotlinx.coroutines.CoroutineScope,
    name: String,
    age: String,
    gender: String,
    onCreated: (Long) -> Unit
) {
    val dao = KavitaDatabase.getInstance(context.applicationContext).patientCaseDao()
    scope.launch(kotlinx.coroutines.Dispatchers.IO) {
        try {
            val id = dao.insert(
                PatientCase(
                    encryptedName = PatientCrypto.encrypt(name.trim()),
                    age = age.trim(),
                    gender = gender.trim()
                )
            )
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                onCreated(id)
            }
        } catch (e: Exception) {
            // If patient creation fails, onCreated simply never fires —
            // caller stays on the "new patient" dialog to retry.
        }
    }
}

/**
 * Deletes a patient AND every case note linked to them (their full history) —
 * this is a doctor-initiated, explicit, irreversible action; the caller
 * (UI) is responsible for confirming with the doctor before calling this.
 */
private fun deletePatient(
    context: Context,
    scope: kotlinx.coroutines.CoroutineScope,
    patientId: Long,
    onDeleted: () -> Unit
) {
    val db = KavitaDatabase.getInstance(context.applicationContext)
    scope.launch(kotlinx.coroutines.Dispatchers.IO) {
        try {
            db.caseNoteDao().deleteForPatient(patientId)
            db.patientCaseDao().getById(patientId)?.let { db.patientCaseDao().delete(it) }
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                onDeleted()
            }
        } catch (e: Exception) {
            // If deletion fails, onDeleted never fires — the entry simply
            // stays in the list and the doctor can retry.
        }
    }
}

/** Decrypted patient list entry, ready for display — never holds ciphertext. */
data class PatientListEntry(
    val id: Long,
    val name: String,
    val age: String,
    val gender: String,
    val lastUpdatedAt: Long,
    val currentDiagnosis: String = "",
    val currentSuggestion: String = "",
    val currentMedicines: String = "",
    val knownAllergies: String = ""
)

private suspend fun loadPatientList(context: Context): List<PatientListEntry> {
    val dao = KavitaDatabase.getInstance(context.applicationContext).patientCaseDao()
    return try {
        dao.getAll().map { p ->
            PatientListEntry(
                id = p.id,
                name = PatientCrypto.decrypt(p.encryptedName).ifBlank { "(naam decrypt nahi ho paya)" },
                age = p.age,
                gender = p.gender,
                lastUpdatedAt = p.lastUpdatedAt,
                currentDiagnosis = p.currentDiagnosis,
                currentSuggestion = p.currentSuggestion,
                currentMedicines = p.currentMedicines,
                knownAllergies = p.knownAllergies
            )
        }
    } catch (e: Exception) {
        emptyList()
    }
}

@Composable
fun MessageBubble(message: Message, onFeedback: (liked: Boolean, reason: String) -> Unit = { _, _ -> }) {
    val isUser = message.isUser
    // null = not yet rated, true = 👍, false = 👎 — once set, stays set for
    // this message so the buttons don't look tappable again after use.
    var rated by remember { mutableStateOf<Boolean?>(null) }
    var showReasonPrompt by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Row(
            horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start,
            modifier = Modifier.fillMaxWidth()
        ) {
            if (!isUser) {
                Image(
                    painter = painterResource(id = R.drawable.kavita_face),
                    contentDescription = "Kavita",
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                )
                Spacer(modifier = Modifier.width(8.dp))
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth(0.85f)
                    .background(
                        (if (isUser) Color(0xFF4A90E2) else Color(0xFFFF6B9D))
                            .let { if (message.isHistorical) it.copy(alpha = 0.45f) else it },
                        RoundedCornerShape(16.dp)
                    )
                    .padding(12.dp)
            ) {
                Column {
                    // Decoded once per message and cached — without
                    // remember(message.id) this would re-decode the same
                    // base64 image on every recomposition (e.g. every
                    // keystroke elsewhere on screen), which is wasteful
                    // and can visibly stutter scrolling in a long chat.
                    val thumbnail = if (message.attachmentMimeType?.startsWith("image/") == true) {
                        remember(message.id) {
                            try {
                                val bytes = android.util.Base64.decode(message.attachmentBase64, android.util.Base64.DEFAULT)
                                android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                                    ?.asImageBitmap()
                            } catch (e: Exception) {
                                null
                            }
                        }
                    } else null

                    if (thumbnail != null) {
                        Image(
                            bitmap = thumbnail,
                            contentDescription = "Attached image",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 220.dp)
                                .clip(RoundedCornerShape(10.dp))
                        )
                        if (message.text.isNotBlank()) Spacer(modifier = Modifier.height(8.dp))
                    }

                    if (thumbnail == null || message.text.isNotBlank()) {
                        Text(
                            text = message.text,
                            color = if (message.isHistorical) Color.White.copy(alpha = 0.75f) else Color.White,
                            fontSize = 16.sp
                        )
                    }
                }
            }
        }

        // Historical bubbles (loaded from a patient's saved file) are
        // read-only — no feedback row, since they're not a live answer the
        // doctor just received.
        if (!isUser && message.question.isNotBlank() && !message.isHistorical) {
            Row(
                modifier = Modifier.padding(start = 40.dp, top = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (rated == null) {
                    IconButton(
                        onClick = {
                            rated = true
                            onFeedback(true, "")
                        },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Text("👍", fontSize = 14.sp)
                    }
                    IconButton(
                        onClick = { showReasonPrompt = true },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Text("👎", fontSize = 14.sp)
                    }
                } else {
                    Text(
                        text = if (rated == true) "👍 Feedback mil gaya" else "👎 Feedback mil gaya",
                        color = Color(0xFF888888),
                        fontSize = 11.sp
                    )
                }
            }

            if (showReasonPrompt) {
                DislikeReasonRow(
                    onReasonPicked = { reason ->
                        rated = false
                        showReasonPrompt = false
                        onFeedback(false, reason)
                    }
                )
            }
        }
    }
}

/** Quick-tap reason chips shown after a 👎, instead of requiring free typing. */
@Composable
private fun DislikeReasonRow(onReasonPicked: (String) -> Unit) {
    val reasons = listOf("Bahut lamba", "Galat tha", "Samajh nahi aaya", "Kaam ka nahi")
    Row(
        modifier = Modifier.padding(start = 40.dp, top = 4.dp)
    ) {
        reasons.forEach { reason ->
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF2A2A3E))
                    .clickable(
                        indication = null,
                        interactionSource = remember { MutableInteractionSource() },
                        onClick = { onReasonPicked(reason) }
                    )
                    .padding(horizontal = 10.dp, vertical = 5.dp)
            ) {
                Text(text = reason, color = Color(0xFFCCCCCC), fontSize = 11.sp)
            }
            Spacer(modifier = Modifier.width(6.dp))
        }
    }
}

/**
 * Small floating round button used for the "jump to top / jump to
 * bottom" fast-scroll controls over the chat message list.
 */
@Composable
private fun FastScrollButton(label: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(Color(0xFF16213E).copy(alpha = 0.9f))
            .clickable(
                indication = null,
                interactionSource = remember { MutableInteractionSource() },
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Text(text = label, color = Color(0xFFFF6B9D), fontSize = 16.sp)
    }
}

data class Message(
    val text: String,
    val isUser: Boolean,
    val id: String = java.util.UUID.randomUUID().toString(),
    val question: String = "", // the user question this answer responds to, used for feedback context
    val isHistorical: Boolean = false, // true = loaded from a patient's saved file, not a live exchange; rendered faded/read-only
    // Populated only for a user message that was sent with an image
    // attachment — lets MessageBubble show a real thumbnail instead of
    // just the filename text. Reuses the same base64 data already loaded
    // for the AI call rather than re-reading the file a second time.
    val attachmentBase64: String? = null,
    val attachmentMimeType: String? = null
)

/**
 * A minimal line chart for one lab/vitals metric's readings over time —
 * built directly on Compose Canvas rather than pulling in a charting
 * library, since this is the one place in the app that needs one and the
 * need is simple (one line, evenly spaced points, min/max-normalized).
 * [series] must already be sorted oldest-first and have at least 2 points
 * (callers check this before rendering — a single point can't show a
 * trend, only a flat dot).
 */
@Composable
private fun LabTrendChart(series: List<LabValue>, modifier: Modifier = Modifier) {
    val lineColor = Color(0xFF6BCB77)
    val pointColor = Color(0xFFFFD166)
    val gridColor = Color(0xFF333333)

    // [value] is free text now (readings like "Trace" or "1+" are valid),
    // so only the subset that actually parses as a number can be plotted —
    // the caller already checked there are at least 2 of these before
    // rendering this chart at all.
    val numericSeries = series.mapNotNull { reading ->
        reading.value.trim().toDoubleOrNull()?.let { reading to it }
    }

    Canvas(modifier = modifier) {
        val minValue = numericSeries.minOf { it.second }
        val maxValue = numericSeries.maxOf { it.second }
        // Guard against a perfectly flat series (all readings identical) —
        // without this the normalization below divides by zero and every
        // point collapses onto the same y, or worse, NaNs the whole line.
        val valueRange = (maxValue - minValue).takeIf { it > 0.0 } ?: 1.0

        val leftPadding = 8.dp.toPx()
        val rightPadding = 8.dp.toPx()
        val topPadding = 12.dp.toPx()
        val bottomPadding = 12.dp.toPx()
        val chartWidth = size.width - leftPadding - rightPadding
        val chartHeight = size.height - topPadding - bottomPadding

        // Baseline grid — just a top and bottom reference line so the
        // chart doesn't float in empty space with no sense of scale.
        drawLine(
            color = gridColor,
            start = Offset(leftPadding, topPadding),
            end = Offset(size.width - rightPadding, topPadding),
            strokeWidth = 1.dp.toPx()
        )
        drawLine(
            color = gridColor,
            start = Offset(leftPadding, size.height - bottomPadding),
            end = Offset(size.width - rightPadding, size.height - bottomPadding),
            strokeWidth = 1.dp.toPx()
        )

        val points = numericSeries.mapIndexed { index, (_, value) ->
            val x = if (numericSeries.size == 1) leftPadding else
                leftPadding + (chartWidth * index / (numericSeries.size - 1).toFloat())
            val normalizedY = (value - minValue) / valueRange
            // Canvas y grows downward, so a higher value should draw
            // nearer the top — invert the normalized fraction.
            val y = topPadding + chartHeight * (1f - normalizedY.toFloat())
            Offset(x, y)
        }

        for (i in 0 until points.size - 1) {
            drawLine(
                color = lineColor,
                start = points[i],
                end = points[i + 1],
                strokeWidth = 3.dp.toPx(),
                cap = StrokeCap.Round
            )
        }
        points.forEach { point ->
            drawCircle(color = pointColor, radius = 5.dp.toPx(), center = point)
        }
    }
}

/**
 * One Apgar component row — label plus 0/1/2 score chips. Defaults to 2
 * (healthy) in the caller; the doctor only needs to tap down the
 * components that are actually reduced instead of scoring every one
 * manually every time.
 */
@Composable
private fun ApgarRow(label: String, selected: Int, onSelect: (Int) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f))
        listOf(0, 1, 2).forEach { score ->
            TextButton(onClick = { onSelect(score) }) {
                Text(
                    "$score",
                    color = if (selected == score) Color(0xFF6BCB77) else Color(0xFFAAAAAA),
                    fontSize = 14.sp
                )
            }
        }
    }
}
