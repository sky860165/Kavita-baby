// ChatScreen.kt
package com.kavitababy.ui

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kavitababy.R
import com.kavitababy.ai.AIRepository
import com.kavitababy.data.CaseNote
import com.kavitababy.data.KavitaDatabase
import com.kavitababy.data.PdfScannerService
import com.kavitababy.data.RagSearchEngine
import com.kavitababy.voice.VoiceManager
import kotlinx.coroutines.launch

private enum class AppMode { STUDY, DOCTOR }

@Composable
fun ChatScreen(voiceManager: VoiceManager, pdfScanTrigger: Int = 0, screenshotScanTrigger: Int = 0) {
    val context = LocalContext.current
    var mode by remember { mutableStateOf(AppMode.STUDY) }
    var messages by remember { mutableStateOf(listOf<Message>()) }
    var inputText by remember { mutableStateOf("") }
    var isListening by remember { mutableStateOf(false) }
    var isThinking by remember { mutableStateOf(false) }
    var isIndexingPdf by remember { mutableStateOf(false) }
    var voiceErrorMessage by remember { mutableStateOf<String?>(null) }
    val aiRepository = remember { AIRepository() }
    val ragEngine = remember { RagSearchEngine(context.applicationContext) }
    val pdfScanner = remember { PdfScannerService(context.applicationContext) }
    val mediaScanner = remember { com.kavitababy.data.MediaScannerService(context.applicationContext) }
    val learningEngine = remember { com.kavitababy.data.LearningEngine(context.applicationContext) }
    val scope = rememberCoroutineScope()
    var isProcessingMedia by remember { mutableStateOf(false) }

    // Storage Access Framework picker — the system's own file browser.
    // Because the user explicitly chooses the file themselves through this
    // picker, Android grants read access to that one file automatically,
    // with no READ_EXTERNAL_STORAGE/READ_MEDIA_* runtime permission needed
    // at all.
    //
    // Mime type "*/*" (instead of the old "application/pdf" only) so the
    // same 📎 button now lets the user pick PDF, image, video, audio, or
    // zip — MediaScannerService/PdfScannerService figure out what it is by
    // extension and route it to the right handler below.
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult

        val name = context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (cursor.moveToFirst() && idx >= 0) cursor.getString(idx) else null
        } ?: uri.lastPathSegment.orEmpty()

        if (name.endsWith(".pdf", ignoreCase = true)) {
            isIndexingPdf = true
            scope.launch {
                val result = pdfScanner.indexPickedPdf(uri)
                isIndexingPdf = false
                val confirmationText = when (result) {
                    is PdfScannerService.PickResult.Success ->
                        "\"${result.pdfName}\" padh liya maine, ${result.chunksCreated} sections mil gaye — ab isse related kuch bhi pucho, jaani!"
                    is PdfScannerService.PickResult.Failure ->
                        "Is PDF ko padhne mein dikkat aa gayi: ${result.reason}"
                }
                messages = messages + Message(confirmationText, isUser = false)
            }
        } else {
            // Image, video, audio, or zip — everything else goes through
            // MediaScannerService + Gemini's multimodal understanding.
            messages = messages + Message("📎 $name bheja", isUser = true)
            isProcessingMedia = true
            scope.launch {
                val loadResult = try {
                    mediaScanner.loadPicked(uri)
                } catch (e: Exception) {
                    com.kavitababy.data.MediaScannerService.LoadResult.Failure(
                        e.message ?: "File load karte waqt kuch galat ho gaya"
                    )
                }

                val responseText = when (loadResult) {
                    is com.kavitababy.data.MediaScannerService.LoadResult.Failure ->
                        loadResult.reason
                    is com.kavitababy.data.MediaScannerService.LoadResult.Success -> {
                        if (loadResult.files.size == 1) {
                            val file = loadResult.files.first()
                            // Doctor Mode + image (X-ray/CT/MRI/ECG/EEG/blood
                            // report etc) goes through the medical-specific
                            // reading path instead of the casual Study Mode
                            // description — same image kind, different depth
                            // and mandatory clinical disclaimer.
                            if (mode == AppMode.DOCTOR && file.kind == com.kavitababy.data.MediaScannerService.Kind.IMAGE) {
                                aiRepository.getDoctorImageResponse(
                                    fileName = file.displayName,
                                    mimeType = file.mimeType,
                                    base64Data = file.base64Data
                                )
                            } else {
                                aiRepository.getMediaResponse(
                                    fileName = file.displayName,
                                    mimeType = file.mimeType,
                                    base64Data = file.base64Data,
                                    kind = file.kind
                                )
                            }
                        } else {
                            // Multiple files came out of a zip.
                            "\"$name\" mein ${loadResult.files.size} files mili, sabko padh rahi hoon...\n\n" +
                                aiRepository.getZipContentsResponse(loadResult.files)
                        }
                    }
                }

                isProcessingMedia = false
                messages = messages + Message(responseText, isUser = false)
                if (mode == AppMode.DOCTOR && loadResult is com.kavitababy.data.MediaScannerService.LoadResult.Success) {
                    val file = loadResult.files.firstOrNull()
                    if (file != null) {
                        saveCaseNote(context, scope, "Medical image: ${file.displayName}", responseText)
                    }
                }
                if (mode == AppMode.STUDY && loadResult is com.kavitababy.data.MediaScannerService.LoadResult.Success) {
                    voiceManager.speak(responseText)
                }
            }
        }
    }

    // Runs on first composition AND again whenever pdfScanTrigger changes
    // (bumped by MainActivity once storage access actually becomes
    // available — either already granted at launch, or granted just now
    // after the user returns from the All Files Access settings screen).
    // Scans the whole device for PDFs (filesystem walk if All Files Access
    // is granted, MediaStore query otherwise) and posts a confirmation into
    // the chat so the user can actually see it happened, instead of it
    // silently running with no feedback.
    LaunchedEffect(pdfScanTrigger) {
        if (pdfScanTrigger == 0) return@LaunchedEffect
        isIndexingPdf = true
        val result = try {
            pdfScanner.scanAllPdfs()
        } catch (e: Exception) {
            null
        }
        isIndexingPdf = false

        val statusText = when {
            result == null ->
                "Phone ke PDFs scan karne mein dikkat aa gayi — 📎 button se manually bhi PDF de sakte ho."
            result.pdfsIndexed > 0 ->
                "Maine tumhare phone mein ${result.pdfsFound} PDF dhoondhe, unme se ${result.pdfsIndexed} naye padh liye — ab in sabse related kuch bhi pucho, jaani!"
            result.pdfsFound > 0 ->
                "Tumhare phone ke saare ${result.pdfsFound} PDFs pehle se hi padhe hue hain, kuch naya nahi mila is baar."
            else ->
                "Mujhe abhi phone mein koi PDF nahi mila. Agar kahin folder mein hai jo main dekh nahi paa rahi, 📎 button se seedha de do."
        }
        messages = messages + Message(statusText, isUser = false)
    }

    // Fires exactly once, only when MainActivity bumps screenshotScanTrigger
    // after the user explicitly tapped "Haan, padho" on the one-time
    // consent dialog. This is not a recurring/background scan — it runs
    // this single pass and then does nothing further unless the user picks
    // an image manually via the 📎 button afterwards.
    LaunchedEffect(screenshotScanTrigger) {
        if (screenshotScanTrigger == 0) return@LaunchedEffect
        isProcessingMedia = true
        messages = messages + Message(
            "Thik hai jaani, tumhare Screenshots folder ki recent images padh rahi hoon, ek second...",
            isUser = false
        )

        var found = 0
        val results = mutableListOf<Pair<String, String>>()
        try {
            found = mediaScanner.scanScreenshotsFolder { fileName, mimeType, base64Data ->
                val summary = aiRepository.getMediaResponse(
                    fileName = fileName,
                    mimeType = mimeType,
                    base64Data = base64Data,
                    kind = com.kavitababy.data.MediaScannerService.Kind.IMAGE
                )
                results.add(fileName to summary)
            }
        } catch (e: Exception) {
            // Scan failing shouldn't crash the chat — just report nothing found below.
        }

        isProcessingMedia = false
        val summaryText = if (results.isEmpty()) {
            "Mujhe Screenshots folder mein koi padhne layak image nahi mili."
        } else {
            "Maine $found screenshots padhe. Kuch important cheez chahiye inme se to bata do, " +
                "ya seedha pucho kisi specific screenshot ke baare mein."
        }
        messages = messages + Message(summaryText, isUser = false)
    }

    fun send(text: String) {
        if (text.isBlank()) return
        messages = messages + Message(text, isUser = true)
        isThinking = true

        scope.launch {
            // Explicit memory commands ("yaad rakhna ki...", "sab bhool ja")
            // short-circuit straight to a confirmation — no need to hit
            // Gemini at all for these, and they should always work even if
            // the AI is unreachable.
            val memoryCommandReply = try {
                learningEngine.maybeHandleExplicitMemoryCommand(text)
            } catch (e: Exception) {
                null
            }
            if (memoryCommandReply != null) {
                messages = messages + Message(memoryCommandReply, isUser = false, question = text)
                isThinking = false
                if (mode == AppMode.STUDY) voiceManager.speak(memoryCommandReply)
                return@launch
            }

            // Passive extraction from ordinary messages (name, exam date,
            // weak subject mentioned in passing) — best-effort, never blocks
            // the main reply if it fails or finds nothing.
            try { learningEngine.autoExtractFromMessage(text) } catch (e: Exception) { }

            val relevantChunks = try {
                ragEngine.findRelevantChunks(text)
            } catch (e: Exception) {
                emptyList()
            }

            val response = try {
                if (mode == AppMode.DOCTOR) {
                    aiRepository.getDoctorResponse(text, relevantChunks)
                } else {
                    val memoryBlock = try { learningEngine.memoryContextBlock() } catch (e: Exception) { "" }
                    val feedbackBlock = try { learningEngine.feedbackContextBlock() } catch (e: Exception) { "" }
                    aiRepository.getResponse(text, relevantChunks, memoryBlock, feedbackBlock)
                }
            } catch (e: Exception) {
                "Sorry jaani, thoda dikkat aa gayi. Dobara try karo."
            }

            messages = messages + Message(response, isUser = false, question = text)
            isThinking = false

            if (mode == AppMode.DOCTOR) {
                saveCaseNote(context, scope, text, response)
            }

            // Doctor Mode answers are long/clinical — reading them aloud
            // isn't useful the way it is for the casual Study Mode chat.
            if (mode == AppMode.STUDY) {
                voiceManager.speak(response)

                // Topic-repeat nudge only makes sense in Study Mode (it's
                // meant for exam revision, not clinical cases). Posted as a
                // separate follow-up message so it doesn't get lost inside
                // the main answer text.
                val nudge = try { learningEngine.trackAndMaybeNudge(text) } catch (e: Exception) { null }
                if (nudge != null) {
                    messages = messages + Message(nudge, isUser = false)
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF1A1A2E))
    ) {
        // Header with Kavita's face
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF16213E))
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Image(
                    painter = painterResource(id = R.drawable.kavita_face),
                    contentDescription = "Kavita Baby",
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                )
                Text(
                    text = if (mode == AppMode.DOCTOR) "Kavita Baby — Doctor Mode 🩺" else "Kavita Baby 💕",
                    color = Color.White,
                    fontSize = 20.sp
                )
                Text(
                    text = when {
                        isListening -> "Sunn rahi hoon... 👂"
                        voiceErrorMessage != null -> voiceErrorMessage!!
                        isThinking -> "Soch rahi hoon... 🤔"
                        isIndexingPdf -> "PDF padh rahi hoon... 📄"
                        isProcessingMedia -> "File samajh rahi hoon... 🔍"
                        mode == AppMode.DOCTOR -> "Case describe karo (naam mat likho)... 📋"
                        else -> "Bolo jaani... 💬"
                    },
                    color = if (voiceErrorMessage != null) Color.Red else Color(0xFFFF6B9D),
                    fontSize = 14.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Mode toggle
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color(0xFF0F1729))
                        .padding(4.dp)
                ) {
                    ModeChip(
                        label = "Study",
                        selected = mode == AppMode.STUDY,
                        onClick = { mode = AppMode.STUDY }
                    )
                    ModeChip(
                        label = "Doctor",
                        selected = mode == AppMode.DOCTOR,
                        onClick = { mode = AppMode.DOCTOR }
                    )
                }
            }
        }

        if (mode == AppMode.DOCTOR) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF2A1A1A))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "⚠️ Reference only — patient ka naam/identity kabhi mat likho. " +
                        "Final decision aapka clinical judgement hai.",
                    color = Color(0xFFFFB4A2),
                    fontSize = 11.sp
                )
            }
        }

        // Chat Messages
        LazyColumn(
            modifier = Modifier.weight(1f),
            reverseLayout = true
        ) {
            items(messages.reversed(), key = { it.id }) { message ->
                MessageBubble(
                    message = message,
                    onFeedback = { liked, reason ->
                        scope.launch {
                            learningEngine.recordFeedback(
                                question = message.question,
                                answer = message.text,
                                liked = liked,
                                reason = reason
                            )
                        }
                    }
                )
            }
        }

        // Input Area
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // PDF Upload Button — opens the system file picker scoped to
            // PDFs. Placed first so it reads left-to-right as "attach, talk,
            // type, send", matching how chat apps usually order these.
            IconButton(
                onClick = { filePickerLauncher.launch("*/*") },
                enabled = !isIndexingPdf && !isProcessingMedia
            ) {
                Icon(
                    painter = painterResource(id = R.drawable.ic_attach),
                    contentDescription = "File upload karo (PDF/image/video/audio/zip)",
                    tint = if (isIndexingPdf || isProcessingMedia) Color(0xFF666666) else Color(0xFFFF6B9D)
                )
            }

            // Voice Button
            IconButton(
                onClick = {
                    isListening = true
                    voiceErrorMessage = null
                    // Driven directly from this Activity's own context —
                    // no separate window is opened, so the rest of the
                    // screen (buttons, text field) stays touchable while
                    // listening. VoiceManager internally retries once via
                    // Google's recognizer explicitly if the device default
                    // rejects the request (common on some MIUI builds).
                    voiceManager.startListening(
                        onResult = { text ->
                            isListening = false
                            if (text.isNotBlank()) {
                                send(text)
                            } else {
                                // Recognizer returned success but with no
                                // usable text — surface this instead of
                                // silently doing nothing, since otherwise
                                // it looks identical to the mic not working.
                                voiceErrorMessage = "Kuch samajh nahi aaya, dobara bolo 🎙️"
                                scope.launch {
                                    kotlinx.coroutines.delay(2500)
                                    if (voiceErrorMessage != null) voiceErrorMessage = null
                                }
                            }
                        },
                        onError = { errorCode ->
                            isListening = false
                            val friendly = when (errorCode) {
                                android.speech.SpeechRecognizer.ERROR_NO_MATCH,
                                android.speech.SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                                    "Kuch samajh nahi aaya, dobara bolo"
                                android.speech.SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                                    "Mic permission chahiye"
                                android.speech.SpeechRecognizer.ERROR_NETWORK,
                                android.speech.SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                                    "Network problem, dobara try karo"
                                else -> "Mic error"
                            }
                            // Error code shown alongside the message so any
                            // future issue is diagnosable straight from a
                            // screenshot instead of guessing the cause again.
                            voiceErrorMessage = "$friendly (code $errorCode) 🎙️"
                            scope.launch {
                                kotlinx.coroutines.delay(4000)
                                if (voiceErrorMessage != null) voiceErrorMessage = null
                            }
                        }
                    )
                }
            ) {
                Icon(
                    painter = painterResource(id = R.drawable.ic_mic),
                    contentDescription = "Voice",
                    tint = if (isListening) Color.Red else Color(0xFFFF6B9D)
                )
            }

            // Text Input
            OutlinedTextField(
                value = inputText,
                onValueChange = { inputText = it },
                modifier = Modifier.weight(1f),
                placeholder = {
                    Text(if (mode == AppMode.DOCTOR) "Age/gender, symptoms, history..." else "Kuch bolo... 💬")
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                )
            )

            // Send Button
            IconButton(
                onClick = {
                    val text = inputText
                    inputText = ""
                    send(text)
                }
            ) {
                Icon(
                    painter = painterResource(id = R.drawable.ic_send),
                    contentDescription = "Send",
                    tint = Color(0xFFFF6B9D)
                )
            }
        }
    }
}

@Composable
private fun ModeChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (selected) Color(0xFFFF6B9D) else Color.Transparent)
            .clickable(
                indication = null,
                interactionSource = remember { MutableInteractionSource() },
                onClick = onClick
            )
            .padding(horizontal = 14.dp, vertical = 6.dp)
    ) {
        Text(
            text = label,
            color = if (selected) Color.White else Color(0xFFAAAAAA),
            fontSize = 13.sp
        )
    }
}

/**
 * Persists a Doctor Mode exchange locally (Room, on-device only). No name or
 * patient identifier is collected — [caseDescription] is whatever free text
 * the doctor typed, which by app convention should already exclude names.
 */
private fun saveCaseNote(
    context: Context,
    scope: kotlinx.coroutines.CoroutineScope,
    caseDescription: String,
    aiSuggestion: String
) {
    val dao = KavitaDatabase.getInstance(context.applicationContext).caseNoteDao()
    scope.launch(kotlinx.coroutines.Dispatchers.IO) {
        try {
            dao.insert(
                CaseNote(
                    caseLabel = "Case ${System.currentTimeMillis()}",
                    ageGender = "",
                    symptoms = caseDescription,
                    history = "",
                    aiSuggestion = aiSuggestion
                )
            )
        } catch (e: Exception) {
            // Local save failing shouldn't disrupt the chat — the answer is
            // already shown on screen either way.
        }
    }
}

@Composable
fun MessageBubble(message: Message, onFeedback: (liked: Boolean, reason: String) -> Unit = { _, _ -> }) {
    val isUser = message.isUser
    // null = not yet rated, true = 👍, false = 👎 — once set, stays set for
    // this message so the buttons don't look tappable again after use.
    var rated by remember { mutableStateOf<Boolean?>(null) }
    var showReasonPrompt by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Row(
            horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start,
            modifier = Modifier.fillMaxWidth()
        ) {
            if (!isUser) {
                Image(
                    painter = painterResource(id = R.drawable.kavita_face),
                    contentDescription = "Kavita",
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                )
                Spacer(modifier = Modifier.width(8.dp))
            }

            Box(
                modifier = Modifier
                    .background(
                        if (isUser) Color(0xFF4A90E2) else Color(0xFFFF6B9D),
                        RoundedCornerShape(16.dp)
                    )
                    .padding(12.dp)
            ) {
                Text(
                    text = message.text,
                    color = Color.White,
                    fontSize = 16.sp
                )
            }
        }

        // Feedback row only on Kavita's own answers (not user messages, and
        // not the auto-scan status/nudge messages which have no question
        // attached to rate against).
        if (!isUser && message.question.isNotBlank()) {
            Row(
                modifier = Modifier.padding(start = 40.dp, top = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (rated == null) {
                    IconButton(
                        onClick = {
                            rated = true
                            onFeedback(true, "")
                        },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Text("👍", fontSize = 14.sp)
                    }
                    IconButton(
                        onClick = { showReasonPrompt = true },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Text("👎", fontSize = 14.sp)
                    }
                } else {
                    Text(
                        text = if (rated == true) "👍 Feedback mil gaya" else "👎 Feedback mil gaya",
                        color = Color(0xFF888888),
                        fontSize = 11.sp
                    )
                }
            }

            if (showReasonPrompt) {
                DislikeReasonRow(
                    onReasonPicked = { reason ->
                        rated = false
                        showReasonPrompt = false
                        onFeedback(false, reason)
                    }
                )
            }
        }
    }
}

/** Quick-tap reason chips shown after a 👎, instead of requiring free typing. */
@Composable
private fun DislikeReasonRow(onReasonPicked: (String) -> Unit) {
    val reasons = listOf("Bahut lamba", "Galat tha", "Samajh nahi aaya", "Kaam ka nahi")
    Row(
        modifier = Modifier.padding(start = 40.dp, top = 4.dp)
    ) {
        reasons.forEach { reason ->
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF2A2A3E))
                    .clickable(
                        indication = null,
                        interactionSource = remember { MutableInteractionSource() },
                        onClick = { onReasonPicked(reason) }
                    )
                    .padding(horizontal = 10.dp, vertical = 5.dp)
            ) {
                Text(text = reason, color = Color(0xFFCCCCCC), fontSize = 11.sp)
            }
            Spacer(modifier = Modifier.width(6.dp))
        }
    }
}

data class Message(
    val text: String,
    val isUser: Boolean,
    val id: String = java.util.UUID.randomUUID().toString(),
    val question: String = "" // the user question this answer responds to, used for feedback context
)
