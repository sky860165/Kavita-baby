// ChatScreen.kt
package com.kavitababy.ui

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kavitababy.R
import com.kavitababy.ai.AIRepository
import com.kavitababy.data.CaseNote
import com.kavitababy.data.FollowUpReminder
import com.kavitababy.data.KavitaDatabase
import com.kavitababy.data.LabValue
import com.kavitababy.data.PatientCase
import com.kavitababy.data.PatientCrypto
import com.kavitababy.data.PdfScannerService
import com.kavitababy.data.RagSearchEngine
import com.kavitababy.data.ReminderScheduler
import com.kavitababy.voice.VoiceManager
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Locale

private enum class AppMode { STUDY, DOCTOR }

@Composable
fun ChatScreen(voiceManager: VoiceManager, pdfScanTrigger: Int = 0, screenshotScanTrigger: Int = 0) {
    val context = LocalContext.current
    var mode by remember { mutableStateOf(AppMode.STUDY) }
    // Study Mode and Doctor Mode each keep their own chat history — they used
    // to share one `messages` list, which made switching tabs show the other
    // mode's conversation mixed in with this one. Kept as two separate
    // remembered lists so switching tabs is a pure UI swap, not a data merge.
    var studyMessages by remember { mutableStateOf(listOf<Message>()) }
    var doctorMessages by remember { mutableStateOf(listOf<Message>()) }
    // Kotlin local vars can't have custom get/set, so `messages` is a plain
    // val that's recomputed on every recomposition (cheap — it's just a
    // reference pick) and every write goes through updateMessages() below,
    // which writes into whichever per-mode list matches the current mode.
    val messages: List<Message> = if (mode == AppMode.STUDY) studyMessages else doctorMessages
    fun updateMessages(newList: List<Message>) {
        if (mode == AppMode.STUDY) studyMessages = newList else doctorMessages = newList
    }
    var inputText by remember { mutableStateOf("") }
    var isListening by remember { mutableStateOf(false) }
    // Male/Female voice picker dialog — tapping the voice-gender button
    // opens this instead of switching immediately, so the doctor/student
    // can see which one is currently selected before choosing.
    var showVoiceGenderDialog by remember { mutableStateOf(false) }
    var currentVoiceGender by remember { mutableStateOf(voiceManager.getCurrentGender()) }
    var isThinking by remember { mutableStateOf(false) }
    var isIndexingPdf by remember { mutableStateOf(false) }
    // Separate from isIndexingPdf on purpose: isIndexingPdf is for the
    // manual 📎-picked single PDF (fast, finite). This one is for the
    // automatic whole-device background scan on app start, which can
    // legitimately take minutes on a phone with lots of files/apps (full
    // filesystem walk + OCR of any scanned-image pages it finds). That
    // background scan used to share isIndexingPdf, which meant the 📎
    // attach button stayed disabled — looking completely dead — for as
    // long as the background scan ran, sometimes several minutes, even
    // though the user never asked for that scan and just wanted to pick a
    // file themselves. The header status text still shows this so the
    // user knows something's happening, but it no longer blocks the
    // attach button.
    var isBackgroundPdfScanning by remember { mutableStateOf(false) }
    var voiceErrorMessage by remember { mutableStateOf<String?>(null) }
    val aiRepository = remember { AIRepository(context.applicationContext) }
    val ragEngine = remember { RagSearchEngine(context.applicationContext) }
    val pdfScanner = remember { PdfScannerService(context.applicationContext) }
    val mediaScanner = remember { com.kavitababy.data.MediaScannerService(context.applicationContext) }
    val learningEngine = remember { com.kavitababy.data.LearningEngine(context.applicationContext) }
    val exportService = remember { com.kavitababy.data.ExportService(context.applicationContext) }
    val scope = rememberCoroutineScope()
    var isProcessingMedia by remember { mutableStateOf(false) }

    // Case Workup: lets Doctor Mode collect MULTIPLE findings (typed notes +
    // every uploaded report/scan's individual reading) for the SAME case,
    // then combine all of them into one ranked differential in a single
    // step — instead of the doctor mentally cross-referencing several
    // separate per-file answers herself. Purely in-memory/session state,
    // same as doctorHistory in AIRepository — not persisted as its own
    // table, only the final combined result gets saved via saveCaseNote
    // (same as any other Doctor Mode answer already is).
    var caseWorkupActive by remember { mutableStateOf(false) }
    var caseFindings by remember { mutableStateOf(listOf<AIRepository.CaseFinding>()) }
    var isCombiningCase by remember { mutableStateOf(false) }
    // Set once the doctor confirms a diagnosis for the active workup, so the
    // "get treatment reference" action has something to act on.
    var confirmedDiagnosisContext by remember { mutableStateOf("") }
    // Which medical system to show treatment reference for — doctor picks
    // before confirming a diagnosis.
    var treatmentSystem by remember { mutableStateOf(AIRepository.TreatmentSystem.BOTH) }

    // Doctor Mode patient list — a simple, on-device, encrypted-name record
    // per patient. Every Case Workup can now be tied to a patient so past
    // cases are organized by who they belong to, instead of being one flat
    // unlabeled list. currentPatient is whichever patient the doctor is
    // actively working with right now (null = no patient context, old
    // ad-hoc behavior).
    data class ActivePatient(
        val id: Long,
        val displayName: String,
        val age: String,
        val gender: String,
        val currentDiagnosis: String = "",
        val currentSuggestion: String = "",
        val currentMedicines: String = "",
        val knownAllergies: String = ""
    )
    var currentPatient by remember { mutableStateOf<ActivePatient?>(null) }
    var showPatientList by remember { mutableStateOf(false) }
    var showUpcomingFollowUps by remember { mutableStateOf(false) }
    var showNewPatientDialog by remember { mutableStateOf(false) }
    var showFollowUpDialog by remember { mutableStateOf(false) }
    var showMedicineCheckDialog by remember { mutableStateOf(false) }
    var showSoapNoteDialog by remember { mutableStateOf(false) }
    var patientListRefreshTrigger by remember { mutableStateOf(0) }
    // Lets the doctor manually edit the patient's clinical summary fields
    // directly, as an alternative to (or override of) the automatic fill
    // that happens after a case combine / diagnosis confirm / treatment ref.
    var showEditPatientFileDialog by remember { mutableStateOf(false) }
    var showLabTrendsDialog by remember { mutableStateOf(false) }
    // "Learn from URL" — doctor explicitly gives one webpage; the app
    // fetches just that page and saves it into the local knowledge base
    // for offline use later. Not a background/autonomous crawl.
    var showLearnUrlDialog by remember { mutableStateOf(false) }
    var isLearningUrl by remember { mutableStateOf(false) }
    // Drug interaction check result — shown in its own dialog rather than
    // dumped into chat, since it's a lookup the doctor triggers on demand
    // and re-runs often (each time medicines change), not a running
    // conversation thread.
    var interactionCheckResult by remember { mutableStateOf<String?>(null) }
    var isCheckingInteractions by remember { mutableStateOf(false) }

    // Doctor Mode's warning banner + patient bar + Case Workup panel used to
    // always be expanded, permanently eating vertical space above the chat
    // no matter how deep the conversation was. Now collapsed by default once
    // there's an active case with messages, and expandable on tap via a
    // single compact summary row — the doctor can still reach every action
    // (Patient List, Learn URL, Case Workup, Combine, Confirm dx) by
    // expanding it, but it no longer permanently shrinks the chat area.
    var doctorPanelExpanded by remember { mutableStateOf(true) }

    // Writes the patient's clinical summary (diagnosis/suggestion/medicines/
    // allergies) to their file and refreshes currentPatient so the UI
    // reflects it immediately — used by BOTH the automatic path (after case
    // combine, diagnosis confirm, treatment reference) and the manual edit
    // dialog, so there is exactly one place that actually performs this
    // write. Passing null for a field leaves that field unchanged; pass ""
    // to explicitly clear it.
    fun updatePatientClinicalSummary(
        patientId: Long,
        diagnosis: String? = null,
        suggestion: String? = null,
        medicines: String? = null,
        allergies: String? = null
    ) {
        scope.launch(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val dao = KavitaDatabase.getInstance(context.applicationContext).patientCaseDao()
                val existing = dao.getById(patientId) ?: return@launch
                dao.updateClinicalSummary(
                    patientId = patientId,
                    diagnosis = diagnosis ?: existing.currentDiagnosis,
                    suggestion = suggestion ?: existing.currentSuggestion,
                    medicines = medicines ?: existing.currentMedicines,
                    allergies = allergies ?: existing.knownAllergies
                )
                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                    if (currentPatient?.id == patientId) {
                        currentPatient = currentPatient?.copy(
                            currentDiagnosis = diagnosis ?: currentPatient?.currentDiagnosis.orEmpty(),
                            currentSuggestion = suggestion ?: currentPatient?.currentSuggestion.orEmpty(),
                            currentMedicines = medicines ?: currentPatient?.currentMedicines.orEmpty(),
                            knownAllergies = allergies ?: currentPatient?.knownAllergies.orEmpty()
                        )
                    }
                }
            } catch (e: Exception) {
                // File write failing shouldn't disrupt the chat — the doctor
                // can retry via the manual edit dialog if this silently fails.
            }
        }
    }

    // Storage Access Framework picker — the system's own file browser.
    // Because the user explicitly chooses the file themselves through this
    // picker, Android grants read access to that one file automatically,
    // with no READ_EXTERNAL_STORAGE/READ_MEDIA_* runtime permission needed
    // at all.
    //
    // Mime type "*/*" (instead of the old "application/pdf" only) so the
    // same 📎 button now lets the user pick PDF, image, video, audio, or
    // zip — MediaScannerService/PdfScannerService figure out what it is by
    // extension and route it to the right handler below.
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val uri: Uri? = result.data?.data
        if (uri == null) return@rememberLauncherForActivityResult

        // Query the display name off the Main thread — some MIUI content
        // providers (Gallery/Files app) are slow to answer this cursor
        // query, and running it directly in the launcher callback (Main
        // thread) is exactly what was freezing the button / triggering the
        // ANR popup. Everything now happens inside scope.launch on IO.
        scope.launch {
            val name = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    val idx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                    if (cursor.moveToFirst() && idx >= 0) cursor.getString(idx) else null
                } ?: uri.lastPathSegment.orEmpty()
            }

            if (name.endsWith(".pdf", ignoreCase = true)) {
                isIndexingPdf = true
                // try/finally so isIndexingPdf is guaranteed to reset even
                // if indexPickedPdf throws something unexpected — without
                // this, a single failure here would leave the flag stuck
                // `true` forever, permanently disabling the attach button
                // (it stays visible but every tap silently does nothing)
                // until the app is force-restarted.
                val result = try {
                    pdfScanner.indexPickedPdf(uri)
                } catch (e: Exception) {
                    PdfScannerService.PickResult.Failure(e.message ?: "PDF padhte waqt kuch galat ho gaya")
                } finally {
                    isIndexingPdf = false
                }
                val confirmationText = when (result) {
                    is PdfScannerService.PickResult.Success ->
                        "\"${result.pdfName}\" padh liya maine, ${result.chunksCreated} sections mil gaye — ab isse related kuch bhi pucho, jaani!"
                    is PdfScannerService.PickResult.Failure ->
                        "Is PDF ko padhne mein dikkat aa gayi: ${result.reason}"
                }
                updateMessages(messages + Message(confirmationText, isUser = false))
            } else {
                // Image, video, audio, or zip — everything else goes through
                // MediaScannerService + Gemini's multimodal understanding.
                updateMessages(messages + Message("📎 $name bheja", isUser = true))
                isProcessingMedia = true

                // Everything below runs inside try/finally so
                // isProcessingMedia is guaranteed to reset even if
                // getMediaResponse/getDoctorImageResponse/
                // getZipContentsResponse throw something unexpected —
                // without this, a single failure here left the flag stuck
                // `true` forever, permanently disabling the attach button
                // (visible but every tap silently doing nothing) until the
                // app was force-restarted. mediaScanner.loadPicked was
                // already try/caught below; the AI-response calls weren't.
                try {
                    val loadResult = try {
                        mediaScanner.loadPicked(uri)
                    } catch (e: Exception) {
                        com.kavitababy.data.MediaScannerService.LoadResult.Failure(
                            e.message ?: "File load karte waqt kuch galat ho gaya"
                        )
                    }

                    val responseText = when (loadResult) {
                        is com.kavitababy.data.MediaScannerService.LoadResult.Failure ->
                            loadResult.reason
                        is com.kavitababy.data.MediaScannerService.LoadResult.Success -> {
                            val pdfSummary = if (loadResult.indexedPdfs.isNotEmpty()) {
                                loadResult.indexedPdfs.joinToString("\n") { result ->
                                    when (result) {
                                        is PdfScannerService.PickResult.Success ->
                                            "📄 \"${result.pdfName}\" padh liya (${result.chunksCreated} sections) — ab isse related pucho!"
                                        is PdfScannerService.PickResult.Failure ->
                                            "📄 \"${result.reason}\""
                                    }
                                }
                            } else null

                            when {
                                loadResult.files.isEmpty() && pdfSummary != null ->
                                    // Zip had only PDF(s), no image/video/audio.
                                    pdfSummary
                                loadResult.files.size == 1 -> {
                                    val file = loadResult.files.first()
                                    // Doctor Mode + image (X-ray/CT/MRI/ECG/EEG/blood
                                    // report etc) goes through the medical-specific
                                    // reading path instead of the casual Study Mode
                                    // description — same image kind, different depth
                                    // and mandatory clinical disclaimer.
                                    val mediaAnswer = if (mode == AppMode.DOCTOR && file.kind == com.kavitababy.data.MediaScannerService.Kind.IMAGE) {
                                        aiRepository.getDoctorImageResponse(
                                            fileName = file.displayName,
                                            mimeType = file.mimeType,
                                            base64Data = file.base64Data
                                        )
                                    } else {
                                        aiRepository.getMediaResponse(
                                            fileName = file.displayName,
                                            mimeType = file.mimeType,
                                            base64Data = file.base64Data,
                                            kind = file.kind
                                        )
                                    }
                                    if (pdfSummary != null) "$pdfSummary\n\n$mediaAnswer" else mediaAnswer
                                }
                                else -> {
                                    // Multiple media files came out of a zip.
                                    val mediaAnswer = "\"$name\" mein ${loadResult.files.size} files mili, sabko padh rahi hoon...\n\n" +
                                        aiRepository.getZipContentsResponse(loadResult.files)
                                    if (pdfSummary != null) "$pdfSummary\n\n$mediaAnswer" else mediaAnswer
                                }
                            }
                        }
                    }

                    updateMessages(messages + Message(responseText, isUser = false))
                    if (mode == AppMode.DOCTOR && loadResult is com.kavitababy.data.MediaScannerService.LoadResult.Success) {
                        val file = loadResult.files.firstOrNull()
                        if (file != null) {
                            saveCaseNote(context, scope, "Medical image: ${file.displayName}", responseText, currentPatient?.id)
                            // If a Case Workup is active, this report's reading
                            // becomes one more finding to be correlated together
                            // with everything else in the case later.
                            if (caseWorkupActive) {
                                caseFindings = caseFindings + AIRepository.CaseFinding(
                                    label = file.displayName,
                                    content = responseText
                                )
                            }
                        }
                    }
                    if (mode == AppMode.STUDY && loadResult is com.kavitababy.data.MediaScannerService.LoadResult.Success) {
                        voiceManager.speak(responseText)
                    }
                } catch (e: Exception) {
                    updateMessages(messages + Message(
                        "File samajhne mein dikkat aa gayi, dobara try karo.",
                        isUser = false
                    ))
                } finally {
                    isProcessingMedia = false
                }
            }
        }
    }

    // Runs on first composition AND again whenever pdfScanTrigger changes
    // (bumped by MainActivity once storage access actually becomes
    // available — either already granted at launch, or granted just now
    // after the user returns from the All Files Access settings screen).
    // Scans the whole device for PDFs (filesystem walk if All Files Access
    // is granted, MediaStore query otherwise) and posts a confirmation into
    // the chat so the user can actually see it happened, instead of it
    // silently running with no feedback.
    LaunchedEffect(pdfScanTrigger) {
        if (pdfScanTrigger == 0) return@LaunchedEffect
        isBackgroundPdfScanning = true
        val result = try {
            // Capped at 2 minutes — a full filesystem walk plus OCR on
            // every scanned-image PDF can genuinely take a long time on a
            // phone with lots of storage/apps, but it should never be able
            // to hang indefinitely. Timing out here just means this
            // particular background pass gives up early (next app launch
            // retries); it does NOT block manual PDF picking either way
            // now, since that's tracked separately via isIndexingPdf.
            kotlinx.coroutines.withTimeoutOrNull(120_000) {
                pdfScanner.scanAllPdfs()
            }
        } catch (e: Exception) {
            null
        }
        isBackgroundPdfScanning = false

        val statusText = when {
            result == null ->
                "Phone ke PDFs scan karne mein dikkat aa gayi — 📎 button se manually bhi PDF de sakte ho."
            result.pdfsIndexed > 0 ->
                "Maine tumhare phone mein ${result.pdfsFound} PDF dhoondhe, unme se ${result.pdfsIndexed} naye padh liye — ab in sabse related kuch bhi pucho, jaani!"
            result.pdfsFound > 0 ->
                "Tumhare phone ke saare ${result.pdfsFound} PDFs pehle se hi padhe hue hain, kuch naya nahi mila is baar."
            else ->
                "Mujhe abhi phone mein koi PDF nahi mila. Agar kahin folder mein hai jo main dekh nahi paa rahi, 📎 button se seedha de do."
        }
        updateMessages(messages + Message(statusText, isUser = false))
    }

    // Fires exactly once, only when MainActivity bumps screenshotScanTrigger
    // after the user explicitly tapped "Haan, padho" on the one-time
    // consent dialog. This is not a recurring/background scan — it runs
    // this single pass and then does nothing further unless the user picks
    // an image manually via the 📎 button afterwards.
    LaunchedEffect(screenshotScanTrigger) {
        if (screenshotScanTrigger == 0) return@LaunchedEffect
        isProcessingMedia = true
        updateMessages(messages + Message(
            "Thik hai jaani, tumhare Screenshots folder ki recent images padh rahi hoon, ek second...",
            isUser = false
        ))

        var found = 0
        val results = mutableListOf<Pair<String, String>>()
        try {
            found = mediaScanner.scanScreenshotsFolder { fileName, mimeType, base64Data ->
                val summary = aiRepository.getMediaResponse(
                    fileName = fileName,
                    mimeType = mimeType,
                    base64Data = base64Data,
                    kind = com.kavitababy.data.MediaScannerService.Kind.IMAGE
                )
                results.add(fileName to summary)
            }
        } catch (e: Exception) {
            // Scan failing shouldn't crash the chat — just report nothing found below.
        }

        isProcessingMedia = false
        val summaryText = if (results.isEmpty()) {
            "Mujhe Screenshots folder mein koi padhne layak image nahi mili."
        } else {
            "Maine $found screenshots padhe. Kuch important cheez chahiye inme se to bata do, " +
                "ya seedha pucho kisi specific screenshot ke baare mein."
        }
        updateMessages(messages + Message(summaryText, isUser = false))
    }

    // Combines every finding gathered so far in the active Case Workup into
    // one ranked differential. Posted into the chat like any other answer,
    // and also saved as a case note so it's retrievable later.
    fun combineCaseFindings() {
        if (caseFindings.isEmpty()) return
        isCombiningCase = true
        updateMessages(messages + Message("🔗 Sab findings combine karke analyze kar rahi hoon (verification pass ke saath)...", isUser = true))
        scope.launch {
            val relevantChunks = try {
                // One search PER finding (not one search over everything
                // joined together) — so a book chunk that's highly
                // relevant to just one finding's specific wording can
                // still surface, instead of needing to also match the
                // other unrelated findings to rank highly.
                ragEngine.findRelevantChunksMulti(
                    ragEngine.queriesFromFindings(caseFindings.map { it.content }),
                    maxChunks = 6
                )
            } catch (e: Exception) {
                emptyList()
            }
            val result = try {
                aiRepository.getCombinedCaseAnalysis(caseFindings, relevantChunks)
            } catch (e: Exception) {
                "Sorry, case combine karte waqt dikkat aa gayi. Dobara try karo."
            }
            isCombiningCase = false
            updateMessages(messages + Message(result, isUser = false))
            saveCaseNote(
                context, scope,
                "Combined case (${caseFindings.size} findings)",
                result,
                currentPatient?.id
            )
            // Auto-fill the patient file's "current suggestion" with this
            // combined differential — the doctor hasn't confirmed a
            // diagnosis yet at this point, so currentDiagnosis is left
            // untouched (only currentSuggestion is written here).
            currentPatient?.let { patient ->
                updatePatientClinicalSummary(patient.id, suggestion = result)
            }
            // Explicit confirmation so the doctor sees this actually landed
            // in the patient's file, instead of just trusting it happened
            // silently in the background.
            updateMessages(messages + Message(
                currentPatient?.let { "💾 Saved to ${it.displayName}'s file." }
                    ?: "💾 Saved (no patient linked — select a patient from Patient List to attach future cases to their file).",
                isUser = false
            ))
            confirmedDiagnosisContext = caseFindings.joinToString("\n") { "${it.label}: ${it.content.take(200)}" }
        }
    }

    // Once the doctor types/confirms a diagnosis, fetches a standard
    // treatment/medicine REFERENCE for it — gated entirely on this explicit
    // confirmation, never auto-suggested off the AI's own ranked list.
    fun getTreatmentForConfirmedDiagnosis(diagnosis: String) {
        if (diagnosis.isBlank()) return
        updateMessages(messages + Message("✅ Diagnosis confirm: $diagnosis", isUser = true))
        isThinking = true
        scope.launch {
            val relevantChunks = try {
                // Search using BOTH the diagnosis name AND the case
                // context separately — a treatment/dosage chunk in the
                // book might be indexed under wording that matches the
                // clinical context (symptoms/history) even if it doesn't
                // literally contain the diagnosis name itself.
                val queries = listOf(diagnosis) +
                    (if (confirmedDiagnosisContext.isNotBlank()) listOf(confirmedDiagnosisContext.take(300)) else emptyList())
                ragEngine.findRelevantChunksMulti(queries, maxChunks = 6)
            } catch (e: Exception) {
                emptyList()
            }
            val result = try {
                aiRepository.getTreatmentReference(diagnosis, confirmedDiagnosisContext, relevantChunks, treatmentSystem)
            } catch (e: Exception) {
                "Sorry, treatment reference laate waqt dikkat aa gayi. Dobara try karo."
            }
            isThinking = false
            updateMessages(messages + Message(result, isUser = false))
            saveCaseNote(context, scope, "Confirmed diagnosis: $diagnosis", result, currentPatient?.id)
            // If the patient already has medicines on file, check the new
            // suggestion against them BEFORE overwriting — this way the
            // interaction warning (if any) is visible while the doctor
            // still has the old list to compare against, not after it's
            // already been replaced.
            currentPatient?.let { patient ->
                if (patient.currentMedicines.isNotBlank()) {
                    updateMessages(messages + Message(
                        "💊 Existing medicines ke saath cross-check kar rahi hoon...",
                        isUser = false
                    ))
                    val interactionResult = try {
                        aiRepository.checkDrugInteractions(
                            existingMedicines = patient.currentMedicines,
                            newMedicines = result,
                            knownAllergies = patient.knownAllergies,
                            relevantChunks = relevantChunks
                        )
                    } catch (e: Exception) {
                        "Sorry, interaction check karte waqt dikkat aa gayi — manually verify karo."
                    }
                    updateMessages(messages + Message(interactionResult, isUser = false))
                }
                updatePatientClinicalSummary(
                    patient.id,
                    diagnosis = diagnosis,
                    medicines = result
                )
                updateMessages(messages + Message(
                    "💾 ${patient.displayName}'s file updated — diagnosis aur medicine/dose reference save ho gaya.",
                    isUser = false
                ))
            }
        }
    }

    fun send(text: String) {
        if (text.isBlank()) return
        updateMessages(messages + Message(text, isUser = true))
        isThinking = true

        // `messages` above is a one-time snapshot from this recomposition.
        // Everything inside scope.launch below runs later/asynchronously, so
        // capturing the mode now and always reading the LIVE per-mode list
        // (instead of the stale `messages` val) is what keeps every message
        // added after this point — including the user bubble we just added —
        // from being silently dropped when the next update overwrites the list.
        val sendMode = mode
        fun liveMessages(): List<Message> = if (sendMode == AppMode.STUDY) studyMessages else doctorMessages
        fun setLiveMessages(newList: List<Message>) {
            if (sendMode == AppMode.STUDY) studyMessages = newList else doctorMessages = newList
        }

        scope.launch {
            // Explicit memory commands ("yaad rakhna ki...", "sab bhool ja")
            // short-circuit straight to a confirmation — no need to hit
            // Gemini at all for these, and they should always work even if
            // the AI is unreachable.
            val memoryCommandReply = try {
                learningEngine.maybeHandleExplicitMemoryCommand(text)
            } catch (e: Exception) {
                null
            }
            if (memoryCommandReply != null) {
                setLiveMessages(liveMessages() + Message(memoryCommandReply, isUser = false, question = text))
                isThinking = false
                if (sendMode == AppMode.STUDY) voiceManager.speak(memoryCommandReply)
                return@launch
            }

            // Passive extraction from ordinary messages (name, exam date,
            // weak subject mentioned in passing) — best-effort, never blocks
            // the main reply if it fails or finds nothing.
            try { learningEngine.autoExtractFromMessage(text) } catch (e: Exception) { }

            val relevantChunks = try {
                ragEngine.findRelevantChunks(text)
            } catch (e: Exception) {
                emptyList()
            }

            var wasStreamed = false
            val response = try {
                if (sendMode == AppMode.DOCTOR) {
                    aiRepository.getDoctorResponse(text, relevantChunks)
                } else {
                    val memoryBlock = try { learningEngine.memoryContextBlock() } catch (e: Exception) { "" }
                    val feedbackBlock = try { learningEngine.feedbackContextBlock() } catch (e: Exception) { "" }

                    // Insert an empty placeholder bubble first, then grow its
                    // text in place as chunks stream in — same Message id
                    // throughout so this reads as "the answer typing itself
                    // out" rather than a new bubble appearing per chunk.
                    val streamingId = java.util.UUID.randomUUID().toString()
                    setLiveMessages(liveMessages() + Message("", isUser = false, id = streamingId, question = text))
                    isThinking = false
                    wasStreamed = true

                    // Streaming mode captured at closure-creation time so
                    // onChunk below always patches the correct per-mode list
                    // even if the doctor somehow switches tabs mid-stream.
                    val streamingMode = sendMode

                    val streamedAnswer = aiRepository.streamResponse(
                        question = text,
                        relevantChunks = relevantChunks,
                        memoryBlock = memoryBlock,
                        feedbackBlock = feedbackBlock
                    ) { chunk ->
                        withContext(kotlinx.coroutines.Dispatchers.Main) {
                            // Read/write the live per-mode state directly
                            // (not the outer `messages` val, which is a
                            // one-time snapshot from when send() started —
                            // using it here would silently drop every
                            // chunk but the first since each update would
                            // overwrite from the same stale base list).
                            if (streamingMode == AppMode.STUDY) {
                                studyMessages = studyMessages.map { m ->
                                    if (m.id == streamingId) m.copy(text = m.text + chunk) else m
                                }
                            } else {
                                doctorMessages = doctorMessages.map { m ->
                                    if (m.id == streamingId) m.copy(text = m.text + chunk) else m
                                }
                            }
                        }
                    }

                    // Reconcile the final bubble with the authoritative full
                    // answer (covers the offline-fallback path inside
                    // streamResponse, where onChunk fires once with the
                    // complete text rather than incrementally).
                    if (streamingMode == AppMode.STUDY) {
                        studyMessages = studyMessages.map { m -> if (m.id == streamingId) m.copy(text = streamedAnswer) else m }
                    } else {
                        doctorMessages = doctorMessages.map { m -> if (m.id == streamingId) m.copy(text = streamedAnswer) else m }
                    }
                    streamedAnswer
                }
            } catch (e: Exception) {
                "Sorry jaani, thoda dikkat aa gayi. Dobara try karo."
            }

            if (!wasStreamed) {
                setLiveMessages(liveMessages() + Message(response, isUser = false, question = text))
            }
            isThinking = false

            if (sendMode == AppMode.DOCTOR) {
                saveCaseNote(context, scope, text, response, currentPatient?.id)
                if (caseWorkupActive) {
                    caseFindings = caseFindings + AIRepository.CaseFinding(
                        label = "Doctor's note",
                        content = text
                    )
                }
            }

            // Doctor Mode answers are long/clinical — reading them aloud
            // isn't useful the way it is for the casual Study Mode chat.
            if (sendMode == AppMode.STUDY) {
                voiceManager.speak(response)

                // Topic-repeat nudge only makes sense in Study Mode (it's
                // meant for exam revision, not clinical cases). Posted as a
                // separate follow-up message so it doesn't get lost inside
                // the main answer text.
                val nudge = try { learningEngine.trackAndMaybeNudge(text) } catch (e: Exception) { null }
                if (nudge != null) {
                    setLiveMessages(liveMessages() + Message(nudge, isUser = false))
                }
            }
        }
    }

    // Fires the Android share sheet for whatever Uri was last exported —
    // a plain Intent.ACTION_SEND rather than a registered launcher, since
    // this doesn't need a result back (the doctor picks WhatsApp/Email/
    // whatever and this app's job is done once the chooser opens).
    fun shareExportedFile(uri: Uri, mimeType: String = "text/plain") {
        try {
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(shareIntent, "Export share karo"))
        } catch (e: Exception) {
            // No app available to handle the share sheet, or some other
            // one-off failure — nothing to recover into, just no-op
            // rather than crash the chat screen over an export share.
        }
    }

    var isExporting by remember { mutableStateOf(false) }

    fun exportCurrentChat() {
        if (messages.isEmpty() || isExporting) return
        isExporting = true
        scope.launch {
            val exportMessages = messages.map {
                com.kavitababy.data.ExportService.ChatMessageForExport(it.text, it.isUser)
            }
            val uri = try {
                exportService.exportChatTranscript(
                    messages = exportMessages,
                    modeLabel = if (mode == AppMode.DOCTOR) "Doctor Mode" else "Study Mode",
                    patientName = currentPatient?.displayName
                )
            } catch (e: Exception) {
                null
            }
            isExporting = false
            if (uri != null) {
                shareExportedFile(uri)
            } else {
                updateMessages(messages + Message("Export banane mein dikkat aa gayi, dobara try karo.", isUser = false))
            }
        }
    }

    fun exportActivePatientHistory() {
        val patient = currentPatient ?: return
        if (isExporting) return
        isExporting = true
        scope.launch {
            val uri = try {
                val db = KavitaDatabase.getInstance(context.applicationContext)
                val notes = db.caseNoteDao().getForPatient(patient.id)
                val patientCase = db.patientCaseDao().getById(patient.id)
                if (patientCase != null) {
                    exportService.exportPatientHistory(patientCase, patient.displayName, notes)
                } else null
            } catch (e: Exception) {
                null
            }
            isExporting = false
            if (uri != null) {
                shareExportedFile(uri)
            } else {
                updateMessages(messages + Message("Patient history export nahi ho payi, dobara try karo.", isUser = false))
            }
        }
    }

    fun exportActivePatientPrescription() {
        val patient = currentPatient ?: return
        if (isExporting) return
        isExporting = true
        scope.launch {
            val uri = try {
                val db = KavitaDatabase.getInstance(context.applicationContext)
                val patientCase = db.patientCaseDao().getById(patient.id)
                if (patientCase != null) {
                    exportService.exportPrescription(patientCase, patient.displayName)
                } else null
            } catch (e: Exception) {
                null
            }
            isExporting = false
            if (uri != null) {
                shareExportedFile(uri)
            } else {
                updateMessages(
                    messages + Message(
                        "Prescription banane ke liye pehle patient ki file mein medicines add karo.",
                        isUser = false
                    )
                )
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF1A1A2E))
    ) {
        // Header with Kavita's face — compact single row in Doctor Mode
        // (face + subtitle removed) since that screen already has several
        // stacked panels below competing for vertical space; Study Mode
        // keeps the original full-size friendly header.
        if (mode == AppMode.DOCTOR) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF16213E))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Image(
                    painter = painterResource(id = R.drawable.kavita_face),
                    contentDescription = "Kavita Baby",
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Kavita Baby — Doctor Mode 🩺",
                        color = Color.White,
                        fontSize = 15.sp
                    )
                    Text(
                        text = when {
                            isListening -> "Sunn rahi hoon... 👂"
                            voiceErrorMessage != null -> voiceErrorMessage!!
                            isThinking -> "Soch rahi hoon... 🤔"
                            isIndexingPdf || isBackgroundPdfScanning -> "PDF padh rahi hoon... 📄"
                            isProcessingMedia -> "File samajh rahi hoon... 🔍"
                            else -> "Case describe karo (naam mat likho)... 📋"
                        },
                        color = if (voiceErrorMessage != null) Color.Red else Color(0xFFFF6B9D),
                        fontSize = 11.sp
                    )
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(Color(0xFF0F1729))
                            .padding(3.dp)
                    ) {
                        ModeChip(label = "Study", selected = false, onClick = { mode = AppMode.STUDY })
                        ModeChip(label = "Doctor", selected = true, onClick = { })
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    // Voice Changer — opens the male/female TTS voice
                    // picker. Kept up here with the mode chips (header
                    // area has room), not in the bottom input row, which
                    // stays reserved for attach + mic like before.
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0xFF0F1729))
                            .clickable(
                                indication = null,
                                interactionSource = remember { MutableInteractionSource() },
                                onClick = { showVoiceGenderDialog = true }
                            )
                            .padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (currentVoiceGender == VoiceManager.VoiceGender.FEMALE) "👩" else "👨",
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Voice Changer",
                            color = Color(0xFFAAAAAA),
                            fontSize = 10.sp
                        )
                    }
                }
            }
        } else {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF16213E))
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Image(
                        painter = painterResource(id = R.drawable.kavita_face),
                        contentDescription = "Kavita Baby",
                        modifier = Modifier
                            .size(80.dp)
                            .clip(CircleShape)
                    )
                    Text(
                        text = "Kavita Baby 💕",
                        color = Color.White,
                        fontSize = 20.sp
                    )
                    Text(
                        text = when {
                            isListening -> "Sunn rahi hoon... 👂"
                            voiceErrorMessage != null -> voiceErrorMessage!!
                            isThinking -> "Soch rahi hoon... 🤔"
                            isIndexingPdf || isBackgroundPdfScanning -> "PDF padh rahi hoon... 📄"
                            isProcessingMedia -> "File samajh rahi hoon... 🔍"
                            else -> "Bolo jaani... 💬"
                        },
                        color = if (voiceErrorMessage != null) Color.Red else Color(0xFFFF6B9D),
                        fontSize = 14.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(Color(0xFF0F1729))
                            .padding(4.dp)
                    ) {
                        ModeChip(label = "Study", selected = true, onClick = { })
                        ModeChip(label = "Doctor", selected = false, onClick = { mode = AppMode.DOCTOR })
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Voice Changer — opens the male/female TTS voice
                        // picker. Kept up here in the header (there's room),
                        // not in the bottom input row, which stays reserved
                        // for attach + mic like before.
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color(0xFF0F1729))
                                .clickable(
                                    indication = null,
                                    interactionSource = remember { MutableInteractionSource() },
                                    onClick = { showVoiceGenderDialog = true }
                                )
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (currentVoiceGender == VoiceManager.VoiceGender.FEMALE) "👩" else "👨",
                                fontSize = 14.sp
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(
                                text = "Voice Changer",
                                color = Color(0xFFAAAAAA),
                                fontSize = 11.sp
                            )
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        // Export this chat as a text file, shareable via
                        // WhatsApp/Email/etc — only meaningful once there's
                        // actually a conversation to export.
                        if (messages.isNotEmpty()) {
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(Color(0xFF0F1729))
                                    .clickable(
                                        indication = null,
                                        interactionSource = remember { MutableInteractionSource() },
                                        onClick = { exportCurrentChat() }
                                    )
                                    .padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(text = if (isExporting) "⏳" else "📤", fontSize = 14.sp)
                                Spacer(modifier = Modifier.width(5.dp))
                                Text(text = "Export", color = Color(0xFFAAAAAA), fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }

        if (mode == AppMode.DOCTOR) {
            // Compact summary row — always visible, one line, tap to
            // expand/collapse everything below (warning banner, patient
            // bar, Case Workup panel). This is what reclaims the vertical
            // space that used to be permanently occupied by those panels.
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF241833))
                    .clickable(
                        indication = null,
                        interactionSource = remember { MutableInteractionSource() },
                        onClick = { doctorPanelExpanded = !doctorPanelExpanded }
                    )
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = currentPatient?.let { "🧑‍⚕️ ${it.displayName}" } ?: "🧑‍⚕️ Patient nahi select",
                    color = Color.White,
                    fontSize = 12.sp,
                    modifier = Modifier.weight(1f)
                )
                if (caseWorkupActive) {
                    Text(
                        text = "📋 ${caseFindings.size} finding${if (caseFindings.size == 1) "" else "s"}",
                        color = Color(0xFFFF6B9D),
                        fontSize = 12.sp,
                        modifier = Modifier.padding(end = 8.dp)
                    )
                }
                // Export — patient's full case history if one is active,
                // otherwise just this session's chat transcript. Nested
                // clickable inside the row's own clickable (which toggles
                // Details) — Compose gives touch priority to the more
                // specific inner target, so tapping this doesn't also
                // toggle the panel.
                Text(
                    text = if (isExporting) "⏳" else "📤",
                    fontSize = 14.sp,
                    modifier = Modifier
                        .padding(end = 10.dp)
                        .clickable(
                            indication = null,
                            interactionSource = remember { MutableInteractionSource() },
                            onClick = {
                                if (currentPatient != null) exportActivePatientHistory() else exportCurrentChat()
                            }
                        )
                )
                // Rx — separate from the full-history export above, this
                // pulls just the current diagnosis + medicines into a
                // clean printable prescription slip. Only shown once a
                // patient is selected and has at least something in the
                // medicines field (checked at export time; a tap with
                // nothing there just gets a friendly nudge instead of a
                // silent no-op) — Case Workup/history export doesn't need
                // this same guard since an empty history is still valid.
                if (currentPatient != null) {
                    Text(
                        text = if (isExporting) "⏳" else "💊",
                        fontSize = 14.sp,
                        modifier = Modifier
                            .padding(end = 10.dp)
                            .clickable(
                                indication = null,
                                interactionSource = remember { MutableInteractionSource() },
                                onClick = { exportActivePatientPrescription() }
                            )
                    )
                }
                Text(
                    text = if (doctorPanelExpanded) "▲ Hide" else "▼ Details",
                    color = Color(0xFF4A90E2),
                    fontSize = 12.sp
                )
            }

            if (doctorPanelExpanded) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF2A1A1A))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "⚠️ Patient naam sirf Patient List ke through add karo (encrypted save hota hai) " +
                            "— chat mein direct naam mat likho. Final decision aapka clinical judgement hai.",
                        color = Color(0xFFFFB4A2),
                        fontSize = 11.sp
                    )
                }

                // Patient bar — shows the active patient (if any) and a button
                // to open the patient list / switch patient / start fresh.
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF241833))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = currentPatient?.let { "🧑‍⚕️ ${it.displayName} (${it.age}, ${it.gender})" }
                            ?: "🧑‍⚕️ Koi patient select nahi hai",
                        color = Color.White,
                        fontSize = 13.sp,
                        modifier = Modifier.weight(1f)
                    )
                    if (currentPatient != null) {
                        TextButton(onClick = { showEditPatientFileDialog = true }) {
                            Text("Edit File", color = Color(0xFFFFD166), fontSize = 13.sp)
                        }
                    }
                    TextButton(onClick = { showLearnUrlDialog = true }) {
                        Text("🌐 Learn URL", color = Color(0xFF4A90E2), fontSize = 13.sp)
                    }
                    TextButton(onClick = {
                        patientListRefreshTrigger++
                        showPatientList = true
                    }) {
                        Text("Patient List", color = Color(0xFFFF6B9D), fontSize = 13.sp)
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF241833))
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 12.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (currentPatient != null) {
                        TextButton(onClick = { showFollowUpDialog = true }) {
                            Text("⏰ Follow-up set karo", color = Color(0xFF6BCB77), fontSize = 13.sp)
                        }
                    }
                    TextButton(onClick = { showUpcomingFollowUps = true }) {
                        Text("📋 Upcoming Follow-ups", color = Color(0xFF6BCB77), fontSize = 13.sp)
                    }
                    TextButton(onClick = { showMedicineCheckDialog = true }) {
                        Text("💊 Medicine Check", color = Color(0xFF6BCB77), fontSize = 13.sp)
                    }
                    TextButton(onClick = { showSoapNoteDialog = true }) {
                        Text("📝 SOAP Note", color = Color(0xFF6BCB77), fontSize = 13.sp)
                    }
                    if (currentPatient != null) {
                        TextButton(onClick = { showLabTrendsDialog = true }) {
                            Text("📈 Lab Trends", color = Color(0xFF6BCB77), fontSize = 13.sp)
                        }
                    }
                }

                // Case Workup panel — lets multiple reports/notes for ONE case be
                // gathered, then combined into a single ranked differential, then
                // (once the doctor confirms a diagnosis) a treatment reference.
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF1E1430))
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = if (caseWorkupActive)
                                "📋 Case Workup: ${caseFindings.size} finding${if (caseFindings.size == 1) "" else "s"} collected"
                            else "📋 Case Workup",
                            color = Color.White,
                            fontSize = 13.sp,
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(onClick = {
                            if (caseWorkupActive) {
                                // Ending a workup clears it — starting a new one
                                // later begins a fresh, empty findings list.
                                caseWorkupActive = false
                                caseFindings = emptyList()
                                confirmedDiagnosisContext = ""
                                currentPatient = null
                            } else {
                                caseWorkupActive = true
                                val patientNote = if (currentPatient == null) {
                                    " (Abhi koi patient select nahi hai — Patient List se select ya naya patient banao " +
                                        "taaki ye case unke record mein bhi save ho.)"
                                } else ""
                                updateMessages(messages + Message(
                                    "Case Workup shuru — ab jo bhi reports/scans upload karogi ya notes " +
                                        "type karogi, sab is ek case mein collect hongi. Jab sab de diya ho, " +
                                        "\"Combine\" dabao ek combined ranked differential ke liye.$patientNote",
                                    isUser = false
                                ))
                            }
                        }) {
                            Text(
                                text = if (caseWorkupActive) "End" else "Start",
                                color = Color(0xFFFF6B9D),
                                fontSize = 13.sp
                            )
                        }
                    }

                    if (caseWorkupActive) {
                        // Treatment-system choice — applies to the "Confirm dx +
                        // treatment" action below.
                        Row(
                            modifier = Modifier.padding(top = 4.dp, bottom = 2.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text("Reference:", color = Color(0xFF888888), fontSize = 10.sp, modifier = Modifier.padding(top = 3.dp))
                            ModeChip(
                                label = "Modern",
                                selected = treatmentSystem == AIRepository.TreatmentSystem.MODERN_ONLY,
                                onClick = { treatmentSystem = AIRepository.TreatmentSystem.MODERN_ONLY }
                            )
                            ModeChip(
                                label = "Ayurveda",
                                selected = treatmentSystem == AIRepository.TreatmentSystem.AYURVEDA_ONLY,
                                onClick = { treatmentSystem = AIRepository.TreatmentSystem.AYURVEDA_ONLY }
                            )
                            ModeChip(
                                label = "Both",
                                selected = treatmentSystem == AIRepository.TreatmentSystem.BOTH,
                                onClick = { treatmentSystem = AIRepository.TreatmentSystem.BOTH }
                            )
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { combineCaseFindings() },
                                enabled = caseFindings.isNotEmpty() && !isCombiningCase,
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4A90E2)),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = if (isCombiningCase) "Combining..." else "Combine (${caseFindings.size})",
                                    fontSize = 12.sp
                                )
                            }
                            Button(
                                onClick = {
                                    val d = inputText
                                    if (d.isNotBlank()) {
                                        inputText = ""
                                        getTreatmentForConfirmedDiagnosis(d)
                                    }
                                },
                                enabled = inputText.isNotBlank(),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Confirm dx + treatment", fontSize = 11.sp)
                            }
                        }
                        Text(
                            text = "Confirm ke liye: text box mein diagnosis type karo, phir upar wala button dabao.",
                            color = Color(0xFF888888),
                            fontSize = 10.sp
                        )
                    }
                }
            }
        }

        // Chat Messages
        LazyColumn(
            modifier = Modifier.weight(1f),
            reverseLayout = true
        ) {
            items(messages.reversed(), key = { it.id }) { message ->
                MessageBubble(
                    message = message,
                    onFeedback = { liked, reason ->
                        scope.launch {
                            learningEngine.recordFeedback(
                                question = message.question,
                                answer = message.text,
                                liked = liked,
                                reason = reason
                            )
                        }
                    }
                )
            }
        }

        // Input Area
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // PDF Upload Button — opens the system file picker scoped to
            // PDFs. Placed first so it reads left-to-right as "attach, talk,
            // type, send", matching how chat apps usually order these.
            IconButton(
                onClick = {
                    // Wrapped in Intent.createChooser and launched via a raw
                    // StartActivityForResult contract instead of plain
                    // ActivityResultContracts.GetContent(). On some OEM ROMs
                    // (MIUI especially) GET_CONTENT with a wildcard mime
                    // resolves to zero activities if the device's default
                    // Files/Documents app isn't registered as a GET_CONTENT
                    // handler — GetContent() then just silently does nothing
                    // on tap (no crash, no picker). createChooser forces
                    // Android to show every matching app (or the picker) and
                    // ACTION_OPEN_DOCUMENT is honoured by more OEM file
                    // managers than GET_CONTENT is. If literally nothing on
                    // the device can handle it, the user now sees why
                    // instead of the button appearing dead.
                    val openDocIntent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                        putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("*/*"))
                    }
                    try {
                        filePickerLauncher.launch(Intent.createChooser(openDocIntent, "File chuno"))
                    } catch (e: ActivityNotFoundException) {
                        val getContentIntent = Intent(Intent.ACTION_GET_CONTENT).apply {
                            addCategory(Intent.CATEGORY_OPENABLE)
                            type = "*/*"
                        }
                        try {
                            filePickerLauncher.launch(Intent.createChooser(getContentIntent, "File chuno"))
                        } catch (e2: ActivityNotFoundException) {
                            updateMessages(messages + Message(
                                "Is phone par koi file picker app nahi mila (Files/Documents app disabled ho sakta hai). Settings > Apps mein check karo.",
                                isUser = false
                            ))
                        }
                    }
                },
                enabled = !isIndexingPdf && !isProcessingMedia
            ) {
                Icon(
                    painter = painterResource(id = R.drawable.ic_attach),
                    contentDescription = "File upload karo (PDF/image/video/audio/zip)",
                    tint = if (isIndexingPdf || isProcessingMedia) Color(0xFF666666) else Color(0xFFFF6B9D)
                )
            }

            // Voice Button
            IconButton(
                onClick = {
                    isListening = true
                    voiceErrorMessage = null
                    // Driven directly from this Activity's own context —
                    // no separate window is opened, so the rest of the
                    // screen (buttons, text field) stays touchable while
                    // listening. VoiceManager internally retries once via
                    // Google's recognizer explicitly if the device default
                    // rejects the request (common on some MIUI builds).
                    voiceManager.startListening(
                        onResult = { text ->
                            isListening = false
                            if (text.isNotBlank()) {
                                send(text)
                            } else {
                                // Recognizer returned success but with no
                                // usable text — surface this instead of
                                // silently doing nothing, since otherwise
                                // it looks identical to the mic not working.
                                voiceErrorMessage = "Kuch samajh nahi aaya, dobara bolo 🎙️"
                                scope.launch {
                                    kotlinx.coroutines.delay(2500)
                                    if (voiceErrorMessage != null) voiceErrorMessage = null
                                }
                            }
                        },
                        onError = { errorCode ->
                            isListening = false
                            val friendly = when (errorCode) {
                                android.speech.SpeechRecognizer.ERROR_NO_MATCH,
                                android.speech.SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                                    "Kuch samajh nahi aaya, dobara bolo"
                                android.speech.SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                                    "Mic permission chahiye"
                                android.speech.SpeechRecognizer.ERROR_NETWORK,
                                android.speech.SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                                    "Network problem, dobara try karo"
                                else -> "Mic error"
                            }
                            // Error code shown alongside the message so any
                            // future issue is diagnosable straight from a
                            // screenshot instead of guessing the cause again.
                            voiceErrorMessage = "$friendly (code $errorCode) 🎙️"
                            scope.launch {
                                kotlinx.coroutines.delay(4000)
                                if (voiceErrorMessage != null) voiceErrorMessage = null
                            }
                        }
                    )
                }
            ) {
                Icon(
                    painter = painterResource(id = R.drawable.ic_mic),
                    contentDescription = "Voice",
                    tint = if (isListening) Color.Red else Color(0xFFFF6B9D)
                )
            }

            // Text Input
            OutlinedTextField(
                value = inputText,
                onValueChange = { inputText = it },
                modifier = Modifier.weight(1f),
                placeholder = {
                    Text(if (mode == AppMode.DOCTOR) "Age/gender, symptoms, history..." else "Kuch bolo... 💬")
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                )
            )

            // Send Button
            IconButton(
                onClick = {
                    val text = inputText
                    inputText = ""
                    send(text)
                }
            ) {
                Icon(
                    painter = painterResource(id = R.drawable.ic_send),
                    contentDescription = "Send",
                    tint = Color(0xFFFF6B9D)
                )
            }
        }
    }

    // Patient List dialog — shows every saved patient (names decrypted only
    // for on-screen display, never re-encrypted-and-logged anywhere), lets
    // the doctor pick one to make active, or start a new patient.
    if (showPatientList) {
        var patients by remember { mutableStateOf(listOf<PatientListEntry>()) }
        var isLoadingPatients by remember { mutableStateOf(true) }
        var expandedPatientId by remember { mutableStateOf<Long?>(null) }
        var expandedPatientHistory by remember { mutableStateOf(listOf<CaseNote>()) }
        // Holds the patient pending delete confirmation — delete only
        // actually happens after the doctor confirms in a second dialog,
        // never on a single tap.
        var patientPendingDelete by remember { mutableStateOf<PatientListEntry?>(null) }

        LaunchedEffect(patientListRefreshTrigger) {
            isLoadingPatients = true
            patients = loadPatientList(context)
            isLoadingPatients = false
        }

        AlertDialog(
            onDismissRequest = { showPatientList = false },
            title = { Text("Patient List", color = Color.White) },
            containerColor = Color(0xFF1A1A2E),
            text = {
                Column(modifier = Modifier.heightIn(max = 420.dp)) {
                    if (isLoadingPatients) {
                        Text("Loading...", color = Color(0xFFAAAAAA), fontSize = 13.sp)
                    } else if (patients.isEmpty()) {
                        Text("Abhi koi patient nahi hai — neeche se naya banao.", color = Color(0xFFAAAAAA), fontSize = 13.sp)
                    } else {
                        LazyColumn(modifier = Modifier.heightIn(max = 320.dp)) {
                            items(patients, key = { it.id }) { patient ->
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable(
                                            indication = null,
                                            interactionSource = remember { MutableInteractionSource() },
                                            onClick = {
                                                currentPatient = ActivePatient(
                                                    id = patient.id,
                                                    displayName = patient.name,
                                                    age = patient.age,
                                                    gender = patient.gender,
                                                    currentDiagnosis = patient.currentDiagnosis,
                                                    currentSuggestion = patient.currentSuggestion,
                                                    currentMedicines = patient.currentMedicines,
                                                    knownAllergies = patient.knownAllergies
                                                )
                                                showPatientList = false
                                                // Switching patients ends any in-progress workup for
                                                // the previous patient — otherwise leftover findings
                                                // could get combined and saved under the wrong file.
                                                caseWorkupActive = false
                                                caseFindings = emptyList()
                                                confirmedDiagnosisContext = ""
                                                // "Open" this patient's file: load their saved case
                                                // history into the chat as faded, read-only bubbles,
                                                // so the doctor sees continuity instead of an empty
                                                // chat with just a name in the header bar.
                                                scope.launch {
                                                    val history = try {
                                                        KavitaDatabase.getInstance(context.applicationContext)
                                                            .caseNoteDao().getForPatient(patient.id)
                                                    } catch (e: Exception) {
                                                        emptyList()
                                                    }
                                                    val historyMessages = history.flatMap { note ->
                                                        listOf(
                                                            Message(note.symptoms, isUser = true, isHistorical = true),
                                                            Message(note.aiSuggestion, isUser = false, isHistorical = true)
                                                        )
                                                    }
                                                    val summaryLines = buildList {
                                                        if (patient.currentDiagnosis.isNotBlank()) add("🩺 Current diagnosis: ${patient.currentDiagnosis}")
                                                        if (patient.currentMedicines.isNotBlank()) add("💊 Current medicines/dose is saved in file — 'Edit File' se dekho ya update karo.")
                                                        if (patient.knownAllergies.isNotBlank()) add("⚠️ Known allergies: ${patient.knownAllergies}")
                                                    }
                                                    val openLine = if (history.isEmpty())
                                                        "📂 ${patient.name} ki file khul gayi — abhi koi purana case nahi hai. Naya case workup shuru karo."
                                                    else
                                                        "📂 ${patient.name} ki file khul gayi — ${history.size} purana case dikh raha hai upar."
                                                    doctorMessages = historyMessages + Message(
                                                        (listOf(openLine) + summaryLines).joinToString("\n"),
                                                        isUser = false
                                                    )
                                                }
                                            }
                                        )
                                        .padding(vertical = 8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(patient.name, color = Color.White, fontSize = 14.sp)
                                            Text(
                                                "${patient.age.ifBlank { "?" }} yrs, ${patient.gender.ifBlank { "?" }}",
                                                color = Color(0xFF888888),
                                                fontSize = 11.sp
                                            )
                                            if (patient.currentDiagnosis.isNotBlank()) {
                                                Text(
                                                    "🩺 ${patient.currentDiagnosis}",
                                                    color = Color(0xFFFFD166),
                                                    fontSize = 11.sp
                                                )
                                            }
                                        }
                                        TextButton(onClick = {
                                            scope.launch {
                                                if (expandedPatientId == patient.id) {
                                                    expandedPatientId = null
                                                } else {
                                                    expandedPatientId = patient.id
                                                    expandedPatientHistory = try {
                                                        KavitaDatabase.getInstance(context.applicationContext)
                                                            .caseNoteDao().getForPatient(patient.id)
                                                    } catch (e: Exception) {
                                                        emptyList()
                                                    }
                                                }
                                            }
                                        }) {
                                            Text(
                                                if (expandedPatientId == patient.id) "Hide history" else "History",
                                                color = Color(0xFFFF6B9D),
                                                fontSize = 11.sp
                                            )
                                        }
                                        TextButton(onClick = { patientPendingDelete = patient }) {
                                            Text("🗑️", fontSize = 14.sp)
                                        }
                                    }

                                    if (expandedPatientId == patient.id) {
                                        if (expandedPatientHistory.isEmpty()) {
                                            Text(
                                                "Is patient ke liye abhi koi saved case nahi hai.",
                                                color = Color(0xFF888888),
                                                fontSize = 11.sp,
                                                modifier = Modifier.padding(start = 8.dp, top = 4.dp)
                                            )
                                        } else {
                                            Column(modifier = Modifier.padding(start = 8.dp, top = 4.dp)) {
                                                expandedPatientHistory.forEach { note ->
                                                    Text(
                                                        "• ${note.caseLabel}",
                                                        color = Color(0xFFCCCCCC),
                                                        fontSize = 11.sp
                                                    )
                                                }
                                            }
                                        }
                                    }
                                    Divider(color = Color(0xFF333333), modifier = Modifier.padding(top = 8.dp))
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    showPatientList = false
                    showNewPatientDialog = true
                }) {
                    Text("+ New Patient", color = Color(0xFFFF6B9D))
                }
            },
            dismissButton = {
                TextButton(onClick = { showPatientList = false }) {
                    Text("Close", color = Color(0xFFAAAAAA))
                }
            }
        )

        // Delete confirmation — separate dialog so a single accidental tap
        // on 🗑️ can never delete a patient; the doctor must explicitly
        // confirm here. Deleting removes the patient AND their entire case
        // history (irreversible).
        patientPendingDelete?.let { toDelete ->
            AlertDialog(
                onDismissRequest = { patientPendingDelete = null },
                title = { Text("Patient delete karein?", color = Color.White) },
                containerColor = Color(0xFF1A1A2E),
                text = {
                    Text(
                        "${toDelete.name} (${toDelete.age.ifBlank { "?" }}, ${toDelete.gender.ifBlank { "?" }}) " +
                            "aur unka poora case history permanently delete ho jaayega. Ye undo nahi ho sakta.",
                        color = Color(0xFFCCCCCC),
                        fontSize = 13.sp
                    )
                },
                confirmButton = {
                    TextButton(onClick = {
                        val idToDelete = toDelete.id
                        val wasActivePatient = currentPatient?.id == idToDelete
                        deletePatient(context, scope, idToDelete) {
                            patients = patients.filterNot { it.id == idToDelete }
                            if (wasActivePatient) {
                                currentPatient = null
                                // Clear the doctor chat too — it was showing this
                                // patient's now-deleted file/history, so leaving
                                // it on screen would be stale, deleted data.
                                doctorMessages = listOf(
                                    Message("🗑️ ${toDelete.name}'s file deleted. Chat cleared.", isUser = false)
                                )
                            }
                            if (expandedPatientId == idToDelete) expandedPatientId = null
                            patientPendingDelete = null
                        }
                    }) {
                        Text("Delete", color = Color(0xFFFF6B6B))
                    }
                },
                dismissButton = {
                    TextButton(onClick = { patientPendingDelete = null }) {
                        Text("Cancel", color = Color(0xFFAAAAAA))
                    }
                }
            )
        }
    }

    // New Patient dialog — the ONLY place a name is ever typed/collected.
    // Encrypted via PatientCrypto before it's written to Room; never sent to
    // any network call from here.
    if (showNewPatientDialog) {
        var nameInput by remember { mutableStateOf("") }
        var ageInput by remember { mutableStateOf("") }
        var genderInput by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showNewPatientDialog = false },
            title = { Text("New Patient", color = Color.White) },
            containerColor = Color(0xFF1A1A2E),
            text = {
                Column {
                    OutlinedTextField(
                        value = nameInput,
                        onValueChange = { nameInput = it },
                        label = { Text("Naam") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = ageInput,
                        onValueChange = { ageInput = it },
                        label = { Text("Age") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = genderInput,
                        onValueChange = { genderInput = it },
                        label = { Text("Gender") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                    )
                    Text(
                        "Naam encrypted save hoga (Android Keystore), sirf is phone par — kahin bhi network par nahi jaata.",
                        color = Color(0xFF888888),
                        fontSize = 10.sp,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (nameInput.isNotBlank()) {
                            createPatient(context, scope, nameInput, ageInput, genderInput) { newId ->
                                currentPatient = ActivePatient(
                                    id = newId,
                                    displayName = nameInput.trim(),
                                    age = ageInput.trim(),
                                    gender = genderInput.trim()
                                )
                                showNewPatientDialog = false
                                caseWorkupActive = true
                                caseFindings = emptyList()
                                confirmedDiagnosisContext = ""
                                updateMessages(messages + Message(
                                    "Naya patient add kiya: ${nameInput.trim()}. Case Workup shuru ho gaya hai " +
                                        "iske liye — reports/notes bhejo.",
                                    isUser = false
                                ))
                            }
                        }
                    },
                    enabled = nameInput.isNotBlank()
                ) {
                    Text("Save", color = Color(0xFFFF6B9D))
                }
            },
            dismissButton = {
                TextButton(onClick = { showNewPatientDialog = false }) {
                    Text("Cancel", color = Color(0xFFAAAAAA))
                }
            }
        )
    }

    // Follow-up reminder dialog — quick-pick day chips (most common cases:
    // "3 din baad", "1 week baad") plus a free-text note. Fires an actual
    // OS notification at 10 AM on the chosen day via AlarmManager
    // (ReminderScheduler) — picking a fixed hour rather than asking the
    // doctor to also pick a time keeps this to one tap for the common
    // case, since "which day" matters far more than "which hour" for a
    // patient check-in reminder.
    if (showFollowUpDialog && currentPatient != null) {
        var reminderNote by remember { mutableStateOf("") }
        var selectedDaysAhead by remember { mutableStateOf(3) }
        val patient = currentPatient!!

        AlertDialog(
            onDismissRequest = { showFollowUpDialog = false },
            title = { Text("Follow-up Reminder", color = Color.White) },
            containerColor = Color(0xFF1A1A2E),
            text = {
                Column {
                    Text(
                        "Patient: ${patient.displayName}",
                        color = Color(0xFFAAAAAA),
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("Kab yaad dilau?", color = Color.White, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(1 to "1 din", 3 to "3 din", 7 to "1 week").forEach { (days, label) ->
                            val isSelected = selectedDaysAhead == days
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (isSelected) Color(0xFF6BCB77) else Color(0xFF0F1729))
                                    .clickable(
                                        indication = null,
                                        interactionSource = remember { MutableInteractionSource() },
                                        onClick = { selectedDaysAhead = days }
                                    )
                                    .padding(horizontal = 12.dp, vertical = 8.dp)
                            ) {
                                Text(
                                    text = label,
                                    color = if (isSelected) Color.Black else Color(0xFFAAAAAA),
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = reminderNote,
                        onValueChange = { reminderNote = it },
                        label = { Text("Note (optional)") },
                        placeholder = { Text("e.g. BP dobara check karo") },
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                    )
                    Text(
                        "Reminder subah 10 baje notification ke through aayega, is din.",
                        color = Color(0xFF888888),
                        fontSize = 10.sp,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val calendar = java.util.Calendar.getInstance().apply {
                        add(java.util.Calendar.DAY_OF_YEAR, selectedDaysAhead)
                        set(java.util.Calendar.HOUR_OF_DAY, 10)
                        set(java.util.Calendar.MINUTE, 0)
                        set(java.util.Calendar.SECOND, 0)
                        set(java.util.Calendar.MILLISECOND, 0)
                    }
                    createFollowUpReminder(
                        context = context,
                        scope = scope,
                        patientId = patient.id,
                        patientDisplayName = patient.displayName,
                        note = reminderNote,
                        triggerAtMillis = calendar.timeInMillis
                    ) {
                        showFollowUpDialog = false
                        updateMessages(messages + Message(
                            "⏰ Follow-up reminder set ho gaya — ${patient.displayName} ke liye, " +
                                "$selectedDaysAhead din baad subah 10 baje.",
                            isUser = false
                        ))
                    }
                }) {
                    Text("Set Reminder", color = Color(0xFF6BCB77))
                }
            },
            dismissButton = {
                TextButton(onClick = { showFollowUpDialog = false }) {
                    Text("Cancel", color = Color(0xFFAAAAAA))
                }
            }
        )
    }

    // Upcoming Follow-ups viewer — lists every not-yet-fired, not-cancelled
    // reminder across ALL patients (not just the currently active one),
    // soonest first, with an inline cancel action per row. Loaded fresh
    // every time the dialog opens via followUpListRefreshTrigger, same
    // reload-on-open pattern already used by the Patient List dialog
    // elsewhere in this screen.
    if (showUpcomingFollowUps) {
        var upcomingReminders by remember { mutableStateOf<List<FollowUpReminder>?>(null) }
        var followUpListRefreshTrigger by remember { mutableStateOf(0) }

        LaunchedEffect(followUpListRefreshTrigger) {
            upcomingReminders = try {
                KavitaDatabase.getInstance(context.applicationContext).followUpReminderDao().getUpcoming()
            } catch (e: Exception) {
                emptyList()
            }
        }

        val dateFormat = remember { java.text.SimpleDateFormat("dd MMM, hh:mm a", java.util.Locale.ENGLISH) }

        AlertDialog(
            onDismissRequest = { showUpcomingFollowUps = false },
            title = { Text("Upcoming Follow-ups", color = Color.White) },
            containerColor = Color(0xFF1A1A2E),
            text = {
                val reminders = upcomingReminders
                when {
                    reminders == null -> Text("Loading...", color = Color(0xFF888888), fontSize = 13.sp)
                    reminders.isEmpty() -> Text(
                        "Koi upcoming follow-up nahi hai abhi. Patient ke \"⏰ Follow-up set karo\" se naya set karo.",
                        color = Color(0xFF888888),
                        fontSize = 13.sp
                    )
                    else -> Column(
                        modifier = Modifier.heightIn(max = 400.dp)
                    ) {
                        // AlertDialog's text slot doesn't scroll on its own
                        // once content is tall — a real LazyColumn here
                        // keeps a long reminder list usable instead of
                        // clipping past the dialog's bottom edge.
                        LazyColumn {
                            items(reminders, key = { it.id }) { reminder ->
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 6.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = if (reminder.patientDisplayName.isNotBlank())
                                                    "🧑‍⚕️ ${reminder.patientDisplayName}"
                                                else "📌 General reminder",
                                                color = Color.White,
                                                fontSize = 13.sp
                                            )
                                            Text(
                                                text = dateFormat.format(java.util.Date(reminder.triggerAtMillis)),
                                                color = Color(0xFF6BCB77),
                                                fontSize = 11.sp
                                            )
                                            if (reminder.note.isNotBlank()) {
                                                Text(
                                                    text = reminder.note,
                                                    color = Color(0xFFAAAAAA),
                                                    fontSize = 11.sp
                                                )
                                            }
                                        }
                                        Text(
                                            text = "✕",
                                            color = Color(0xFFFF6B6B),
                                            fontSize = 14.sp,
                                            modifier = Modifier
                                                .padding(start = 8.dp)
                                                .clickable(
                                                    indication = null,
                                                    interactionSource = remember { MutableInteractionSource() },
                                                    onClick = {
                                                        cancelFollowUpReminder(context, scope, reminder) {
                                                            followUpListRefreshTrigger++
                                                        }
                                                    }
                                                )
                                        )
                                    }
                                    HorizontalDivider(color = Color(0xFF2A2A3E), modifier = Modifier.padding(top = 6.dp))
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showUpcomingFollowUps = false }) {
                    Text("Band karo", color = Color(0xFF4A90E2))
                }
            }
        )
    }

    // Medicine Check dialog — one input box, comma-separated medicine
    // names. A single name does a full clinical reference lookup; two or
    // more names runs a cross-drug interaction check instead. Both paths
    // pull real FDA label data via DrugInfoService first, then Gemini
    // synthesizes it — same "real data grounds the AI" pattern as RAG
    // over uploaded PDFs elsewhere in this app.
    if (showMedicineCheckDialog) {
        var medicineInput by remember { mutableStateOf("") }
        var isChecking by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { if (!isChecking) showMedicineCheckDialog = false },
            title = { Text("💊 Medicine Check", color = Color.White) },
            containerColor = Color(0xFF1A1A2E),
            text = {
                Column {
                    Text(
                        "Ek medicine ka naam do (full info ke liye) ya 2+ names " +
                            "comma se separate karke do (interaction check ke liye).",
                        color = Color(0xFFAAAAAA),
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = medicineInput,
                        onValueChange = { medicineInput = it },
                        label = { Text("Medicine name(s)") },
                        placeholder = { Text("e.g. Paracetamol, Ibuprofen") },
                        enabled = !isChecking,
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(
                        "Note: FDA (US) database use hoti hai — Indian brand names " +
                            "(jaise Crocin) ke bajaye generic naam (Paracetamol) se " +
                            "search zyada reliable rahega.",
                        color = Color(0xFF888888),
                        fontSize = 10.sp,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                    if (isChecking) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("Check kar rahi hoon...", color = Color(0xFF6BCB77), fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                TextButton(
                    enabled = !isChecking && medicineInput.isNotBlank(),
                    onClick = {
                        val names = medicineInput.split(",").map { it.trim() }.filter { it.isNotBlank() }
                        if (names.isEmpty()) return@TextButton
                        isChecking = true
                        scope.launch {
                            val result = try {
                                if (names.size == 1) {
                                    aiRepository.getMedicineInfo(names.first())
                                } else {
                                    aiRepository.getDrugInteractionAnalysis(names)
                                }
                            } catch (e: Exception) {
                                "Medicine check karne mein dikkat aa gayi, dobara try karo."
                            }
                            isChecking = false
                            showMedicineCheckDialog = false
                            medicineInput = ""
                            val questionLabel = if (names.size == 1) {
                                "💊 Medicine info: ${names.first()}"
                            } else {
                                "💊 Interaction check: ${names.joinToString(", ")}"
                            }
                            updateMessages(messages + Message(questionLabel, isUser = true) + Message(result, isUser = false))
                            if (currentPatient != null) {
                                saveCaseNote(context, scope, questionLabel, result, currentPatient?.id)
                            }
                        }
                    }
                ) {
                    Text("Check karo", color = Color(0xFF6BCB77))
                }
            },
            dismissButton = {
                TextButton(
                    enabled = !isChecking,
                    onClick = { showMedicineCheckDialog = false; medicineInput = "" }
                ) {
                    Text("Cancel", color = Color(0xFFAAAAAA))
                }
            }
        )
    }

    // Voice-to-SOAP Note dialog — doctor either types or dictates (mic
    // button inside the dialog, reusing the same voiceManager.startListening
    // already used for the main chat mic) their encounter notes in
    // whatever order they naturally speak them, and Gemini organizes it
    // into a standard Subjective/Objective/Assessment/Plan note. Multiple
    // mic taps append to the text field rather than replacing it, so the
    // doctor can dictate in several short bursts (e.g. pause to think,
    // then continue) instead of one unbroken take.
    if (showSoapNoteDialog) {
        var soapInput by remember { mutableStateOf("") }
        var isGeneratingSoap by remember { mutableStateOf(false) }
        var isListeningForSoap by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { if (!isGeneratingSoap && !isListeningForSoap) showSoapNoteDialog = false },
            title = { Text("📝 Voice-to-SOAP Note", color = Color.White) },
            containerColor = Color(0xFF1A1A2E),
            text = {
                Column {
                    Text(
                        "Encounter ke baare mein bolo ya likho (jis order mein " +
                            "yaad aaye, kuch structure follow karna zaroori nahi) " +
                            "— main isse Subjective/Objective/Assessment/Plan mein " +
                            "organize kar dungi.",
                        color = Color(0xFFAAAAAA),
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = soapInput,
                        onValueChange = { soapInput = it },
                        label = { Text("Encounter notes") },
                        placeholder = { Text("e.g. patient 3 din se fever, BP 120/80, malaria rule out karne ko bola, paracetamol start kiya...") },
                        enabled = !isGeneratingSoap,
                        minLines = 4,
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    TextButton(
                        enabled = !isGeneratingSoap,
                        onClick = {
                            isListeningForSoap = true
                            voiceManager.startListening(
                                onResult = { text ->
                                    isListeningForSoap = false
                                    if (text.isNotBlank()) {
                                        soapInput = if (soapInput.isBlank()) text else "$soapInput $text"
                                    }
                                },
                                onError = { isListeningForSoap = false }
                            )
                        }
                    ) {
                        Text(
                            if (isListeningForSoap) "🎙️ Sunn rahi hoon..." else "🎙️ Bolke add karo",
                            color = if (isListeningForSoap) Color(0xFFFF6B9D) else Color(0xFF4A90E2)
                        )
                    }
                    if (isGeneratingSoap) {
                        Text("SOAP note bana rahi hoon...", color = Color(0xFF6BCB77), fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                TextButton(
                    enabled = !isGeneratingSoap && !isListeningForSoap && soapInput.isNotBlank(),
                    onClick = {
                        isGeneratingSoap = true
                        scope.launch {
                            val result = try {
                                aiRepository.getSoapNote(soapInput)
                            } catch (e: Exception) {
                                "SOAP note banane mein dikkat aa gayi, dobara try karo."
                            }
                            isGeneratingSoap = false
                            showSoapNoteDialog = false
                            val notesUsed = soapInput
                            soapInput = ""
                            updateMessages(
                                messages + Message("📝 SOAP Note", isUser = true) +
                                    Message(result, isUser = false)
                            )
                            if (currentPatient != null) {
                                saveCaseNote(context, scope, "📝 SOAP Note: $notesUsed", result, currentPatient?.id)
                            }
                        }
                    }
                ) {
                    Text("Banao", color = Color(0xFF6BCB77))
                }
            },
            dismissButton = {
                TextButton(
                    enabled = !isGeneratingSoap,
                    onClick = { showSoapNoteDialog = false; soapInput = "" }
                ) {
                    Text("Cancel", color = Color(0xFFAAAAAA))
                }
            }
        )
    }

    // Lab Trends dialog — lets the doctor log a lab/vitals reading (BP,
    // blood sugar, Hb, whatever) for the active patient, then see it
    // charted over time to answer "improve ho raha hai ya nahi" at a
    // glance instead of scrolling back through old case notes to compare
    // numbers mentally. Two states within the same dialog: metric list
    // (default) and a selected metric's chart+history (drill-in) — kept as
    // one dialog rather than a separate screen since it's a quick, focused
    // in-and-out action during a consult.
    if (showLabTrendsDialog && currentPatient != null) {
        val patientId = currentPatient!!.id
        var readings by remember { mutableStateOf(listOf<LabValue>()) }
        var metricNames by remember { mutableStateOf(listOf<String>()) }
        var isLoadingLabData by remember { mutableStateOf(true) }
        var selectedMetric by remember { mutableStateOf<String?>(null) }
        var labRefreshTrigger by remember { mutableStateOf(0) }

        var newMetricName by remember { mutableStateOf("") }
        var newValue by remember { mutableStateOf("") }
        var newUnit by remember { mutableStateOf("") }
        var isSavingReading by remember { mutableStateOf(false) }
        val labDateFormat = remember { SimpleDateFormat("dd MMM, hh:mm a", Locale.ENGLISH) }

        LaunchedEffect(labRefreshTrigger) {
            isLoadingLabData = true
            val dao = KavitaDatabase.getInstance(context.applicationContext).labValueDao()
            readings = withContext(kotlinx.coroutines.Dispatchers.IO) { dao.getAllForPatient(patientId) }
            metricNames = withContext(kotlinx.coroutines.Dispatchers.IO) { dao.getDistinctMetricNames(patientId) }
            isLoadingLabData = false
        }

        AlertDialog(
            onDismissRequest = { showLabTrendsDialog = false; selectedMetric = null },
            title = {
                Text(
                    if (selectedMetric == null) "📈 Lab Trends — ${currentPatient?.displayName}"
                    else "📈 ${selectedMetric}",
                    color = Color.White,
                    fontSize = 16.sp
                )
            },
            containerColor = Color(0xFF1A1A2E),
            text = {
                Column(modifier = Modifier.heightIn(max = 460.dp)) {
                    if (isLoadingLabData) {
                        Text("Loading...", color = Color(0xFFAAAAAA), fontSize = 13.sp)
                    } else if (selectedMetric != null) {
                        val series = readings
                            .filter { it.metricName == selectedMetric }
                            .sortedBy { it.recordedAt }

                        TextButton(onClick = { selectedMetric = null }) {
                            Text("← Sab metrics", color = Color(0xFF4A90E2), fontSize = 12.sp)
                        }

                        if (series.size < 2) {
                            Text(
                                "Trend dikhane ke liye kam se kam 2 readings chahiye — " +
                                    "abhi sirf ${series.size} hai.",
                                color = Color(0xFFAAAAAA),
                                fontSize = 12.sp,
                                modifier = Modifier.padding(vertical = 8.dp)
                            )
                        } else {
                            LabTrendChart(
                                series = series,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(160.dp)
                                    .padding(vertical = 8.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        LazyColumn(modifier = Modifier.heightIn(max = 220.dp)) {
                            items(series.reversed(), key = { it.id }) { reading ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        labDateFormat.format(java.util.Date(reading.recordedAt)),
                                        color = Color(0xFFAAAAAA),
                                        fontSize = 11.sp
                                    )
                                    Text(
                                        "${reading.value} ${reading.unit}".trim(),
                                        color = Color.White,
                                        fontSize = 13.sp
                                    )
                                }
                            }
                        }
                    } else {
                        // Add-reading form — always visible at the top of
                        // the metric-list screen so a new reading can be
                        // logged in one step without drilling anywhere.
                        OutlinedTextField(
                            value = newMetricName,
                            onValueChange = { newMetricName = it },
                            label = { Text("Metric") },
                            placeholder = { Text("e.g. BP Systolic, Blood Sugar") },
                            enabled = !isSavingReading,
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                            modifier = Modifier.fillMaxWidth()
                        )
                        if (metricNames.isNotEmpty()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState())
                                    .padding(top = 4.dp)
                            ) {
                                metricNames.forEach { name ->
                                    TextButton(onClick = { newMetricName = name }) {
                                        Text(name, color = Color(0xFF4A90E2), fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                        Row(modifier = Modifier.padding(top = 6.dp)) {
                            OutlinedTextField(
                                value = newValue,
                                onValueChange = { newValue = it },
                                label = { Text("Value") },
                                enabled = !isSavingReading,
                                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                                    keyboardType = androidx.compose.ui.text.input.KeyboardType.Number
                                ),
                                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            OutlinedTextField(
                                value = newUnit,
                                onValueChange = { newUnit = it },
                                label = { Text("Unit") },
                                placeholder = { Text("mg/dL") },
                                enabled = !isSavingReading,
                                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White),
                                modifier = Modifier.weight(1f)
                            )
                        }
                        TextButton(
                            enabled = !isSavingReading && newMetricName.isNotBlank() &&
                                newValue.trim().toDoubleOrNull() != null,
                            onClick = {
                                val parsedValue = newValue.trim().toDoubleOrNull() ?: return@TextButton
                                isSavingReading = true
                                scope.launch {
                                    val dao = KavitaDatabase.getInstance(context.applicationContext).labValueDao()
                                    withContext(kotlinx.coroutines.Dispatchers.IO) {
                                        dao.insert(
                                            LabValue(
                                                patientId = patientId,
                                                metricName = newMetricName.trim(),
                                                value = parsedValue,
                                                unit = newUnit.trim()
                                            )
                                        )
                                    }
                                    newMetricName = ""
                                    newValue = ""
                                    newUnit = ""
                                    isSavingReading = false
                                    labRefreshTrigger++
                                }
                            },
                            modifier = Modifier.padding(top = 4.dp)
                        ) {
                            Text(
                                if (isSavingReading) "Save ho raha hai..." else "+ Reading add karo",
                                color = Color(0xFF6BCB77)
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider(color = Color(0xFF333333))
                        Spacer(modifier = Modifier.height(6.dp))

                        if (metricNames.isEmpty()) {
                            Text(
                                "Abhi is patient ke liye koi reading nahi hai — upar se ek add karo.",
                                color = Color(0xFFAAAAAA),
                                fontSize = 12.sp
                            )
                        } else {
                            LazyColumn(modifier = Modifier.heightIn(max = 200.dp)) {
                                items(metricNames, key = { it }) { name ->
                                    val count = readings.count { it.metricName == name }
                                    TextButton(
                                        onClick = { selectedMetric = name },
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(name, color = Color.White, fontSize = 13.sp)
                                            Text(
                                                "$count reading${if (count == 1) "" else "s"} →",
                                                color = Color(0xFFAAAAAA),
                                                fontSize = 11.sp
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showLabTrendsDialog = false; selectedMetric = null }) {
                    Text("Band karo", color = Color(0xFFAAAAAA))
                }
            }
        )
    }

    // Manual edit — lets the doctor directly set/override the patient
    // file's diagnosis, suggestion, and current medicines/dose, as an
    // alternative to (or correction of) whatever got auto-filled by case
    // combine / diagnosis confirm / treatment reference. Writes through the
    // exact same updatePatientClinicalSummary() function as the automatic
    // path, so there's one source of truth for how this data gets saved.
    if (showEditPatientFileDialog && currentPatient != null) {
        val patient = currentPatient!!
        var diagnosisInput by remember(patient.id) { mutableStateOf(patient.currentDiagnosis) }
        var suggestionInput by remember(patient.id) { mutableStateOf(patient.currentSuggestion) }
        var medicinesInput by remember(patient.id) { mutableStateOf(patient.currentMedicines) }
        var allergiesInput by remember(patient.id) { mutableStateOf(patient.knownAllergies) }

        AlertDialog(
            onDismissRequest = { showEditPatientFileDialog = false },
            title = { Text("${patient.displayName}'s File — Manual Edit", color = Color.White, fontSize = 16.sp) },
            containerColor = Color(0xFF1A1A2E),
            text = {
                Column(modifier = Modifier.heightIn(max = 460.dp)) {
                    OutlinedTextField(
                        value = diagnosisInput,
                        onValueChange = { diagnosisInput = it },
                        label = { Text("Diagnosis") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = suggestionInput,
                        onValueChange = { suggestionInput = it },
                        label = { Text("AI Suggestion / Differential") },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 80.dp),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = medicinesInput,
                        onValueChange = { medicinesInput = it },
                        label = { Text("Current Medicines & Dose") },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 80.dp),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = allergiesInput,
                        onValueChange = { allergiesInput = it },
                        label = { Text("Known Allergies") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    // Checks whatever's currently SAVED on file
                    // (patient.currentMedicines) against whatever's
                    // currently TYPED in the medicines box — so the doctor
                    // can type a new addition, check it before saving, then
                    // decide whether to actually save it.
                    TextButton(
                        onClick = {
                            if (medicinesInput.isBlank()) return@TextButton
                            isCheckingInteractions = true
                            interactionCheckResult = null
                            scope.launch {
                                val relevantChunks = try {
                                    // Search both the existing medicines
                                    // AND the newly typed one separately —
                                    // an interaction/contraindication note
                                    // in the book might be indexed under
                                    // either drug's name.
                                    val queries = listOfNotNull(
                                        medicinesInput.take(300),
                                        patient.currentMedicines.takeIf { it.isNotBlank() }?.take(300)
                                    )
                                    ragEngine.findRelevantChunksMulti(queries, maxChunks = 6)
                                } catch (e: Exception) {
                                    emptyList()
                                }
                                interactionCheckResult = try {
                                    if (patient.currentMedicines.isBlank()) {
                                        "Patient ke file mein abhi koi existing medicine nahi hai " +
                                            "cross-check karne ke liye — ye pehla medicine hoga."
                                    } else {
                                        aiRepository.checkDrugInteractions(
                                            existingMedicines = patient.currentMedicines,
                                            newMedicines = medicinesInput,
                                            knownAllergies = allergiesInput,
                                            relevantChunks = relevantChunks
                                        )
                                    }
                                } catch (e: Exception) {
                                    "Sorry, interaction check karte waqt dikkat aa gayi. Dobara try karo."
                                }
                                isCheckingInteractions = false
                            }
                        },
                        enabled = !isCheckingInteractions
                    ) {
                        Text(
                            if (isCheckingInteractions) "Checking..." else "🔎 Check Interactions",
                            color = Color(0xFFFFD166),
                            fontSize = 13.sp
                        )
                    }
                    Text(
                        "Ye teeno fields automatic bhi update hoti hain (case combine / diagnosis confirm / " +
                            "treatment reference ke baad) — yahan se manually bhi edit ya override kar sakte ho.",
                        color = Color(0xFF888888),
                        fontSize = 10.sp,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    updatePatientClinicalSummary(
                        patient.id,
                        diagnosis = diagnosisInput.trim(),
                        suggestion = suggestionInput.trim(),
                        medicines = medicinesInput.trim(),
                        allergies = allergiesInput.trim()
                    )
                    showEditPatientFileDialog = false
                    updateMessages(messages + Message(
                        "💾 ${patient.displayName}'s file manually update ki gayi.",
                        isUser = false
                    ))
                }) {
                    Text("Save", color = Color(0xFFFF6B9D))
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditPatientFileDialog = false }) {
                    Text("Cancel", color = Color(0xFFAAAAAA))
                }
            }
        )
    }

    // Interaction check result — separate small dialog so it doesn't get
    // buried inside the (already long) edit file dialog, and stays visible
    // even after the doctor dismisses the edit dialog.
    interactionCheckResult?.let { checkResult ->
        AlertDialog(
            onDismissRequest = { interactionCheckResult = null },
            title = { Text("💊 Interaction Check", color = Color.White, fontSize = 16.sp) },
            containerColor = Color(0xFF1A1A2E),
            text = {
                Column(modifier = Modifier.heightIn(max = 420.dp)) {
                    Text(checkResult, color = Color(0xFFCCCCCC), fontSize = 13.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = { interactionCheckResult = null }) {
                    Text("Close", color = Color(0xFFFF6B9D))
                }
            }
        )
    }

    // "Learn from URL" — the doctor pastes exactly one page's URL (a
    // guideline, circular, reference article) and the app fetches just
    // that page and saves its text locally. This is a manual, one-page-
    // at-a-time action every time — there is no "scan the whole site" or
    // "keep fetching more on its own" behavior here by design.
    if (showLearnUrlDialog) {
        var urlInput by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { if (!isLearningUrl) showLearnUrlDialog = false },
            title = { Text("🌐 Learn From URL", color = Color.White, fontSize = 16.sp) },
            containerColor = Color(0xFF1A1A2E),
            text = {
                Column {
                    Text(
                        "Ek specific page ka URL do (jaise WHO guideline, MoHFW circular) — " +
                            "us page ka text phone mein save ho jaayega, phir internet ke bina bhi " +
                            "usse related sawaalon ka jawab mil sakega.",
                        color = Color(0xFF888888),
                        fontSize = 12.sp,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    OutlinedTextField(
                        value = urlInput,
                        onValueChange = { urlInput = it },
                        label = { Text("https://...") },
                        singleLine = true,
                        enabled = !isLearningUrl,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                    )
                    if (isLearningUrl) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Page fetch kar rahi hoon...", color = Color(0xFF4A90E2), fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                TextButton(
                    enabled = !isLearningUrl && urlInput.isNotBlank(),
                    onClick = {
                        val urlToLearn = urlInput.trim()
                        isLearningUrl = true
                        scope.launch {
                            val result = try {
                                aiRepository.learnFromUrl(urlToLearn)
                            } catch (e: Exception) {
                                AIRepository.UrlLearnResult.Failure("Kuch galat ho gaya — dobara try karo.")
                            }
                            isLearningUrl = false
                            showLearnUrlDialog = false
                            val statusText = when (result) {
                                is AIRepository.UrlLearnResult.Success ->
                                    "🌐 \"${result.title}\" save ho gaya (${result.charsSaved} characters) — " +
                                        "ab isse related sawaal offline mein bhi pucho sakte ho."
                                is AIRepository.UrlLearnResult.Failure ->
                                    "🌐 ${result.reason}"
                            }
                            updateMessages(messages + Message(statusText, isUser = false))
                        }
                    }
                ) {
                    Text("Fetch & Save", color = Color(0xFF4A90E2))
                }
            },
            dismissButton = {
                TextButton(enabled = !isLearningUrl, onClick = { showLearnUrlDialog = false }) {
                    Text("Cancel", color = Color(0xFFAAAAAA))
                }
            }
        )
    }

    // Voice Gender Picker — lets the user switch Kavita's spoken voice
    // between a male and female Hindi TTS voice. The actual device-level
    // voice matching (by name pattern) happens inside VoiceManager; this
    // dialog just presents the two choices and shows which installed
    // voices were found for each, so it's clear if a gender has no voice
    // on this particular device.
    if (showVoiceGenderDialog) {
        val availableVoices = remember { voiceManager.listAvailableHindiVoices() }
        val femaleCount = availableVoices.count { it.gender == VoiceManager.VoiceGender.FEMALE }
        val maleCount = availableVoices.count { it.gender == VoiceManager.VoiceGender.MALE }

        AlertDialog(
            onDismissRequest = { showVoiceGenderDialog = false },
            title = { Text("Kavita ki Awaaz", color = Color.White) },
            containerColor = Color(0xFF1A1A2E),
            text = {
                Column {
                    Text(
                        "Bolne ke liye voice choose karo:",
                        color = Color(0xFFAAAAAA),
                        fontSize = 13.sp,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    listOf(
                        Triple(VoiceManager.VoiceGender.FEMALE, "👩 Female Voice", femaleCount),
                        Triple(VoiceManager.VoiceGender.MALE, "👨 Male Voice", maleCount)
                    ).forEach { (gender, label, count) ->
                        val isSelected = currentVoiceGender == gender
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) Color(0xFF4A90E2).copy(alpha = 0.25f) else Color.Transparent)
                                .clickable(
                                    indication = null,
                                    interactionSource = remember { MutableInteractionSource() },
                                    onClick = {
                                        currentVoiceGender = gender
                                        voiceManager.setVoiceGender(gender)
                                        voiceManager.speak(
                                            if (gender == VoiceManager.VoiceGender.FEMALE)
                                                "Namaste, ab main is awaaz mein bolungi"
                                            else
                                                "Namaste, ab main is awaaz mein bolunga"
                                        )
                                    }
                                )
                                .padding(vertical = 10.dp, horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(label, color = Color.White, fontSize = 15.sp, modifier = Modifier.weight(1f))
                            if (count == 0) {
                                Text("Is device pe nahi mila", color = Color(0xFF888888), fontSize = 11.sp)
                            } else if (isSelected) {
                                Text("✓", color = Color(0xFF4A90E2), fontSize = 16.sp)
                            }
                        }
                    }

                    Text(
                        "Agar phone mein us gender ki voice install nahi hai, toh jo best available hai wahi use hogi.",
                        color = Color(0xFF666666),
                        fontSize = 11.sp,
                        modifier = Modifier.padding(top = 10.dp)
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showVoiceGenderDialog = false }) {
                    Text("Done", color = Color(0xFF4A90E2))
                }
            }
        )
    }
}

@Composable
private fun ModeChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (selected) Color(0xFFFF6B9D) else Color.Transparent)
            .clickable(
                indication = null,
                interactionSource = remember { MutableInteractionSource() },
                onClick = onClick
            )
            .padding(horizontal = 14.dp, vertical = 6.dp)
    ) {
        Text(
            text = label,
            color = if (selected) Color.White else Color(0xFFAAAAAA),
            fontSize = 13.sp
        )
    }
}

/**
 * Persists a Doctor Mode exchange locally (Room, on-device only). No name or
 * patient identifier is collected — [caseDescription] is whatever free text
 * the doctor typed, which by app convention should already exclude names.
 */
private fun saveCaseNote(
    context: Context,
    scope: kotlinx.coroutines.CoroutineScope,
    caseDescription: String,
    aiSuggestion: String,
    patientId: Long? = null
) {
    val dao = KavitaDatabase.getInstance(context.applicationContext).caseNoteDao()
    scope.launch(kotlinx.coroutines.Dispatchers.IO) {
        try {
            dao.insert(
                CaseNote(
                    caseLabel = "Case ${System.currentTimeMillis()}",
                    ageGender = "",
                    symptoms = caseDescription,
                    history = "",
                    aiSuggestion = aiSuggestion,
                    patientId = patientId
                )
            )
            // Bump the patient's lastUpdatedAt so the patient list can sort
            // by most-recently-active case.
            if (patientId != null) {
                val patientDao = KavitaDatabase.getInstance(context.applicationContext).patientCaseDao()
                patientDao.getById(patientId)?.let { patient ->
                    patientDao.update(patient.copy(lastUpdatedAt = System.currentTimeMillis()))
                }
            }
        } catch (e: Exception) {
            // Local save failing shouldn't disrupt the chat — the answer is
            // already shown on screen either way.
        }
    }
}

/**
 * Saves a new follow-up reminder to Room AND schedules its AlarmManager
 * alarm in the same step — the two always need to happen together (a row
 * with no alarm never fires; an alarm with no row can't be shown in the
 * "Upcoming Follow-ups" list or cancelled later), so this is the single
 * entry point for creating one rather than leaving callers to remember
 * both steps themselves.
 */
private fun createFollowUpReminder(
    context: Context,
    scope: kotlinx.coroutines.CoroutineScope,
    patientId: Long?,
    patientDisplayName: String,
    note: String,
    triggerAtMillis: Long,
    onCreated: () -> Unit
) {
    val dao = KavitaDatabase.getInstance(context.applicationContext).followUpReminderDao()
    scope.launch(kotlinx.coroutines.Dispatchers.IO) {
        try {
            val reminder = FollowUpReminder(
                patientId = patientId,
                patientDisplayName = patientDisplayName,
                note = note.trim(),
                triggerAtMillis = triggerAtMillis
            )
            val id = dao.insert(reminder)
            ReminderScheduler.schedule(context.applicationContext, reminder.copy(id = id))
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                onCreated()
            }
        } catch (e: Exception) {
            // If this fails, onCreated never fires — the dialog just stays
            // open so the doctor can retry rather than silently losing the
            // reminder with no feedback.
        }
    }
}

/** Cancels a follow-up reminder's alarm and marks it cancelled in Room. */
private fun cancelFollowUpReminder(
    context: Context,
    scope: kotlinx.coroutines.CoroutineScope,
    reminder: FollowUpReminder,
    onCancelled: () -> Unit
) {
    val dao = KavitaDatabase.getInstance(context.applicationContext).followUpReminderDao()
    scope.launch(kotlinx.coroutines.Dispatchers.IO) {
        try {
            ReminderScheduler.cancel(context.applicationContext, reminder)
            dao.markCancelled(reminder.id)
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                onCancelled()
            }
        } catch (e: Exception) {
            // Leave it in the list rather than silently disappearing —
            // doctor can retry the cancel.
        }
    }
}

/**
 * Creates a new patient record — [name] is encrypted via [PatientCrypto]
 * before it ever touches the database. [onCreated] receives the new
 * patient's id along with the plain (decrypted-equivalent, since it's the
 * same string just typed) name/age/gender for immediate in-session use, so
 * the doctor doesn't have to re-fetch and decrypt right after creating it.
 */
private fun createPatient(
    context: Context,
    scope: kotlinx.coroutines.CoroutineScope,
    name: String,
    age: String,
    gender: String,
    onCreated: (Long) -> Unit
) {
    val dao = KavitaDatabase.getInstance(context.applicationContext).patientCaseDao()
    scope.launch(kotlinx.coroutines.Dispatchers.IO) {
        try {
            val id = dao.insert(
                PatientCase(
                    encryptedName = PatientCrypto.encrypt(name.trim()),
                    age = age.trim(),
                    gender = gender.trim()
                )
            )
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                onCreated(id)
            }
        } catch (e: Exception) {
            // If patient creation fails, onCreated simply never fires —
            // caller stays on the "new patient" dialog to retry.
        }
    }
}

/**
 * Deletes a patient AND every case note linked to them (their full history) —
 * this is a doctor-initiated, explicit, irreversible action; the caller
 * (UI) is responsible for confirming with the doctor before calling this.
 */
private fun deletePatient(
    context: Context,
    scope: kotlinx.coroutines.CoroutineScope,
    patientId: Long,
    onDeleted: () -> Unit
) {
    val db = KavitaDatabase.getInstance(context.applicationContext)
    scope.launch(kotlinx.coroutines.Dispatchers.IO) {
        try {
            db.caseNoteDao().deleteForPatient(patientId)
            db.patientCaseDao().getById(patientId)?.let { db.patientCaseDao().delete(it) }
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                onDeleted()
            }
        } catch (e: Exception) {
            // If deletion fails, onDeleted never fires — the entry simply
            // stays in the list and the doctor can retry.
        }
    }
}

/** Decrypted patient list entry, ready for display — never holds ciphertext. */
data class PatientListEntry(
    val id: Long,
    val name: String,
    val age: String,
    val gender: String,
    val lastUpdatedAt: Long,
    val currentDiagnosis: String = "",
    val currentSuggestion: String = "",
    val currentMedicines: String = "",
    val knownAllergies: String = ""
)

private suspend fun loadPatientList(context: Context): List<PatientListEntry> {
    val dao = KavitaDatabase.getInstance(context.applicationContext).patientCaseDao()
    return try {
        dao.getAll().map { p ->
            PatientListEntry(
                id = p.id,
                name = PatientCrypto.decrypt(p.encryptedName).ifBlank { "(naam decrypt nahi ho paya)" },
                age = p.age,
                gender = p.gender,
                lastUpdatedAt = p.lastUpdatedAt,
                currentDiagnosis = p.currentDiagnosis,
                currentSuggestion = p.currentSuggestion,
                currentMedicines = p.currentMedicines,
                knownAllergies = p.knownAllergies
            )
        }
    } catch (e: Exception) {
        emptyList()
    }
}

@Composable
fun MessageBubble(message: Message, onFeedback: (liked: Boolean, reason: String) -> Unit = { _, _ -> }) {
    val isUser = message.isUser
    // null = not yet rated, true = 👍, false = 👎 — once set, stays set for
    // this message so the buttons don't look tappable again after use.
    var rated by remember { mutableStateOf<Boolean?>(null) }
    var showReasonPrompt by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Row(
            horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start,
            modifier = Modifier.fillMaxWidth()
        ) {
            if (!isUser) {
                Image(
                    painter = painterResource(id = R.drawable.kavita_face),
                    contentDescription = "Kavita",
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                )
                Spacer(modifier = Modifier.width(8.dp))
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth(0.85f)
                    .background(
                        (if (isUser) Color(0xFF4A90E2) else Color(0xFFFF6B9D))
                            .let { if (message.isHistorical) it.copy(alpha = 0.45f) else it },
                        RoundedCornerShape(16.dp)
                    )
                    .padding(12.dp)
            ) {
                Text(
                    text = message.text,
                    color = if (message.isHistorical) Color.White.copy(alpha = 0.75f) else Color.White,
                    fontSize = 16.sp
                )
            }
        }

        // Historical bubbles (loaded from a patient's saved file) are
        // read-only — no feedback row, since they're not a live answer the
        // doctor just received.
        if (!isUser && message.question.isNotBlank() && !message.isHistorical) {
            Row(
                modifier = Modifier.padding(start = 40.dp, top = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (rated == null) {
                    IconButton(
                        onClick = {
                            rated = true
                            onFeedback(true, "")
                        },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Text("👍", fontSize = 14.sp)
                    }
                    IconButton(
                        onClick = { showReasonPrompt = true },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Text("👎", fontSize = 14.sp)
                    }
                } else {
                    Text(
                        text = if (rated == true) "👍 Feedback mil gaya" else "👎 Feedback mil gaya",
                        color = Color(0xFF888888),
                        fontSize = 11.sp
                    )
                }
            }

            if (showReasonPrompt) {
                DislikeReasonRow(
                    onReasonPicked = { reason ->
                        rated = false
                        showReasonPrompt = false
                        onFeedback(false, reason)
                    }
                )
            }
        }
    }
}

/** Quick-tap reason chips shown after a 👎, instead of requiring free typing. */
@Composable
private fun DislikeReasonRow(onReasonPicked: (String) -> Unit) {
    val reasons = listOf("Bahut lamba", "Galat tha", "Samajh nahi aaya", "Kaam ka nahi")
    Row(
        modifier = Modifier.padding(start = 40.dp, top = 4.dp)
    ) {
        reasons.forEach { reason ->
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF2A2A3E))
                    .clickable(
                        indication = null,
                        interactionSource = remember { MutableInteractionSource() },
                        onClick = { onReasonPicked(reason) }
                    )
                    .padding(horizontal = 10.dp, vertical = 5.dp)
            ) {
                Text(text = reason, color = Color(0xFFCCCCCC), fontSize = 11.sp)
            }
            Spacer(modifier = Modifier.width(6.dp))
        }
    }
}

data class Message(
    val text: String,
    val isUser: Boolean,
    val id: String = java.util.UUID.randomUUID().toString(),
    val question: String = "", // the user question this answer responds to, used for feedback context
    val isHistorical: Boolean = false // true = loaded from a patient's saved file, not a live exchange; rendered faded/read-only
)

/**
 * A minimal line chart for one lab/vitals metric's readings over time —
 * built directly on Compose Canvas rather than pulling in a charting
 * library, since this is the one place in the app that needs one and the
 * need is simple (one line, evenly spaced points, min/max-normalized).
 * [series] must already be sorted oldest-first and have at least 2 points
 * (callers check this before rendering — a single point can't show a
 * trend, only a flat dot).
 */
@Composable
private fun LabTrendChart(series: List<LabValue>, modifier: Modifier = Modifier) {
    val lineColor = Color(0xFF6BCB77)
    val pointColor = Color(0xFFFFD166)
    val gridColor = Color(0xFF333333)

    Canvas(modifier = modifier) {
        val minValue = series.minOf { it.value }
        val maxValue = series.maxOf { it.value }
        // Guard against a perfectly flat series (all readings identical) —
        // without this the normalization below divides by zero and every
        // point collapses onto the same y, or worse, NaNs the whole line.
        val valueRange = (maxValue - minValue).takeIf { it > 0.0 } ?: 1.0

        val leftPadding = 8.dp.toPx()
        val rightPadding = 8.dp.toPx()
        val topPadding = 12.dp.toPx()
        val bottomPadding = 12.dp.toPx()
        val chartWidth = size.width - leftPadding - rightPadding
        val chartHeight = size.height - topPadding - bottomPadding

        // Baseline grid — just a top and bottom reference line so the
        // chart doesn't float in empty space with no sense of scale.
        drawLine(
            color = gridColor,
            start = Offset(leftPadding, topPadding),
            end = Offset(size.width - rightPadding, topPadding),
            strokeWidth = 1.dp.toPx()
        )
        drawLine(
            color = gridColor,
            start = Offset(leftPadding, size.height - bottomPadding),
            end = Offset(size.width - rightPadding, size.height - bottomPadding),
            strokeWidth = 1.dp.toPx()
        )

        val points = series.mapIndexed { index, reading ->
            val x = if (series.size == 1) leftPadding else
                leftPadding + (chartWidth * index / (series.size - 1).toFloat())
            val normalizedY = (reading.value - minValue) / valueRange
            // Canvas y grows downward, so a higher value should draw
            // nearer the top — invert the normalized fraction.
            val y = topPadding + chartHeight * (1f - normalizedY.toFloat())
            Offset(x, y)
        }

        for (i in 0 until points.size - 1) {
            drawLine(
                color = lineColor,
                start = points[i],
                end = points[i + 1],
                strokeWidth = 3.dp.toPx(),
                cap = StrokeCap.Round
            )
        }
        points.forEach { point ->
            drawCircle(color = pointColor, radius = 5.dp.toPx(), center = point)
        }
    }
}
