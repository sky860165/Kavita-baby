// ui/SettingsScreen.kt
package com.kavitababy.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kavitababy.data.BackupService
import kotlinx.coroutines.launch

private val BG = Color(0xFF1A1A2E)
private val CARD = Color(0xFF16213E)
private val ACCENT = Color(0xFFFF6B9D)
private val MUTED = Color(0xFFAAAAAA)

/**
 * Profile / Settings screen, opened by tapping Kavita's photo+name in the
 * chat header. Fully offline — backup/restore goes through the normal
 * Android share sheet and file picker (WhatsApp, Google Drive app, email,
 * a USB copy, whatever the doctor picks), same as the rest of this app's
 * exports. No sign-in, no account of any kind — nothing to configure.
 */
@Composable
fun SettingsScreen(
    onDismiss: () -> Unit,
    onOpenChatMode: (modeTag: String) -> Unit,
    studyMessageCount: Int,
    doctorMessageCount: Int,
    engineerMessageCount: Int,
    onDeleteChatHistory: (modeTag: String) -> Unit,
    onFullAccountDeleted: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val backupService = remember { BackupService(context) }

    var statusMessage by remember { mutableStateOf<String?>(null) }
    var isWorking by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var showDeleteHistoryConfirmFor by remember { mutableStateOf<String?>(null) } // "STUDY"/"DOCTOR"/"ENGINEER"

    // "*/*" not "application/zip" — file managers/WhatsApp frequently
    // don't report a correct mime type for zip files, which would hide
    // the backup file from a filtered picker entirely.
    val restoreLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        isWorking = true
        scope.launch {
            val ok = try {
                backupService.importBackup(uri)
            } catch (e: Exception) {
                false
            }
            isWorking = false
            statusMessage = if (ok) {
                "Restore ho gaya ✅ — app ko poori tarah band karke (recent se swipe karke) dobara kholo."
            } else {
                "Restore nahi ho paaya — check karo ki ye wahi backup file hai jo 'Backup Banao' se banayi thi."
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BG)
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(CARD)
                .padding(horizontal = 8.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onDismiss) {
                Text("←", color = Color.White, fontSize = 22.sp)
            }
            Text("Profile & Settings", color = Color.White, fontSize = 17.sp)
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(14.dp)
        ) {
            // ---------- DATA BACKUP ----------
            SectionCard(title = "Data Backup") {
                Text(
                    "Poora data (patient cases, PDFs index, chat history) ek file mein backup " +
                        "hota hai. Backup banane ke baad share sheet khulega — Google Drive, " +
                        "WhatsApp, email, jahan chaho save kar do.",
                    color = MUTED,
                    fontSize = 11.sp
                )
                Spacer(modifier = Modifier.height(10.dp))
                FilledButton(
                    text = if (isWorking) "Ho raha hai..." else "Backup Banao",
                    enabled = !isWorking
                ) {
                    isWorking = true
                    scope.launch {
                        val uri = try {
                            backupService.exportBackup()
                        } catch (e: Exception) {
                            null
                        }
                        isWorking = false
                        if (uri != null) {
                            try {
                                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "application/zip"
                                    putExtra(Intent.EXTRA_STREAM, uri)
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                context.startActivity(Intent.createChooser(shareIntent, "Backup share karo"))
                            } catch (e: Exception) {
                                statusMessage = "Backup ban gaya, lekin share nahi ho paaya."
                            }
                        } else {
                            statusMessage = "Backup banane mein dikkat aa gayi."
                        }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedButtonRow(
                    text = if (isWorking) "Ho raha hai..." else "Backup se Restore Karo",
                    enabled = !isWorking
                ) {
                    restoreLauncher.launch("*/*")
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // ---------- CHAT HISTORY ----------
            SectionCard(title = "Chat History") {
                ChatHistoryRow(
                    label = "Study Mode",
                    count = studyMessageCount,
                    onOpen = { onOpenChatMode("STUDY"); onDismiss() },
                    onDelete = { showDeleteHistoryConfirmFor = "STUDY" }
                )
                Spacer(modifier = Modifier.height(10.dp))
                ChatHistoryRow(
                    label = "Doctor Mode",
                    count = doctorMessageCount,
                    onOpen = { onOpenChatMode("DOCTOR"); onDismiss() },
                    onDelete = { showDeleteHistoryConfirmFor = "DOCTOR" }
                )
                Spacer(modifier = Modifier.height(10.dp))
                ChatHistoryRow(
                    label = "Engineer Mode",
                    count = engineerMessageCount,
                    onOpen = { onOpenChatMode("ENGINEER"); onDismiss() },
                    onDelete = { showDeleteHistoryConfirmFor = "ENGINEER" }
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // ---------- DANGER ZONE ----------
            SectionCard(title = "Account Delete", titleColor = Color(0xFFFF5252)) {
                Text(
                    "Kavita Baby AI ka koi apna server nahi hai — sab data sirf is phone par hai. " +
                        "Ye button phone se saara data (chat, patient cases, PDFs index) permanently " +
                        "delete kar dega. Ye wapas nahi ho sakta — pehle 'Backup Banao' se ek copy " +
                        "bana lena agar chahiye ho.",
                    color = MUTED,
                    fontSize = 11.sp
                )
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = { showDeleteConfirm = true },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB71C1C)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Account aur Saara Data Delete Karo", color = Color.White)
                }
            }

            statusMessage?.let {
                Spacer(modifier = Modifier.height(14.dp))
                Text(it, color = ACCENT, fontSize = 12.sp)
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // ----- Delete account confirmation -----
    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Pakka delete karna hai?") },
            text = { Text("Ye phone ka saara Kavita Baby AI data hamesha ke liye mita dega. Ye wapas nahi ho sakta.") },
            confirmButton = {
                TextButton(onClick = {
                    showDeleteConfirm = false
                    isWorking = true
                    scope.launch {
                        backupService.wipeAllLocalData()
                        isWorking = false
                        onFullAccountDeleted()
                    }
                }) { Text("Haan, delete karo", color = Color(0xFFFF5252)) }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) { Text("Cancel") }
            }
        )
    }

    // ----- Delete chat history confirmation -----
    showDeleteHistoryConfirmFor?.let { modeTag ->
        val label = when (modeTag) {
            "STUDY" -> "Study"
            "DOCTOR" -> "Doctor"
            else -> "Engineer"
        }
        AlertDialog(
            onDismissRequest = { showDeleteHistoryConfirmFor = null },
            title = { Text("Chat history delete karein?") },
            text = { Text("$label Mode ki poori chat history mit jayegi.") },
            confirmButton = {
                TextButton(onClick = {
                    onDeleteChatHistory(modeTag)
                    showDeleteHistoryConfirmFor = null
                    statusMessage = "Chat history delete ho gayi"
                }) { Text("Haan, delete karo", color = Color(0xFFFF5252)) }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteHistoryConfirmFor = null }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun SectionCard(
    title: String,
    titleColor: Color = Color.White,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(CARD)
            .padding(14.dp)
    ) {
        Text(title, color = titleColor, fontSize = 14.sp)
        Spacer(modifier = Modifier.height(10.dp))
        content()
    }
}

@Composable
private fun ChatHistoryRow(label: String, count: Int, onOpen: () -> Unit, onDelete: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.weight(1f)) {
            Text(label, color = Color.White, fontSize = 13.sp)
            Text("$count messages", color = MUTED, fontSize = 11.sp)
        }
        TextButton(onClick = onOpen) { Text("Kholo", color = ACCENT) }
        TextButton(onClick = onDelete) { Text("Delete", color = Color(0xFFFF5252)) }
    }
}

@Composable
private fun FilledButton(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        enabled = enabled,
        colors = ButtonDefaults.buttonColors(containerColor = ACCENT),
        modifier = Modifier.fillMaxWidth()
    ) { Text(text, color = Color.White) }
}

@Composable
private fun OutlinedButtonRow(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier.fillMaxWidth()
    ) { Text(text) }
}
