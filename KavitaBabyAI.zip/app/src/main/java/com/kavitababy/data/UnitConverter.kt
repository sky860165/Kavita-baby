package com.kavitababy.data

/**
 * Real, locally-computed unit conversion for Engineer Mode — same
 * philosophy as [EngineeringCalculator]: exact on-device math, never a
 * number guessed by the AI. Engineering work constantly crosses SI/
 * Imperial boundaries (a datasheet in inches, a spec in Nm, a US
 * supplier's drawing in psi), so this is a standalone tool independent
 * of any AI call.
 */
object UnitConverter {

    enum class Category(val label: String) {
        LENGTH("Length"),
        MASS("Mass"),
        FORCE("Force"),
        PRESSURE("Pressure / Stress"),
        TORQUE("Torque"),
        POWER("Power"),
        ENERGY("Energy"),
        TEMPERATURE("Temperature")
    }

    /**
     * Every unit's multiplier to convert INTO this category's base SI
     * unit (meter, kilogram, newton, pascal, N·m, watt, joule). Not used
     * for TEMPERATURE, which needs offset math, not a pure multiplier.
     */
    private val unitsByCategory: Map<Category, Map<String, Double>> = mapOf(
        Category.LENGTH to mapOf(
            "mm" to 0.001,
            "cm" to 0.01,
            "m" to 1.0,
            "km" to 1000.0,
            "in" to 0.0254,
            "ft" to 0.3048,
            "yd" to 0.9144,
            "mile" to 1609.344
        ),
        Category.MASS to mapOf(
            "mg" to 0.000001,
            "g" to 0.001,
            "kg" to 1.0,
            "tonne" to 1000.0,
            "lb" to 0.45359237,
            "oz" to 0.028349523125
        ),
        Category.FORCE to mapOf(
            "N" to 1.0,
            "kN" to 1000.0,
            "lbf" to 4.4482216153,
            "kgf" to 9.80665,
            "dyne" to 0.00001
        ),
        Category.PRESSURE to mapOf(
            "Pa" to 1.0,
            "kPa" to 1000.0,
            "MPa" to 1_000_000.0,
            "bar" to 100_000.0,
            "psi" to 6894.757293168,
            "atm" to 101325.0,
            "mmHg" to 133.322387415
        ),
        Category.TORQUE to mapOf(
            "N·m" to 1.0,
            "kN·m" to 1000.0,
            "lbf·ft" to 1.3558179483,
            "lbf·in" to 0.1129814957,
            "kgf·m" to 9.80665
        ),
        Category.POWER to mapOf(
            "W" to 1.0,
            "kW" to 1000.0,
            "MW" to 1_000_000.0,
            "hp (mech)" to 745.6998715823,
            "hp (metric)" to 735.49875,
            "BTU/h" to 0.29307107
        ),
        Category.ENERGY to mapOf(
            "J" to 1.0,
            "kJ" to 1000.0,
            "kWh" to 3_600_000.0,
            "cal" to 4.184,
            "kcal" to 4184.0,
            "BTU" to 1055.05585262
        )
    )

    fun unitsFor(category: Category): List<String> =
        if (category == Category.TEMPERATURE) listOf("°C", "°F", "K")
        else unitsByCategory.getValue(category).keys.toList()

    fun convert(category: Category, value: Double, fromUnit: String, toUnit: String): Result<Double> {
        return try {
            if (fromUnit == toUnit) return Result.success(value)

            if (category == Category.TEMPERATURE) {
                // Convert to Kelvin first, then to the target — avoids 9
                // hand-written pairwise formulas for 3 units.
                val kelvin = when (fromUnit) {
                    "°C" -> value + 273.15
                    "°F" -> (value - 32) * 5.0 / 9.0 + 273.15
                    "K" -> value
                    else -> throw IllegalArgumentException("Unknown unit: $fromUnit")
                }
                val result = when (toUnit) {
                    "°C" -> kelvin - 273.15
                    "°F" -> (kelvin - 273.15) * 9.0 / 5.0 + 32
                    "K" -> kelvin
                    else -> throw IllegalArgumentException("Unknown unit: $toUnit")
                }
                return Result.success(result)
            }

            val units = unitsByCategory.getValue(category)
            val fromFactor = units[fromUnit] ?: throw IllegalArgumentException("Unknown unit: $fromUnit")
            val toFactor = units[toUnit] ?: throw IllegalArgumentException("Unknown unit: $toUnit")
            Result.success(value * fromFactor / toFactor)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
