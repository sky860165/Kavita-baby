// data/FollowUpReminderDao.kt
package com.kavitababy.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update

@Dao
interface FollowUpReminderDao {

    @Insert
    suspend fun insert(reminder: FollowUpReminder): Long

    @Update
    suspend fun update(reminder: FollowUpReminder)

    @Query("SELECT * FROM followup_reminders WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): FollowUpReminder?

    // Upcoming = not yet fired/cancelled, ordered soonest-first — this is
    // what the "Upcoming Follow-ups" list in the UI reads from.
    @Query(
        """
        SELECT * FROM followup_reminders
        WHERE isCompleted = 0 AND isCancelled = 0
        ORDER BY triggerAtMillis ASC
        """
    )
    suspend fun getUpcoming(): List<FollowUpReminder>

    @Query("SELECT * FROM followup_reminders WHERE patientId = :patientId ORDER BY triggerAtMillis DESC")
    suspend fun getForPatient(patientId: Long): List<FollowUpReminder>

    // Read on device boot (see BootReminderReceiver) to re-schedule every
    // still-pending future alarm, since AlarmManager alarms are cleared by
    // the OS on reboot.
    @Query(
        """
        SELECT * FROM followup_reminders
        WHERE isCompleted = 0 AND isCancelled = 0 AND triggerAtMillis > :nowMillis
        """
    )
    suspend fun getPendingFutureReminders(nowMillis: Long): List<FollowUpReminder>

    @Query("UPDATE followup_reminders SET isCompleted = 1 WHERE id = :id")
    suspend fun markCompleted(id: Long)

    @Query("UPDATE followup_reminders SET isCancelled = 1 WHERE id = :id")
    suspend fun markCancelled(id: Long)
}
