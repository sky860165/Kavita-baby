package com.kavitababy.data

import kotlin.math.pow
import kotlin.math.sqrt
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.exp
import kotlin.math.sin
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.PI

/**
 * Standard BTech/MTech-curriculum Physics, Chemistry, and Maths formulas
 * — real, locally-computed, same philosophy as [EngineeringCalculator]
 * and [UnitConverter]: exact on-device math, never a number guessed by
 * the AI.
 *
 * Honest scope note: "PhD level" physics/chem/maths is mostly derivation,
 * proof, and open-ended reasoning — not something that fits a plug-in-
 * the-numbers calculator. What's here is the standard set of named,
 * well-defined formulas used from BTech fundamentals right through
 * research-level work (e.g. de Broglie wavelength, Nernst equation,
 * Arrhenius equation) — the actual PhD-level depth for a given problem
 * still comes from Engineer Mode's AI reasoning/derivation, this
 * calculator just gives it (and the user) exact numbers to reason from.
 */
object ScienceCalculator {

    enum class Category(val label: String) {
        MECHANICS("Mechanics"),
        ELECTROMAGNETISM("Electromagnetism"),
        THERMODYNAMICS("Thermodynamics"),
        WAVES_OPTICS("Waves & Optics"),
        MODERN_PHYSICS("Modern Physics"),
        CHEMISTRY("Chemistry"),
        MATHEMATICS("Mathematics")
    }

    enum class Formula(val category: Category, val label: String) {
        // ---- MECHANICS ----
        KINEMATICS_V(Category.MECHANICS, "v = u + at"),
        KINEMATICS_S(Category.MECHANICS, "s = ut + ½at²"),
        KINEMATICS_V2(Category.MECHANICS, "v² = u² + 2as"),
        NEWTON_SECOND_LAW(Category.MECHANICS, "Newton's 2nd Law (F=ma)"),
        MOMENTUM(Category.MECHANICS, "Momentum (p=mv)"),
        KINETIC_ENERGY(Category.MECHANICS, "Kinetic Energy (KE=½mv²)"),
        POTENTIAL_ENERGY(Category.MECHANICS, "Gravitational PE (mgh)"),
        WORK_DONE(Category.MECHANICS, "Work Done (W=Fd·cosθ)"),
        GRAVITATION(Category.MECHANICS, "Newton's Gravitation (F=Gm₁m₂/r²)"),
        CENTRIPETAL_FORCE(Category.MECHANICS, "Centripetal Force (F=mv²/r)"),
        ANGULAR_MOMENTUM(Category.MECHANICS, "Angular Momentum (L=Iω)"),
        SHM_PERIOD(Category.MECHANICS, "SHM Period (T=2π√(m/k))"),
        ESCAPE_VELOCITY(Category.MECHANICS, "Escape Velocity (v=√(2GM/R))"),

        // ---- ELECTROMAGNETISM ----
        COULOMBS_LAW(Category.ELECTROMAGNETISM, "Coulomb's Law (F=kq₁q₂/r²)"),
        ELECTRIC_FIELD(Category.ELECTROMAGNETISM, "Electric Field (E=F/q)"),
        CAPACITOR_ENERGY(Category.ELECTROMAGNETISM, "Capacitor Energy (U=½CV²)"),
        MAGNETIC_FORCE(Category.ELECTROMAGNETISM, "Force on Moving Charge (F=qvB)"),
        BIOT_SAVART_WIRE(Category.ELECTROMAGNETISM, "B-field of Straight Wire (B=μ₀I/2πr)"),
        FARADAY_EMF(Category.ELECTROMAGNETISM, "Faraday's Law (ε=N·ΔΦ/Δt)"),

        // ---- THERMODYNAMICS ----
        IDEAL_GAS_LAW(Category.THERMODYNAMICS, "Ideal Gas Law (PV=nRT)"),
        FIRST_LAW_THERMO(Category.THERMODYNAMICS, "First Law (Q=ΔU+W)"),
        CARNOT_EFFICIENCY(Category.THERMODYNAMICS, "Carnot Efficiency (η=1-Tc/Th)"),
        ENTROPY_CHANGE(Category.THERMODYNAMICS, "Entropy Change (ΔS=Q/T)"),
        HEAT_CAPACITY(Category.THERMODYNAMICS, "Heat Energy (Q=mcΔT)"),
        STEFAN_BOLTZMANN(Category.THERMODYNAMICS, "Stefan-Boltzmann (P=σAT⁴)"),
        WIENS_LAW(Category.THERMODYNAMICS, "Wien's Displacement (λmax·T=b)"),

        // ---- WAVES & OPTICS ----
        WAVE_SPEED(Category.WAVES_OPTICS, "Wave Speed (v=fλ)"),
        DOPPLER_APPROACHING(Category.WAVES_OPTICS, "Doppler Effect (source approaching)"),
        SNELLS_LAW(Category.WAVES_OPTICS, "Snell's Law (n₁sinθ₁=n₂sinθ₂)"),
        THIN_LENS(Category.WAVES_OPTICS, "Thin Lens Equation (1/f=1/do+1/di)"),
        YOUNG_DOUBLE_SLIT(Category.WAVES_OPTICS, "Young's Double Slit Fringe Width"),

        // ---- MODERN PHYSICS ----
        PHOTOELECTRIC_EFFECT(Category.MODERN_PHYSICS, "Photoelectric Effect (KEmax=hf-φ)"),
        DE_BROGLIE(Category.MODERN_PHYSICS, "de Broglie Wavelength (λ=h/mv)"),
        MASS_ENERGY(Category.MODERN_PHYSICS, "Mass-Energy Equivalence (E=mc²)"),
        TIME_DILATION(Category.MODERN_PHYSICS, "Time Dilation (Δt'=Δt/√(1-v²/c²))"),
        RADIOACTIVE_DECAY(Category.MODERN_PHYSICS, "Radioactive Decay (N=N₀e^-λt)"),
        HALF_LIFE(Category.MODERN_PHYSICS, "Half-Life (λ=ln2/t½)"),
        BOHR_ENERGY_LEVEL(Category.MODERN_PHYSICS, "Bohr Model Energy Level (En=-13.6/n² eV)"),

        // ---- CHEMISTRY ----
        PH_FROM_H(Category.CHEMISTRY, "pH (from [H⁺])"),
        MOLARITY(Category.CHEMISTRY, "Molarity (M=mol/L)"),
        DILUTION(Category.CHEMISTRY, "Dilution Equation (M₁V₁=M₂V₂)"),
        ARRHENIUS(Category.CHEMISTRY, "Arrhenius Equation (k=Ae^(-Ea/RT))"),
        NERNST_EQUATION(Category.CHEMISTRY, "Nernst Equation (E=E°-(0.0592/n)logQ)"),
        GIBBS_FREE_ENERGY(Category.CHEMISTRY, "Gibbs Free Energy (ΔG=ΔH-TΔS)"),
        COMBINED_GAS_LAW(Category.CHEMISTRY, "Combined Gas Law (P₁V₁/T₁=P₂V₂/T₂)"),

        // ---- MATHEMATICS ----
        QUADRATIC_FORMULA(Category.MATHEMATICS, "Quadratic Formula (roots of ax²+bx+c)"),
        DISTANCE_2D(Category.MATHEMATICS, "Distance Formula (2D)"),
        VECTOR_MAGNITUDE_3D(Category.MATHEMATICS, "Vector Magnitude (3D)"),
        COMPOUND_INTEREST(Category.MATHEMATICS, "Compound Growth (A=P(1+r/n)^nt)"),
        PERMUTATIONS(Category.MATHEMATICS, "Permutations (nPr)"),
        COMBINATIONS(Category.MATHEMATICS, "Combinations (nCr)"),
        LAW_OF_COSINES(Category.MATHEMATICS, "Law of Cosines (c²=a²+b²-2ab·cosC)")
    }

    // Physical constants used below (SI units)
    private const val G_CONST = 6.674e-11       // gravitational constant
    private const val K_COULOMB = 8.9875e9      // Coulomb's constant
    private const val MU0 = 4 * PI * 1e-7       // permeability of free space
    private const val SIGMA_SB = 5.670374e-8    // Stefan-Boltzmann constant
    private const val WIEN_B = 2.897771955e-3   // Wien's displacement constant
    private const val R_GAS = 8.314             // universal gas constant J/(mol·K)
    private const val H_PLANCK = 6.62607015e-34 // Planck's constant
    private const val C_LIGHT = 2.99792458e8    // speed of light
    private const val F_FARADAY = 96485.0       // Faraday constant

    fun formulasFor(category: Category): List<Formula> = Formula.values().filter { it.category == category }

    fun requiredFields(formula: Formula): List<String> = when (formula) {
        Formula.KINEMATICS_V -> listOf("Initial Velocity u (m/s)", "Acceleration a (m/s²)", "Time t (s)")
        Formula.KINEMATICS_S -> listOf("Initial Velocity u (m/s)", "Time t (s)", "Acceleration a (m/s²)")
        Formula.KINEMATICS_V2 -> listOf("Initial Velocity u (m/s)", "Acceleration a (m/s²)", "Displacement s (m)")
        Formula.NEWTON_SECOND_LAW -> listOf("Mass m (kg)", "Acceleration a (m/s²)")
        Formula.MOMENTUM -> listOf("Mass m (kg)", "Velocity v (m/s)")
        Formula.KINETIC_ENERGY -> listOf("Mass m (kg)", "Velocity v (m/s)")
        Formula.POTENTIAL_ENERGY -> listOf("Mass m (kg)", "Height h (m)", "g (m/s², default 9.81)")
        Formula.WORK_DONE -> listOf("Force F (N)", "Displacement d (m)", "Angle θ (degrees)")
        Formula.GRAVITATION -> listOf("Mass m1 (kg)", "Mass m2 (kg)", "Distance r (m)")
        Formula.CENTRIPETAL_FORCE -> listOf("Mass m (kg)", "Velocity v (m/s)", "Radius r (m)")
        Formula.ANGULAR_MOMENTUM -> listOf("Moment of Inertia I (kg·m²)", "Angular Velocity ω (rad/s)")
        Formula.SHM_PERIOD -> listOf("Mass m (kg)", "Spring Constant k (N/m)")
        Formula.ESCAPE_VELOCITY -> listOf("Mass of Body M (kg)", "Radius R (m)")

        Formula.COULOMBS_LAW -> listOf("Charge q1 (C)", "Charge q2 (C)", "Distance r (m)")
        Formula.ELECTRIC_FIELD -> listOf("Force F (N)", "Charge q (C)")
        Formula.CAPACITOR_ENERGY -> listOf("Capacitance C (F)", "Voltage V (V)")
        Formula.MAGNETIC_FORCE -> listOf("Charge q (C)", "Velocity v (m/s)", "Magnetic Field B (T)")
        Formula.BIOT_SAVART_WIRE -> listOf("Current I (A)", "Distance r (m)")
        Formula.FARADAY_EMF -> listOf("Number of Turns N", "Flux Change ΔΦ (Wb)", "Time Δt (s)")

        Formula.IDEAL_GAS_LAW -> listOf("Moles n (mol)", "Temperature T (K)", "Volume V (m³)")
        Formula.FIRST_LAW_THERMO -> listOf("Internal Energy Change ΔU (J)", "Work Done by System W (J)")
        Formula.CARNOT_EFFICIENCY -> listOf("Cold Reservoir Tc (K)", "Hot Reservoir Th (K)")
        Formula.ENTROPY_CHANGE -> listOf("Heat Q (J)", "Temperature T (K)")
        Formula.HEAT_CAPACITY -> listOf("Mass m (kg)", "Specific Heat c (J/kg·K)", "ΔT (K)")
        Formula.STEFAN_BOLTZMANN -> listOf("Area A (m²)", "Temperature T (K)")
        Formula.WIENS_LAW -> listOf("Temperature T (K)")

        Formula.WAVE_SPEED -> listOf("Frequency f (Hz)", "Wavelength λ (m)")
        Formula.DOPPLER_APPROACHING -> listOf("Source Frequency f (Hz)", "Wave Speed v (m/s)", "Source Speed vs (m/s)")
        Formula.SNELLS_LAW -> listOf("n1", "Angle θ1 (degrees)", "n2")
        Formula.THIN_LENS -> listOf("Object Distance do (m)", "Focal Length f (m)")
        Formula.YOUNG_DOUBLE_SLIT -> listOf("Wavelength λ (m)", "Slit Separation d (m)", "Screen Distance D (m)")

        Formula.PHOTOELECTRIC_EFFECT -> listOf("Frequency f (Hz)", "Work Function φ (J)")
        Formula.DE_BROGLIE -> listOf("Mass m (kg)", "Velocity v (m/s)")
        Formula.MASS_ENERGY -> listOf("Mass m (kg)")
        Formula.TIME_DILATION -> listOf("Proper Time Δt (s)", "Velocity v (m/s)")
        Formula.RADIOACTIVE_DECAY -> listOf("Initial Quantity N0", "Decay Constant λ (1/s)", "Time t (s)")
        Formula.HALF_LIFE -> listOf("Half-Life t½ (s)")
        Formula.BOHR_ENERGY_LEVEL -> listOf("Principal Quantum Number n")

        Formula.PH_FROM_H -> listOf("[H⁺] Concentration (mol/L)")
        Formula.MOLARITY -> listOf("Moles of Solute (mol)", "Volume of Solution (L)")
        Formula.DILUTION -> listOf("M1 (mol/L)", "V1 (L)", "V2 (L)")
        Formula.ARRHENIUS -> listOf("Pre-exponential A", "Activation Energy Ea (J/mol)", "Temperature T (K)")
        Formula.NERNST_EQUATION -> listOf("Standard Potential E° (V)", "Electrons Transferred n", "Reaction Quotient Q")
        Formula.GIBBS_FREE_ENERGY -> listOf("ΔH (J)", "Temperature T (K)", "ΔS (J/K)")
        Formula.COMBINED_GAS_LAW -> listOf("P1 (Pa)", "V1 (m³)", "T1 (K)", "P2 (Pa)", "T2 (K)")

        Formula.QUADRATIC_FORMULA -> listOf("a", "b", "c")
        Formula.DISTANCE_2D -> listOf("x1", "y1", "x2", "y2")
        Formula.VECTOR_MAGNITUDE_3D -> listOf("x", "y", "z")
        Formula.COMPOUND_INTEREST -> listOf("Principal P", "Rate r (decimal, e.g 0.05)", "Compounds per Year n", "Years t")
        Formula.PERMUTATIONS -> listOf("n", "r")
        Formula.COMBINATIONS -> listOf("n", "r")
        Formula.LAW_OF_COSINES -> listOf("Side a", "Side b", "Angle C (degrees)")
    }

    fun calculate(formula: Formula, inputs: Map<String, String>): Result<String> = try {
        fun d(key: String) = inputs.getValue(key).toDouble()

        when (formula) {
            // ---- MECHANICS ----
            Formula.KINEMATICS_V -> {
                val u = d("Initial Velocity u (m/s)"); val a = d("Acceleration a (m/s²)"); val t = d("Time t (s)")
                Result.success("v (m/s): ${u + a * t}")
            }
            Formula.KINEMATICS_S -> {
                val u = d("Initial Velocity u (m/s)"); val t = d("Time t (s)"); val a = d("Acceleration a (m/s²)")
                Result.success("s (m): ${u * t + 0.5 * a * t.pow(2)}")
            }
            Formula.KINEMATICS_V2 -> {
                val u = d("Initial Velocity u (m/s)"); val a = d("Acceleration a (m/s²)"); val s = d("Displacement s (m)")
                val v2 = u.pow(2) + 2 * a * s
                if (v2 < 0) throw IllegalArgumentException("v² came out negative — check inputs")
                Result.success("v (m/s): ${sqrt(v2)}")
            }
            Formula.NEWTON_SECOND_LAW -> {
                Result.success("Force F (N): ${d("Mass m (kg)") * d("Acceleration a (m/s²)")}")
            }
            Formula.MOMENTUM -> {
                Result.success("Momentum p (kg·m/s): ${d("Mass m (kg)") * d("Velocity v (m/s)")}")
            }
            Formula.KINETIC_ENERGY -> {
                Result.success("KE (J): ${0.5 * d("Mass m (kg)") * d("Velocity v (m/s)").pow(2)}")
            }
            Formula.POTENTIAL_ENERGY -> {
                val g = inputs["g (m/s², default 9.81)"]?.toDoubleOrNull() ?: 9.81
                Result.success("PE (J): ${d("Mass m (kg)") * g * d("Height h (m)")}")
            }
            Formula.WORK_DONE -> {
                val f = d("Force F (N)"); val dist = d("Displacement d (m)"); val theta = Math.toRadians(d("Angle θ (degrees)"))
                Result.success("Work W (J): ${f * dist * cos(theta)}")
            }
            Formula.GRAVITATION -> {
                val m1 = d("Mass m1 (kg)"); val m2 = d("Mass m2 (kg)"); val r = d("Distance r (m)")
                Result.success("Force F (N): ${G_CONST * m1 * m2 / r.pow(2)}")
            }
            Formula.CENTRIPETAL_FORCE -> {
                val m = d("Mass m (kg)"); val v = d("Velocity v (m/s)"); val r = d("Radius r (m)")
                Result.success("Force F (N): ${m * v.pow(2) / r}")
            }
            Formula.ANGULAR_MOMENTUM -> {
                Result.success("Angular Momentum L (kg·m²/s): ${d("Moment of Inertia I (kg·m²)") * d("Angular Velocity ω (rad/s)")}")
            }
            Formula.SHM_PERIOD -> {
                val m = d("Mass m (kg)"); val k = d("Spring Constant k (N/m)")
                Result.success("Period T (s): ${2 * PI * sqrt(m / k)}")
            }
            Formula.ESCAPE_VELOCITY -> {
                val m = d("Mass of Body M (kg)"); val r = d("Radius R (m)")
                Result.success("Escape Velocity (m/s): ${sqrt(2 * G_CONST * m / r)}")
            }

            // ---- ELECTROMAGNETISM ----
            Formula.COULOMBS_LAW -> {
                val q1 = d("Charge q1 (C)"); val q2 = d("Charge q2 (C)"); val r = d("Distance r (m)")
                Result.success("Force F (N): ${K_COULOMB * q1 * q2 / r.pow(2)}")
            }
            Formula.ELECTRIC_FIELD -> {
                Result.success("Electric Field E (N/C): ${d("Force F (N)") / d("Charge q (C)")}")
            }
            Formula.CAPACITOR_ENERGY -> {
                Result.success("Energy U (J): ${0.5 * d("Capacitance C (F)") * d("Voltage V (V)").pow(2)}")
            }
            Formula.MAGNETIC_FORCE -> {
                Result.success("Force F (N): ${d("Charge q (C)") * d("Velocity v (m/s)") * d("Magnetic Field B (T)")}")
            }
            Formula.BIOT_SAVART_WIRE -> {
                val i = d("Current I (A)"); val r = d("Distance r (m)")
                Result.success("Magnetic Field B (T): ${MU0 * i / (2 * PI * r)}")
            }
            Formula.FARADAY_EMF -> {
                val n = d("Number of Turns N"); val dPhi = d("Flux Change ΔΦ (Wb)"); val dt = d("Time Δt (s)")
                Result.success("EMF ε (V): ${-n * dPhi / dt}")
            }

            // ---- THERMODYNAMICS ----
            Formula.IDEAL_GAS_LAW -> {
                val n = d("Moles n (mol)"); val t = d("Temperature T (K)"); val v = d("Volume V (m³)")
                Result.success("Pressure P (Pa): ${n * R_GAS * t / v}")
            }
            Formula.FIRST_LAW_THERMO -> {
                val du = d("Internal Energy Change ΔU (J)"); val w = d("Work Done by System W (J)")
                Result.success("Heat Q (J): ${du + w}")
            }
            Formula.CARNOT_EFFICIENCY -> {
                val tc = d("Cold Reservoir Tc (K)"); val th = d("Hot Reservoir Th (K)")
                Result.success("Efficiency η: ${1 - tc / th} (${(1 - tc / th) * 100}%)")
            }
            Formula.ENTROPY_CHANGE -> {
                Result.success("ΔS (J/K): ${d("Heat Q (J)") / d("Temperature T (K)")}")
            }
            Formula.HEAT_CAPACITY -> {
                Result.success("Heat Q (J): ${d("Mass m (kg)") * d("Specific Heat c (J/kg·K)") * d("ΔT (K)")}")
            }
            Formula.STEFAN_BOLTZMANN -> {
                val a = d("Area A (m²)"); val t = d("Temperature T (K)")
                Result.success("Power P (W): ${SIGMA_SB * a * t.pow(4)}")
            }
            Formula.WIENS_LAW -> {
                Result.success("λmax (m): ${WIEN_B / d("Temperature T (K)")}")
            }

            // ---- WAVES & OPTICS ----
            Formula.WAVE_SPEED -> {
                Result.success("Speed v (m/s): ${d("Frequency f (Hz)") * d("Wavelength λ (m)")}")
            }
            Formula.DOPPLER_APPROACHING -> {
                val f = d("Source Frequency f (Hz)"); val v = d("Wave Speed v (m/s)"); val vs = d("Source Speed vs (m/s)")
                if (v - vs == 0.0) throw IllegalArgumentException("v - vs can't be zero")
                Result.success("Observed Frequency f' (Hz): ${f * (v / (v - vs))}")
            }
            Formula.SNELLS_LAW -> {
                val n1 = d("n1"); val theta1 = Math.toRadians(d("Angle θ1 (degrees)")); val n2 = d("n2")
                val sinTheta2 = n1 * sin(theta1) / n2
                if (sinTheta2 > 1 || sinTheta2 < -1) Result.success("Total internal reflection — no refracted ray")
                else Result.success("Angle θ2 (degrees): ${Math.toDegrees(asin(sinTheta2))}")
            }
            Formula.THIN_LENS -> {
                val doo = d("Object Distance do (m)"); val f = d("Focal Length f (m)")
                if (doo == f) throw IllegalArgumentException("do can't equal f (image at infinity)")
                Result.success("Image Distance di (m): ${1.0 / (1.0 / f - 1.0 / doo)}")
            }
            Formula.YOUNG_DOUBLE_SLIT -> {
                val lambda = d("Wavelength λ (m)"); val dSlit = d("Slit Separation d (m)"); val dist = d("Screen Distance D (m)")
                Result.success("Fringe Width β (m): ${lambda * dist / dSlit}")
            }

            // ---- MODERN PHYSICS ----
            Formula.PHOTOELECTRIC_EFFECT -> {
                val f = d("Frequency f (Hz)"); val phi = d("Work Function φ (J)")
                val ke = H_PLANCK * f - phi
                Result.success("KEmax (J): $ke (${ke / 1.602176634e-19} eV)")
            }
            Formula.DE_BROGLIE -> {
                val m = d("Mass m (kg)"); val v = d("Velocity v (m/s)")
                Result.success("Wavelength λ (m): ${H_PLANCK / (m * v)}")
            }
            Formula.MASS_ENERGY -> {
                Result.success("Energy E (J): ${d("Mass m (kg)") * C_LIGHT.pow(2)}")
            }
            Formula.TIME_DILATION -> {
                val dt = d("Proper Time Δt (s)"); val v = d("Velocity v (m/s)")
                val factor = 1 - (v.pow(2) / C_LIGHT.pow(2))
                if (factor <= 0) throw IllegalArgumentException("v must be less than c")
                Result.success("Dilated Time Δt' (s): ${dt / sqrt(factor)}")
            }
            Formula.RADIOACTIVE_DECAY -> {
                val n0 = d("Initial Quantity N0"); val lambda = d("Decay Constant λ (1/s)"); val t = d("Time t (s)")
                Result.success("N(t): ${n0 * exp(-lambda * t)}")
            }
            Formula.HALF_LIFE -> {
                Result.success("Decay Constant λ (1/s): ${ln(2.0) / d("Half-Life t½ (s)")}")
            }
            Formula.BOHR_ENERGY_LEVEL -> {
                val n = d("Principal Quantum Number n")
                Result.success("Energy En (eV): ${-13.6 / n.pow(2)}")
            }

            // ---- CHEMISTRY ----
            Formula.PH_FROM_H -> {
                val h = d("[H⁺] Concentration (mol/L)")
                if (h <= 0) throw IllegalArgumentException("[H+] must be positive")
                Result.success("pH: ${-log10(h)}")
            }
            Formula.MOLARITY -> {
                Result.success("Molarity M (mol/L): ${d("Moles of Solute (mol)") / d("Volume of Solution (L)")}")
            }
            Formula.DILUTION -> {
                val m1 = d("M1 (mol/L)"); val v1 = d("V1 (L)"); val v2 = d("V2 (L)")
                Result.success("M2 (mol/L): ${m1 * v1 / v2}")
            }
            Formula.ARRHENIUS -> {
                val a = d("Pre-exponential A"); val ea = d("Activation Energy Ea (J/mol)"); val t = d("Temperature T (K)")
                Result.success("Rate Constant k: ${a * exp(-ea / (R_GAS * t))}")
            }
            Formula.NERNST_EQUATION -> {
                val e0 = d("Standard Potential E° (V)"); val n = d("Electrons Transferred n"); val q = d("Reaction Quotient Q")
                if (q <= 0) throw IllegalArgumentException("Q must be positive")
                Result.success("Cell Potential E (V): ${e0 - (0.0592 / n) * log10(q)}")
            }
            Formula.GIBBS_FREE_ENERGY -> {
                val dh = d("ΔH (J)"); val t = d("Temperature T (K)"); val ds = d("ΔS (J/K)")
                Result.success("ΔG (J): ${dh - t * ds}")
            }
            Formula.COMBINED_GAS_LAW -> {
                val p1 = d("P1 (Pa)"); val v1 = d("V1 (m³)"); val t1 = d("T1 (K)"); val p2 = d("P2 (Pa)"); val t2 = d("T2 (K)")
                if (p2 == 0.0) throw IllegalArgumentException("P2 can't be zero")
                Result.success("V2 (m³): ${(p1 * v1 * t2) / (t1 * p2)}")
            }

            // ---- MATHEMATICS ----
            Formula.QUADRATIC_FORMULA -> {
                val a = d("a"); val b = d("b"); val c = d("c")
                if (a == 0.0) throw IllegalArgumentException("a can't be zero (not quadratic)")
                val disc = b.pow(2) - 4 * a * c
                if (disc < 0) {
                    val realPart = -b / (2 * a); val imagPart = sqrt(-disc) / (2 * a)
                    Result.success("Complex roots: $realPart ± ${imagPart}i")
                } else {
                    val x1 = (-b + sqrt(disc)) / (2 * a); val x2 = (-b - sqrt(disc)) / (2 * a)
                    Result.success("x1 = $x1, x2 = $x2")
                }
            }
            Formula.DISTANCE_2D -> {
                val x1 = d("x1"); val y1 = d("y1"); val x2 = d("x2"); val y2 = d("y2")
                Result.success("Distance: ${sqrt((x2 - x1).pow(2) + (y2 - y1).pow(2))}")
            }
            Formula.VECTOR_MAGNITUDE_3D -> {
                val x = d("x"); val y = d("y"); val z = d("z")
                Result.success("Magnitude: ${sqrt(x.pow(2) + y.pow(2) + z.pow(2))}")
            }
            Formula.COMPOUND_INTEREST -> {
                val p = d("Principal P"); val r = d("Rate r (decimal, e.g 0.05)"); val n = d("Compounds per Year n"); val t = d("Years t")
                Result.success("Final Amount A: ${p * (1 + r / n).pow(n * t)}")
            }
            Formula.PERMUTATIONS -> {
                val n = d("n").toInt(); val r = d("r").toInt()
                if (r > n || n < 0 || r < 0) throw IllegalArgumentException("Need 0 ≤ r ≤ n")
                Result.success("nPr: ${factorial(n) / factorial(n - r)}")
            }
            Formula.COMBINATIONS -> {
                val n = d("n").toInt(); val r = d("r").toInt()
                if (r > n || n < 0 || r < 0) throw IllegalArgumentException("Need 0 ≤ r ≤ n")
                Result.success("nCr: ${factorial(n) / (factorial(r) * factorial(n - r))}")
            }
            Formula.LAW_OF_COSINES -> {
                val a = d("Side a"); val b = d("Side b"); val c = Math.toRadians(d("Angle C (degrees)"))
                val cSquared = a.pow(2) + b.pow(2) - 2 * a * b * cos(c)
                Result.success("Side c: ${sqrt(cSquared)}")
            }
        }
    } catch (e: Exception) {
        Result.failure(Exception("Invalid input: ${e.message}"))
    }

    private fun factorial(n: Int): Double {
        if (n < 0) throw IllegalArgumentException("Factorial needs n ≥ 0")
        var result = 1.0
        for (i in 2..n) result *= i
        return result
    }
}
