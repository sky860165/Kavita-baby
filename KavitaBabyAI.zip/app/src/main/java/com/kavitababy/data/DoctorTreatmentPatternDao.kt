// data/DoctorTreatmentPatternDao.kt
package com.kavitababy.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface DoctorTreatmentPatternDao {

    @Insert
    suspend fun insert(pattern: DoctorTreatmentPattern)

    /**
     * Same simple LIKE-based keyword match [PdfChunkDao]/[LearnedKnowledgeDao]
     * already use — good enough since diagnosis names/treatment text share
     * vocabulary the same way exam notes do, and it keeps this fully
     * on-device with no embeddings/network needed.
     */
    @Query("SELECT * FROM doctor_treatment_patterns WHERE searchableText LIKE '%' || :keyword || '%' ORDER BY createdAt DESC LIMIT 25")
    suspend fun searchByKeyword(keyword: String): List<DoctorTreatmentPattern>

    @Query("SELECT COUNT(*) FROM doctor_treatment_patterns")
    suspend fun count(): Int
}
