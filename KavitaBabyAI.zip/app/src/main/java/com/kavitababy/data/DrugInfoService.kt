// data/DrugInfoService.kt
package com.kavitababy.data

import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Pulls real, structured drug-label data from openFDA's public
 * `/drug/label.json` endpoint — free, no API key required, sourced
 * directly from FDA-submitted Structured Product Labeling (SPL)
 * documents. This is the "ground truth" layer: AIRepository combines
 * this raw label data across multiple drugs and asks Gemini to reason
 * over it logically (cross-referencing interactions, contraindications,
 * dosage overlap) rather than relying purely on the model's own training
 * data, which can be outdated or hallucinate specifics.
 *
 * IMPORTANT scope note, always surfaced to the doctor: openFDA is a
 * US-FDA database. Indian brand names (e.g. "Crocin" for paracetamol)
 * usually won't match directly — lookups are done by generic/active
 * ingredient name wherever possible, and Gemini is told explicitly when
 * a lookup came back empty so it can fall back to its own general
 * pharmacology knowledge rather than silently guessing FDA data that was
 * never actually found.
 */
class DrugInfoService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    data class DrugInfo(
        val queriedName: String,
        val brandName: String,
        val genericName: String,
        val manufacturer: String,
        val indications: String,
        val dosageAndAdministration: String,
        val contraindications: String,
        val warnings: String,
        val boxedWarning: String,
        val drugInteractions: String,
        val adverseReactions: String
    )

    /**
     * Looks up [drugName] against openFDA. Tries generic name first (more
     * likely to match across brands/countries), then falls back to brand
     * name search if that comes back empty. Returns null on no match or
     * any failure — callers (AIRepository) treat null as "no FDA data
     * found for this one", not as a hard error, since a doctor should
     * still get an answer built from Gemini's own knowledge in that case.
     */
    fun lookupDrug(drugName: String): DrugInfo? {
        val cleaned = drugName.trim()
        if (cleaned.isBlank()) return null

        return queryLabel("openfda.generic_name", cleaned)
            ?: queryLabel("openfda.brand_name", cleaned)
    }

    private fun queryLabel(field: String, drugName: String): DrugInfo? {
        val url = "https://api.fda.gov/drug/label.json".toHttpUrlOrNull()?.newBuilder()
            ?.addQueryParameter("search", "$field:\"${drugName}\"")
            ?.addQueryParameter("limit", "1")
            ?.build() ?: return null

        val request = Request.Builder().url(url).get().build()

        return try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return null
                val bodyString = response.body?.string().orEmpty()
                val json = JSONObject(bodyString)
                val results = json.optJSONArray("results")
                if (results == null || results.length() == 0) return null

                val result = results.getJSONObject(0)
                val openfda = result.optJSONObject("openfda")

                DrugInfo(
                    queriedName = drugName,
                    brandName = openfda?.optJSONArray("brand_name")?.optString(0).orEmpty(),
                    genericName = openfda?.optJSONArray("generic_name")?.optString(0).orEmpty(),
                    manufacturer = openfda?.optJSONArray("manufacturer_name")?.optString(0).orEmpty(),
                    indications = firstOf(result, "indications_and_usage"),
                    dosageAndAdministration = firstOf(result, "dosage_and_administration"),
                    contraindications = firstOf(result, "contraindications"),
                    warnings = firstOf(result, "warnings").ifBlank { firstOf(result, "warnings_and_cautions") },
                    boxedWarning = firstOf(result, "boxed_warning"),
                    drugInteractions = firstOf(result, "drug_interactions"),
                    adverseReactions = firstOf(result, "adverse_reactions")
                )
            }
        } catch (e: Exception) {
            null
        }
    }

    /** openFDA label fields are JSON arrays of section text (usually one element) — take the first, capped so one bloated section can't blow out the prompt. */
    private fun firstOf(result: JSONObject, field: String, maxChars: Int = 1200): String {
        val text = result.optJSONArray(field)?.optString(0).orEmpty()
        return if (text.length > maxChars) text.take(maxChars) + "..." else text
    }
}
