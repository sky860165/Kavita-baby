// data/VitalsCalculator.kt
package com.kavitababy.data

import kotlin.math.roundToInt

/**
 * Pure, offline clinical calculators — BMI, an estimated creatinine
 * clearance (used as a GFR proxy), pediatric/weight-based dosage, and
 * Apgar scoring. Deliberately has zero AI/network dependency: these are
 * fixed formulas, not something that should ever wait on Gemini or vary
 * run to run. Every function is a plain, stateless calculation so it can
 * be unit-tested and reused outside Compose easily.
 */
object VitalsCalculator {

    data class BmiResult(val bmi: Double, val category: String)

    /** Standard BMI = weight(kg) / height(m)^2. Category bands follow WHO's general (Asian bands differ slightly, so this is a general reference, not a diagnosis). */
    fun calculateBmi(weightKg: Double, heightCm: Double): BmiResult? {
        if (weightKg <= 0 || heightCm <= 0) return null
        val heightM = heightCm / 100.0
        val bmi = weightKg / (heightM * heightM)
        val category = when {
            bmi < 18.5 -> "Underweight"
            bmi < 25.0 -> "Normal"
            bmi < 30.0 -> "Overweight"
            else -> "Obese"
        }
        return BmiResult(roundTo(bmi, 1), category)
    }

    data class CrClResult(val crClMlMin: Double, val interpretation: String)

    /**
     * Estimated creatinine clearance via Cockcroft-Gault — the classic
     * bedside GFR-proxy formula (needs age/weight/serum creatinine, no lab
     * eGFR panel required). CrCl = ((140-age) * weight) / (72 * Scr), with
     * a 0.85 multiplier for female patients. This is an ESTIMATE for quick
     * bedside reference only, not a substitute for a lab-measured eGFR.
     */
    fun calculateCreatinineClearance(
        ageYears: Int,
        weightKg: Double,
        serumCreatinineMgDl: Double,
        isFemale: Boolean
    ): CrClResult? {
        if (ageYears <= 0 || weightKg <= 0 || serumCreatinineMgDl <= 0) return null
        var crCl = ((140 - ageYears) * weightKg) / (72 * serumCreatinineMgDl)
        if (isFemale) crCl *= 0.85
        val interpretation = when {
            crCl >= 90 -> "Normal"
            crCl >= 60 -> "Mildly reduced"
            crCl >= 30 -> "Moderately reduced"
            crCl >= 15 -> "Severely reduced"
            else -> "Kidney failure range"
        }
        return CrClResult(roundTo(crCl, 1), interpretation)
    }

    data class DosageResult(val perDoseMg: Double, val perDayMg: Double)

    /**
     * Weight-based (mg/kg) dosage — total per-dose and per-day amount from
     * a dose-per-kg figure (as printed on a drug label/formulary) and the
     * patient's weight. Deliberately does NOT suggest a dose-per-kg number
     * itself — the doctor supplies that from the formulary/label; this
     * just does the multiplication so nothing gets miscalculated by hand
     * mid-consult.
     */
    fun calculateDosage(weightKg: Double, dosePerKgMg: Double, dosesPerDay: Int): DosageResult? {
        if (weightKg <= 0 || dosePerKgMg <= 0 || dosesPerDay <= 0) return null
        val perDose = weightKg * dosePerKgMg
        return DosageResult(roundTo(perDose, 2), roundTo(perDose * dosesPerDay, 2))
    }

    data class ApgarResult(val total: Int, val interpretation: String)

    /**
     * Apgar score — sum of 5 components each scored 0-2 (Appearance/color,
     * Pulse/heart rate, Grimace/reflex irritability, Activity/muscle tone,
     * Respiration). Each parameter is passed in pre-scored (0/1/2) since
     * the actual clinical judgement of "is the grimace weak or strong"
     * stays with the doctor/nurse at the bedside — this just totals and
     * labels the standard bands.
     */
    fun calculateApgar(
        appearance: Int,
        pulse: Int,
        grimace: Int,
        activity: Int,
        respiration: Int
    ): ApgarResult? {
        val scores = listOf(appearance, pulse, grimace, activity, respiration)
        if (scores.any { it !in 0..2 }) return null
        val total = scores.sum()
        val interpretation = when {
            total >= 7 -> "Normal"
            total >= 4 -> "Moderately abnormal — close monitoring"
            else -> "Low — needs immediate attention"
        }
        return ApgarResult(total, interpretation)
    }

    private fun roundTo(value: Double, decimals: Int): Double {
        val factor = Math.pow(10.0, decimals.toDouble())
        return (value * factor).roundToInt() / factor
    }
}
