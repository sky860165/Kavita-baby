// data/ReminderReceiver.kt
package com.kavitababy.data

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.kavitababy.MainActivity
import com.kavitababy.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Fires when a scheduled follow-up reminder's AlarmManager alarm goes off
 * (see [ReminderScheduler]) and shows a notification. Also marks the
 * reminder row as completed in Room, so it drops out of the "Upcoming
 * Follow-ups" list once it's actually fired.
 */
class ReminderReceiver : BroadcastReceiver() {

    companion object {
        const val EXTRA_REMINDER_ID = "reminder_id"
        const val EXTRA_PATIENT_NAME = "patient_name"
        const val EXTRA_NOTE = "note"
        const val CHANNEL_ID = "kavita_followup_reminders"
        private const val CHANNEL_NAME = "Follow-up Reminders"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val reminderId = intent.getLongExtra(EXTRA_REMINDER_ID, -1L)
        val patientName = intent.getStringExtra(EXTRA_PATIENT_NAME).orEmpty()
        val note = intent.getStringExtra(EXTRA_NOTE).orEmpty()

        showNotification(context, reminderId, patientName, note)

        // Mark completed in the background — goAsync() keeps the
        // BroadcastReceiver alive long enough for this suspend DB write to
        // finish, since a plain onReceive() would otherwise be killed by
        // the OS the moment this function returns, before the coroutine
        // below gets a chance to actually run.
        if (reminderId != -1L) {
            val pendingResult = goAsync()
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    KavitaDatabase.getInstance(context.applicationContext)
                        .followUpReminderDao()
                        .markCompleted(reminderId)
                } catch (e: Exception) {
                    // Notification already shown either way — a failed
                    // completion-flag write just means this reminder might
                    // still show under "Upcoming" even though it already
                    // fired, which is harmless (worst case: doctor sees a
                    // stale entry they can manually dismiss).
                } finally {
                    pendingResult.finish()
                }
            }
        }
    }

    private fun showNotification(context: Context, reminderId: Long, patientName: String, note: String) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Patient follow-up reminders scheduled from Doctor Mode"
            }
            notificationManager.createNotificationChannel(channel)
        }

        val openAppIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentIntent = PendingIntent.getActivity(
            context,
            reminderId.toInt(),
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title = if (patientName.isNotBlank()) "Follow-up: $patientName" else "Follow-up reminder"
        val body = note.ifBlank { "Patient ko check karne ka time ho gaya" }

        // ic_attach reused as the notification's small icon — a
        // dedicated bell/reminder icon would look better but doesn't
        // exist in the drawable set yet, and a functioning reminder with
        // a mismatched icon beats no reminder at all.
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_attach)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(contentIntent)
            .build()

        notificationManager.notify(reminderId.toInt(), notification)
    }
}
