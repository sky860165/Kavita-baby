// data/ChatMessageEntity.kt
package com.kavitababy.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Persisted copy of a chat [com.kavitababy.ui.Message] so conversation
 * history survives the app being killed and reopened.
 *
 * Before this, `studyMessages`/`doctorMessages` in ChatScreen were plain
 * `remember { }` state — held only in memory. Android can kill a
 * backgrounded app's process at any time (low memory, long time away,
 * OEM battery-saver aggressiveness on MIUI etc), and on reopen Compose
 * starts a brand new composition with empty lists. That's what made it
 * look like "purane messages ghayab ho gaye" — they weren't deleted, they
 * were just never saved anywhere to begin with.
 *
 * [mode] is "STUDY" or "DOCTOR" so each tab's history is stored and
 * restored separately, matching the existing in-memory split.
 * [sortOrder] is a simple increasing index (not wall-clock time) so
 * ordering survives even if multiple messages land in the same
 * millisecond.
 */
@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey
    val id: String,
    val mode: String,
    val sortOrder: Long,
    val text: String,
    val isUser: Boolean,
    val question: String,
    val isHistorical: Boolean
)
