// data/CrashHandler.kt
package com.kavitababy.data

import android.content.Context
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * A small, dependency-free crash logger.
 *
 * Firebase Crashlytics is the usual production answer here, but it needs
 * its own Firebase console project + a google-services.json file that has
 * to be generated outside this codebase — not something that can be wired
 * up sight-unseen. This gives the same core benefit (know *why* the app
 * died last time, without needing the phone plugged into a debugger at
 * the exact moment it crashes) with zero external setup: every uncaught
 * exception gets written to a plain text file in the app's private
 * storage, then the default handler still runs (so Android's own
 * "app has stopped" behavior is unchanged).
 *
 * On the next launch, [consumeLastCrashIfAny] returns the most recent
 * crash log once (and deletes it), so ChatScreen/MainActivity can surface
 * it — or it can be pulled anytime via [exportAllCrashLogs] and shared
 * through the same FileProvider pattern as every other export in this app.
 */
object CrashHandler {

    private const val CRASH_DIR = "crash_logs"
    private val timestampFormat = SimpleDateFormat("yyyy-MM-dd_HHmmss", Locale.ENGLISH)

    /** Call once, as early as possible — [KavitaBabyApp.onCreate] is the right place. */
    fun install(context: Context) {
        val appContext = context.applicationContext
        val existingHandler = Thread.getDefaultUncaughtExceptionHandler()

        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                writeCrashLog(appContext, thread, throwable)
            } catch (e: Exception) {
                // Logging the crash must never itself throw and mask the
                // real crash — if this fails, just fall through silently.
            }
            // Preserve normal Android crash behavior (process death,
            // "app has stopped" dialog) — this handler only adds logging
            // on top, it never swallows the crash.
            existingHandler?.uncaughtException(thread, throwable)
                ?: Runtime.getRuntime().exit(2)
        }
    }

    private fun writeCrashLog(context: Context, thread: Thread, throwable: Throwable) {
        val dir = File(context.filesDir, CRASH_DIR).apply { mkdirs() }
        val timestamp = timestampFormat.format(Date())
        val file = File(dir, "crash_$timestamp.txt")

        val stackTrace = StringWriter().also { throwable.printStackTrace(PrintWriter(it)) }.toString()
        file.writeText(
            buildString {
                appendLine("Kavita Baby AI crash log")
                appendLine("Time: ${Date()}")
                appendLine("Thread: ${thread.name}")
                appendLine("App version: ${getVersionName(context)}")
                appendLine("Android: ${android.os.Build.VERSION.RELEASE} (SDK ${android.os.Build.VERSION.SDK_INT})")
                appendLine("Device: ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}")
                appendLine("-".repeat(50))
                append(stackTrace)
            }
        )

        // Keep only the most recent 20 logs so this can never grow
        // unbounded on a phone that crashes repeatedly during development.
        dir.listFiles()?.sortedByDescending { it.lastModified() }
            ?.drop(20)
            ?.forEach { it.delete() }
    }

    private fun getVersionName(context: Context): String = try {
        context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "unknown"
    } catch (e: Exception) {
        "unknown"
    }

    /**
     * Returns the single most recent crash log's text if the app crashed
     * since this was last called, and deletes it so it's only ever
     * surfaced once (as a one-time "here's what happened last time"
     * message in chat, not a repeating nag on every future launch).
     */
    fun consumeLastCrashIfAny(context: Context): String? {
        val dir = File(context.filesDir, CRASH_DIR)
        val latest = dir.listFiles()?.maxByOrNull { it.lastModified() } ?: return null
        return try {
            val text = latest.readText()
            latest.delete()
            text
        } catch (e: Exception) {
            null
        }
    }

    /** All crash logs still on disk, most recent first — for a manual "export crash logs" action. */
    fun allCrashLogFiles(context: Context): List<File> {
        val dir = File(context.filesDir, CRASH_DIR)
        return dir.listFiles()?.sortedByDescending { it.lastModified() } ?: emptyList()
    }
}
