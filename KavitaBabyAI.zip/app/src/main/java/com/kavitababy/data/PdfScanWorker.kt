// data/PdfScanWorker.kt
package com.kavitababy.data

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

/**
 * Runs [PdfScannerService.scanAllPdfs] as a genuine background job via
 * WorkManager, independent of whether ChatScreen (or the app at all) is
 * currently open. Scheduled periodically by [PdfScanScheduler] so a large
 * backlog — e.g. 20GB spread across many PDFs — keeps making steady
 * progress in the background between app opens, rather than only ever
 * advancing during the few minutes someone happens to have the app in
 * the foreground.
 *
 * A time budget well under WorkManager's own execution window (the system
 * can stop a plain Worker after ~10 minutes) so [PdfScannerService]'s own
 * graceful stop-and-return-partial-result kicks in first, same as the
 * foreground path in ChatScreen — no functionality is duplicated, this
 * just gives the existing resumable scan a second way to get invoked.
 */
class PdfScanWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        return try {
            val scanner = PdfScannerService(applicationContext)
            val result = scanner.scanAllPdfs(
                forceRescan = false,
                timeBudgetMs = 8 * 60 * 1000L
            )
            // If there's still more to do (timed out with files remaining),
            // ask WorkManager to run this again soon rather than waiting
            // for the next full periodic interval — keeps a big backlog
            // moving at a reasonable pace instead of one small bite every
            // several hours.
            if (result.timedOut && result.pdfsRemaining > 0) Result.retry() else Result.success()
        } catch (e: Exception) {
            Result.failure()
        }
    }
}
