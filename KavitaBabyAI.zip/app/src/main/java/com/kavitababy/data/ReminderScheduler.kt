// data/ReminderScheduler.kt
package com.kavitababy.data

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

/**
 * Thin wrapper around AlarmManager for scheduling/cancelling a single
 * follow-up reminder's notification. Each [FollowUpReminder] row's
 * database [FollowUpReminder.id] doubles as its AlarmManager request code
 * so scheduling and cancelling always target the exact same alarm.
 *
 * Uses setExactAndAllowWhileIdle rather than plain setExact — Doze mode on
 * modern Android would otherwise delay the alarm by potentially hours,
 * defeating the point of a doctor scheduling a reminder for a specific
 * time. This does NOT need the "Alarms & reminders" special access screen
 * (that's only for setExact with alarm-clock-style UI treatment); regular
 * apps can call setExactAndAllowWhileIdle without extra user permission.
 */
object ReminderScheduler {

    private fun buildPendingIntent(context: Context, reminder: FollowUpReminder): PendingIntent {
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            putExtra(ReminderReceiver.EXTRA_REMINDER_ID, reminder.id)
            putExtra(ReminderReceiver.EXTRA_PATIENT_NAME, reminder.patientDisplayName)
            putExtra(ReminderReceiver.EXTRA_NOTE, reminder.note)
        }
        return PendingIntent.getBroadcast(
            context,
            reminder.id.toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun schedule(context: Context, reminder: FollowUpReminder) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pendingIntent = buildPendingIntent(context, reminder)

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    reminder.triggerAtMillis,
                    pendingIntent
                )
            } else {
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, reminder.triggerAtMillis, pendingIntent)
            }
        } catch (e: SecurityException) {
            // Some OEM builds (rare) restrict exact alarms without the
            // dedicated SCHEDULE_EXACT_ALARM permission dialog ever having
            // been shown — fall back to an inexact alarm rather than
            // silently failing to schedule anything at all. It may fire a
            // little late, which is still far better than never firing.
            alarmManager.set(AlarmManager.RTC_WAKEUP, reminder.triggerAtMillis, pendingIntent)
        }
    }

    fun cancel(context: Context, reminder: FollowUpReminder) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarmManager.cancel(buildPendingIntent(context, reminder))
    }
}
