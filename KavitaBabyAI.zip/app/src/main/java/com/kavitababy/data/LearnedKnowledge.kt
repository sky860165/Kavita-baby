// data/LearnedKnowledge.kt
package com.kavitababy.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * A question-answer pair the app learned by actually asking Gemini (or
 * fetching a doctor-chosen URL) — saved locally so the SAME question (or a
 * close match) can be answered offline next time, without needing the
 * internet again.
 *
 * This is intentionally NOT a bulk "download all of medicine" store. It
 * only ever grows one real conversation at a time:
 *  - Every genuine (non-fallback) answer from a real Study/Doctor Mode
 *    question gets saved here automatically (see [AIRepository.callAI]).
 *  - A doctor can also explicitly fetch one specific webpage (a trusted
 *    guideline page, for example) via the "Learn from URL" action, and
 *    that page's text gets saved here too.
 * Nothing is scraped, crawled, or bulk-downloaded on its own — every row
 * traces back to a specific question the doctor actually asked, or a
 * specific URL the doctor actually chose.
 *
 * [sourceType] distinguishes how a row got here, since a doctor should be
 * able to tell "this came from Kavita's own answer" apart from "this came
 * from a webpage I fetched" apart from "this came from my own uploaded
 * PDF" (that last one lives in [PdfChunk], not here).
 */
@Entity(tableName = "learned_knowledge")
data class LearnedKnowledge(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val question: String,
    val answer: String,
    // Lowercased, whitespace-normalized copy of question+answer for fast
    // keyword search — mirrors PdfChunk.searchableText's role exactly.
    val searchableText: String,
    val sourceType: String, // "ai_answer" or "web_fetch"
    // For sourceType == "web_fetch": the URL it came from, so a doctor can
    // trace a saved answer back to its source. Blank for "ai_answer" rows.
    val sourceUrl: String = "",
    val savedAt: Long = System.currentTimeMillis()
)
