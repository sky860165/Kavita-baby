// data/MedicalWebSearchService.kt
package com.kavitababy.data

import com.kavitababy.BuildConfig
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Live web search for Doctor Mode, restricted to the same handful of
 * sites a real doctor actually reaches for when they Google something
 * mid-case — NOT the open web. Uses Google's Custom Search JSON API
 * (GCP_API_KEY1 + a Programmable Search Engine ID from
 * local.properties/GitHub Secrets).
 *
 * Two layers of restriction, both applied:
 *  1. The Programmable Search Engine itself should ideally be configured
 *     (at https://programmablesearchengine.google.com) to only index the
 *     trusted domains below — this is the STRONGEST restriction since
 *     Google never even considers other sites.
 *  2. As a safety net regardless of how the search engine is configured,
 *     every result returned is filtered again here against
 *     [trustedDomains] before being used — so even if the search engine
 *     config is ever loosened or misconfigured, a random blog/forum
 *     result can never silently reach the AI prompt as if it were a
 *     trusted medical source.
 *
 * This is NOT a general web browser — it never fetches arbitrary pages,
 * only search result snippets already returned by the API, same as how
 * [RagSearchEngine] only ever returns short indexed chunks, not whole
 * documents.
 */
class MedicalWebSearchService {

    /**
     * Domains considered trustworthy enough to actually influence a
     * diagnosis/treatment answer. Deliberately conservative — this list
     * favors major health authorities, government/public-health bodies,
     * and established clinical reference sites over anything
     * user-editable (forums, wikis, personal blogs), which is exactly
     * the class of site a careful doctor would also avoid relying on.
     */
    private val trustedDomains = setOf(
        "who.int",
        "ncbi.nlm.nih.gov",
        "pubmed.ncbi.nlm.nih.gov",
        "nih.gov",
        "medlineplus.gov",
        "cdc.gov",
        "mayoclinic.org",
        "icmr.gov.in",
        "icmr.nic.in",
        "mohfw.gov.in",
        "nhp.gov.in",
        "nice.org.uk",
        "cochranelibrary.com",
        "bmj.com",
        "thelancet.com",
        "nejm.org",
        "msdmanuals.com",
        "medscape.com"
    )

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    data class WebResult(val title: String, val snippet: String, val url: String, val domain: String)

    /**
     * Runs [query] through Google Custom Search, restricted to
     * [trustedDomains], and returns up to [maxResults] hits. Returns an
     * empty list (never throws) on any failure — missing/blank API key,
     * network error, quota exceeded, or zero results — so callers can
     * treat "no live web context" exactly like "no PDF context" and fall
     * back to the AI's own general knowledge without special-casing this
     * path.
     */
    fun search(query: String, maxResults: Int = 4): List<WebResult> {
        val apiKey = BuildConfig.GCP_API_KEY1
        val searchEngineId = BuildConfig.GCP_SEARCH_ENGINE_ID
        if (apiKey.isBlank() || searchEngineId.isBlank() || query.isBlank()) return emptyList()

        // siteSearch restriction is applied server-side too, via an "OR
        // site:x OR site:y..." style query suffix — this is the request-
        // level restriction; the trustedDomains filter below the response
        // is the second, independent safety net described in the class doc.
        val siteFilter = trustedDomains.joinToString(" OR ") { "site:$it" }
        val fullQuery = "$query ($siteFilter)"

        val url = buildSearchUrl(apiKey, searchEngineId, fullQuery, maxResults) ?: return emptyList()

        val request = Request.Builder().url(url).get().build()

        return try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return emptyList()
                val bodyString = response.body?.string().orEmpty()
                val json = JSONObject(bodyString)
                val items = json.optJSONArray("items") ?: return emptyList()

                val results = mutableListOf<WebResult>()
                for (i in 0 until items.length()) {
                    val item = items.getJSONObject(i)
                    val link = item.optString("link")
                    val domain = extractDomain(link)
                    // Second-layer filter — only keep results whose domain
                    // actually matches the trusted list, regardless of
                    // what the search API returned.
                    if (trustedDomains.none { domain == it || domain.endsWith(".$it") }) continue

                    results.add(
                        WebResult(
                            title = item.optString("title"),
                            snippet = item.optString("snippet"),
                            url = link,
                            domain = domain
                        )
                    )
                    if (results.size >= maxResults) break
                }
                results
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun extractDomain(url: String): String {
        return try {
            val host = java.net.URI(url).host ?: return ""
            if (host.startsWith("www.")) host.removePrefix("www.") else host
        } catch (e: Exception) {
            ""
        }
    }

    /** Builds the Custom Search request URL with query params. */
    private fun buildSearchUrl(apiKey: String, cx: String, query: String, num: Int): okhttp3.HttpUrl? {
        return "https://www.googleapis.com/customsearch/v1".toHttpUrlOrNull()?.newBuilder()
            ?.addQueryParameter("key", apiKey)
            ?.addQueryParameter("cx", cx)
            ?.addQueryParameter("q", query)
            ?.addQueryParameter("num", num.coerceIn(1, 10).toString())
            ?.build()
    }
}
