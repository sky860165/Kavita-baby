// data/MediaScannerService.kt
package com.kavitababy.data

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import kotlinx.coroutines.withContext
import java.io.File
import java.util.zip.ZipInputStream

/**
 * Handles every non-PDF file type picked through the 📎 attach button:
 * images, videos, audio, and zip archives.
 *
 * Images/videos/audio are read into memory and Base64-encoded so they can
 * be sent as inline_data to Gemini's multimodal API (see
 * AIRepository.getMediaResponse) — Gemini natively understands all three
 * (OCR + visual description for images, frame-by-frame understanding for
 * video, transcription + understanding for audio).
 *
 * Zip archives are extracted into the app's private cache dir; every file
 * inside is classified by extension and queued up as its own MediaFile so
 * each one gets read/understood individually (nested zips are also
 * unpacked, up to a small depth limit to avoid a zip-bomb style loop).
 */
class MediaScannerService(private val context: Context) {

    /** A single file ready to be sent to Gemini or otherwise processed. */
    data class MediaFile(
        val displayName: String,
        val mimeType: String,
        val base64Data: String,
        val kind: Kind
    )

    enum class Kind { IMAGE, VIDEO, AUDIO, UNSUPPORTED }

    sealed class LoadResult {
        data class Success(
            val files: List<MediaFile>,
            // PDFs found inside a zip, already indexed into Room via
            // PdfScannerService.indexExtractedFile — reported separately
            // from `files` since they're handled through the RAG/chunk
            // pipeline, not sent to Gemini as inline_data like the rest.
            val indexedPdfs: List<PdfScannerService.PickResult> = emptyList()
        ) : LoadResult()
        data class Failure(val reason: String) : LoadResult()
    }

    private val imageExtensions = setOf("jpg", "jpeg", "png", "webp", "gif", "bmp", "heic", "heif")
    private val videoExtensions = setOf("mp4", "mkv", "webm", "3gp", "mov", "avi")
    private val audioExtensions = setOf("mp3", "wav", "m4a", "aac", "ogg", "flac", "amr", "opus")

    // 25MB safety cap isn't a hard block — it's just skipped with a clear
    // reason so one giant file doesn't silently hang the whole request or
    // blow past Gemini's own inline-data size limits (base64 inflates size
    // by ~33%, and there's a real request-size ceiling on the API side).
    private val maxInlineBytes = 25L * 1024 * 1024

    /**
     * Loads whatever the user picked through the attach button. If it's a
     * zip, unpacks it and returns every supported file inside. Otherwise
     * returns the single picked file wrapped in a list.
     */
    suspend fun loadPicked(uri: Uri): LoadResult = withContext(kotlinx.coroutines.Dispatchers.IO) {
        val name = queryDisplayName(uri) ?: "file_${System.currentTimeMillis()}"

        if (name.endsWith(".zip", ignoreCase = true)) {
            return@withContext loadZip(uri, name)
        }

        val bytes = try {
            context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
        } catch (e: Exception) {
            null
        } ?: return@withContext LoadResult.Failure("File open nahi ho payi")

        if (bytes.size.toLong() > maxInlineBytes) {
            return@withContext LoadResult.Failure(
                "\"$name\" bahut badi hai (${bytes.size / (1024 * 1024)}MB) — abhi ke liye " +
                    "25MB tak ki files hi bhej sakte ho, chhoti clip/photo try karo"
            )
        }

        val kind = classify(name)
        if (kind == Kind.UNSUPPORTED) {
            return@withContext LoadResult.Failure(
                "\"$name\" is file type ko main samajh nahi paati abhi (sirf image, " +
                    "video, audio, PDF, ya zip)"
            )
        }

        val mime = mimeTypeFor(name, kind)
        val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
        LoadResult.Success(listOf(MediaFile(name, mime, b64, kind)))
    }

    private suspend fun loadZip(uri: Uri, zipDisplayName: String): LoadResult {
        val extractDir = File(context.cacheDir, "zip_extract_${System.currentTimeMillis()}")
        extractDir.mkdirs()

        try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                unzipInto(input, extractDir)
            } ?: return LoadResult.Failure("Zip file open nahi ho payi")

            val allFiles = mutableListOf<File>()
            collectFiles(extractDir, allFiles)

            if (allFiles.isEmpty()) {
                return LoadResult.Failure("\"$zipDisplayName\" mein koi file nahi mili")
            }

            val results = mutableListOf<MediaFile>()
            val indexedPdfs = mutableListOf<PdfScannerService.PickResult>()
            var skippedCount = 0
            val pdfScanner = PdfScannerService(context)

            for (file in allFiles) {
                // PDFs inside a zip don't go through the image/video/audio
                // classifier below (they'd just fall out as UNSUPPORTED and
                // get silently dropped) — instead they're indexed into Room
                // the same way a directly-picked PDF is, so their content
                // becomes searchable via RAG like any other indexed PDF.
                if (file.name.endsWith(".pdf", ignoreCase = true)) {
                    if (file.length() > maxInlineBytes) {
                        skippedCount++
                        continue
                    }
                    indexedPdfs.add(pdfScanner.indexExtractedFile(file, file.name))
                    continue
                }

                val kind = classify(file.name)
                if (kind == Kind.UNSUPPORTED) {
                    skippedCount++
                    continue
                }
                if (file.length() > maxInlineBytes) {
                    skippedCount++
                    continue
                }
                try {
                    val bytes = file.readBytes()
                    val mime = mimeTypeFor(file.name, kind)
                    val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
                    results.add(MediaFile(file.name, mime, b64, kind))
                } catch (e: Exception) {
                    skippedCount++
                }
            }

            if (results.isEmpty() && indexedPdfs.isEmpty()) {
                return LoadResult.Failure(
                    "\"$zipDisplayName\" mein $skippedCount files thi lekin koi bhi " +
                        "samajhne layak format (image/video/audio/PDF) mein nahi thi"
                )
            }

            return LoadResult.Success(results, indexedPdfs)
        } catch (e: Exception) {
            return LoadResult.Failure(e.message ?: "Zip extract karte waqt kuch galat ho gaya")
        } finally {
            extractDir.deleteRecursively()
        }
    }

    /** Extracts a zip stream into [outDir], guarding against path traversal (zip-slip). */
    private fun unzipInto(input: java.io.InputStream, outDir: File) {
        ZipInputStream(input).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                val safeName = File(entry.name).name // strip any directory traversal in the entry name
                if (safeName.isNotBlank() && !entry.isDirectory) {
                    val outFile = File(outDir, "${System.nanoTime()}_$safeName")
                    outFile.outputStream().use { output -> zis.copyTo(output) }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
    }

    private fun collectFiles(dir: File, out: MutableList<File>) {
        dir.listFiles()?.forEach { entry ->
            if (entry.isDirectory) collectFiles(entry, out) else out.add(entry)
        }
    }

    /** Result of a one-time screenshot folder scan, triggered only after explicit user consent. */
    data class ScreenshotScanResult(
        val screenshotsFound: Int,
        val screenshotsRead: Int,
        val summaries: List<Pair<String, String>> // fileName to Gemini's understanding of it
    )

    // Common screenshot folder names across stock Android, MIUI/HyperOS,
    // Samsung, and most other OEM skins — checked case-insensitively.
    private val screenshotFolderNames = setOf("screenshots", "screenshot")

    /**
     * Finds image files sitting in a device's Screenshots folder(s) and
     * hands each one to the caller's [onEach] for reading (OCR + summary
     * via Gemini). This is NEVER called automatically — MainActivity only
     * triggers it once, the very first time, after the user has explicitly
     * tapped "Haan, screenshots padho" on a one-time consent dialog. There
     * is no background/periodic scanning: this always runs as a single
     * on-demand pass, same as the manual PDF folder scan.
     *
     * Requires the same storage access (All Files Access on Android 11+,
     * READ_EXTERNAL_STORAGE below that) already used for the PDF scan — no
     * extra permission needed beyond what's already requested in
     * MainActivity.
     */
    suspend fun scanScreenshotsFolder(
        maxFiles: Int = 30,
        onEach: suspend (fileName: String, mimeType: String, base64Data: String) -> Unit
    ): Int = withContext(kotlinx.coroutines.Dispatchers.IO) {
        val root = android.os.Environment.getExternalStorageDirectory()
        val screenshotFiles = mutableListOf<File>()
        findScreenshotFiles(root, screenshotFiles)

        // Newest first, capped — screenshot folders can have hundreds of
        // files, and reading every single one through Gemini on a single
        // consent tap would be slow and use a lot of data. Most-recent-first
        // means the cap still surfaces what the user is most likely to
        // actually want summarized.
        val toProcess = screenshotFiles.sortedByDescending { it.lastModified() }.take(maxFiles)

        var processed = 0
        for (file in toProcess) {
            if (file.length() > maxInlineBytes) continue
            try {
                val bytes = file.readBytes()
                val kind = classify(file.name)
                if (kind != Kind.IMAGE) continue
                val mime = mimeTypeFor(file.name, kind)
                val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
                onEach(file.name, mime, b64)
                processed++
            } catch (e: Exception) {
                continue
            }
        }
        processed
    }

    private fun findScreenshotFiles(dir: File, out: MutableList<File>, depth: Int = 0) {
        if (depth > 8) return
        val entries = try { dir.listFiles() } catch (e: Exception) { null } ?: return

        for (entry in entries) {
            if (entry.name.startsWith(".")) continue
            if (entry.isDirectory) {
                if (entry.name in setOf("Android", "data", "obb")) continue
                if (entry.name.lowercase() in screenshotFolderNames) {
                    // Inside a screenshots folder — collect image files
                    // directly, no need to recurse further into it.
                    entry.listFiles()?.forEach { f ->
                        if (f.isFile && classify(f.name) == Kind.IMAGE) out.add(f)
                    }
                } else {
                    findScreenshotFiles(entry, out, depth + 1)
                }
            }
        }
    }

    private fun classify(fileName: String): Kind {
        val ext = fileName.substringAfterLast('.', "").lowercase()
        return when (ext) {
            in imageExtensions -> Kind.IMAGE
            in videoExtensions -> Kind.VIDEO
            in audioExtensions -> Kind.AUDIO
            else -> Kind.UNSUPPORTED
        }
    }

    private fun mimeTypeFor(fileName: String, kind: Kind): String {
        val ext = fileName.substringAfterLast('.', "").lowercase()
        return when (kind) {
            Kind.IMAGE -> when (ext) {
                "jpg", "jpeg" -> "image/jpeg"
                "png" -> "image/png"
                "webp" -> "image/webp"
                "gif" -> "image/gif"
                "heic" -> "image/heic"
                "heif" -> "image/heif"
                else -> "image/jpeg"
            }
            Kind.VIDEO -> when (ext) {
                "mp4" -> "video/mp4"
                "webm" -> "video/webm"
                "3gp" -> "video/3gpp"
                "mov" -> "video/quicktime"
                else -> "video/mp4"
            }
            Kind.AUDIO -> when (ext) {
                "mp3" -> "audio/mp3"
                "wav" -> "audio/wav"
                "m4a", "aac" -> "audio/aac"
                "ogg", "opus" -> "audio/ogg"
                "flac" -> "audio/flac"
                else -> "audio/mp3"
            }
            Kind.UNSUPPORTED -> "application/octet-stream"
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        return try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (cursor.moveToFirst() && nameIndex >= 0) cursor.getString(nameIndex) else null
            }
        } catch (e: Exception) {
            null
        }
    }
}
