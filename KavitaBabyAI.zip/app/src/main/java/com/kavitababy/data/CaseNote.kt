// data/CaseNote.kt
package com.kavitababy.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * A single Doctor Mode case entry, saved locally on-device only.
 *
 * [patientId] links this note to a [PatientCase] in the patient list —
 * nullable so older/ad-hoc case notes (not tied to any patient, e.g. a
 * quick reference question) remain valid. When a doctor starts a Case
 * Workup from the patient list, every note/finding/analysis/treatment
 * generated during that workup gets this field set.
 *
 * [caseLabel] is free text for the doctor's own reference — kept even
 * when [patientId] is set, since it's still useful as a short summary
 * label distinct from the full symptoms text.
 */
@Entity(tableName = "case_notes")
data class CaseNote(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val caseLabel: String,
    val ageGender: String,
    val symptoms: String,
    val history: String,
    val aiSuggestion: String,
    val createdAt: Long = System.currentTimeMillis(),
    val patientId: Long? = null
)
