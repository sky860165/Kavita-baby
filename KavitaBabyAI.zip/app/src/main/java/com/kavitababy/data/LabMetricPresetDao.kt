// data/LabMetricPresetDao.kt
package com.kavitababy.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query

@Dao
interface LabMetricPresetDao {

    @Insert
    suspend fun insert(preset: LabMetricPreset): Long

    @Insert
    suspend fun insertAll(presets: List<LabMetricPreset>)

    /** Built-ins first, then custom ones — each group in creation order. */
    @Query("SELECT * FROM lab_metric_presets ORDER BY isBuiltIn DESC, sortOrder ASC")
    suspend fun getAll(): List<LabMetricPreset>

    @Query("SELECT COUNT(*) FROM lab_metric_presets")
    suspend fun count(): Int

    /** Prevents adding "BP Systolic" twice under two different presets by accident. */
    @Query("SELECT COUNT(*) FROM lab_metric_presets WHERE name = :name COLLATE NOCASE")
    suspend fun countByName(name: String): Int

    @Delete
    suspend fun delete(preset: LabMetricPreset)
}
