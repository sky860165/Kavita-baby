// data/RagSearchEngine.kt
package com.kavitababy.data

import android.content.Context

/**
 * Lightweight, on-device "search" over indexed PDF chunks AND previously
 * learned Q&A pairs — no embeddings, no network call needed just to find
 * relevant text. Good enough for exam notes where questions tend to share
 * vocabulary with the source material.
 *
 * Two sources are searched together:
 *  - [PdfChunk] — text indexed from PDFs on the phone (including OCR'd
 *    scanned pages).
 *  - [LearnedKnowledge] — genuine answers Kavita has actually given before
 *    (auto-saved by [com.kavitababy.ai.AIRepository]) plus any pages a
 *    doctor explicitly fetched from a URL — so a question asked once while
 *    online can be answered offline the next time, without needing a PDF
 *    for it at all.
 *
 * Flow:
 *  1. Break the question into meaningful keywords (drop common stop words).
 *  2. Expand keywords through [MedicalSynonyms] — a Hinglish/colloquial term
 *     like "bukhar" also searches for "fever", so content that only uses
 *     the English medical term still gets found.
 *  3. Pull candidate rows from both Room tables that contain at least one
 *     keyword (original or expanded).
 *  4. Score each candidate by how many ORIGINAL keywords it contains
 *     (+ bonus for exact phrase matches) and return the top few, merged
 *     across both sources — scoring stays keyed to the original terms so a
 *     row matched only through a synonym doesn't unfairly outscore one that
 *     matched the doctor's actual words.
 */
class RagSearchEngine(context: Context) {

    private val pdfDao = KavitaDatabase.getInstance(context).pdfChunkDao()
    private val knowledgeDao = KavitaDatabase.getInstance(context).learnedKnowledgeDao()

    private val stopWords = setOf(
        "the", "a", "an", "is", "are", "was", "were", "what", "when", "where",
        "how", "why", "who", "which", "of", "in", "on", "at", "to", "for",
        "and", "or", "kya", "hai", "ka", "ki", "ke", "kaise", "kyun", "mein",
        "se", "ko", "aur", "ye", "wo", "hain", "tha", "thi"
    )

    /**
     * [pdfName] doubles as a general "source label" across both underlying
     * tables — for a PDF hit it's the actual file name; for a learned Q&A
     * hit it's "Kavita's saved answer" or the fetched URL, so callers/UI
     * that just display "${pdfName}, page ${pageNumber}" still make sense
     * without needing a separate source-kind field threaded everywhere.
     * [pageNumber] is 0 for learned-knowledge hits (no page concept there).
     */
    data class RelevantChunk(val pdfName: String, val pageNumber: Int, val text: String, val score: Int)

    /**
     * Returns the top [maxChunks] most relevant chunks for [question]
     * across PDFs and previously learned answers combined, or an empty
     * list if nothing indexed/learned seems related — callers should treat
     * an empty list as "no local context available" and fall back to
     * general knowledge.
     */
    suspend fun findRelevantChunks(question: String, maxChunks: Int = 4): List<RelevantChunk> {
        val originalKeywords = extractKeywords(question)
        if (originalKeywords.isEmpty()) return emptyList()

        // Expand single-word keywords ("bukhar" -> also "fever") plus any
        // multi-word Hinglish phrases found in the raw question ("sar
        // dard" -> also "headache") — phrases can't come out of
        // extractKeywords() since that splits on whitespace, so they're
        // detected separately against the normalized question text.
        val searchKeywords = (originalKeywords.flatMap { MedicalSynonyms.expand(it) } +
            expandPhrases(question)).distinct()

        val pdfCandidates = mutableMapOf<Long, PdfChunk>()
        val knowledgeCandidates = mutableMapOf<Long, LearnedKnowledge>()
        for (keyword in searchKeywords) {
            pdfDao.searchByKeyword(keyword).forEach { chunk -> pdfCandidates[chunk.id] = chunk }
            knowledgeDao.searchByKeyword(keyword).forEach { entry -> knowledgeCandidates[entry.id] = entry }
        }

        if (pdfCandidates.isEmpty() && knowledgeCandidates.isEmpty()) return emptyList()

        val scoredPdf = pdfCandidates.values.map { chunk ->
            val score = scoreChunk(chunk.searchableText, originalKeywords, question)
            RelevantChunk(chunk.pdfName, chunk.pageNumber, chunk.text, score)
        }
        val scoredKnowledge = knowledgeCandidates.values.map { entry ->
            val score = scoreChunk(entry.searchableText, originalKeywords, question)
            val label = if (entry.sourceType == "web_fetch" && entry.sourceUrl.isNotBlank())
                entry.sourceUrl
            else
                "Kavita's saved answer"
            // Answer-only text (not the stored question) is what's actually
            // useful as context to feed back into a prompt — the question
            // is only used above for search-matching/scoring.
            RelevantChunk(label, 0, entry.answer, score)
        }

        // A minimum score keeps genuinely unrelated rows (which only
        // matched on a common word) from being sent to Gemini as if they
        // were relevant context.
        return (scoredPdf + scoredKnowledge)
            .filter { it.score > 0 }
            .sortedByDescending { it.score }
            .take(maxChunks)
    }

    /**
     * Deeper version of [findRelevantChunks] for Doctor Mode's high-stakes
     * flows (combined differential, treatment reference, interaction
     * check) — instead of one search over one blob of text, this runs a
     * SEPARATE search per query string (e.g. one per finding, or one per
     * ranked differential name) and merges results.
     *
     * Why this matters: a single combined search can miss a book chunk
     * that only matches ONE specific finding's wording, because that
     * finding's keywords get diluted inside a long joined string scored
     * against the whole thing. Searching each piece independently lets a
     * chunk that's highly relevant to just one finding still surface,
     * instead of needing to also match the other unrelated findings to
     * rank highly.
     *
     * Deduplicates by (pdfName, text) so the same chunk matched by
     * multiple queries only appears once, keeping its best score.
     */
    suspend fun findRelevantChunksMulti(queries: List<String>, maxChunks: Int = 6): List<RelevantChunk> {
        val merged = mutableMapOf<Pair<String, String>, RelevantChunk>()
        for (query in queries) {
            if (query.isBlank()) continue
            val hits = try {
                findRelevantChunks(query, maxChunks = maxChunks)
            } catch (e: Exception) {
                emptyList()
            }
            for (hit in hits) {
                val key = hit.pdfName to hit.text
                val existing = merged[key]
                if (existing == null || hit.score > existing.score) {
                    merged[key] = hit
                }
            }
        }
        return merged.values.sortedByDescending { it.score }.take(maxChunks)
    }

    /**
     * Convenience for extracting search-worthy query strings for a
     * combined case analysis: one query per finding (so each finding's
     * own wording gets its own dedicated search), so nothing gets diluted
     * by being joined into one long string first.
     */
    fun queriesFromFindings(findings: List<String>): List<String> {
        return findings.map { it.take(300) }.filter { it.isNotBlank() }
    }


     * in [question] (e.g. "sar dard", "jodo mein dard") and returns all of
     * that phrase's synonyms — this is how phrase-level colloquial terms
     * reach the search even though [extractKeywords] only ever produces
     * single-word tokens.
     */
    private fun expandPhrases(question: String): Set<String> {
        val normalized = question.lowercase().trim()
        val result = mutableSetOf<String>()
        for (phrase in MedicalSynonyms.phraseKeys) {
            if (normalized.contains(phrase)) {
                result += MedicalSynonyms.expand(phrase)
            }
        }
        return result
    }

    private fun extractKeywords(question: String): List<String> {
        return question
            .lowercase()
            .replace(Regex("[^a-z0-9\\u0900-\\u097F\\s]"), " ") // keep latin, digits, Devanagari
            .split(Regex("\\s+"))
            .filter { it.length > 2 && it !in stopWords }
            .distinct()
    }

    private fun scoreChunk(searchableText: String, keywords: List<String>, originalQuestion: String): Int {
        var score = 0
        for (keyword in keywords) {
            if (searchableText.contains(keyword)) score += 1
        }
        // Reward chunks that contain the question's words close together /
        // in sequence, not just scattered individual keyword hits.
        val normalizedQuestion = originalQuestion.lowercase().trim()
        if (normalizedQuestion.length > 5 && searchableText.contains(normalizedQuestion)) {
            score += 5
        }
        return score
    }
}
