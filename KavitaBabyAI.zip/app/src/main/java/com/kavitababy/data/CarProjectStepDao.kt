// data/CarProjectStepDao.kt
package com.kavitababy.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface CarProjectStepDao {

    @Insert
    suspend fun insertAll(steps: List<CarProjectStep>)

    @Query("SELECT * FROM car_project_steps WHERE projectId = :projectId ORDER BY stepOrder ASC")
    suspend fun getForProject(projectId: Long): List<CarProjectStep>

    @Query("UPDATE car_project_steps SET isDone = :done WHERE id = :stepId")
    suspend fun setDone(stepId: Long, done: Boolean)

    @Query("DELETE FROM car_project_steps WHERE projectId = :projectId")
    suspend fun deleteForProject(projectId: Long)

    @Query(
        "SELECT COUNT(*) FROM car_project_steps WHERE projectId = :projectId AND isDone = 1"
    )
    suspend fun doneCount(projectId: Long): Int

    @Query("SELECT COUNT(*) FROM car_project_steps WHERE projectId = :projectId")
    suspend fun totalCount(projectId: Long): Int
}
