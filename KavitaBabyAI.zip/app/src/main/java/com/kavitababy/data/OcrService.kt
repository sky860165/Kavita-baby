// data/OcrService.kt
package com.kavitababy.data

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.rendering.PDFRenderer
import kotlinx.coroutines.tasks.await
import java.io.File

/**
 * On-device OCR for scanned medical books/notes — a page that's actually a
 * photo (no real text layer) returns blank from PDFBox's text stripper, so
 * this renders that page to a bitmap and runs ML Kit's bundled recognition
 * models on it instead. Fully offline: both the Latin and Devanagari models
 * ship inside the library itself, nothing is downloaded at runtime, no
 * image or text ever leaves the device.
 *
 * Two recognizers are tried per page (Latin first, since most medical
 * textbooks are English-majority; Devanagari second, for Hindi-script
 * pages/mixed content) and whichever finds more text wins — cheap enough to
 * run both since ML Kit's on-device models are small and fast, and doctors'
 * source material is genuinely a mix of scripts.
 */
class OcrService {

    private val latinRecognizer: TextRecognizer =
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val devanagariRecognizer: TextRecognizer =
        TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build())

    /**
     * Renders every page of [file] to a bitmap and OCRs each one, returning
     * page-number-to-text pairs. Only meant to be called for a PDF (or
     * specific pages within one) that [PdfScannerService] already found to
     * have no extractable text — running full-page OCR on every page of
     * every PDF regardless would be needlessly slow and battery-heavy.
     */
    suspend fun ocrPdfPages(file: File, pageNumbers: List<Int>): Map<Int, String> {
        if (pageNumbers.isEmpty()) return emptyMap()

        val results = mutableMapOf<Int, String>()
        android.os.ParcelFileDescriptor.open(
            file,
            android.os.ParcelFileDescriptor.MODE_READ_ONLY
        ).use { pfd ->
            PDDocument.load(file).use { document ->
                val renderer = PDFRenderer(document)
                for (pageNum in pageNumbers) {
                    if (pageNum < 1 || pageNum > document.numberOfPages) continue
                    try {
                        // 200 DPI is a practical middle ground — high enough
                        // for OCR accuracy on textbook-size print, without
                        // producing bitmaps so large they risk OOM on
                        // lower-end phones during a big scan batch.
                        val bitmap = renderer.renderImageWithDPI(pageNum - 1, 200f)
                        val text = ocrBitmap(bitmap)
                        bitmap.recycle()
                        if (text.isNotBlank()) results[pageNum] = text
                    } catch (e: Exception) {
                        // One bad page (corrupt image data, render failure)
                        // shouldn't abort OCR for the rest of the document.
                        continue
                    }
                }
            }
        }
        return results
    }

    /** OCRs a single already-decoded bitmap (used for picked images too, not just PDF pages). */
    suspend fun ocrBitmap(bitmap: Bitmap): String {
        val image = InputImage.fromBitmap(bitmap, 0)

        val latinResult = try {
            latinRecognizer.process(image).await().text
        } catch (e: Exception) {
            ""
        }

        val devanagariResult = try {
            devanagariRecognizer.process(image).await().text
        } catch (e: Exception) {
            ""
        }

        // Whichever recognizer found more text is almost always the
        // correct-script one for that page — a Devanagari model run on an
        // English page (or vice versa) typically returns much less (or
        // garbled/empty) output.
        return if (devanagariResult.length > latinResult.length) devanagariResult else latinResult
    }
}
