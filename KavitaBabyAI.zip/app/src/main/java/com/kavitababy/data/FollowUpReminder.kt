// data/FollowUpReminder.kt
package com.kavitababy.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * A doctor-scheduled follow-up reminder — e.g. "3 din baad Sharma ji ko
 * check karo" said during a case, or set manually from a patient's file.
 * Stored locally only; the actual OS-level alarm is scheduled separately
 * via [ReminderScheduler] using AlarmManager — this row is what survives
 * app restarts and reboots so alarms can be re-scheduled from it if
 * needed, and what the "Upcoming Follow-ups" list reads from.
 *
 * [patientId] is nullable so a reminder can exist without being tied to a
 * specific patient (e.g. "PDF library recheck karo next week"), matching
 * how [CaseNote.patientId] already allows the same for ad-hoc notes.
 */
@Entity(tableName = "followup_reminders")
data class FollowUpReminder(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val patientId: Long?,
    // Denormalized snapshot of the patient's decrypted display name at the
    // time the reminder was created — kept here (not re-looked-up at
    // notification time) so the notification can still show a name even
    // if PatientCrypto/DB access has some transient issue when the alarm
    // actually fires. Never re-encrypted or written back to PatientCase.
    val patientDisplayName: String,
    val note: String,
    val triggerAtMillis: Long,
    val createdAt: Long = System.currentTimeMillis(),
    // False once the notification has actually fired, or the doctor marks
    // it done/cancels it — kept as a row rather than deleted immediately
    // so "past follow-ups" history isn't silently lost.
    val isCompleted: Boolean = false,
    val isCancelled: Boolean = false
)
