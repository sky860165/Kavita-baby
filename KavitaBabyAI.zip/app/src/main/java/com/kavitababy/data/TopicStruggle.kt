// data/TopicStruggle.kt
package com.kavitababy.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Tracks how many times the user has asked about a given topic/keyword,
 * as a lightweight proxy for "keeps struggling with this." Kept entirely
 * on-device.
 *
 * [topic] is a normalized keyword or short phrase Gemini extracts from the
 * question (e.g. "thermodynamics", "pointers in c", "kidney physiology") —
 * lowercased and trimmed so near-duplicate phrasing still increments the
 * same row rather than creating a new one every time.
 *
 * This is simple frequency counting, not a real mastery/spaced-repetition
 * model — it's meant to let Kavita proactively say "you keep coming back to
 * X, want to revise it properly?" after a few repeats, which is genuinely
 * useful without pretending to be more sophisticated than it is.
 */
@Entity(tableName = "topic_struggles")
data class TopicStruggle(
    @PrimaryKey
    val topic: String,
    val count: Int = 1,
    val lastAskedAt: Long = System.currentTimeMillis(),
    // Once the user has been nudged about this topic, don't nudge again
    // immediately on the very next matching question — wait for the count
    // to climb further first, or this gets annoying fast.
    val lastNudgedAtCount: Int = 0
)
