// data/TopicStruggleDao.kt
package com.kavitababy.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface TopicStruggleDao {

    @Query("SELECT * FROM topic_struggles WHERE topic = :topic LIMIT 1")
    suspend fun get(topic: String): TopicStruggle?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(struggle: TopicStruggle)

    @Query("SELECT * FROM topic_struggles WHERE count >= :minCount ORDER BY count DESC LIMIT :limit")
    suspend fun getFrequentTopics(minCount: Int = 3, limit: Int = 5): List<TopicStruggle>
}
