// data/LabValue.kt
package com.kavitababy.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * A single lab/vitals reading for a patient — one number, tagged with a
 * metric name (e.g. "BP Systolic", "Blood Sugar", "Hemoglobin"), a unit,
 * and when it was recorded. Multiple readings of the SAME [metricName] for
 * the SAME [patientId] form a time-series, which the Lab Trends screen
 * charts so the doctor can see at a glance whether a patient is improving
 * or not — the same number sitting alone in a case note doesn't show that,
 * only a series of them over time does.
 *
 * Deliberately free-text [metricName] rather than a fixed enum: doctors
 * track very different things depending on specialty (BP/sugar for a
 * physician, Hb/platelets for a hematology case, TSH for endocrine
 * follow-up) and a fixed list would either be too narrow or bloated.
 * Existing metric names already used for this patient are surfaced as
 * quick-pick suggestions in the UI instead, so in practice the doctor
 * rarely retypes a new name for repeat readings.
 */
@Entity(tableName = "lab_values")
data class LabValue(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val patientId: Long,
    val metricName: String,
    val value: Double,
    val unit: String,
    val recordedAt: Long = System.currentTimeMillis(),
    val note: String = ""
)
