// data/LabValue.kt
package com.kavitababy.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * A single lab/vitals reading for a patient — one value, tagged with a
 * metric name (e.g. "BP Systolic", "Blood Sugar", "Hemoglobin"), a unit,
 * and when it was recorded. Multiple readings of the SAME [metricName] for
 * the SAME [patientId] form a time-series, which the Lab Trends screen
 * charts so the doctor can see at a glance whether a patient is improving
 * or not — the same number sitting alone in a case note doesn't show that,
 * only a series of them over time does.
 *
 * [value] is a free-text String, not a Double — some readings genuinely
 * aren't a plain number (e.g. "Trace", "1+", "Negative", "6.5/12"), so the
 * add-reading box accepts the full keyboard including letters and special
 * characters. Anything that *does* parse as a number is still used for the
 * trend chart; non-numeric readings just show up in the history list
 * without being plotted.
 *
 * [metricName] is deliberately free-text rather than a fixed enum: doctors
 * track very different things depending on specialty (BP/sugar for a
 * physician, Hb/platelets for a hematology case, TSH for endocrine
 * follow-up). A curated set of common metrics ships as built-in presets
 * (see [LabMetricPreset]) so the doctor usually just taps one instead of
 * typing, but a custom metric can always be added.
 */
@Entity(tableName = "lab_values")
data class LabValue(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val patientId: Long,
    val metricName: String,
    val value: String,
    val unit: String,
    val recordedAt: Long = System.currentTimeMillis(),
    val note: String = ""
)
