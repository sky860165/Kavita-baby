// data/PatientCaseDao.kt
package com.kavitababy.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update

@Dao
interface PatientCaseDao {

    @Insert
    suspend fun insert(patient: PatientCase): Long

    @Update
    suspend fun update(patient: PatientCase)

    // Updates only the clinical summary fields (+ lastUpdatedAt) without
    // needing the full PatientCase object in hand first. Used by both the
    // automatic path (workup combine / diagnosis confirm / medicine
    // suggestion) and the manual doctor-edit path, so both write through
    // the exact same fields.
    @Query(
        """
        UPDATE patient_cases
        SET currentDiagnosis = :diagnosis,
            currentSuggestion = :suggestion,
            currentMedicines = :medicines,
            knownAllergies = :allergies,
            lastUpdatedAt = :updatedAt
        WHERE id = :patientId
        """
    )
    suspend fun updateClinicalSummary(
        patientId: Long,
        diagnosis: String,
        suggestion: String,
        medicines: String,
        allergies: String,
        updatedAt: Long = System.currentTimeMillis()
    )

    @Query("SELECT * FROM patient_cases ORDER BY lastUpdatedAt DESC")
    suspend fun getAll(): List<PatientCase>

    @Query("SELECT * FROM patient_cases WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): PatientCase?

    @Delete
    suspend fun delete(patient: PatientCase)
}
