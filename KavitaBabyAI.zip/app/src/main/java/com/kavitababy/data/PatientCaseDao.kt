// data/PatientCaseDao.kt
package com.kavitababy.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update

@Dao
interface PatientCaseDao {

    @Insert
    suspend fun insert(patient: PatientCase): Long

    @Update
    suspend fun update(patient: PatientCase)

    @Query("SELECT * FROM patient_cases ORDER BY lastUpdatedAt DESC")
    suspend fun getAll(): List<PatientCase>

    @Query("SELECT * FROM patient_cases WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): PatientCase?

    @Delete
    suspend fun delete(patient: PatientCase)
}
