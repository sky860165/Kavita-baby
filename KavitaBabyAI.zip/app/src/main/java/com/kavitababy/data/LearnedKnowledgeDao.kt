// data/LearnedKnowledgeDao.kt
package com.kavitababy.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface LearnedKnowledgeDao {

    @Insert
    suspend fun insert(entry: LearnedKnowledge): Long

    @Query("SELECT COUNT(*) FROM learned_knowledge")
    suspend fun count(): Int

    @Query("SELECT COUNT(*) FROM learned_knowledge WHERE sourceType = 'web_fetch'")
    suspend fun countWebFetched(): Int

    @Query("SELECT * FROM learned_knowledge ORDER BY savedAt DESC LIMIT :limit")
    suspend fun getRecent(limit: Int = 50): List<LearnedKnowledge>

    // Same cheap first-pass filter pattern as PdfChunkDao.searchByKeyword —
    // only pull rows that contain at least one query word, so
    // RagSearchEngine doesn't have to score every saved row on every
    // question.
    @Query(
        """
        SELECT * FROM learned_knowledge
        WHERE searchableText LIKE '%' || :keyword || '%'
        LIMIT 200
        """
    )
    suspend fun searchByKeyword(keyword: String): List<LearnedKnowledge>

    @Query("DELETE FROM learned_knowledge")
    suspend fun clearAll()

    @Query("DELETE FROM learned_knowledge WHERE id = :id")
    suspend fun deleteById(id: Long)
}
