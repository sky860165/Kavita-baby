// data/LabMetricPreset.kt
package com.kavitababy.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * A saved lab/vitals metric definition — just a name + its usual unit
 * (e.g. "BP Systolic" / "mmHg", "Hemoglobin" / "g/dL"). This is what makes
 * the Lab Trends "add reading" screen a tap instead of retyping the metric
 * name and unit every single visit: pick the preset, only the value needs
 * typing.
 *
 * [isBuiltIn] presets ship with the app (common vitals/labs every doctor
 * tracks) and can't be deleted from the UI. Doctor-created presets have
 * [isBuiltIn] = false and can be deleted any time — they're global (not
 * per-patient), since the same doctor tracking, say, "Vitamin D" for one
 * patient will want it available for every other patient too.
 */
@Entity(tableName = "lab_metric_presets")
data class LabMetricPreset(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val unit: String,
    val isBuiltIn: Boolean = false,
    // Keeps built-ins in a stable, sensible order and custom presets in the
    // order they were created, rather than alphabetical or insert-id order.
    val sortOrder: Long = System.currentTimeMillis()
)
