// data/PdfScannerService.kt
package com.kavitababy.data

import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.zip.ZipFile

/**
 * Finds every PDF on the device via MediaStore, pulls text out of it with
 * PdfBox, and stores it as searchable chunks in Room.
 *
 * Re-running scanAllPdfs() is safe: PDFs already indexed (same path) are
 * skipped, so calling this both on app start and from a manual "Scan PDFs"
 * button won't duplicate work or data.
 */
class PdfScannerService(private val context: Context) {

    private val dao = KavitaDatabase.getInstance(context).pdfChunkDao()
    private val ocrService = OcrService()

    // Roughly one paragraph per chunk. Small enough that the RAG search
    // returns focused context, big enough to keep sentence meaning intact.
    private val chunkSizeChars = 800

    data class ScanResult(
        val pdfsFound: Int,
        val pdfsIndexed: Int,
        val chunksCreated: Int,
        // Name + short reason for every file that was found but couldn't be
        // indexed (corrupt, password-protected, no extractable text, etc).
        // Surfaced in chat so "PDF baar baar fail ho raha" actually shows
        // *which* file and *why*, instead of silently skipping it.
        val failedFiles: List<Pair<String, String>> = emptyList(),
        // True when scanAllPdfs stopped early because its internal time
        // budget ran out — NOT a failure. Everything indexed before the
        // cutoff is already committed to Room, so this just tells the
        // caller "partial pass, rest is queued for next time" instead of
        // looking like every file failed.
        val timedOut: Boolean = false,
        // Cumulative progress across ALL passes so far (not just this one
        // call) — lets the UI say "X/Y PDFs done overall (Z%), W baaki",
        // since a big storage (e.g. 20GB) is expected to need several
        // scan passes to finish, each one picking up where the last left
        // off. Only meaningfully populated by scanAllPdfs; defaults to 0
        // for scanAllFiles, which doesn't track resumable progress the
        // same way.
        val totalIndexedOverall: Int = 0,
        val pdfsRemaining: Int = 0
    )

    /** Result of indexing a single user-picked PDF via [indexPickedPdf]. */
    sealed class PickResult {
        data class Success(val pdfName: String, val chunksCreated: Int) : PickResult()
        data class Failure(val reason: String) : PickResult()
    }

    // [timeBudgetMs] is an internal, graceful stopping point — deliberately
    // set a bit below whatever hard withTimeoutOrNull the caller wraps this
    // in (ChatScreen does 2min/5min). Without it, a storage full of PDFs
    // (e.g. 2GB worth) would run right up against the caller's hard
    // timeout, which kills the coroutine mid-file and discards the whole
    // ScanResult — even though most files by then were already indexed and
    // committed to Room. Stopping a few seconds early instead lets us
    // return a normal ScanResult with timedOut=true, so the caller can say
    // "partially done, rest next time" rather than "scan failed".
    // [perFileTimeoutMs] stops one huge/heavily-scanned PDF from eating the
    // entire budget by itself and starving every file behind it in the list.
    suspend fun scanAllPdfs(
        forceRescan: Boolean = false,
        timeBudgetMs: Long = 240_000L,
        perFileTimeoutMs: Long = 45_000L
    ): ScanResult = withContext(Dispatchers.IO) {
        PDFBoxResourceLoader.init(context.applicationContext)

        val pdfFiles = findAllPdfPaths()
        val alreadyIndexed = if (forceRescan) emptySet() else dao.getAllIndexedPaths().toSet()

        var indexedCount = 0
        var totalChunks = 0
        val failed = mutableListOf<Pair<String, String>>()
        val startTime = android.os.SystemClock.elapsedRealtime()
        var timedOut = false

        for (path in pdfFiles) {
            if (!forceRescan && path in alreadyIndexed) continue

            // Graceful internal stop — leaves every file processed so far
            // committed, and lets a re-scan (even the silent startup one)
            // pick up exactly here since already-indexed paths are skipped.
            if (android.os.SystemClock.elapsedRealtime() - startTime > timeBudgetMs) {
                timedOut = true
                break
            }

            val file = File(path)
            if (!file.exists() || !file.canRead()) {
                failed.add(file.name to "file padh nahi payi (permission/path issue)")
                continue
            }

            try {
                val chunks = kotlinx.coroutines.withTimeoutOrNull(perFileTimeoutMs) {
                    extractChunks(file)
                }
                if (chunks == null) {
                    // This one file alone blew past its share of time
                    // (usually heavy OCR on a scanned book) — skip it and
                    // keep going instead of letting it hang everything
                    // behind it.
                    failed.add(file.name to "is file ko padhne mein zyada time lag raha tha, skip kar diya")
                    continue
                }
                if (chunks.isNotEmpty()) {
                    if (forceRescan) dao.deleteForPdf(path)
                    dao.insertAll(chunks)
                    indexedCount++
                    totalChunks += chunks.size
                } else {
                    failed.add(file.name to "koi text nahi mila (scanned/blank ho sakta hai)")
                }
            } catch (e: Exception) {
                // Corrupt / password-protected / unreadable PDF — skip it,
                // don't let one bad file stop the whole scan, but remember
                // *why* so the user can actually see it in chat.
                failed.add(file.name to (e.message?.take(80) ?: "corrupt ya password-protected"))
                continue
            }
        }

        // Cumulative totals across this pass + everything already indexed
        // in previous passes — this is what makes "20GB will need several
        // passes" visible as concrete progress instead of a mystery.
        val alreadyIndexedBefore = alreadyIndexed.size
        val overallIndexed = alreadyIndexedBefore + indexedCount
        val remaining = (pdfFiles.size - overallIndexed - failed.size).coerceAtLeast(0)

        ScanResult(
            pdfsFound = pdfFiles.size,
            pdfsIndexed = indexedCount,
            chunksCreated = totalChunks,
            failedFiles = failed,
            timedOut = timedOut,
            totalIndexedOverall = overallIndexed,
            pdfsRemaining = remaining
        )
    }

    /**
     * Same idea as [scanAllPdfs] but walks the device for PDFs *and* plain
     * text / Word documents (.txt, .md, .docx) in one pass, so the "Sab
     * Files Padho" button reads everything at once instead of just PDFs.
     * Images/audio/video still go through the 📎 attach button (they need
     * to be sent to Gemini, not text-indexed), but any document format that
     * has real extractable text goes into the same searchable pdf_chunks
     * table as PDFs, so RagSearchEngine picks it up automatically.
     */
    suspend fun scanAllFiles(forceRescan: Boolean = false): ScanResult = withContext(Dispatchers.IO) {
        PDFBoxResourceLoader.init(context.applicationContext)

        val allFiles = findAllDocumentPaths()
        val alreadyIndexed = if (forceRescan) emptySet() else dao.getAllIndexedPaths().toSet()

        var indexedCount = 0
        var totalChunks = 0
        val failed = mutableListOf<Pair<String, String>>()

        for (path in allFiles) {
            if (!forceRescan && path in alreadyIndexed) continue

            val file = File(path)
            if (!file.exists() || !file.canRead()) {
                failed.add(file.name to "file padh nahi payi (permission/path issue)")
                continue
            }

            try {
                val chunks = when (file.extension.lowercase()) {
                    "pdf" -> extractChunks(file)
                    "txt", "md" -> extractTxtChunks(file)
                    "docx" -> extractDocxChunks(file)
                    else -> emptyList()
                }
                if (chunks.isNotEmpty()) {
                    if (forceRescan) dao.deleteForPdf(path)
                    dao.insertAll(chunks)
                    indexedCount++
                    totalChunks += chunks.size
                } else {
                    failed.add(file.name to "koi text nahi mila (khali ya scanned ho sakta hai)")
                }
            } catch (e: Exception) {
                failed.add(file.name to (e.message?.take(80) ?: "padhte waqt error aayi"))
                continue
            }
        }

        ScanResult(
            pdfsFound = allFiles.size,
            pdfsIndexed = indexedCount,
            chunksCreated = totalChunks,
            failedFiles = failed
        )
    }

    /**
     * Indexes a single PDF the user picked through the system file picker
     * (Storage Access Framework — the 📎 upload button in ChatScreen).
     *
     * SAF hands back a content:// Uri, not a filesystem path, and that Uri
     * isn't readable by File()/PdfBox directly — so we first stream it into
     * the app's own private cache dir, then reuse the same extraction logic
     * as the full-device scan. This path works regardless of Android version
     * or scoped-storage restrictions, since the user explicitly chose the
     * file through the picker (no broad storage permission needed at all).
     */
    // Wrapped in a hard 3-minute timeout — without this, a single huge or
    // heavily-scanned (OCR-needing) PDF could hang this function forever,
    // which left isIndexingPdf stuck `true` in ChatScreen permanently
    // (its try/finally never runs if the suspend call itself never
    // returns) — disabling the 📎 attach button for the rest of the app
    // session, looking exactly like "the button just stopped working".
    // scanAllPdfs already had this same protection; this one didn't.
    suspend fun indexPickedPdf(uri: Uri): PickResult = withContext(Dispatchers.IO) {
        kotlinx.coroutines.withTimeoutOrNull(180_000L) {
            indexPickedPdfInternal(uri)
        } ?: PickResult.Failure(
            "3 minute mein PDF padhna poora nahi hua (bahut badi file ya scanned pages zyada OCR maang rahe hain). Chhoti file try karo ya PDF split karke bhejo."
        )
    }

    private suspend fun indexPickedPdfInternal(uri: Uri): PickResult = withContext(Dispatchers.IO) {
        PDFBoxResourceLoader.init(context.applicationContext)

        val pdfName = queryDisplayName(uri) ?: "picked_${System.currentTimeMillis()}.pdf"
        val localFile = File(context.cacheDir, "picked_${System.currentTimeMillis()}_$pdfName")

        try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                localFile.outputStream().use { output ->
                    input.copyTo(output)
                }
            } ?: return@withContext PickResult.Failure("File open nahi ho payi")

            // Use the content Uri as the stable identity for re-indexing
            // checks (deleteForPdf/countForPdf), not the throwaway cache
            // path, since the cache filename includes a timestamp and would
            // never match on a re-pick of the same file.
            val identityPath = uri.toString()

            val chunks = extractChunks(localFile, pdfNameOverride = pdfName, pdfPathOverride = identityPath)
            if (chunks.isEmpty()) {
                return@withContext PickResult.Failure("Is PDF mein padhne layak text nahi mila (scanned image ho sakta hai)")
            }

            dao.deleteForPdf(identityPath)
            dao.insertAll(chunks)
            PickResult.Success(pdfName = pdfName, chunksCreated = chunks.size)
        } catch (e: Exception) {
            PickResult.Failure(e.message ?: "Kuch galat ho gaya PDF padhte waqt")
        } finally {
            localFile.delete()
        }
    }

    /**
     * Indexes a PDF [File] that's already sitting on local disk — used for
     * PDFs found inside a zip archive after MediaScannerService extracts
     * them, since those are already regular Files (not content:// Uris) and
     * don't need the SAF copy-to-cache step that [indexPickedPdf] does.
     */
    suspend fun indexExtractedFile(file: File, displayName: String): PickResult = withContext(Dispatchers.IO) {
        PDFBoxResourceLoader.init(context.applicationContext)

        try {
            // Identity path uses the display name (not the temp extraction
            // path, which is unique per zip-unpack and would never match on
            // a re-upload of the same zip) so re-indexing checks behave the
            // same way they do for a directly-picked PDF.
            val identityPath = "zip_entry:$displayName"

            val chunks = extractChunks(file, pdfNameOverride = displayName, pdfPathOverride = identityPath)
            if (chunks.isEmpty()) {
                return@withContext PickResult.Failure("\"$displayName\" mein padhne layak text nahi mila")
            }

            dao.deleteForPdf(identityPath)
            dao.insertAll(chunks)
            PickResult.Success(pdfName = displayName, chunksCreated = chunks.size)
        } catch (e: Exception) {
            PickResult.Failure(e.message ?: "Kuch galat ho gaya PDF padhte waqt")
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        return try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (cursor.moveToFirst() && nameIndex >= 0) cursor.getString(nameIndex) else null
            }
        } catch (e: Exception) {
            null
        }
    }

    // Extensions the "Sab Files Padho" full-device scan looks for, beyond
    // PDF: plain text notes and Word docs are the other formats that
    // realistically hold real extractable text on a phone.
    private val documentExtensions = setOf("pdf", "txt", "md", "docx")

    private fun findAllDocumentPaths(): List<String> {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && Environment.isExternalStorageManager()) {
            val root = Environment.getExternalStorageDirectory()
            val found = mutableListOf<String>()
            walkForExtensions(root, documentExtensions, found)
            return found
        }

        // Fallback without All Files Access: MediaStore only indexes PDFs
        // reliably as a MIME type query, so this path is PDF-only — same
        // limitation scanAllPdfs already has on older/unpermitted setups.
        return findAllPdfPaths()
    }

    private fun walkForExtensions(dir: File, extensions: Set<String>, out: MutableList<String>, depth: Int = 0) {
        if (depth > 12) return
        val entries = try { dir.listFiles() } catch (e: Exception) { null } ?: return

        for (entry in entries) {
            val name = entry.name
            if (name.startsWith(".")) continue

            if (entry.isDirectory) {
                if (name in skipDirNames) continue
                walkForExtensions(entry, extensions, out, depth + 1)
            } else if (entry.extension.lowercase() in extensions) {
                out.add(entry.absolutePath)
            }
        }
    }

    private fun findAllPdfPaths(): List<String> {
        // With All Files Access (MANAGE_EXTERNAL_STORAGE) granted, walk the
        // filesystem directly instead of going through MediaStore. This is
        // what actually fixes the "PDFs it can't see" problem — MediaStore's
        // index misses PDFs sitting in folders it never scanned (custom app
        // folders, nested subfolders, files moved outside its indexing
        // triggers), especially on MIUI/Xiaomi builds. A direct filesystem
        // walk finds every PDF that physically exists, regardless of
        // whether MediaStore ever indexed it.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && Environment.isExternalStorageManager()) {
            val root = Environment.getExternalStorageDirectory()
            val found = mutableListOf<String>()
            walkForPdfs(root, found)
            return found
        }

        // Fallback (All Files Access not granted, or pre-Android-11 device
        // relying on the classic READ_EXTERNAL_STORAGE permission instead):
        // MediaStore query, which at least catches PDFs it has indexed.
        val paths = mutableListOf<String>()
        val projection = arrayOf(MediaStore.Files.FileColumns.DATA)
        val selection = "${MediaStore.Files.FileColumns.MIME_TYPE} = ?"
        val selectionArgs = arrayOf("application/pdf")

        val cursor = context.contentResolver.query(
            MediaStore.Files.getContentUri("external"),
            projection,
            selection,
            selectionArgs,
            null
        )

        cursor?.use {
            val dataIndex = it.getColumnIndex(MediaStore.Files.FileColumns.DATA)
            while (it.moveToNext()) {
                if (dataIndex >= 0) {
                    it.getString(dataIndex)?.let { path -> paths.add(path) }
                }
            }
        }
        return paths
    }

    // Folders that are pointless or slow to walk into: Android/data and
    // Android/obb are restricted anyway on modern Android and just waste
    // time; hidden dot-folders (.thumbnails, .trash-can equivalents from
    // various apps) never contain anything worth indexing.
    private val skipDirNames = setOf("Android", "data", "obb")

    private fun walkForPdfs(dir: File, out: MutableList<String>, depth: Int = 0) {
        // Safety cap — real device folder structures never nest this deep,
        // this just guards against a pathological symlink loop or similar.
        if (depth > 12) return

        val entries = try {
            dir.listFiles()
        } catch (e: Exception) {
            null
        } ?: return

        for (entry in entries) {
            val name = entry.name
            if (name.startsWith(".")) continue

            if (entry.isDirectory) {
                if (name in skipDirNames) continue
                walkForPdfs(entry, out, depth + 1)
            } else if (name.endsWith(".pdf", ignoreCase = true)) {
                out.add(entry.absolutePath)
            }
        }
    }

    private suspend fun extractChunks(
        file: File,
        pdfNameOverride: String? = null,
        pdfPathOverride: String? = null
    ): List<PdfChunk> {
        val chunks = mutableListOf<PdfChunk>()
        val displayName = pdfNameOverride ?: file.name
        val identityPath = pdfPathOverride ?: file.absolutePath

        // Pages where PdfBox found no extractable text — these are almost
        // always scanned photos of a page rather than real text, so they're
        // collected here and OCR'd in one batch afterward instead of one at
        // a time (batching keeps the PDDocument open/renderer setup cost to
        // once per file instead of once per blank page).
        val blankPages = mutableListOf<Int>()

        PDDocument.load(file).use { document ->
            val stripper = PDFTextStripper()
            val pageCount = document.numberOfPages

            for (pageNum in 1..pageCount) {
                stripper.startPage = pageNum
                stripper.endPage = pageNum
                val pageText = stripper.getText(document).trim()
                if (pageText.isBlank()) {
                    blankPages.add(pageNum)
                    continue
                }

                chunks.addAll(splitIntoChunks(pageText, displayName, identityPath, pageNum))
            }
        }

        // OCR fallback for scanned pages (a photographed book page, not a
        // real text layer) — this is what lets scanned medical
        // books/notes get indexed at all, since PdfBox alone can't read
        // text out of an image. Runs fully on-device, no network call.
        if (blankPages.isNotEmpty()) {
            val ocrResults = try {
                ocrService.ocrPdfPages(file, blankPages)
            } catch (e: Exception) {
                emptyMap()
            }
            for ((pageNum, ocrText) in ocrResults) {
                chunks.addAll(splitIntoChunks(ocrText, displayName, identityPath, pageNum, isOcr = true))
            }
        }

        return chunks
    }

    /** Plain text / Markdown notes — no page concept, so everything is "page 1". */
    private suspend fun extractTxtChunks(file: File): List<PdfChunk> = withContext(Dispatchers.IO) {
        val text = file.readText(Charsets.UTF_8).trim()
        if (text.isBlank()) return@withContext emptyList()
        splitIntoChunks(text, file.name, file.absolutePath, pageNumber = 1)
    }

    /**
     * A .docx is a zip archive; the actual text lives in word/document.xml
     * as a series of <w:t> runs inside <w:p> paragraphs. Parsed with
     * Android's built-in XmlPullParser — no extra library needed (Apache
     * POI is too heavy for this app's size/offline constraints).
     */
    private suspend fun extractDocxChunks(file: File): List<PdfChunk> = withContext(Dispatchers.IO) {
        val text = StringBuilder()

        ZipFile(file).use { zip ->
            val entry = zip.getEntry("word/document.xml")
                ?: return@withContext emptyList()

            zip.getInputStream(entry).use { input ->
                val parser = android.util.Xml.newPullParser()
                parser.setInput(input, "UTF-8")

                var event = parser.eventType
                var insideText = false
                while (event != org.xmlpull.v1.XmlPullParser.END_DOCUMENT) {
                    when (event) {
                        org.xmlpull.v1.XmlPullParser.START_TAG -> {
                            when (parser.name) {
                                "t" -> insideText = true
                                "p" -> { /* paragraph start, nothing to do yet */ }
                            }
                        }
                        org.xmlpull.v1.XmlPullParser.TEXT -> {
                            if (insideText) text.append(parser.text)
                        }
                        org.xmlpull.v1.XmlPullParser.END_TAG -> {
                            when (parser.name) {
                                "t" -> insideText = false
                                "p" -> text.append("\n\n")
                            }
                        }
                    }
                    event = parser.next()
                }
            }
        }

        val finalText = text.toString().trim()
        if (finalText.isBlank()) return@withContext emptyList()
        splitIntoChunks(finalText, file.name, file.absolutePath, pageNumber = 1)
    }

    private fun splitIntoChunks(
        pageText: String,
        pdfName: String,
        pdfPath: String,
        pageNumber: Int,
        isOcr: Boolean = false
    ): List<PdfChunk> {
        val chunks = mutableListOf<PdfChunk>()
        val paragraphs = pageText.split(Regex("\n\\s*\n")).filter { it.isNotBlank() }

        val buffer = StringBuilder()
        for (para in paragraphs) {
            if (buffer.length + para.length > chunkSizeChars && buffer.isNotEmpty()) {
                chunks.add(buildChunk(buffer.toString(), pdfName, pdfPath, pageNumber, isOcr))
                buffer.clear()
            }
            buffer.append(para).append("\n\n")
        }
        if (buffer.isNotEmpty()) {
            chunks.add(buildChunk(buffer.toString(), pdfName, pdfPath, pageNumber, isOcr))
        }
        return chunks
    }

    private fun buildChunk(text: String, pdfName: String, pdfPath: String, pageNumber: Int, isOcr: Boolean = false): PdfChunk {
        return PdfChunk(
            pdfName = pdfName,
            pdfPath = pdfPath,
            pageNumber = pageNumber,
            text = text.trim(),
            searchableText = text.lowercase().replace(Regex("\\s+"), " ").trim(),
            isOcr = isOcr
        )
    }
}
