// data/PdfScannerService.kt
package com.kavitababy.data

import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Finds every PDF on the device via MediaStore, pulls text out of it with
 * PdfBox, and stores it as searchable chunks in Room.
 *
 * Re-running scanAllPdfs() is safe: PDFs already indexed (same path) are
 * skipped, so calling this both on app start and from a manual "Scan PDFs"
 * button won't duplicate work or data.
 */
class PdfScannerService(private val context: Context) {

    private val dao = KavitaDatabase.getInstance(context).pdfChunkDao()
    private val ocrService = OcrService()

    // Roughly one paragraph per chunk. Small enough that the RAG search
    // returns focused context, big enough to keep sentence meaning intact.
    private val chunkSizeChars = 800

    data class ScanResult(val pdfsFound: Int, val pdfsIndexed: Int, val chunksCreated: Int)

    /** Result of indexing a single user-picked PDF via [indexPickedPdf]. */
    sealed class PickResult {
        data class Success(val pdfName: String, val chunksCreated: Int) : PickResult()
        data class Failure(val reason: String) : PickResult()
    }

    suspend fun scanAllPdfs(forceRescan: Boolean = false): ScanResult = withContext(Dispatchers.IO) {
        PDFBoxResourceLoader.init(context.applicationContext)

        val pdfFiles = findAllPdfPaths()
        val alreadyIndexed = if (forceRescan) emptySet() else dao.getAllIndexedPaths().toSet()

        var indexedCount = 0
        var totalChunks = 0

        for (path in pdfFiles) {
            if (!forceRescan && path in alreadyIndexed) continue

            val file = File(path)
            if (!file.exists() || !file.canRead()) continue

            try {
                val chunks = extractChunks(file)
                if (chunks.isNotEmpty()) {
                    if (forceRescan) dao.deleteForPdf(path)
                    dao.insertAll(chunks)
                    indexedCount++
                    totalChunks += chunks.size
                }
            } catch (e: Exception) {
                // Corrupt / password-protected / unreadable PDF — skip it,
                // don't let one bad file stop the whole scan.
                continue
            }
        }

        ScanResult(pdfsFound = pdfFiles.size, pdfsIndexed = indexedCount, chunksCreated = totalChunks)
    }

    /**
     * Indexes a single PDF the user picked through the system file picker
     * (Storage Access Framework — the 📎 upload button in ChatScreen).
     *
     * SAF hands back a content:// Uri, not a filesystem path, and that Uri
     * isn't readable by File()/PdfBox directly — so we first stream it into
     * the app's own private cache dir, then reuse the same extraction logic
     * as the full-device scan. This path works regardless of Android version
     * or scoped-storage restrictions, since the user explicitly chose the
     * file through the picker (no broad storage permission needed at all).
     */
    suspend fun indexPickedPdf(uri: Uri): PickResult = withContext(Dispatchers.IO) {
        PDFBoxResourceLoader.init(context.applicationContext)

        val pdfName = queryDisplayName(uri) ?: "picked_${System.currentTimeMillis()}.pdf"
        val localFile = File(context.cacheDir, "picked_${System.currentTimeMillis()}_$pdfName")

        try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                localFile.outputStream().use { output ->
                    input.copyTo(output)
                }
            } ?: return@withContext PickResult.Failure("File open nahi ho payi")

            // Use the content Uri as the stable identity for re-indexing
            // checks (deleteForPdf/countForPdf), not the throwaway cache
            // path, since the cache filename includes a timestamp and would
            // never match on a re-pick of the same file.
            val identityPath = uri.toString()

            val chunks = extractChunks(localFile, pdfNameOverride = pdfName, pdfPathOverride = identityPath)
            if (chunks.isEmpty()) {
                return@withContext PickResult.Failure("Is PDF mein padhne layak text nahi mila (scanned image ho sakta hai)")
            }

            dao.deleteForPdf(identityPath)
            dao.insertAll(chunks)
            PickResult.Success(pdfName = pdfName, chunksCreated = chunks.size)
        } catch (e: Exception) {
            PickResult.Failure(e.message ?: "Kuch galat ho gaya PDF padhte waqt")
        } finally {
            localFile.delete()
        }
    }

    /**
     * Indexes a PDF [File] that's already sitting on local disk — used for
     * PDFs found inside a zip archive after MediaScannerService extracts
     * them, since those are already regular Files (not content:// Uris) and
     * don't need the SAF copy-to-cache step that [indexPickedPdf] does.
     */
    suspend fun indexExtractedFile(file: File, displayName: String): PickResult = withContext(Dispatchers.IO) {
        PDFBoxResourceLoader.init(context.applicationContext)

        try {
            // Identity path uses the display name (not the temp extraction
            // path, which is unique per zip-unpack and would never match on
            // a re-upload of the same zip) so re-indexing checks behave the
            // same way they do for a directly-picked PDF.
            val identityPath = "zip_entry:$displayName"

            val chunks = extractChunks(file, pdfNameOverride = displayName, pdfPathOverride = identityPath)
            if (chunks.isEmpty()) {
                return@withContext PickResult.Failure("\"$displayName\" mein padhne layak text nahi mila")
            }

            dao.deleteForPdf(identityPath)
            dao.insertAll(chunks)
            PickResult.Success(pdfName = displayName, chunksCreated = chunks.size)
        } catch (e: Exception) {
            PickResult.Failure(e.message ?: "Kuch galat ho gaya PDF padhte waqt")
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        return try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (cursor.moveToFirst() && nameIndex >= 0) cursor.getString(nameIndex) else null
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun findAllPdfPaths(): List<String> {
        // With All Files Access (MANAGE_EXTERNAL_STORAGE) granted, walk the
        // filesystem directly instead of going through MediaStore. This is
        // what actually fixes the "PDFs it can't see" problem — MediaStore's
        // index misses PDFs sitting in folders it never scanned (custom app
        // folders, nested subfolders, files moved outside its indexing
        // triggers), especially on MIUI/Xiaomi builds. A direct filesystem
        // walk finds every PDF that physically exists, regardless of
        // whether MediaStore ever indexed it.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && Environment.isExternalStorageManager()) {
            val root = Environment.getExternalStorageDirectory()
            val found = mutableListOf<String>()
            walkForPdfs(root, found)
            return found
        }

        // Fallback (All Files Access not granted, or pre-Android-11 device
        // relying on the classic READ_EXTERNAL_STORAGE permission instead):
        // MediaStore query, which at least catches PDFs it has indexed.
        val paths = mutableListOf<String>()
        val projection = arrayOf(MediaStore.Files.FileColumns.DATA)
        val selection = "${MediaStore.Files.FileColumns.MIME_TYPE} = ?"
        val selectionArgs = arrayOf("application/pdf")

        val cursor = context.contentResolver.query(
            MediaStore.Files.getContentUri("external"),
            projection,
            selection,
            selectionArgs,
            null
        )

        cursor?.use {
            val dataIndex = it.getColumnIndex(MediaStore.Files.FileColumns.DATA)
            while (it.moveToNext()) {
                if (dataIndex >= 0) {
                    it.getString(dataIndex)?.let { path -> paths.add(path) }
                }
            }
        }
        return paths
    }

    // Folders that are pointless or slow to walk into: Android/data and
    // Android/obb are restricted anyway on modern Android and just waste
    // time; hidden dot-folders (.thumbnails, .trash-can equivalents from
    // various apps) never contain anything worth indexing.
    private val skipDirNames = setOf("Android", "data", "obb")

    private fun walkForPdfs(dir: File, out: MutableList<String>, depth: Int = 0) {
        // Safety cap — real device folder structures never nest this deep,
        // this just guards against a pathological symlink loop or similar.
        if (depth > 12) return

        val entries = try {
            dir.listFiles()
        } catch (e: Exception) {
            null
        } ?: return

        for (entry in entries) {
            val name = entry.name
            if (name.startsWith(".")) continue

            if (entry.isDirectory) {
                if (name in skipDirNames) continue
                walkForPdfs(entry, out, depth + 1)
            } else if (name.endsWith(".pdf", ignoreCase = true)) {
                out.add(entry.absolutePath)
            }
        }
    }

    private suspend fun extractChunks(
        file: File,
        pdfNameOverride: String? = null,
        pdfPathOverride: String? = null
    ): List<PdfChunk> {
        val chunks = mutableListOf<PdfChunk>()
        val displayName = pdfNameOverride ?: file.name
        val identityPath = pdfPathOverride ?: file.absolutePath

        // Pages where PdfBox found no extractable text — these are almost
        // always scanned photos of a page rather than real text, so they're
        // collected here and OCR'd in one batch afterward instead of one at
        // a time (batching keeps the PDDocument open/renderer setup cost to
        // once per file instead of once per blank page).
        val blankPages = mutableListOf<Int>()

        PDDocument.load(file).use { document ->
            val stripper = PDFTextStripper()
            val pageCount = document.numberOfPages

            for (pageNum in 1..pageCount) {
                stripper.startPage = pageNum
                stripper.endPage = pageNum
                val pageText = stripper.getText(document).trim()
                if (pageText.isBlank()) {
                    blankPages.add(pageNum)
                    continue
                }

                chunks.addAll(splitIntoChunks(pageText, displayName, identityPath, pageNum))
            }
        }

        // OCR fallback for scanned pages (a photographed book page, not a
        // real text layer) — this is what lets scanned medical
        // books/notes get indexed at all, since PdfBox alone can't read
        // text out of an image. Runs fully on-device, no network call.
        if (blankPages.isNotEmpty()) {
            val ocrResults = try {
                ocrService.ocrPdfPages(file, blankPages)
            } catch (e: Exception) {
                emptyMap()
            }
            for ((pageNum, ocrText) in ocrResults) {
                chunks.addAll(splitIntoChunks(ocrText, displayName, identityPath, pageNum, isOcr = true))
            }
        }

        return chunks
    }

    private fun splitIntoChunks(
        pageText: String,
        pdfName: String,
        pdfPath: String,
        pageNumber: Int,
        isOcr: Boolean = false
    ): List<PdfChunk> {
        val chunks = mutableListOf<PdfChunk>()
        val paragraphs = pageText.split(Regex("\n\\s*\n")).filter { it.isNotBlank() }

        val buffer = StringBuilder()
        for (para in paragraphs) {
            if (buffer.length + para.length > chunkSizeChars && buffer.isNotEmpty()) {
                chunks.add(buildChunk(buffer.toString(), pdfName, pdfPath, pageNumber, isOcr))
                buffer.clear()
            }
            buffer.append(para).append("\n\n")
        }
        if (buffer.isNotEmpty()) {
            chunks.add(buildChunk(buffer.toString(), pdfName, pdfPath, pageNumber, isOcr))
        }
        return chunks
    }

    private fun buildChunk(text: String, pdfName: String, pdfPath: String, pageNumber: Int, isOcr: Boolean = false): PdfChunk {
        return PdfChunk(
            pdfName = pdfName,
            pdfPath = pdfPath,
            pageNumber = pageNumber,
            text = text.trim(),
            searchableText = text.lowercase().replace(Regex("\\s+"), " ").trim(),
            isOcr = isOcr
        )
    }
}
