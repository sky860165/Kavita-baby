// data/PdfScannerService.kt
package com.kavitababy.data

import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import android.provider.OpenableColumns
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.io.File

/**
 * Finds every PDF on the device via MediaStore, pulls text out of it with
 * PdfBox, and stores it as searchable chunks in Room.
 *
 * Re-running scanAllPdfs() is safe: PDFs already indexed (same path) are
 * skipped, so calling this both on app start and from a manual "Scan PDFs"
 * button won't duplicate work or data.
 */
class PdfScannerService(private val context: Context) {

    private val dao = KavitaDatabase.getInstance(context).pdfChunkDao()

    // Roughly one paragraph per chunk. Small enough that the RAG search
    // returns focused context, big enough to keep sentence meaning intact.
    private val chunkSizeChars = 800

    data class ScanResult(val pdfsFound: Int, val pdfsIndexed: Int, val chunksCreated: Int)

    /** Result of indexing a single user-picked PDF via [indexPickedPdf]. */
    sealed class PickResult {
        data class Success(val pdfName: String, val chunksCreated: Int) : PickResult()
        data class Failure(val reason: String) : PickResult()
    }

    suspend fun scanAllPdfs(forceRescan: Boolean = false): ScanResult {
        PDFBoxResourceLoader.init(context.applicationContext)

        val pdfFiles = findAllPdfPaths()
        val alreadyIndexed = if (forceRescan) emptySet() else dao.getAllIndexedPaths().toSet()

        var indexedCount = 0
        var totalChunks = 0

        for (path in pdfFiles) {
            if (!forceRescan && path in alreadyIndexed) continue

            val file = File(path)
            if (!file.exists() || !file.canRead()) continue

            try {
                val chunks = extractChunks(file)
                if (chunks.isNotEmpty()) {
                    if (forceRescan) dao.deleteForPdf(path)
                    dao.insertAll(chunks)
                    indexedCount++
                    totalChunks += chunks.size
                }
            } catch (e: Exception) {
                // Corrupt / password-protected / unreadable PDF — skip it,
                // don't let one bad file stop the whole scan.
                continue
            }
        }

        return ScanResult(pdfsFound = pdfFiles.size, pdfsIndexed = indexedCount, chunksCreated = totalChunks)
    }

    /**
     * Indexes a single PDF the user picked through the system file picker
     * (Storage Access Framework — the 📎 upload button in ChatScreen).
     *
     * SAF hands back a content:// Uri, not a filesystem path, and that Uri
     * isn't readable by File()/PdfBox directly — so we first stream it into
     * the app's own private cache dir, then reuse the same extraction logic
     * as the full-device scan. This path works regardless of Android version
     * or scoped-storage restrictions, since the user explicitly chose the
     * file through the picker (no broad storage permission needed at all).
     */
    suspend fun indexPickedPdf(uri: Uri): PickResult {
        PDFBoxResourceLoader.init(context.applicationContext)

        val pdfName = queryDisplayName(uri) ?: "picked_${System.currentTimeMillis()}.pdf"
        val localFile = File(context.cacheDir, "picked_${System.currentTimeMillis()}_$pdfName")

        try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                localFile.outputStream().use { output ->
                    input.copyTo(output)
                }
            } ?: return PickResult.Failure("File open nahi ho payi")

            // Use the content Uri as the stable identity for re-indexing
            // checks (deleteForPdf/countForPdf), not the throwaway cache
            // path, since the cache filename includes a timestamp and would
            // never match on a re-pick of the same file.
            val identityPath = uri.toString()

            val chunks = extractChunks(localFile, pdfNameOverride = pdfName, pdfPathOverride = identityPath)
            if (chunks.isEmpty()) {
                return PickResult.Failure("Is PDF mein padhne layak text nahi mila (scanned image ho sakta hai)")
            }

            dao.deleteForPdf(identityPath)
            dao.insertAll(chunks)
            return PickResult.Success(pdfName = pdfName, chunksCreated = chunks.size)
        } catch (e: Exception) {
            return PickResult.Failure(e.message ?: "Kuch galat ho gaya PDF padhte waqt")
        } finally {
            localFile.delete()
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        return try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (cursor.moveToFirst() && nameIndex >= 0) cursor.getString(nameIndex) else null
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun findAllPdfPaths(): List<String> {
        val paths = mutableListOf<String>()
        val projection = arrayOf(MediaStore.Files.FileColumns.DATA)
        val selection = "${MediaStore.Files.FileColumns.MIME_TYPE} = ?"
        val selectionArgs = arrayOf("application/pdf")

        val cursor = context.contentResolver.query(
            MediaStore.Files.getContentUri("external"),
            projection,
            selection,
            selectionArgs,
            null
        )

        cursor?.use {
            val dataIndex = it.getColumnIndex(MediaStore.Files.FileColumns.DATA)
            while (it.moveToNext()) {
                if (dataIndex >= 0) {
                    it.getString(dataIndex)?.let { path -> paths.add(path) }
                }
            }
        }
        return paths
    }

    private fun extractChunks(
        file: File,
        pdfNameOverride: String? = null,
        pdfPathOverride: String? = null
    ): List<PdfChunk> {
        val chunks = mutableListOf<PdfChunk>()
        val displayName = pdfNameOverride ?: file.name
        val identityPath = pdfPathOverride ?: file.absolutePath

        PDDocument.load(file).use { document ->
            val stripper = PDFTextStripper()
            val pageCount = document.numberOfPages

            for (pageNum in 1..pageCount) {
                stripper.startPage = pageNum
                stripper.endPage = pageNum
                val pageText = stripper.getText(document).trim()
                if (pageText.isBlank()) continue

                chunks.addAll(splitIntoChunks(pageText, displayName, identityPath, pageNum))
            }
        }
        return chunks
    }

    private fun splitIntoChunks(
        pageText: String,
        pdfName: String,
        pdfPath: String,
        pageNumber: Int
    ): List<PdfChunk> {
        val chunks = mutableListOf<PdfChunk>()
        val paragraphs = pageText.split(Regex("\n\\s*\n")).filter { it.isNotBlank() }

        val buffer = StringBuilder()
        for (para in paragraphs) {
            if (buffer.length + para.length > chunkSizeChars && buffer.isNotEmpty()) {
                chunks.add(buildChunk(buffer.toString(), pdfName, pdfPath, pageNumber))
                buffer.clear()
            }
            buffer.append(para).append("\n\n")
        }
        if (buffer.isNotEmpty()) {
            chunks.add(buildChunk(buffer.toString(), pdfName, pdfPath, pageNumber))
        }
        return chunks
    }

    private fun buildChunk(text: String, pdfName: String, pdfPath: String, pageNumber: Int): PdfChunk {
        return PdfChunk(
            pdfName = pdfName,
            pdfPath = pdfPath,
            pageNumber = pageNumber,
            text = text.trim(),
            searchableText = text.lowercase().replace(Regex("\\s+"), " ").trim()
        )
    }
}
