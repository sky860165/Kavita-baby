// data/PdfScanScheduler.kt
package com.kavitababy.data

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

/**
 * Schedules [PdfScanWorker] to run periodically in the background, so a
 * large PDF backlog keeps getting chipped away at even when the app isn't
 * open — instead of progress only happening during the few minutes someone
 * has ChatScreen on screen.
 */
object PdfScanScheduler {

    private const val WORK_NAME = "background_pdf_scan"

    /**
     * Call once at app startup (see [com.kavitababy.KavitaBabyApp]).
     * [ExistingPeriodicWorkPolicy.KEEP] means calling this on every app
     * launch doesn't reset an already-scheduled job's timer or in-flight
     * retry backoff — it only actually schedules on the very first call.
     */
    fun schedulePeriodic(context: Context) {
        // Battery-not-low and storage-not-low so this never fights the
        // user for resources they need for something else — a background
        // index job should be invisible, not the reason the phone feels
        // slow or the battery drains faster.
        val constraints = Constraints.Builder()
            .setRequiresBatteryNotLow(true)
            .setRequiresStorageNotLow(true)
            .build()

        // 6 hours is a reasonable steady drip for a backlog that doesn't
        // need to finish urgently; PdfScanWorker's own Result.retry() (with
        // the short linear backoff below) is what actually keeps a large
        // 20GB-style backlog moving faster than once per periodic cycle
        // whenever there's still more left to do.
        val request = PeriodicWorkRequestBuilder<PdfScanWorker>(6, TimeUnit.HOURS)
            .setConstraints(constraints)
            .setBackoffCriteria(BackoffPolicy.LINEAR, 1, TimeUnit.MINUTES)
            .build()

        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            WORK_NAME,
            ExistingPeriodicWorkPolicy.KEEP,
            request
        )
    }
}
