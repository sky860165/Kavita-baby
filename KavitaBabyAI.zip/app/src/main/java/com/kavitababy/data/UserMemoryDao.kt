// data/UserMemoryDao.kt
package com.kavitababy.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.OnConflictStrategy
import androidx.room.Insert
import androidx.room.Query

@Dao
interface UserMemoryDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(memory: UserMemory)

    @Query("SELECT * FROM user_memories ORDER BY updatedAt DESC")
    suspend fun getAll(): List<UserMemory>

    @Query("DELETE FROM user_memories WHERE `key` = :key")
    suspend fun deleteByKey(key: String)

    @Query("DELETE FROM user_memories")
    suspend fun clearAll()

    @Delete
    suspend fun delete(memory: UserMemory)
}
