// data/KavitaDatabase.kt
package com.kavitababy.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        PdfChunk::class,
        CaseNote::class,
        UserMemory::class,
        AnswerFeedback::class,
        TopicStruggle::class,
        PatientCase::class,
        LearnedKnowledge::class,
        FollowUpReminder::class
    ],
    version = 8,
    exportSchema = false
)
abstract class KavitaDatabase : RoomDatabase() {

    abstract fun pdfChunkDao(): PdfChunkDao
    abstract fun caseNoteDao(): CaseNoteDao
    abstract fun userMemoryDao(): UserMemoryDao
    abstract fun answerFeedbackDao(): AnswerFeedbackDao
    abstract fun topicStruggleDao(): TopicStruggleDao
    abstract fun patientCaseDao(): PatientCaseDao
    abstract fun learnedKnowledgeDao(): LearnedKnowledgeDao
    abstract fun followUpReminderDao(): FollowUpReminderDao

    companion object {
        @Volatile
        private var INSTANCE: KavitaDatabase? = null

        fun getInstance(context: Context): KavitaDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    KavitaDatabase::class.java,
                    "kavita_baby_db"
                )
                    // No prior release to migrate real users from yet, so a
                    // destructive fallback is fine here — it just resets the
                    // local, on-device DB rather than crashing on upgrade.
                    .fallbackToDestructiveMigration()
                    .build().also { INSTANCE = it }
            }
        }
    }
}
