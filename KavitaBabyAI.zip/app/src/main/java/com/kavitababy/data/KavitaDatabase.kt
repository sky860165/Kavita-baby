// data/KavitaDatabase.kt
package com.kavitababy.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.launch

@Database(
    entities = [
        PdfChunk::class,
        CaseNote::class,
        UserMemory::class,
        AnswerFeedback::class,
        TopicStruggle::class,
        PatientCase::class,
        LearnedKnowledge::class,
        FollowUpReminder::class,
        LabValue::class,
        LabMetricPreset::class,
        DoctorTreatmentPattern::class,
        ChatMessageEntity::class
    ],
    version = 12,
    exportSchema = false
)
abstract class KavitaDatabase : RoomDatabase() {

    abstract fun pdfChunkDao(): PdfChunkDao
    abstract fun caseNoteDao(): CaseNoteDao
    abstract fun userMemoryDao(): UserMemoryDao
    abstract fun answerFeedbackDao(): AnswerFeedbackDao
    abstract fun topicStruggleDao(): TopicStruggleDao
    abstract fun patientCaseDao(): PatientCaseDao
    abstract fun learnedKnowledgeDao(): LearnedKnowledgeDao
    abstract fun followUpReminderDao(): FollowUpReminderDao
    abstract fun labValueDao(): LabValueDao
    abstract fun labMetricPresetDao(): LabMetricPresetDao
    abstract fun doctorTreatmentPatternDao(): DoctorTreatmentPatternDao
    abstract fun chatMessageDao(): ChatMessageDao

    companion object {
        @Volatile
        private var INSTANCE: KavitaDatabase? = null

        // Common vitals/labs every doctor tracks, shipped so the "add
        // reading" screen isn't empty on first use. Doctor can still add
        // as many custom ones as needed alongside these.
        private val builtInPresets = listOf(
            "BP Systolic" to "mmHg",
            "BP Diastolic" to "mmHg",
            "Pulse" to "bpm",
            "Temperature" to "°F",
            "SpO2" to "%",
            "Weight" to "kg",
            "Blood Sugar Fasting" to "mg/dL",
            "Blood Sugar PP" to "mg/dL",
            "HbA1c" to "%",
            "Hemoglobin" to "g/dL",
            "WBC Count" to "/µL",
            "Platelet Count" to "/µL",
            "Creatinine" to "mg/dL",
            "TSH" to "mIU/L"
        )

        fun getInstance(context: Context): KavitaDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    KavitaDatabase::class.java,
                    "kavita_baby_db"
                )
                    // No prior release to migrate real users from yet, so a
                    // destructive fallback is fine here — it just resets the
                    // local, on-device DB rather than crashing on upgrade.
                    .fallbackToDestructiveMigration()
                    .addCallback(object : RoomDatabase.Callback() {
                        override fun onCreate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                            super.onCreate(db)
                            // Seed built-in presets once, on first-ever DB
                            // creation for this install. Runs on a
                            // background thread via a fresh getInstance
                            // call so it doesn't touch the DB from the
                            // callback thread directly.
                            kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
                                val dao = INSTANCE?.labMetricPresetDao() ?: return@launch
                                if (dao.count() == 0) {
                                    dao.insertAll(
                                        builtInPresets.mapIndexed { index, (name, unit) ->
                                            LabMetricPreset(
                                                name = name,
                                                unit = unit,
                                                isBuiltIn = true,
                                                sortOrder = index.toLong()
                                            )
                                        }
                                    )
                                }
                            }
                        }
                    })
                    .build().also { INSTANCE = it }
            }
        }

        /**
         * Closes the current Room instance and clears the singleton so the
         * next [getInstance] call opens a fresh connection to whatever file
         * is on disk at that point. Needed by [BackupService.importBackup]
         * — swapping the underlying .db file while Room still holds an open
         * connection/cached statements against the old one would corrupt
         * or silently ignore the restore.
         */
        fun closeAndClearInstance() {
            synchronized(this) {
                INSTANCE?.close()
                INSTANCE = null
            }
        }
    }
}
