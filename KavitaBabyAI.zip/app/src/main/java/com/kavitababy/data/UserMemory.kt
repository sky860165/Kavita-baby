// data/UserMemory.kt
package com.kavitababy.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * A single remembered fact about the user, kept entirely on-device (Room).
 *
 * [key] is a short tag Kavita uses to avoid storing duplicates (e.g. "name",
 * "exam_date", "weak_subject_1") — inserting with an existing key overwrites
 * the old value rather than piling up stale duplicates. [value] is the
 * actual fact in plain text, exactly as Kavita understood it from the
 * conversation, with no separate categorization needed beyond the key.
 *
 * This is real persistence, not simulated "learning" — nothing here trains
 * or changes the underlying Gemini model. It just gives future prompts more
 * context about this specific user, the same way a person remembers things
 * about a friend across conversations.
 */
@Entity(tableName = "user_memories")
data class UserMemory(
    @PrimaryKey
    val key: String,
    val value: String,
    val updatedAt: Long = System.currentTimeMillis()
)
