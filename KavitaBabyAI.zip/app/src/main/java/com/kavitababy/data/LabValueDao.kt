// data/LabValueDao.kt
package com.kavitababy.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query

@Dao
interface LabValueDao {

    @Insert
    suspend fun insert(value: LabValue): Long

    /** Every reading for a patient, oldest first — ready to plot as a time-series. */
    @Query("SELECT * FROM lab_values WHERE patientId = :patientId AND metricName = :metricName ORDER BY recordedAt ASC")
    suspend fun getForMetric(patientId: Long, metricName: String): List<LabValue>

    /** Every reading for a patient across all metrics, newest first — used for the "add reading" screen's history list. */
    @Query("SELECT * FROM lab_values WHERE patientId = :patientId ORDER BY recordedAt DESC")
    suspend fun getAllForPatient(patientId: Long): List<LabValue>

    /**
     * Distinct metric names already recorded for this patient, most
     * recently used first — powers the quick-pick suggestions so the
     * doctor doesn't have to retype "BP Systolic" every single visit.
     */
    @Query(
        "SELECT metricName FROM lab_values WHERE patientId = :patientId " +
            "GROUP BY metricName ORDER BY MAX(recordedAt) DESC"
    )
    suspend fun getDistinctMetricNames(patientId: Long): List<String>

    @Delete
    suspend fun delete(value: LabValue)

    @Query("DELETE FROM lab_values WHERE patientId = :patientId")
    suspend fun deleteForPatient(patientId: Long)
}
