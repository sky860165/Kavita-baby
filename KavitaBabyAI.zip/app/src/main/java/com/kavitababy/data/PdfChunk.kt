// data/PdfChunk.kt
package com.kavitababy.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "pdf_chunks")
data class PdfChunk(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val pdfName: String,
    val pdfPath: String,
    val pageNumber: Int,
    val text: String,
    // Lowercased, whitespace-normalized copy of `text` used for fast keyword search.
    val searchableText: String,
    // True if this chunk's text came from on-device OCR (a scanned/photo
    // page) rather than the PDF's real text layer. OCR text is somewhat
    // more error-prone (misread characters, especially in tables/formulas),
    // so callers surface this so a doctor isn't fully trusting a possibly
    // misread drug name/dose without knowing it came from OCR.
    val isOcr: Boolean = false
)
