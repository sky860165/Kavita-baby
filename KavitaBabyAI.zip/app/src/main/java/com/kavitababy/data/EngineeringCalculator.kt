package com.kavitababy.data

import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.cos
import kotlin.math.tan
import kotlin.math.ln
import kotlin.math.sqrt

/**
 * Real, locally-computed engineering formulas + a free-form expression
 * evaluator. Used by Engineer Mode's calculator dialog — everything here
 * is actual math done on-device, never a number guessed by the AI.
 */
object EngineeringCalculator {

    enum class Formula(val label: String) {
        OHMS_LAW("Ohm's Law (V=IR)"),
        POWER("Power (P=VI)"),
        SERIES_RESISTANCE("Series Resistance (R=R1+R2)"),
        PARALLEL_RESISTANCE("Parallel Resistance (2 resistors)"),
        CAPACITIVE_REACTANCE("Capacitive Reactance (Xc=1/2πfC)"),
        INDUCTIVE_REACTANCE("Inductive Reactance (XL=2πfL)"),
        RLC_RESONANT_FREQ("RLC Resonant Frequency (f=1/2π√LC)"),
        BEAM_STRESS("Bending Stress (σ=Mc/I)"),
        BEAM_DEFLECTION("Simply-Supported Beam Deflection (center point load)"),
        EULER_BUCKLING("Euler Buckling Load (Pcr=π²EI/(KL)²)"),
        TORSIONAL_SHEAR("Torsional Shear Stress (τ=Tr/J)"),
        FACTOR_OF_SAFETY("Factor of Safety (FoS=Failure/Allowable)"),
        CONDUCTION_HEAT_TRANSFER("Conduction Heat Transfer (Q=kAΔT/L)"),
        REYNOLDS_NUMBER("Reynolds Number (Re=ρvD/μ)"),
        FREE_EXPRESSION("Free Expression")
    }

    fun requiredFields(formula: Formula): List<String> = when (formula) {
        Formula.OHMS_LAW -> listOf("Current (A)", "Resistance (Ω)")
        Formula.POWER -> listOf("Voltage (V)", "Current (A)")
        Formula.SERIES_RESISTANCE -> listOf("R1 (Ω)", "R2 (Ω)")
        Formula.PARALLEL_RESISTANCE -> listOf("R1 (Ω)", "R2 (Ω)")
        Formula.CAPACITIVE_REACTANCE -> listOf("Frequency f (Hz)", "Capacitance C (F)")
        Formula.INDUCTIVE_REACTANCE -> listOf("Frequency f (Hz)", "Inductance L (H)")
        Formula.RLC_RESONANT_FREQ -> listOf("Inductance L (H)", "Capacitance C (F)")
        Formula.BEAM_STRESS -> listOf("Moment M (N·m)", "Distance c (m)", "Moment of Inertia I (m⁴)")
        Formula.BEAM_DEFLECTION -> listOf("Load P (N)", "Length L (m)", "Modulus E (Pa)", "Moment of Inertia I (m⁴)")
        Formula.EULER_BUCKLING -> listOf("Modulus E (Pa)", "Moment of Inertia I (m⁴)", "Effective Length Factor K", "Length L (m)")
        Formula.TORSIONAL_SHEAR -> listOf("Torque T (N·m)", "Radius r (m)", "Polar Moment J (m⁴)")
        Formula.FACTOR_OF_SAFETY -> listOf("Failure Stress/Load", "Allowable Stress/Load")
        Formula.CONDUCTION_HEAT_TRANSFER -> listOf("Thermal Conductivity k (W/m·K)", "Area A (m²)", "ΔT (K)", "Thickness L (m)")
        Formula.REYNOLDS_NUMBER -> listOf("Density ρ (kg/m³)", "Velocity v (m/s)", "Diameter D (m)", "Viscosity μ (Pa·s)")
        Formula.FREE_EXPRESSION -> listOf("Expression")
    }

    fun calculate(formula: Formula, inputs: Map<String, String>): Result<String> = try {
        when (formula) {
            Formula.OHMS_LAW -> {
                val i = inputs.getValue("Current (A)").toDouble()
                val r = inputs.getValue("Resistance (Ω)").toDouble()
                Result.success("Voltage (V): ${i * r}")
            }
            Formula.POWER -> {
                val v = inputs.getValue("Voltage (V)").toDouble()
                val i = inputs.getValue("Current (A)").toDouble()
                Result.success("Power (W): ${v * i}")
            }
            Formula.SERIES_RESISTANCE -> {
                val r1 = inputs.getValue("R1 (Ω)").toDouble()
                val r2 = inputs.getValue("R2 (Ω)").toDouble()
                Result.success("Total Resistance (Ω): ${r1 + r2}")
            }
            Formula.PARALLEL_RESISTANCE -> {
                val r1 = inputs.getValue("R1 (Ω)").toDouble()
                val r2 = inputs.getValue("R2 (Ω)").toDouble()
                if (r1 + r2 == 0.0) throw IllegalArgumentException("R1+R2 can't be zero")
                Result.success("Total Resistance (Ω): ${(r1 * r2) / (r1 + r2)}")
            }
            Formula.CAPACITIVE_REACTANCE -> {
                val f = inputs.getValue("Frequency f (Hz)").toDouble()
                val c = inputs.getValue("Capacitance C (F)").toDouble()
                if (f == 0.0 || c == 0.0) throw IllegalArgumentException("f and C must be non-zero")
                Result.success("Xc (Ω): ${1.0 / (2 * Math.PI * f * c)}")
            }
            Formula.INDUCTIVE_REACTANCE -> {
                val f = inputs.getValue("Frequency f (Hz)").toDouble()
                val l = inputs.getValue("Inductance L (H)").toDouble()
                Result.success("XL (Ω): ${2 * Math.PI * f * l}")
            }
            Formula.RLC_RESONANT_FREQ -> {
                val l = inputs.getValue("Inductance L (H)").toDouble()
                val c = inputs.getValue("Capacitance C (F)").toDouble()
                if (l <= 0.0 || c <= 0.0) throw IllegalArgumentException("L and C must be positive")
                Result.success("Resonant Frequency f (Hz): ${1.0 / (2 * Math.PI * sqrt(l * c))}")
            }
            Formula.BEAM_STRESS -> {
                val m = inputs.getValue("Moment M (N·m)").toDouble()
                val c = inputs.getValue("Distance c (m)").toDouble()
                val inertia = inputs.getValue("Moment of Inertia I (m⁴)").toDouble()
                Result.success("Bending Stress σ (Pa): ${(m * c) / inertia}")
            }
            Formula.BEAM_DEFLECTION -> {
                // Simply-supported beam, single point load at center: δ = PL³/48EI
                val p = inputs.getValue("Load P (N)").toDouble()
                val length = inputs.getValue("Length L (m)").toDouble()
                val e = inputs.getValue("Modulus E (Pa)").toDouble()
                val inertia = inputs.getValue("Moment of Inertia I (m⁴)").toDouble()
                Result.success("Max Deflection δ (m): ${(p * length.pow(3)) / (48 * e * inertia)}")
            }
            Formula.EULER_BUCKLING -> {
                val e = inputs.getValue("Modulus E (Pa)").toDouble()
                val inertia = inputs.getValue("Moment of Inertia I (m⁴)").toDouble()
                val k = inputs.getValue("Effective Length Factor K").toDouble()
                val length = inputs.getValue("Length L (m)").toDouble()
                Result.success("Critical Load Pcr (N): ${(Math.PI.pow(2) * e * inertia) / (k * length).pow(2)}")
            }
            Formula.TORSIONAL_SHEAR -> {
                val t = inputs.getValue("Torque T (N·m)").toDouble()
                val r = inputs.getValue("Radius r (m)").toDouble()
                val j = inputs.getValue("Polar Moment J (m⁴)").toDouble()
                Result.success("Shear Stress τ (Pa): ${(t * r) / j}")
            }
            Formula.FACTOR_OF_SAFETY -> {
                val failure = inputs.getValue("Failure Stress/Load").toDouble()
                val allowable = inputs.getValue("Allowable Stress/Load").toDouble()
                if (allowable == 0.0) throw IllegalArgumentException("Allowable value can't be zero")
                Result.success("Factor of Safety: ${failure / allowable}")
            }
            Formula.CONDUCTION_HEAT_TRANSFER -> {
                val k = inputs.getValue("Thermal Conductivity k (W/m·K)").toDouble()
                val a = inputs.getValue("Area A (m²)").toDouble()
                val dt = inputs.getValue("ΔT (K)").toDouble()
                val l = inputs.getValue("Thickness L (m)").toDouble()
                if (l == 0.0) throw IllegalArgumentException("Thickness can't be zero")
                Result.success("Heat Transfer Q (W): ${(k * a * dt) / l}")
            }
            Formula.REYNOLDS_NUMBER -> {
                val rho = inputs.getValue("Density ρ (kg/m³)").toDouble()
                val v = inputs.getValue("Velocity v (m/s)").toDouble()
                val d = inputs.getValue("Diameter D (m)").toDouble()
                val mu = inputs.getValue("Viscosity μ (Pa·s)").toDouble()
                if (mu == 0.0) throw IllegalArgumentException("Viscosity can't be zero")
                val re = (rho * v * d) / mu
                val regime = when {
                    re < 2300 -> "Laminar"
                    re < 4000 -> "Transitional"
                    else -> "Turbulent"
                }
                Result.success("Reynolds Number: $re ($regime)")
            }
            Formula.FREE_EXPRESSION -> {
                val expr = inputs.getValue("Expression")
                Result.success("Result: ${ExpressionEvaluator(expr).evaluate()}")
            }
        }
    } catch (e: Exception) {
        Result.failure(Exception("Invalid input: ${e.message}"))
    }
}

/**
 * Small recursive-descent evaluator for arithmetic expressions.
 * Supports + - * / ^ (), and functions sqrt/sin/cos/tan/ln.
 */
private class ExpressionEvaluator(expression: String) {
    private val tokens = expression.replace(" ", "").replace("pi", Math.PI.toString())
    private var pos = 0

    fun evaluate(): Double {
        val result = parseExpression()
        if (pos != tokens.length) throw IllegalArgumentException("Unexpected character at $pos")
        return result
    }

    private fun parseExpression(): Double {
        var value = parseTerm()
        while (pos < tokens.length && (tokens[pos] == '+' || tokens[pos] == '-')) {
            val op = tokens[pos]; pos++
            val next = parseTerm()
            value = if (op == '+') value + next else value - next
        }
        return value
    }

    private fun parseTerm(): Double {
        var value = parseFactor()
        while (pos < tokens.length && (tokens[pos] == '*' || tokens[pos] == '/')) {
            val op = tokens[pos]; pos++
            val next = parseFactor()
            value = if (op == '*') value * next else value / next
        }
        return value
    }

    private fun parseFactor(): Double {
        var value = parseBase()
        if (pos < tokens.length && tokens[pos] == '^') {
            pos++
            value = value.pow(parseFactor())
        }
        return value
    }

    private fun parseBase(): Double {
        if (pos < tokens.length && tokens[pos] == '-') { pos++; return -parseBase() }
        if (pos < tokens.length && tokens[pos] == '(') {
            pos++
            val value = parseExpression()
            if (pos < tokens.length && tokens[pos] == ')') pos++
            return value
        }
        for ((name, fn) in functions) {
            if (tokens.startsWith(name, pos)) {
                pos += name.length
                if (pos < tokens.length && tokens[pos] == '(') {
                    pos++
                    val arg = parseExpression()
                    if (pos < tokens.length && tokens[pos] == ')') pos++
                    return fn(arg)
                }
            }
        }
        val start = pos
        while (pos < tokens.length && (tokens[pos].isDigit() || tokens[pos] == '.')) pos++
        if (start == pos) throw IllegalArgumentException("Invalid expression at $pos")
        return tokens.substring(start, pos).toDouble()
    }

    companion object {
        private val functions: List<Pair<String, (Double) -> Double>> = listOf(
            "sqrt" to { x -> sqrt(x) },
            "sin" to { x -> sin(x) },
            "cos" to { x -> cos(x) },
            "tan" to { x -> tan(x) },
            "ln" to { x -> ln(x) }
        )
    }
}
