// data/CarProjectDao.kt
package com.kavitababy.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query

@Dao
interface CarProjectDao {

    @Insert
    suspend fun insert(project: CarProject): Long

    @Query("SELECT * FROM car_projects ORDER BY lastUpdatedAt DESC")
    suspend fun getAll(): List<CarProject>

    @Query("SELECT * FROM car_projects WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): CarProject?

    @Query("UPDATE car_projects SET lastUpdatedAt = :updatedAt WHERE id = :id")
    suspend fun touch(id: Long, updatedAt: Long = System.currentTimeMillis())

    @Delete
    suspend fun delete(project: CarProject)
}
