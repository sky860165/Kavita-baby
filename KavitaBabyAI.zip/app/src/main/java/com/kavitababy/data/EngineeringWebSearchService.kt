// data/EngineeringWebSearchService.kt
package com.kavitababy.data

import com.kavitababy.BuildConfig
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Live web search for Engineer Mode, restricted to established
 * standards bodies, technical references, and academic sources — same
 * two-layer trusted-domain discipline as [MedicalWebSearchService], just
 * pointed at engineering sources instead of medical ones.
 *
 * Reuses the same Google Custom Search JSON API credentials
 * (GCP_API_KEY1) as Doctor Mode. The Programmable Search Engine ID can
 * either be a SEPARATE engine scoped to the domains below
 * (GCP_SEARCH_ENGINE_ID_ENGINEERING — recommended, set this up at
 * https://programmablesearchengine.google.com same as the medical one),
 * or, if that secret is left blank, this falls back to the same engine
 * ID Doctor Mode uses (GCP_SEARCH_ENGINE_ID). NOTE: if that shared engine
 * is itself configured (on Google's side) to only index medical domains,
 * the "site:" filter below can't override that restriction — a
 * dedicated engineering engine is the reliable way to get real results.
 *
 * Same two layers of restriction as Doctor Mode:
 *  1. site: filter in the query itself.
 *  2. Every result is re-checked against [trustedDomains] after the API
 *     responds, regardless of how the search engine itself is configured.
 */
class EngineeringWebSearchService {

    /**
     * Standards bodies, established technical references, and open
     * courseware — deliberately favors authoritative, citable sources
     * over forums/wikis/random blogs, the same way a careful engineer
     * would prefer a datasheet or a standards document over a random
     * search hit.
     */
    private val trustedDomains = setOf(
        "ieee.org",
        "ieeexplore.ieee.org",
        "asme.org",
        "asce.org",
        "nist.gov",
        "nasa.gov",
        "iso.org",
        "din.de",
        "en.wikipedia.org",
        "engineeringtoolbox.com",
        "nptel.ac.in",
        "ocw.mit.edu",
        "mit.edu",
        "sciencedirect.com",
        "ieeeaccess.ieee.org",
        "autodesk.com",
        "ni.com",
        "ansys.com",
        "matweb.com",
        "efunda.com",
        // --- Mechatronics/robotics/PCB/motor real-world practical sources ---
        // Without these, live search only ever returned academic/standards
        // content — nothing about actual motor drivers, PCB layout, or
        // embedded code, which is what a "build a real robot/EV car" question
        // actually needs.
        "ti.com",               // Texas Instruments — motor driver/power IC datasheets
        "st.com",               // STMicroelectronics — motor driver/MCU datasheets
        "microchip.com",        // Microchip — MCU/motor control datasheets & app notes
        "analog.com",           // Analog Devices — motor control, sensor ICs
        "arduino.cc",           // Arduino — official docs, reference, libraries
        "espressif.com",        // Espressif — ESP32 official docs
        "docs.espressif.com",
        "adafruit.com",         // Adafruit — parts + real wiring/code tutorials
        "learn.adafruit.com",
        "sparkfun.com",         // SparkFun — parts + tutorials
        "learn.sparkfun.com",
        "pololu.com",           // Pololu — motors/drivers, excellent technical docs
        "robotshop.com",        // RobotShop — robotics parts + guides
        "allaboutcircuits.com", // Practical circuit design/PCB tutorials
        "electronics-tutorials.ws",
        "circuitdigest.com",    // Real circuit/PCB/embedded project walkthroughs
        "digikey.com",          // Digi-Key — datasheets, technical articles
        "hackster.io",          // Real, documented robotics/embedded builds
        "kicad.org",            // KiCad — free PCB design tool docs
        "jlcpcb.com",           // PCB fabrication — design rules/capabilities
        "randomnerdtutorials.com" // Widely-used, accurate ESP32/Arduino tutorials
    )

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    data class WebResult(val title: String, val snippet: String, val url: String, val domain: String)

    /**
     * Runs [query] through Google Custom Search, restricted to
     * [trustedDomains], and returns up to [maxResults] hits. Returns an
     * empty list (never throws) on any failure — missing/blank API key,
     * network error, quota exceeded, or zero results — so callers can
     * treat "no live web context" exactly like "no PDF context" and fall
     * back to the AI's own general engineering knowledge.
     */
    fun search(query: String, maxResults: Int = 4): List<WebResult> {
        val apiKey = BuildConfig.GCP_API_KEY1
        val searchEngineId = BuildConfig.GCP_SEARCH_ENGINE_ID_ENGINEERING.ifBlank {
            BuildConfig.GCP_SEARCH_ENGINE_ID
        }
        if (apiKey.isBlank() || searchEngineId.isBlank() || query.isBlank()) return emptyList()

        val siteFilter = trustedDomains.joinToString(" OR ") { "site:$it" }
        val fullQuery = "$query ($siteFilter)"

        val url = buildSearchUrl(apiKey, searchEngineId, fullQuery, maxResults) ?: return emptyList()

        val request = Request.Builder().url(url).get().build()

        return try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return emptyList()
                val bodyString = response.body?.string().orEmpty()
                val json = JSONObject(bodyString)
                val items = json.optJSONArray("items") ?: return emptyList()

                val results = mutableListOf<WebResult>()
                for (i in 0 until items.length()) {
                    val item = items.getJSONObject(i)
                    val link = item.optString("link")
                    val domain = extractDomain(link)
                    if (trustedDomains.none { domain == it || domain.endsWith(".$it") }) continue

                    results.add(
                        WebResult(
                            title = item.optString("title"),
                            snippet = item.optString("snippet"),
                            url = link,
                            domain = domain
                        )
                    )
                    if (results.size >= maxResults) break
                }
                results
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun extractDomain(url: String): String {
        return try {
            val host = java.net.URI(url).host ?: return ""
            if (host.startsWith("www.")) host.removePrefix("www.") else host
        } catch (e: Exception) {
            ""
        }
    }

    private fun buildSearchUrl(apiKey: String, cx: String, query: String, num: Int): okhttp3.HttpUrl? {
        return "https://www.googleapis.com/customsearch/v1".toHttpUrlOrNull()?.newBuilder()
            ?.addQueryParameter("key", apiKey)
            ?.addQueryParameter("cx", cx)
            ?.addQueryParameter("q", query)
            ?.addQueryParameter("num", num.coerceIn(1, 10).toString())
            ?.build()
    }
}
