// data/DoctorLearningEngine.kt
package com.kavitababy.data

import android.content.Context

/**
 * Doctor Mode's version of [LearningEngine] — instead of remembering facts
 * about a student, this remembers how THIS specific doctor actually
 * practices: for a given diagnosis, what did she actually end up
 * prescribing/doing, across her real patients over time. That gets fed back
 * into future prompts as reference context (same mechanism as a PDF chunk),
 * so over time suggestions lean toward this doctor's own established
 * pattern instead of only generic textbook guidance.
 *
 * Deliberately built on an explicit signal only: a pattern is only recorded
 * when the doctor manually saves/confirms a patient's file (Edit File
 * dialog) — never automatically off the AI's own suggestion, and never off
 * an unconfirmed differential. That's what makes this "the doctor's
 * pattern" rather than "the AI's suggestion reflected back at itself."
 *
 * Fully on-device (Room), same as everything else in [LearningEngine] —
 * nothing here trains or modifies Gemini; it only changes how much of this
 * doctor's own history is included as context in her next prompt. Every
 * public function degrades to a no-op / empty string on any failure so a
 * DB hiccup never blocks an actual clinical answer.
 */
class DoctorLearningEngine(context: Context) {

    private val dao = KavitaDatabase.getInstance(context).doctorTreatmentPatternDao()

    private val stopWords = setOf(
        "the", "a", "an", "is", "are", "was", "were", "with", "and", "or",
        "of", "in", "on", "at", "to", "for", "kya", "hai", "ka", "ki", "ke",
        "mein", "se", "ko", "aur", "ye", "wo", "hain", "tha", "thi", "patient"
    )

    private fun extractKeywords(text: String): List<String> {
        return text.lowercase()
            .replace(Regex("[^a-z0-9\\u0900-\\u097F ]"), " ")
            .split(" ")
            .map { it.trim() }
            .filter { it.length > 3 && it !in stopWords }
            .distinct()
    }

    /**
     * Called ONLY from the doctor's manual "Edit File" save — records that
     * for [diagnosis], this doctor's actual decision was [treatmentGiven].
     * Silently skipped if either side is blank (nothing meaningful to
     * learn from yet) — e.g. a doctor filling in just an allergy update
     * with no diagnosis/medicines set shouldn't create a hollow entry.
     */
    suspend fun recordTreatmentPattern(diagnosis: String, treatmentGiven: String) {
        val cleanDiagnosis = diagnosis.trim()
        val cleanTreatment = treatmentGiven.trim()
        if (cleanDiagnosis.isBlank() || cleanTreatment.isBlank()) return

        try {
            val searchable = (cleanDiagnosis + " " + cleanTreatment)
                .lowercase().replace(Regex("\\s+"), " ").trim()
            dao.insert(
                DoctorTreatmentPattern(
                    diagnosis = cleanDiagnosis,
                    treatmentGiven = cleanTreatment,
                    searchableText = searchable
                )
            )
        } catch (e: Exception) {
            // Non-fatal — worst case, this one save just doesn't get
            // remembered as a pattern; the file itself still saved fine.
        }
    }

    /**
     * Returns a prompt-ready block of this doctor's own past treatment
     * patterns that look relevant to [caseOrDiagnosis] (a free-text
     * diagnosis name or case description) — grouped so a diagnosis she's
     * confirmed the same way multiple times reads as an established
     * pattern rather than a flat list of one-off entries. Empty string if
     * nothing relevant is found (fresh install, or a genuinely new kind of
     * case), so callers can just always append this without an extra
     * isBlank() check cluttering the call site.
     */
    suspend fun doctorPatternContextBlock(caseOrDiagnosis: String): String {
        if (caseOrDiagnosis.isBlank()) return ""

        val keywords = extractKeywords(caseOrDiagnosis)
        if (keywords.isEmpty()) return ""

        val candidates = mutableMapOf<Long, DoctorTreatmentPattern>()
        for (keyword in keywords) {
            try {
                dao.searchByKeyword(keyword).forEach { candidates[it.id] = it }
            } catch (e: Exception) {
                return ""
            }
        }
        if (candidates.isEmpty()) return ""

        // Score by how many of the ORIGINAL keywords the diagnosis text
        // contains — same idea as RagSearchEngine's chunk scoring, so a
        // pattern that actually matches the current diagnosis closely
        // outranks one that only shares one incidental word.
        data class Scored(val pattern: DoctorTreatmentPattern, val score: Int)

        val scored = candidates.values.map { p ->
            val lower = p.diagnosis.lowercase()
            val score = keywords.count { lower.contains(it) }
            Scored(p, score)
        }.filter { it.score > 0 }
            .sortedWith(compareByDescending<Scored> { it.score }.thenByDescending { it.pattern.createdAt })

        if (scored.isEmpty()) return ""

        // Group by diagnosis (case-insensitive) so 3 past entries of
        // "Type 2 Diabetes" -> "Metformin 500mg BD" collapse into ONE
        // grouped line showing how many times, not 3 repeated lines.
        val grouped = scored.map { it.pattern }
            .groupBy { it.diagnosis.trim().lowercase() }
            .values
            .sortedByDescending { group -> group.maxOf { it.createdAt } }
            .take(5)

        val lines = grouped.joinToString("\n\n") { group ->
            val diagnosisLabel = group.first().diagnosis
            val mostRecentFirst = group.sortedByDescending { it.createdAt }
            val treatmentCounts = mostRecentFirst
                .groupingBy { it.treatmentGiven.trim() }
                .eachCount()
                .entries
                .sortedByDescending { it.value }

            val treatmentLines = treatmentCounts.joinToString("\n") { (treatment, count) ->
                if (count > 1) "  • $treatment (${count}x is doctor ne pehle bhi diya hai)"
                else "  • $treatment"
            }
            "[$diagnosisLabel]\n$treatmentLines"
        }

        return """
            --- IS DOCTOR KA APNA PAST TREATMENT PATTERN (unke khud ke pehle confirm kiye gaye cases se) ---
            Ye is doctor ne khud, apne judgement se, pehle is jaisi diagnosis
            mein jo actually diya hai — koi textbook guideline nahi, unki
            apni practice ka record hai. Agar current case genuinely similar
            hai, to isi pattern ko naturally mention/suggest karo (consistent
            raho unki apni practice ke saath), lekin agar current case ke
            findings clearly alag hain (severity, comorbidity, allergy, etc),
            to blindly isi purane pattern ko mat thoopo — apna clinical
            reasoning use karo aur bata do ki ye case pehle wale se kyun alag
            hai.
            $lines
            --- END DOCTOR'S PATTERN ---
        """.trimIndent()
    }
}
