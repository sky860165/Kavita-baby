// data/BootReminderReceiver.kt
package com.kavitababy.data

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * AlarmManager alarms are wiped by the OS on every reboot — without this,
 * a follow-up reminder scheduled for "3 din baad" would silently never
 * fire if the phone happened to restart in between (common enough on
 * budget/MIUI devices that reboot for updates or low-memory kills). This
 * re-reads every still-pending future reminder from Room on boot and
 * re-schedules its AlarmManager alarm — the doctor never has to notice or
 * do anything for this to keep working.
 */
class BootReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return

        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val dao = KavitaDatabase.getInstance(context.applicationContext).followUpReminderDao()
                val pending = dao.getPendingFutureReminders(System.currentTimeMillis())
                for (reminder in pending) {
                    ReminderScheduler.schedule(context.applicationContext, reminder)
                }
            } catch (e: Exception) {
                // If this fails, reminders simply won't fire until the
                // doctor next opens the app (nothing else re-triggers this
                // re-scheduling) — not ideal, but not a crash either.
            } finally {
                pendingResult.finish()
            }
        }
    }
}
