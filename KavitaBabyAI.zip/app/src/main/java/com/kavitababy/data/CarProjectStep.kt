// data/CarProjectStep.kt
package com.kavitababy.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * One tick-off-able step in a [CarProject]'s build checklist. [phase] is
 * one of "MECHANICAL", "ELECTRICAL", "SOFTWARE", or "INTEGRATION" — used
 * only to group/order steps in the UI, not a hard enum column, so the AI's
 * output can't crash parsing over an unexpected label (unrecognized
 * phases just fall into an "Other" group, see [AIRepository] parsing).
 */
@Entity(tableName = "car_project_steps")
data class CarProjectStep(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val projectId: Long,
    val phase: String,
    val stepOrder: Int,
    val title: String,
    val detail: String = "",
    val isDone: Boolean = false
)
