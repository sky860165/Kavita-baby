// data/AnswerFeedback.kt
package com.kavitababy.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Records a 👍/👎 the user gave on a specific Kavita answer, plus an
 * optional short reason for a 👎 (e.g. "bahut lamba", "galat tha", "samajh
 * nahi aaya"). Kept entirely on-device.
 *
 * Only the most recent handful of 👎 reasons are pulled into future prompts
 * (see AIRepository.buildFeedbackContext) — this steers Gemini's *style*
 * (length, tone, directness) based on what specifically annoyed this user
 * before. It doesn't and can't change facts Gemini gets wrong; it's a
 * writing-style nudge, not a correctness fix.
 */
@Entity(tableName = "answer_feedback")
data class AnswerFeedback(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val question: String,
    val answer: String,
    val liked: Boolean,
    val reason: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
