// data/AnswerFeedbackDao.kt
package com.kavitababy.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface AnswerFeedbackDao {

    @Insert
    suspend fun insert(feedback: AnswerFeedback): Long

    // Only recent dislikes matter for steering future answers — old ones
    // may no longer reflect what the user cares about, and an unbounded
    // list would bloat every prompt over time.
    @Query("SELECT * FROM answer_feedback WHERE liked = 0 ORDER BY createdAt DESC LIMIT :limit")
    suspend fun getRecentDislikes(limit: Int = 5): List<AnswerFeedback>

    @Query("SELECT COUNT(*) FROM answer_feedback WHERE liked = 1")
    suspend fun likedCount(): Int

    @Query("SELECT COUNT(*) FROM answer_feedback WHERE liked = 0")
    suspend fun dislikedCount(): Int
}
