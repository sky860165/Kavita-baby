// data/PatientCase.kt
package com.kavitababy.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * One patient in Doctor Mode's patient list. Everything about a patient is
 * local-only (Room, on-device) — nothing here is ever sent to Gemini/any
 * network call except the specific text a doctor is actively discussing in
 * a message, and even then only what she chooses to type into that message
 * (the raw name field below is never included in AI prompts by itself).
 *
 * [encryptedName] is stored already encrypted via [PatientCrypto] — always
 * go through [PatientCrypto.encrypt]/[PatientCrypto.decrypt] when writing/
 * reading it, never store or compare plain text directly. Age and gender
 * are kept as plain fields (not independently identifying on their own),
 * matching how CaseNote already avoided storing identity but did keep
 * clinical fields in plain text.
 */
@Entity(tableName = "patient_cases")
data class PatientCase(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val encryptedName: String,
    val age: String,
    val gender: String,
    val createdAt: Long = System.currentTimeMillis(),
    val lastUpdatedAt: Long = System.currentTimeMillis()
)
