// data/PatientCase.kt
package com.kavitababy.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * One patient in Doctor Mode's patient list. Everything about a patient is
 * local-only (Room, on-device) — nothing here is ever sent to Gemini/any
 * network call except the specific text a doctor is actively discussing in
 * a message, and even then only what she chooses to type into that message
 * (the raw name field below is never included in AI prompts by itself).
 *
 * [encryptedName] is stored already encrypted via [PatientCrypto] — always
 * go through [PatientCrypto.encrypt]/[PatientCrypto.decrypt] when writing/
 * reading it, never store or compare plain text directly. Age and gender
 * are kept as plain fields (not independently identifying on their own),
 * matching how CaseNote already avoided storing identity but did keep
 * clinical fields in plain text.
 *
 * [currentDiagnosis]/[currentSuggestion]/[currentMedicines] are the
 * patient's active clinical summary — kept directly on the patient record
 * (not just buried inside individual [CaseNote] rows) so the file's
 * headline state is visible immediately without paging through history.
 * These update two ways:
 *  1. Automatically — when a Case Workup is combined and a diagnosis is
 *     confirmed, or the AI suggests a medicine/dose during a workup.
 *  2. Manually — the doctor can edit any of these three fields directly
 *     from the patient's file, overriding whatever was auto-filled.
 * Both paths write through the same fields, so there's no separate
 * "doctor version" vs "AI version" to reconcile — whichever happened most
 * recently is simply what's there, and [lastUpdatedAt] reflects it.
 *
 * [knownAllergies] is free text, doctor-entered only (never auto-filled) —
 * used as extra context for the drug interaction checker so a suggested
 * medicine from an allergic class gets flagged.
 */
@Entity(tableName = "patient_cases")
data class PatientCase(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val encryptedName: String,
    val age: String,
    val gender: String,
    val createdAt: Long = System.currentTimeMillis(),
    val lastUpdatedAt: Long = System.currentTimeMillis(),
    val currentDiagnosis: String = "",
    val currentSuggestion: String = "",
    val currentMedicines: String = "",
    val knownAllergies: String = ""
)
