// data/LearningEngine.kt
package com.kavitababy.data

/**
 * Ties together the three "gets better over time" pieces the user asked
 * for: remembered facts, feedback-driven style adjustment, and
 * recurring-topic detection. Everything here is plain on-device storage
 * and prompt-building — nothing trains or modifies the Gemini model
 * itself. What actually improves over time is how much relevant context
 * Kavita has about this specific user, not the underlying AI's raw
 * capability.
 *
 * All three pieces degrade gracefully to "no context" if the DB is empty
 * (fresh install) or a read fails, so this never blocks a normal chat
 * reply — it only adds to it when there's something worth adding.
 */
class LearningEngine(context: android.content.Context) {

    private val memoryDao = KavitaDatabase.getInstance(context).userMemoryDao()
    private val feedbackDao = KavitaDatabase.getInstance(context).answerFeedbackDao()
    private val topicDao = KavitaDatabase.getInstance(context).topicStruggleDao()

    // ---- Memory ----

    /** Saves or updates a remembered fact about the user. */
    suspend fun remember(key: String, value: String) {
        try {
            memoryDao.upsert(UserMemory(key = key.trim().lowercase(), value = value.trim()))
        } catch (e: Exception) {
            // Non-fatal — worst case, Kavita just doesn't remember this one thing.
        }
    }

    suspend fun forget(key: String) {
        try {
            memoryDao.deleteByKey(key.trim().lowercase())
        } catch (e: Exception) { }
    }

    suspend fun forgetEverything() {
        try {
            memoryDao.clearAll()
        } catch (e: Exception) { }
    }

    /** All remembered facts, formatted for inclusion in a Gemini prompt. Empty string if nothing stored. */
    suspend fun memoryContextBlock(): String {
        val memories = try { memoryDao.getAll() } catch (e: Exception) { emptyList() }
        if (memories.isEmpty()) return ""

        val lines = memories.joinToString("\n") { "- ${it.key}: ${it.value}" }
        return """
            --- KAVITA KO USER KE BAARE MEIN YE PATA HAI (pichle conversations se yaad hai) ---
            $lines
            Inhe naturally use karo jaha relevant ho, lekin har jawab mein zabardasti mat thoodo.
            Agar user koi purani baat change kare (jaise naya exam date, naya subject), to naya
            fact yaad rakho, purana wala use mat karo.
            --- END REMEMBERED INFO ---
        """.trimIndent()
    }

    /**
     * Very lightweight fact extraction: looks for a few common patterns in
     * the user's own message (name, exam date, weak subject) and stores
     * them automatically. This is deliberately simple pattern-matching, not
     * another AI call — keeps it fast, free, and fully offline. Anything
     * more nuanced the user says gets stored later via explicit "yaad
     * rakhna" commands instead (see maybeHandleExplicitMemoryCommand).
     */
    suspend fun autoExtractFromMessage(message: String) {
        val lower = message.lowercase()

        Regex("mera naam (\\w+)").find(lower)?.let {
            remember("name", it.groupValues[1].replaceFirstChar { c -> c.uppercase() })
        }
        Regex("mujhe (\\w+) (kamzor|weak) lagta").find(lower)?.let {
            remember("weak_subject", it.groupValues[1])
        }
        Regex("(exam|paper) (\\d{1,2} \\w+|\\d{1,2}/\\d{1,2})").find(lower)?.let {
            remember("exam_date", it.groupValues[2])
        }
    }

    /**
     * Explicit memory commands ("yaad rakhna ki...", "bhool ja ki...") the
     * user can say directly. Returns a confirmation reply if this message
     * was a memory command, or null if it wasn't (so the caller falls
     * through to a normal AI response instead).
     */
    suspend fun maybeHandleExplicitMemoryCommand(message: String): String? {
        val trimmed = message.trim()
        val lower = trimmed.lowercase()

        if (lower.startsWith("yaad rakhna") || lower.startsWith("yaad rakho")) {
            val fact = trimmed.substringAfter("ki", "").ifBlank { trimmed }.trim()
            if (fact.isBlank()) return null
            val key = "note_${System.currentTimeMillis()}"
            remember(key, fact)
            return "Theek hai jaani, yaad rakh liya: \"$fact\""
        }

        if (lower.startsWith("sab bhool ja") || lower.startsWith("sab kuch bhool")) {
            forgetEverything()
            return "Theek hai, maine sab kuch bhula diya jo tumhare baare mein yaad tha. Fresh start!"
        }

        return null
    }

    // ---- Feedback ----

    suspend fun recordFeedback(question: String, answer: String, liked: Boolean, reason: String = "") {
        try {
            feedbackDao.insert(AnswerFeedback(question = question, answer = answer, liked = liked, reason = reason))
        } catch (e: Exception) { }
    }

    /** Recent dislike reasons, formatted for a Gemini prompt. Empty string if none recorded. */
    suspend fun feedbackContextBlock(): String {
        val dislikes = try { feedbackDao.getRecentDislikes() } catch (e: Exception) { emptyList() }
        val withReasons = dislikes.filter { it.reason.isNotBlank() }
        if (withReasons.isEmpty()) return ""

        val lines = withReasons.joinToString("\n") { "- \"${it.reason}\"" }
        return """
            --- USER NE PEHLE IN CHEEZON PE 👎 DIYA THA (inhe avoid karo) ---
            $lines
            --- END FEEDBACK ---
        """.trimIndent()
    }

    // ---- Topic struggle tracking ----

    /**
     * Extremely simple keyword extraction — takes the longest capitalized-
     * or-technical-looking word/phrase isn't reliable enough offline, so
     * instead this just normalizes the whole question to a short key. It's
     * intentionally crude: exact repeat questions or near-repeats will
     * match and accumulate count, which is enough for a "you keep asking
     * about this" nudge without needing a real NLP topic model on-device.
     */
    private fun normalizeTopic(question: String): String {
        return question.lowercase()
            .replace(Regex("[^a-z0-9\\u0900-\\u097F ]"), "")
            .trim()
            .split(" ")
            .filter { it.length > 3 } // drop short filler words
            .take(4)
            .joinToString(" ")
    }

    /**
     * Records that this topic came up again, and returns a nudge message
     * IF this crossed a repeat threshold and hasn't already been nudged
     * for this count — otherwise returns null (normal reply, no nudge).
     */
    suspend fun trackAndMaybeNudge(question: String): String? {
        val topic = normalizeTopic(question)
        if (topic.isBlank()) return null

        return try {
            val existing = topicDao.get(topic)
            val newCount = (existing?.count ?: 0) + 1
            topicDao.upsert(
                TopicStruggle(
                    topic = topic,
                    count = newCount,
                    lastNudgedAtCount = existing?.lastNudgedAtCount ?: 0
                )
            )

            val shouldNudge = newCount >= 3 && newCount > (existing?.lastNudgedAtCount ?: 0)
            if (shouldNudge) {
                topicDao.upsert(
                    TopicStruggle(topic = topic, count = newCount, lastNudgedAtCount = newCount)
                )
                "jaani, ye tumne $newCount baar pucha hai ab \"$topic\" jaise topic ke baare mein — " +
                    "lagta hai isme thoda confusion hai. Chaho to isko step-by-step properly revise " +
                    "karwa doon, taaki baar baar atakna na pade?"
            } else {
                null
            }
        } catch (e: Exception) {
            null
        }
    }
}
