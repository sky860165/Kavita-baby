// data/CaseNoteDao.kt
package com.kavitababy.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query

@Dao
interface CaseNoteDao {

    @Insert
    suspend fun insert(note: CaseNote): Long

    @Query("SELECT * FROM case_notes ORDER BY createdAt DESC")
    suspend fun getAll(): List<CaseNote>

    @Query("SELECT * FROM case_notes WHERE patientId = :patientId ORDER BY createdAt ASC")
    suspend fun getForPatient(patientId: Long): List<CaseNote>

    @Query("DELETE FROM case_notes WHERE patientId = :patientId")
    suspend fun deleteForPatient(patientId: Long)

    @Delete
    suspend fun delete(note: CaseNote)
}
