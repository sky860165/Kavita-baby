// data/ExportService.kt
package com.kavitababy.data

import android.content.Context
import androidx.core.content.FileProvider
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Builds plain-text exports of chat conversations and patient case
 * histories, writes them to the app's private cache dir, and hands back a
 * shareable content:// Uri (via FileProvider) so the doctor can send the
 * file through WhatsApp/Email/Drive/whatever they normally use.
 *
 * Plain .txt rather than a generated PDF deliberately — it opens
 * everywhere with zero extra dependency, a doctor can paste it straight
 * into an EMR/notes app, and it avoids pulling in a PDF-generation library
 * just for this one feature. Nothing here ever leaves the device on its
 * own; the doctor explicitly chooses where to send the file via the share
 * sheet.
 */
class ExportService(private val context: Context) {

    private val dateFormat = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.ENGLISH)

    /**
     * Exports a Study/Doctor Mode chat transcript (the in-memory message
     * list currently on screen) as a readable Q&A-style text file.
     * [patientName] is only used for the filename/header when exporting a
     * Doctor Mode session tied to an open patient — pass null for a
     * general Study Mode chat with no patient context.
     */
    suspend fun exportChatTranscript(
        messages: List<ChatMessageForExport>,
        modeLabel: String,
        patientName: String? = null
    ): Uri? = withContext(Dispatchers.IO) {
        if (messages.isEmpty()) return@withContext null

        val header = buildString {
            appendLine("Kavita Baby AI — $modeLabel Transcript")
            if (patientName != null) appendLine("Patient: $patientName")
            appendLine("Exported: ${dateFormat.format(Date())}")
            appendLine("=".repeat(50))
            appendLine()
        }

        val body = buildString {
            for (msg in messages) {
                val speaker = if (msg.isUser) "You" else "Kavita"
                appendLine("[$speaker]")
                appendLine(msg.text)
                appendLine()
            }
        }

        // Disclaimer mirrors AIRepository's Doctor Mode disclaimer —
        // exported text can end up printed/pasted somewhere the on-screen
        // chat's own disclaimer text won't travel with it, so it's
        // re-stated here explicitly.
        val footer = if (modeLabel.contains("Doctor", ignoreCase = true)) {
            "\n" + "-".repeat(50) +
                "\n⚠️ AI-generated reference — final diagnosis/treatment decisions " +
                "must be based on the doctor's own clinical judgement, examination, " +
                "and test results.\n"
        } else ""

        writeAndShare(header + body + footer, filePrefix = "chat_transcript")
    }

    /**
     * Exports a patient's full case history (every [CaseNote] linked to
     * them, oldest first) as one combined text file — the doctor-facing
     * equivalent of printing a patient's file.
     */
    suspend fun exportPatientHistory(
        patient: PatientCase,
        patientName: String,
        notes: List<CaseNote>
    ): Uri? = withContext(Dispatchers.IO) {
        val header = buildString {
            appendLine("Kavita Baby AI — Patient Case History")
            appendLine("Patient: $patientName")
            appendLine("Age/Gender: ${patient.age} / ${patient.gender}")
            if (patient.currentDiagnosis.isNotBlank()) appendLine("Current diagnosis: ${patient.currentDiagnosis}")
            if (patient.currentMedicines.isNotBlank()) appendLine("Current medicines: ${patient.currentMedicines}")
            if (patient.knownAllergies.isNotBlank()) appendLine("Known allergies: ${patient.knownAllergies}")
            appendLine("Exported: ${dateFormat.format(Date())}")
            appendLine("=".repeat(50))
            appendLine()
        }

        val body = if (notes.isEmpty()) {
            "No case notes recorded yet.\n"
        } else {
            buildString {
                for (note in notes) {
                    appendLine("Date: ${dateFormat.format(Date(note.createdAt))}")
                    appendLine("Case: ${note.caseLabel}")
                    if (note.symptoms.isNotBlank()) appendLine("Symptoms/Notes: ${note.symptoms}")
                    if (note.history.isNotBlank()) appendLine("History: ${note.history}")
                    appendLine("Kavita's reference:")
                    appendLine(note.aiSuggestion)
                    appendLine("-".repeat(50))
                    appendLine()
                }
            }
        }

        val footer = "\n⚠️ AI-generated reference — final diagnosis/treatment decisions " +
            "must be based on the doctor's own clinical judgement, examination, " +
            "and test results.\n"

        writeAndShare(header + body + footer, filePrefix = "patient_${patientName.filter { it.isLetterOrDigit() }}")
    }

    private fun writeAndShare(content: String, filePrefix: String): Uri? {
        return try {
            val exportsDir = File(context.cacheDir, "exports").apply { mkdirs() }
            val timestamp = System.currentTimeMillis()
            val file = File(exportsDir, "${filePrefix}_$timestamp.txt")
            file.writeText(content)

            FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
        } catch (e: Exception) {
            null
        }
    }

    /** Deletes every previously exported file — call occasionally (e.g. app start) so cache doesn't grow unbounded. */
    fun clearOldExports() {
        try {
            File(context.cacheDir, "exports").listFiles()?.forEach { it.delete() }
        } catch (e: Exception) {
            // Best-effort cleanup only — a leftover cached export file is harmless.
        }
    }

    /** Minimal message shape ExportService needs — decoupled from ChatScreen's Message so this file has no UI-layer dependency. */
    data class ChatMessageForExport(val text: String, val isUser: Boolean)
}
