// data/CarProject.kt
package com.kavitababy.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * A single "sketch to ready-to-run" build project started from Engineer
 * Mode's EV Car Project flow. [scale] is either "HOBBY" (small RC/college
 * project scale) or "FULL_SIZE" (rideable go-kart/EV scale) — picked once
 * up front so every generated BOM/step suggestion (motor size, battery
 * pack, budget) matches what's actually being built.
 *
 * [sketchAnalysis] and [bom] are the AI's one-time output from the
 * uploaded sketch (kept as plain text, not re-parsed after save) so the
 * project screen can always show exactly what was originally generated.
 * The actual build checklist lives separately in [CarProjectStep] rows —
 * one project has many steps.
 */
@Entity(tableName = "car_projects")
data class CarProject(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val scale: String,
    val sketchAnalysis: String = "",
    val bom: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val lastUpdatedAt: Long = System.currentTimeMillis()
)
