// data/MedicalSynonyms.kt
package com.kavitababy.data

/**
 * Maps common Hinglish/colloquial terms a doctor might actually type or say
 * to the medical/English vocabulary that indexed textbooks/notes actually
 * use — so a search for "sar dard" also matches a PDF chunk that only
 * contains the word "headache".
 *
 * This is intentionally a plain, hand-maintained map rather than an
 * embeddings model: it needs zero extra storage/RAM/model download, runs in
 * microseconds, and is easy for a doctor (or future edit) to extend by just
 * adding a line — no retraining, no ML pipeline. It won't catch every
 * possible phrasing, but it directly targets the most common gap this app's
 * doctors will actually hit: colloquial/Hindi symptom words vs. the English
 * medical terms their textbooks use.
 *
 * Keys and values are both already lowercased/normalized the same way
 * [RagSearchEngine.extractKeywords] normalizes its input, so lookups are a
 * direct map hit with no extra normalization needed at call time.
 *
 * Deliberately many-to-one and one-to-many: several colloquial terms can
 * point at the same medical term (e.g. "bukhar"/"fever"/"garmi" all reach
 * "fever"), and looking a term up expands to ALL its known synonyms/related
 * terms, not just a single canonical form — this keeps the expansion
 * symmetric (searching "fever" also pulls in "bukhar", not just the reverse).
 */
object MedicalSynonyms {

    // Each inner list is a "synonym group" — every term in the group is
    // considered equivalent to every other term in the same group. A term
    // can appear in more than one group where medically appropriate (e.g.
    // "pet dard" relates to both general "pain" and specific "abdominal").
    private val synonymGroups: List<List<String>> = listOf(
        // --- General symptoms ---
        listOf("bukhar", "fever", "garmi", "temperature", "pyrexia"),
        listOf("sar dard", "sardard", "headache", "sir dard", "cephalgia"),
        listOf("pet dard", "petdard", "stomach ache", "abdominal pain", "abdomen pain", "pait dard"),
        listOf("khansi", "cough", "khaansi"),
        listOf("jukam", "zukam", "cold", "common cold", "coryza", "sardi"),
        listOf("saans", "breath", "breathing", "dyspnea", "saans phoolna", "shortness of breath"),
        listOf("ulti", "vomiting", "vomit", "emesis", "qay"),
        listOf("dast", "diarrhea", "diarrhoea", "loose motion", "loose motions"),
        listOf("kabj", "constipation", "kabz"),
        listOf("chakkar", "dizziness", "vertigo", "giddiness"),
        listOf("kamzori", "weakness", "fatigue", "thakan", "tiredness"),
        listOf("sujan", "swelling", "edema", "oedema", "inflammation"),
        listOf("khujli", "itching", "pruritus", "khaarish"),
        listOf("jalan", "burning sensation", "burning"),
        listOf("dard", "pain", "ache"),
        listOf("kapkapi", "chills", "rigor", "thand lagna", "shivering"),
        listOf("neend na aana", "insomnia", "sleeplessness", "neend ki kami"),
        listOf("bhookh na lagna", "loss of appetite", "anorexia", "bhookh kam"),

        // --- Cardiovascular ---
        listOf("bp", "blood pressure", "raktchaap"),
        listOf("high bp", "hypertension", "high blood pressure", "uchch rakt chaap"),
        listOf("low bp", "hypotension", "low blood pressure"),
        listOf("dil ki dhadkan", "heartbeat", "palpitations", "dhadkan"),
        listOf("chest pain", "seene mein dard", "sine me dard", "angina"),
        listOf("dil ka daura", "heart attack", "myocardial infarction", "mi"),

        // --- Endocrine / metabolic ---
        listOf("sugar", "diabetes", "madhumeh", "blood sugar", "glucose"),
        listOf("thyroid", "thairoid"),

        // --- Respiratory ---
        listOf("dama", "asthma", "asthama"),
        listOf("tb", "tuberculosis", "tapedik", "kshay rog"),
        listOf("nimonia", "pneumonia"),

        // --- Renal / urinary ---
        listOf("paishab", "urine", "peshab", "mootra"),
        listOf("gurde", "kidney", "kidneys", "vrikka", "renal"),
        listOf("patthri", "stone", "kidney stone", "renal calculus", "pathri"),

        // --- GI / liver ---
        listOf("jigar", "liver", "yakrit"),
        listOf("pilia", "jaundice", "yellow eyes", "peeliya"),
        listOf("badhazmi", "indigestion", "dyspepsia", "acidity", "gas"),

        // --- Musculoskeletal ---
        listOf("haddi", "bone", "haddiyan", "asthi"),
        listOf("jodo mein dard", "joint pain", "arthralgia", "jodon ka dard"),
        listOf("gathiya", "arthritis"),

        // --- Neuro ---
        listOf("mirgi", "epilepsy", "seizure", "fits", "daura"),
        listOf("lakwa", "paralysis", "stroke", "falij"),

        // --- Skin ---
        listOf("daad", "ringworm", "fungal infection", "khaj"),
        listOf("chakatte", "rash", "skin rash", "daane"),

        // --- Obstetrics/gynae ---
        listOf("garbhavastha", "pregnancy", "pregnant", "hamal"),
        listOf("mahavari", "periods", "menstruation", "masik dharm"),

        // --- Common drug classes (helps when doctor types generic Hindi term) ---
        listOf("dard ki dawai", "painkiller", "analgesic"),
        listOf("bukhar ki dawai", "antipyretic", "fever medicine"),
        listOf("antibiotic", "antibayotic", "jeevanurodhi"),

        // --- Diagnosis/reference words ---
        listOf("ilaj", "treatment", "therapy", "upchar"),
        listOf("dawai", "dawa", "medicine", "medication", "drug"),
        listOf("khuraak", "dose", "dosage"),
        listOf("jaanch", "test", "investigation", "lab test"),
        listOf("lakshan", "symptom", "symptoms", "sign")
    )

    // Built once at class-load time: every term in a group maps to the set
    // of ALL OTHER terms in that same group, so a lookup is a single map
    // hit rather than a scan over synonymGroups on every search.
    private val termToSynonyms: Map<String, Set<String>> = buildMap {
        for (group in synonymGroups) {
            val groupSet = group.toSet()
            for (term in group) {
                // Merge with any synonyms already collected for this term
                // from an earlier group it also appeared in.
                val existing = get(term) ?: emptySet()
                put(term, existing + groupSet - term)
            }
        }
    }

    // Multi-word phrase keys only (e.g. "sar dard", "jodo mein dard") —
    // split out separately because these can never be produced by
    // RagSearchEngine's single-word tokenizer, so they need to be matched
    // as substrings against the raw question text instead of against
    // individual extracted keywords.
    val phraseKeys: List<String> = termToSynonyms.keys.filter { it.contains(' ') }

    /**
     * Returns [term] plus every known synonym for it (empty set if none
     * known). Multi-word terms (e.g. "sar dard") are matched as a whole
     * first; if [term] is a single word that's also a substring of a
     * multi-word key (or vice versa), that's intentionally NOT matched here
     * — only exact term matches expand, to avoid noisy over-expansion (e.g.
     * "dard" alone matching into every phrase that happens to contain it).
     */
    fun expand(term: String): Set<String> {
        val synonyms = termToSynonyms[term] ?: emptySet()
        return synonyms + term
    }
}
