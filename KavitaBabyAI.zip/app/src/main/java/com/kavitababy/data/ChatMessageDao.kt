// data/ChatMessageDao.kt
package com.kavitababy.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction

@Dao
interface ChatMessageDao {

    @Query("SELECT * FROM chat_messages WHERE mode = :mode ORDER BY sortOrder ASC")
    suspend fun getAllForMode(mode: String): List<ChatMessageEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(messages: List<ChatMessageEntity>)

    @Query("DELETE FROM chat_messages WHERE mode = :mode")
    suspend fun deleteAllForMode(mode: String)

    // Replaces this mode's whole saved history with [messages] in one
    // transaction — simplest way to keep the saved copy exactly in sync
    // with whatever's on screen, without having to diff old vs new lists
    // at every call site that appends a message.
    @Transaction
    suspend fun replaceForMode(mode: String, messages: List<ChatMessageEntity>) {
        deleteAllForMode(mode)
        if (messages.isNotEmpty()) insertAll(messages)
    }
}
