// data/BackupService.kt
package com.kavitababy.data

import android.content.Context
import android.net.Uri
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Backs up and restores the entire on-device Room database — PDF index,
 * patient cases, lab trends, reminders, chat history, everything — as a
 * single shareable .zip file.
 *
 * This is the "don't lose everything if the phone is lost/reset/app is
 * uninstalled" safety net. Nothing is uploaded automatically; the doctor
 * explicitly picks the destination (WhatsApp, Drive, email, a USB copy —
 * whatever) through the normal Android share sheet, same as every other
 * export in this app.
 */
class BackupService(private val context: Context) {

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd_HHmm", Locale.ENGLISH)

    // Must match the name Room was opened with in KavitaDatabase.getInstance.
    private val dbName = "kavita_baby_db"

    /**
     * Checkpoints Room's WAL file into the main .db file (so nothing
     * recently written is left behind in kavita_baby_db-wal, which a
     * simple file copy would otherwise miss) and zips just that one file.
     * Returns a shareable content:// Uri, or null on failure.
     */
    suspend fun exportBackup(): Uri? = withContext(Dispatchers.IO) {
        try {
            val db = KavitaDatabase.getInstance(context.applicationContext)
            // Forces every WAL-buffered write into the main DB file so the
            // zip is a complete, consistent snapshot instead of missing
            // whatever hasn't been checkpointed yet.
            db.openHelper.writableDatabase.query("PRAGMA wal_checkpoint(FULL)").use { it.moveToFirst() }

            val dbFile = context.getDatabasePath(dbName)
            if (!dbFile.exists()) return@withContext null

            val backupDir = File(context.cacheDir, "exports").apply { mkdirs() }
            val zipFile = File(backupDir, "kavita_backup_${dateFormat.format(Date())}.zip")

            ZipOutputStream(FileOutputStream(zipFile)).use { zos ->
                zos.putNextEntry(ZipEntry(dbName))
                FileInputStream(dbFile).use { it.copyTo(zos) }
                zos.closeEntry()

                // Bundled in for free — if the doctor/student is exporting
                // a backup anyway (e.g. right after a crash), the crash
                // log(s) travel with it instead of needing a separate step.
                for (logFile in CrashHandler.allCrashLogFiles(context)) {
                    zos.putNextEntry(ZipEntry("crash_logs/${logFile.name}"))
                    FileInputStream(logFile).use { it.copyTo(zos) }
                    zos.closeEntry()
                }
            }

            FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", zipFile)
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Restores a previously exported backup zip, replacing the current
     * on-device database entirely. Returns true on success.
     *
     * IMPORTANT: the app should be closed and reopened right after a
     * successful restore — Room's currently-cached DAOs/queries and any
     * in-memory Compose state still reflect the pre-restore data, and a
     * simple file swap underneath a running process won't refresh those.
     * The caller is expected to tell the user to restart the app rather
     * than this function attempting a risky in-process restart itself.
     */
    suspend fun wipeAllLocalData(): Boolean = withContext(Dispatchers.IO) {
        try {
            KavitaDatabase.closeAndClearInstance()

            val dbFile = context.getDatabasePath(dbName)
            dbFile.delete()
            File(dbFile.path + "-wal").delete()
            File(dbFile.path + "-shm").delete()
            File(dbFile.path + "-journal").delete()

            File(context.cacheDir, "exports").deleteRecursively()

            KavitaDatabase.getInstance(context.applicationContext)
            true
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Restores from either:
     *  1. A proper backup zip (made by [exportBackup]) — the normal case.
     *  2. A raw, unzipped SQLite db file — kept as a fallback because
     *     WhatsApp/OEM file managers frequently mangle or drop the
     *     ".zip" extension on downloaded documents (the picker now opens
     *     with a wildcard "any file type" filter instead of an "application/zip" filter for exactly
     *     this reason — that filter was silently hiding files whose
     *     reported mime type didn't match, which is what "restore button
     *     mein file select nahi hoti" turned out to be), and a doctor
     *     restoring an old share shouldn't hit a dead end just because
     *     the extension got lost along the way.
     *
     * Detects which case it is by peeking the first two bytes — a zip
     * file always starts with "PK" (0x50 0x4B); anything else is treated
     * as a raw db file and copied straight over.
     */
    suspend fun importBackup(uri: Uri): Boolean = withContext(Dispatchers.IO) {
        try {
            val dbFile = context.getDatabasePath(dbName)
            dbFile.parentFile?.mkdirs()

            val header = ByteArray(2)
            val isZip = context.contentResolver.openInputStream(uri)?.use { peek ->
                val read = peek.read(header)
                read == 2 && header[0] == 0x50.toByte() && header[1] == 0x4B.toByte()
            } ?: return@withContext false

            var restored = false
            if (isZip) {
                context.contentResolver.openInputStream(uri)?.use { input ->
                    ZipInputStream(input).use { zis ->
                        var entry = zis.nextEntry
                        while (entry != null) {
                            if (entry.name == dbName) {
                                // Close the live Room connection right before
                                // overwriting its file, not before opening the
                                // zip — keeps the window where the DB is
                                // unusable as short as possible.
                                KavitaDatabase.closeAndClearInstance()
                                FileOutputStream(dbFile).use { out -> zis.copyTo(out) }
                                restored = true
                            }
                            entry = zis.nextEntry
                        }
                    }
                } ?: return@withContext false
            } else {
                // Raw db file — copy it directly over the live one.
                context.contentResolver.openInputStream(uri)?.use { input ->
                    KavitaDatabase.closeAndClearInstance()
                    FileOutputStream(dbFile).use { out -> input.copyTo(out) }
                    restored = true
                } ?: return@withContext false
            }

            if (restored) {
                // Stale WAL/SHM files from the database we just replaced
                // would otherwise conflict with the restored one.
                File(dbFile.path + "-wal").delete()
                File(dbFile.path + "-shm").delete()
            }
            restored
        } catch (e: Exception) {
            false
        }
    }
}
