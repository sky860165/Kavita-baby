// data/DoctorTreatmentPattern.kt
package com.kavitababy.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * One real instance of what THIS doctor actually decided to do for a given
 * diagnosis — captured the moment they manually save/confirm a patient's
 * file (Doctor Mode's "Edit File" dialog), NOT whatever the AI happened to
 * suggest during a case workup. That distinction matters: the AI's own
 * differential/treatment reference is already visible elsewhere in the
 * prompt, so re-feeding it back as "the doctor's pattern" would just be the
 * model echoing itself. This table only grows from an explicit, deliberate
 * save action, which is the closest on-device signal we have to "this is
 * genuinely how this doctor practices."
 *
 * Nothing here is ever sent anywhere except back into this SAME doctor's own
 * future Gemini prompts (as plain reference context, same as a PDF chunk) —
 * still fully on-device storage, no training, no network upload of this
 * data on its own.
 *
 * [diagnosis] and [treatmentGiven] are stored as free text exactly as saved
 * in the patient file — no patient name/identity here at all (this table
 * has no [patientId] link on purpose, so it stays a pure "diagnosis ->
 * this doctor's typical treatment" record, reusable across every patient
 * with a similar diagnosis, not tied to any one person's file).
 *
 * [searchableText] mirrors the lowercase/whitespace-normalized pattern
 * already used by [PdfChunk]/[LearnedKnowledge] so [DoctorLearningEngine]
 * can reuse the same simple keyword-LIKE search instead of a new matching
 * strategy.
 */
@Entity(tableName = "doctor_treatment_patterns")
data class DoctorTreatmentPattern(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val diagnosis: String,
    val treatmentGiven: String,
    val searchableText: String,
    val createdAt: Long = System.currentTimeMillis()
)
