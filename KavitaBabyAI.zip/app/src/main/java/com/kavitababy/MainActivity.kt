// MainActivity.kt
package com.kavitababy

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.kavitababy.data.PdfScannerService
import com.kavitababy.ui.ChatScreen
import com.kavitababy.ui.theme.KavitaBabyTheme
import com.kavitababy.voice.VoiceManager
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var voiceManager: VoiceManager
    private lateinit var pdfScanner: PdfScannerService

    private val micPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (!granted) {
            // Mic won't work without this; the chat screen will still show
            // but voice input will silently fail until the user grants it
            // from Settings. Nothing to crash on here — just no-op.
        }
    }

    // Only needed for the automatic full-device PDF scan (finding every PDF
    // via MediaStore) on Android 12L and below. On Android 13+, MediaStore's
    // non-media file query for PDFs doesn't require a runtime permission at
    // all, and the manual upload button (Storage Access Framework picker in
    // ChatScreen) never needs this permission on any version — the system
    // grants access to whatever single file the user picks automatically.
    private val storagePermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            runInitialPdfScan()
        }
        // If denied, the automatic full-device scan just won't find
        // anything — the 📎 upload button still works either way, so
        // nothing else needs to change here.
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        voiceManager = VoiceManager(this)
        pdfScanner = PdfScannerService(this)

        requestMicPermissionIfNeeded()
        requestStoragePermissionIfNeeded()

        setContent {
            KavitaBabyTheme {
                ChatScreen(voiceManager)
            }
        }
    }

    private fun requestMicPermissionIfNeeded() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun requestStoragePermissionIfNeeded() {
        // Android 13+ (API 33+) doesn't need READ_EXTERNAL_STORAGE for this
        // app's MediaStore PDF query, so skip straight to scanning there.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            runInitialPdfScan()
            return
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
            == PackageManager.PERMISSION_GRANTED
        ) {
            runInitialPdfScan()
        } else {
            storagePermissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }

    private fun runInitialPdfScan() {
        lifecycleScope.launch {
            // Safe to call every launch — PdfScannerService skips PDFs
            // that are already indexed, so this is cheap after the first run.
            pdfScanner.scanAllPdfs()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        voiceManager.destroy()
    }
}
