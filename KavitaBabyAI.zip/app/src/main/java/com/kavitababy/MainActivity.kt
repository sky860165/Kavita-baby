// MainActivity.kt
package com.kavitababy

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.kavitababy.data.PdfScannerService
import com.kavitababy.ui.ChatScreen
import com.kavitababy.ui.theme.KavitaBabyTheme
import com.kavitababy.voice.VoiceManager
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var voiceManager: VoiceManager
    private lateinit var pdfScanner: PdfScannerService

    private val micPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (!granted) {
            // Mic won't work without this; the chat screen will still show
            // but voice input will silently fail until the user grants it
            // from Settings. Nothing to crash on here — just no-op.
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        voiceManager = VoiceManager(this)
        pdfScanner = PdfScannerService(this)

        requestMicPermissionIfNeeded()
        runInitialPdfScan()

        setContent {
            KavitaBabyTheme {
                ChatScreen(voiceManager)
            }
        }
    }

    private fun requestMicPermissionIfNeeded() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun runInitialPdfScan() {
        lifecycleScope.launch {
            // Safe to call every launch — PdfScannerService skips PDFs
            // that are already indexed, so this is cheap after the first run.
            pdfScanner.scanAllPdfs()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        voiceManager.destroy()
    }
}
