// MainActivity.kt
package com.kavitababy

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.mutableIntStateOf
import androidx.core.content.ContextCompat
import com.kavitababy.ui.ChatScreen
import com.kavitababy.ui.theme.KavitaBabyTheme
import com.kavitababy.voice.VoiceManager

class MainActivity : ComponentActivity() {

    private lateinit var voiceManager: VoiceManager

    // Bumped every time storage access becomes available (either already
    // granted on launch, or granted just now after returning from the All
    // Files Access settings screen). ChatScreen watches this as a
    // LaunchedEffect key, so a rescan actually fires when permission is
    // granted later rather than only on the very first (permission-less)
    // launch.
    private val pdfScanTrigger = mutableIntStateOf(0)

    private val micPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (!granted) {
            // Mic won't work without this; the chat screen will still show
            // but voice input will silently fail until the user grants it
            // from Settings. Nothing to crash on here — just no-op.
        }
    }

    // Pre-Android-11 fallback path (regular runtime permission dialog).
    private val legacyStoragePermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) pdfScanTrigger.intValue++
    }

    // "All Files Access" (MANAGE_EXTERNAL_STORAGE) can't be granted through
    // a normal permission dialog — Android requires sending the user to a
    // dedicated system Settings screen where they flip a toggle themselves.
    // This launcher just waits for them to come back from that screen, then
    // triggers a rescan if they granted it. MediaStore's plain PDF query was
    // unreliable on some OEM builds (MIUI etc) for PDFs sitting in
    // nested/custom folders it never indexed — All Files Access reads
    // straight off the filesystem instead, so it isn't affected by that.
    private val allFilesAccessSettingsLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (Environment.isExternalStorageManager()) {
            pdfScanTrigger.intValue++
        }
        // If they backed out without granting it, nothing changes — the
        // 📎 upload button in ChatScreen still works regardless.
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        voiceManager = VoiceManager(this)

        requestMicPermissionIfNeeded()
        requestStoragePermissionIfNeeded()

        setContent {
            KavitaBabyTheme {
                ChatScreen(voiceManager, pdfScanTrigger.intValue)
            }
        }
    }

    private fun requestMicPermissionIfNeeded() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun requestStoragePermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            // Android 11+ : need explicit All Files Access, since the
            // regular MediaStore PDF query has proven unreliable on some
            // devices for PDFs outside the standard indexed folders.
            if (Environment.isExternalStorageManager()) {
                pdfScanTrigger.intValue++
            } else {
                val intent = Intent(
                    Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                allFilesAccessSettingsLauncher.launch(intent)
            }
        } else {
            // Android 10 and below: the classic runtime permission dialog.
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED
            ) {
                pdfScanTrigger.intValue++
            } else {
                legacyStoragePermissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        voiceManager.destroy()
    }
}
